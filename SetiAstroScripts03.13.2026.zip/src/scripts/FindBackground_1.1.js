/*!
 * FindBackground
 * File: FindBackground_1.1.js
 * Description: A script to find regions covering true background in astronomical images. This file handles the UI and interaction with the core functionality.
 *
 * Copyright (c) 2024, Gerrit Erdt
 * Copyright (c) 2024, Franklin Marek
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * In case you are interested in collaborating or have questions regarding the code, its use in other products or anything else, feel free to contact us at:
 *  - Gerrit Erdt: gerrit_erdt@hotmail.com
 *  - Franklin Marek: frank@setiastro.com
 */

#ifndef FIND_BACKGROUND_JS
#define FIND_BACKGROUND_JS

#include <pjsr/StarDetector.jsh>
#define __PJSR_USE_STAR_DETECTOR_V2

function FindBackground(windowSize, spacingPortion) {
    this.window = null;
    this.image = null;
    this.windowSize = windowSize;
    this.spacing = Math.round(windowSize / spacingPortion);
    this.brightnessArray = new Array(this.windowSize * this.windowSize);
    this.verbosity = 1;
    this.generatePreview = true;

    // Add property for exclusion areas
    this.exclusionAreas = [];

    this.filterAverage = true;
    this.filterStandardDeviation = true;
    this.filterMedianAverageAbsoluteDifference = true;
    this.filterPoissonIndex = false;
    this.filterForObjects = true;

    let filterAverageValue = 1.0;
    let filterStandardDeviationValue = 1.0;
    let filterMedianAverageAbsoluteDifferenceValue = 1.0;
    let filterPoissonIndexValue = 1.0;
    let filterForObjectsValue = 1.0;

    let filterStandardDeviationCap = 0.3333333;
    let filterMedianAverageAbsoluteDifferenceCap = 0.1;
    let filterPoissonIndexCap = 0.2;

    let filterStandardDeviationNormalization = 1.0;
    let filterMedianAverageAbsoluteDifferenceNormalization = 1.0;
    let filterPoissonIndexNormalization = 1.0;

    let filterForObjectsThreshold = 0.0;

    this.setTarget = function(window) {
        if (window.isNull)
            throw new Error("The selected image is invalid. Please select a valid image.");
        this.window = window;
        this.image = window.mainView.image;
    }

    this.setWindowSize = function(windowSize) {
        this.windowSize = windowSize;
        this.spacing = -1;
    }

    this.setSpacingPortion = function(spacingPortion) {
        this.spacing = Number((this.windowSize / spacingPortion).toFixed(0));
    }

    this.searchBackground = function(printInformationToConsole, previewName) {
        if (this.spacing == -1)
            throw new Error("Spacing is not set. Please set the spacing before starting the search.");

        //this.window.mainView.beginProcess();

        let objectFilteringWasOn = this.filterForObjects;
        this.filterForObjects = false;

        if (this.filterForObjects)
            setupObjectFilter();

        log("Setting up normalization constants...");
        setupFilterNormalization();

        this.filterForObjects = objectFilteringWasOn;

        let lowestX = 0;
        let lowestY = 0;
        let lowestScore = Infinity;

        let optimizationCount = 0;
        if (this.filterAverage)
            optimizationCount++;
        if (this.filterStandardDeviation)
            optimizationCount++;
        if (this.filterMedianAverageAbsoluteDifference)
            optimizationCount++;

    let outerIterations = Math.ceil((this.image.width - 2 * this.windowSize) / this.spacing);
    let innerIterations = Math.ceil((this.image.height - 2 * this.windowSize) / this.spacing);
    let totalIterations = 0;
    for (let x = windowSize; x < this.image.width - this.windowSize; x += this.spacing) {
        for (let y = windowSize; y < this.image.height - this.windowSize; y += this.spacing) {
            let point = { x: x, y: y };
            if (!this.isPointInAnyExclusionArea(point, this.exclusionAreas)) {
                totalIterations++;
            }
        }
    }
    let divisor = Math.floor(totalIterations / 100);
    let currentIteration = 0;

        console.abortEnabled = true;

        if (this.verbosity == 1) {
            console.show();
            console.writeln("Processing started...");
            console.writeln("Exclusion areas: " + JSON.stringify(this.exclusionAreas));
            console.writeln("|....................................................................................................|");
            console.write("|");
        }

        for (let x = windowSize; x < this.image.width - this.windowSize; x += this.spacing) {
            for (var y = windowSize; y < this.image.height - this.windowSize; y += this.spacing) {
                let point = { x: x, y: y };
                 if (this.isPointInAnyExclusionArea(point, this.exclusionAreas)) {
                     continue; // Skip points inside the exclusion areas
                 }

                calculateFilterValues(x, y);
                let score = getScore();

                if (score < lowestScore) {
                    lowestScore = score;
                    lowestX = x;
                    lowestY = y;
                }

                currentIteration++;
                if (currentIteration % divisor == 0)
                    console.write(".");
            }
            processEvents();
            if (console.abortRequested) {
                console.writeln("|");
                console.writeln("Processing aborted by user.");
                return;
            }
        }

        log("|");

        log("Refining solution using gradient descent...");

        let refinedSolution = gradientDescent(lowestX, lowestY);
        lowestX = refinedSolution[0];
        lowestY = refinedSolution[1];

        log("Gradient descent finished, found final solution.");

        if (this.generatePreview)
            this.window.createPreview(lowestX, lowestY, lowestX + this.windowSize, lowestY + this.windowSize, previewName || "Background");

        if (printInformationToConsole)
            printInformation(lowestX, lowestY);

        //this.window.mainView.endProcess();
    }

    this.fastSearchBackground = function(initialSize, targetCount, printInformationToConsole, previewName) {
        if (this.spacing == -1)
            throw new Error("Spacing is not set. Please set the spacing before starting the fast search.");

        //this.window.mainView.beginProcess();
        console.show();
        console.abortEnabled = true;
        log("Fast search started...");

        let objectFilteringWasOn = this.filterForObjects;
        this.filterForObjects = false;

        log("Setting up normalization constants...");
        setupFilterNormalization();

        let oldSpacing = this.spacing;
        this.spacing = initialSize;

        let countWidth = Math.ceil((this.image.width - 2 * this.windowSize) / this.spacing);
        let countHeight = Math.ceil((this.image.height - 2 * this.windowSize) / this.spacing);
        let totalIterations = countWidth * countHeight;
        let averages = new Array(totalIterations);

console.writeln("Looking for starting points...");
console.writeln("Exclusion areas: " + JSON.stringify(this.exclusionAreas));


for (var x = this.spacing; x < this.image.width - this.spacing; x += this.spacing) {
    for (var y = this.spacing; y < this.image.height - this.spacing; y += this.spacing) {
        let point = { x: x, y: y };

        if (this.isPointInAnyExclusionArea(point, this.exclusionAreas)) {
            continue; // Skip points inside the exclusion areas
        }

        calculateFilterValues(x, y);
        let score = getScore();
        averages[(x - this.spacing) / this.spacing * countHeight + (y - this.spacing) / this.spacing] = [x, y, score];
    }
    processEvents();
    if (console.abortRequested) {
        throw new Error("Processing aborted by user.");
    }
}

console.writeln("Finished looking for starting points.");



        this.spacing = oldSpacing;

        averages = averages.sort((a, b) => a[2] - b[2]);
        averages = averages.slice(0, targetCount);

        log("Selected the " + targetCount + " best starting points.");
        this.filterForObjects = objectFilteringWasOn;

        let results = new Array(targetCount);

        for (var i = 0; i < averages.length; i++) {
            log("Optimizing window " + (i + 1) + " of " + targetCount + "...");
            let result = gradientDescent(averages[i][0], averages[i][1]);
            results[i] = result;
            processEvents();
            if (console.abortRequested) {
                throw new Error("Processing aborted by user.");
            }
        }

        results = results.sort((a, b) => a[2] - b[2]);

        log("Selected the best result.");

        if (this.generatePreview)
            this.window.createPreview(results[0][0], results[0][1], results[0][0] + this.windowSize, results[0][1] + this.windowSize, previewName || "Background");

        if (printInformationToConsole)
            printInformation(results[0][0], results[0][1]);

        //this.window.mainView.endProcess();
    }

// Function to check if a point is inside any exclusion area
this.isPointInAnyExclusionArea = function(point, exclusionAreas) {
    let result = exclusionAreas.some(area => this.isPointInExclusionArea(point, area));
    return result;
};

// Function to check if a point is inside an exclusion area
this.isPointInExclusionArea = function(point, exclusionArea) {
    let result = point.x >= exclusionArea.left && point.x <= exclusionArea.right && point.y >= exclusionArea.top && point.y <= exclusionArea.bottom;
    return result;
};


    let gradientDescent = (x, y) => {
        this.spacing = parseFloat(this.spacing);
        x = parseFloat(x);
        y = parseFloat(y);

        let lowestScore = Infinity;
        let improved = true;
        let moveRate = 1.0;

        let lowestX = x;
        let lowestY = y;

        let iterationCounter = 0;
        let rects = [];

        while (moveRate * parseFloat(this.spacing) >= 1.0) {
            rects.push([x, y]);
            iterationCounter++;

            improved = false;

            for (let dx = -1.0; dx <= 1.0; dx += 1.0) {
                for (let dy = -1.0; dy <= 1.0; dy += 1.0) {
                    let newX = Math.round(x + dx * this.spacing * moveRate);
                    let newY = Math.round(y + dy * this.spacing * moveRate);

                    if (newX - this.windowSize < 0 || newX + this.windowSize >= this.image.width || newY - this.windowSize < 0 || newY + this.windowSize >= this.image.height)
                        continue;

                    let point = { x: newX, y: newY };
                    if (this.isPointInAnyExclusionArea(point, this.exclusionAreas)) {
                        continue; // Skip points inside the exclusion areas
                    }

                    calculateFilterValues(newX, newY);
                    let score = getScore();

                    if (score < lowestScore) {
                        lowestScore = score;
                        lowestX = newX;
                        lowestY = newY;
                        improved = true;
                    }
                }
            }

            if (!improved)
                moveRate *= 0.5;

            x = lowestX;
            y = lowestY;

            processEvents();
            if (console.abortRequested) {
                throw new Error("Processing aborted by user.");
            }
        }

        return [lowestX, lowestY, lowestScore];
    };

    let calculateFilterValues = (x, y) => {
        if (this.filterAverage)
            calculateAverage(x, y);
        if (this.filterStandardDeviation) {
            if (!this.filterAverage)
                calculateAverage(x, y);
            calculateStandardDeviation(x, y, filterAverageValue);
        }
        if (this.filterMedianAverageAbsoluteDifference) {
            if (!this.filterAverage && !this.filterStandardDeviation)
                calculateAverage(x, y);
            if (!this.filterStandardDeviation)
                calculateStandardDeviation(x, y, filterAverageValue);
            calculateMedianAverageAbsoluteDifference(x, y, filterAverageValue, filterStandardDeviationValue);
        }
        if (this.filterPoissonIndex)
            calculatePoissonIndex(x, y);
    };

    let printInformation = (lowestX, lowestY) => {
        calculateFilterValues(lowestX, lowestY);
        let score = getScore();
        console.noteln("\n\nProcessing finished!\n\n");
        let informationBrightnessArray = new Array(this.image.numberOfChannels);
        for (var i = 0; i < this.image.numberOfChannels; i++)
            informationBrightnessArray[i] = 0;

        for (var x = lowestX; x < lowestX + this.windowSize; x++)
            for (var y = lowestY; y < lowestY + this.windowSize; y++)
                for (var c = 0; c < this.image.numberOfChannels; c++)
                    informationBrightnessArray[c] += this.image.sample(x, y, c);

        for (var c = 0; c < this.image.numberOfChannels; c++)
            informationBrightnessArray[c] /= this.windowSize * this.windowSize;

        let highestValue = 0;
        for (var c = 0; c < this.image.numberOfChannels; c++)
            if (informationBrightnessArray[c] > highestValue)
                highestValue = informationBrightnessArray[c];

        let correctionConstants = new Array(this.image.numberOfChannels);
        for (var c = 0; c < this.image.numberOfChannels; c++)
            correctionConstants[c] = highestValue - informationBrightnessArray[c];

        console.writeln("Average channel brightness:");
        for (var c = 0; c < this.image.numberOfChannels; c++)
            console.writeln("\t[" + c + "]: " + informationBrightnessArray[c]);

        if (this.image.numberOfChannels > 1) {
            console.writeln("\nAdditive color correction constants:");
            for (var c = 0; c < this.image.numberOfChannels; c++)
                console.writeln("\t[" + c + "]: " + correctionConstants[c]);
        }

        console.writeln("\nROI coordinates:");
        console.writeln("\tX: " + lowestX);
        console.writeln("\tY: " + lowestY);
        console.writeln("\tWidth: " + this.windowSize);
        console.writeln("\tHeight: " + this.windowSize);

        console.writeln("\nQuality assessment: ");
        if (this.filterAverage)
            console.writeln("\tAverage brightness                 : " + filterAverageValue);
        if (this.filterStandardDeviation)
            console.writeln("\tStandard deviation                 : " + filterStandardDeviationValue);
        if (this.filterPoissonIndex)
            console.writeln("\tPoisson index                      : " + filterPoissonIndexValue);
        if (this.filterMedianAverageAbsoluteDifference)
            console.writeln(
                "\tMedian average absolute difference : " + filterMedianAverageAbsoluteDifferenceValue
            );
        console.writeln("\tScore                              : " + score);
        console.noteln("Background Found! Preview Created!");
    };

    let getScore = () => {
        let avgScore, stDevScore, maadScore, poissonScore;
        if (this.filterAverage) avgScore = 1 / filterAverageValue;
        if (this.filterStandardDeviation) stDevScore = 1 / filterStandardDeviationValue;
        if (this.filterMedianAverageAbsoluteDifference)
            maadScore = 1 / filterMedianAverageAbsoluteDifferenceValue;
        if (this.filterPoissonIndex) poissonScore = 1 / filterPoissonIndexValue;

        let score = 0;

        if (this.filterAverage) score += avgScore;

        if (this.filterStandardDeviation && this.filterAverage)
            score += Math.min(avgScore * filterStandardDeviationCap, filterStandardDeviationNormalization * stDevScore);
        else if (this.filterStandardDeviation) score += stDevScore * filterStandardDeviationNormalization;

        if (this.filterMedianAverageAbsoluteDifference && this.filterAverage)
            score += Math.min(
                avgScore * filterMedianAverageAbsoluteDifferenceCap,
                filterMedianAverageAbsoluteDifferenceNormalization * maadScore
            );
        else if (this.filterMedianAverageAbsoluteDifference)
            score += maadScore * filterMedianAverageAbsoluteDifferenceNormalization;

        if (this.filterPoissonIndex && this.filterAverage)
            score += Math.min(avgScore * filterPoissonIndexCap, filterPoissonIndexNormalization * poissonScore);
        else if (this.filterPoissonIndex) score += poissonScore * filterPoissonIndexNormalization;

        score = 1 / score;

        // if(this.filterForObjects)
        //     score *= filterForObjectsValue;

        return score;
    };

    let log = (message) => {
        if (this.verbosity == 1) console.writeln(message);
        processEvents();
    };

    // let setupObjectFilter = () =>
    // {
    //     let detector = new StarDetector;
    //     detector.hotPixelFilterRadius = 1;
    //     detector.sensitivity = 1;
    //     detector.peakResponse = 1;
    //     detector.allowClusteredSources = true;
    //     detector.maxDistortion = 0;

    //     let stars = detector.stars(this.image);
    //     let lowestCenterIntensity = Infinity;
    //     for(var i = 0; i < stars.length; i++)
    //     {
    //         let centerIntensity = 0;
    //         for(var c = 0; c < this.image.numberOfChannels; c++)
    //             centerIntensity += this.image.sample(stars[i].pos.x, stars[i].pos.y, c);
    //         centerIntensity /= this.image.numberOfChannels;
    //         if(centerIntensity < lowestCenterIntensity)
    //             lowestCenterIntensity = centerIntensity;
    //     }

    //     filterForObjectsThreshold = lowestCenterIntensity;
    // }

    let setupFilterNormalization = () => {
        let tileSize = 500;
        let targetMedianValue = 0.5;
        let averageValues = [];
        let standardDeviationValues = [];
        let medianAverageAbsoluteDifferenceValues = [];
        let poissonIndexValues = [];

        for (var x = 0; x < this.image.width - tileSize; x += tileSize) {
            for (var y = 0; y < this.image.height - tileSize; y += tileSize) {
                calculateFilterValues(x, y);
                averageValues.push(filterAverageValue);
                standardDeviationValues.push(filterStandardDeviationValue);
                medianAverageAbsoluteDifferenceValues.push(filterMedianAverageAbsoluteDifferenceValue);
                poissonIndexValues.push(filterPoissonIndexValue);
            }
        }

        let indices = averageValues.map((_, index) => index);
        indices = indices.sort((a, b) => averageValues[a] - averageValues[b]);

        averageValues = reorderArray(averageValues, indices).slice(0, Math.floor(averageValues.length / 4));
        standardDeviationValues = reorderArray(standardDeviationValues, indices).slice(0, Math.floor(standardDeviationValues.length / 4));
        medianAverageAbsoluteDifferenceValues = reorderArray(medianAverageAbsoluteDifferenceValues, indices).slice(
            0,
            Math.floor(medianAverageAbsoluteDifferenceValues.length / 4)
        );
        poissonIndexValues = reorderArray(poissonIndexValues, indices).slice(0, Math.floor(poissonIndexValues.length / 4));

        let medianAverageScore = 1 / averageValues[Math.floor(averageValues.length / 2)];
        let medianStandardDeviationScore = 1 / standardDeviationValues[Math.floor(standardDeviationValues.length / 2)];
        let medianMedianAverageAbsoluteDifferenceScore =
            1 / medianAverageAbsoluteDifferenceValues[Math.floor(medianAverageAbsoluteDifferenceValues.length / 2)];
        let medianPoissonIndexScore = 1 / poissonIndexValues[Math.floor(poissonIndexValues.length / 2)];

        filterStandardDeviationNormalization =
            (targetMedianValue * filterStandardDeviationCap * medianAverageScore) / medianStandardDeviationScore;
        filterMedianAverageAbsoluteDifferenceNormalization =
            (targetMedianValue * filterMedianAverageAbsoluteDifferenceCap * medianAverageScore) /
            medianMedianAverageAbsoluteDifferenceScore;
        filterPoissonIndexNormalization =
            (targetMedianValue * filterPoissonIndexCap * medianAverageScore) / medianPoissonIndexScore;
    };

    let reorderArray = (array, indices) => {
        let newArray = new Array(array.length);
        for (var i = 0; i < array.length; i++) newArray[i] = array[indices[i]];
        return newArray;
    };

    let calculateAverage = (x, y) => {
        let average = 0;

        for (let dx = 0; dx < this.windowSize; dx++)
            for (let dy = 0; dy < this.windowSize; dy++)
                for (var c = 0; c < this.image.numberOfChannels; c++)
                    average += this.image.sample(x + dx, y + dy, c);

        filterAverageValue = average / (this.windowSize * this.windowSize * this.image.numberOfChannels);
    };

    let calculateStandardDeviation = (x, y, average) => {
        let standardDeviation = 0;
        let pixelBrightness = 0;

        for (var dx = 0; dx < this.windowSize; dx++) {
            for (var dy = 0; dy < this.windowSize; dy++) {
                pixelBrightness = 0;
                for (var c = 0; c < this.image.numberOfChannels; c++) pixelBrightness += this.image.sample(x + dx, y + dy, c);

                standardDeviation += Math.pow(pixelBrightness - average, 2);
            }
        }

        filterStandardDeviationValue = Math.sqrt(
            standardDeviation / (this.windowSize * this.windowSize * this.image.numberOfChannels)
        );
    };

    let calculateMedianAverageAbsoluteDifference = (x, y, average, stDev) => {
        for (var dx = 0; dx < this.windowSize; dx++) {
            for (var dy = 0; dy < this.windowSize; dy++) {
                let pixelBrightness = 0;
                for (var c = 0; c < this.image.numberOfChannels; c++) pixelBrightness += this.image.sample(x + dx, y + dy, c);

                this.brightnessArray[dx * this.windowSize + dy] = pixelBrightness;
            }
        }

        this.brightnessArray = this.brightnessArray.sort((a, b) => a - b);

        let index = Math.floor(this.brightnessArray.length / 2);

        if (this.brightnessArray.length % 2)
            filterMedianAverageAbsoluteDifferenceValue = Math.abs(this.brightnessArray[index] - average) / stDev;
        else
            filterMedianAverageAbsoluteDifferenceValue =
                Math.abs((this.brightnessArray[index - 1] + this.brightnessArray[index]) / 2 - average) / stDev;
    };

    let calculatePoissonIndex = (x, y) => {
        let averages = new Array(this.image.numberOfChannels);
        for (var i = 0; i < averages.length; i++) averages[i] = 0;
        for (var dx = 0; dx < this.windowSize; dx++)
            for (var dy = 0; dy < this.windowSize; dy++)
                for (var c = 0; c < this.image.numberOfChannels; c++) averages[c] += this.image.sample(x + dx, y + dy, c);

        for (var i = 0; i < averages.length; i++) averages[i] /= this.windowSize * this.windowSize;

        let variances = new Array(this.image.numberOfChannels);
        for (var i = 0; i < variances.length; i++) variances[i] = 0;
        for (var dx = 0; dx < this.windowSize; dx++)
            for (var dy = 0; dy < this.windowSize; dy++)
                for (var c = 0; c < this.image.numberOfChannels; c++)
                    variances[c] += Math.pow(this.image.sample(x + dx, y + dy, c) - averages[i], 2);

        for (var i = 0; i < variances.length; i++) variances[i] /= this.windowSize * this.windowSize;

        let poissonIndexes = new Array(this.image.numberOfChannels);
        for (var i = 0; i < poissonIndexes.length; i++)
            poissonIndexes[i] = Math.abs(averages[i] - variances[i]) / averages[i];

        let poissonIndex = 0;
        for (var i = 0; i < poissonIndexes.length; i++) poissonIndex += poissonIndexes[i];

        filterPoissonIndexValue = Math.abs(poissonIndex / this.image.numberOfChannels - 1);
    };

    // Function to check if a point is inside any exclusion area
    this.isPointInAnyExclusionArea = function(point, exclusionAreas) {
        return exclusionAreas.some(area => this.isPointInExclusionArea(point, area));
    };

    // Function to check if a point is inside an exclusion area
    this.isPointInExclusionArea = function(point, exclusionArea) {
        if (!exclusionArea) return false;
        return (
            point.x >= exclusionArea.left &&
            point.x <= exclusionArea.right &&
            point.y >= exclusionArea.top &&
            point.y <= exclusionArea.bottom
        );
    };
}

#endif

#ifndef USE_FIND_BACKGROUND_JS_LIBRARY

let window = ImageWindow.activeWindow;
let finder = new FindBackground(50, 2);

finder.filterAverage = true;
finder.filterStandardDeviation = true;
finder.filterPoissonIndex = false;
finder.filterMedianAverageAbsoluteDifference = false;
finder.filterForObjects = false;

finder.setTarget(window);
finder.fastSearchBackground(100, 40, true);

#endif
