
#feature-id FAME : SetiAstro > FAME
#feature-icon  fame.svg
#feature-info This script allows freehand, ellipse, and rectangular drawing of masks.

// Main Script

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Freehand Adaptive Mask Editor
 * Version: V1.5
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is designed for freehand drawing, creating ellipses,
 * and drawing rectangles that can then be used as masks.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define TITLE "Freehand Adaptive Mask Editor"
#define VERSION "V1.5"

let parameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    shapes: [],
    shapeTypes: [], // Store types of shapes
    save: function() {
        Parameters.set("shapes", JSON.stringify(this.shapes));
        Parameters.set("shapeTypes", JSON.stringify(this.shapeTypes));
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function() {
        if (Parameters.has("shapes")) {
            this.shapes = JSON.parse(Parameters.getString("shapes"));
        }
        if (Parameters.has("shapeTypes")) {
            this.shapeTypes = JSON.parse(Parameters.getString("shapeTypes"));
        }
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
    }
};

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.isDrawing = false; // Flag for detecting drawing
    this.isTransforming = false; // Flag for detecting transforming (rotate + resize)
    this.currentShape = [];
    this.shapes = [];
    this.shapeTypes = []; // Track types of shapes
    this.activeShapeIndex = 0; // Initialize activeShapeIndex
    this.scrollPosition = new Point(0, 0); // Ensure scrollPosition is always defined
    this.previousZoomLevel = 1;
    this.shapeType = "Freehand"; // Default shape type
    this.transformCenter = null; // Center point for transformations
    this.initialDistance = null; // Initial distance for resizing
    this.initialAngle = null; // Initial angle for rotating
    this.gradientStartPoint = null; // To store the start point of the gradient
    this.gradientEndPoint = null;   // To store the end point of the gradient


    this.brushRadius = 10; // Default brush radius
    this.sprayDensity = 0.5; // Default spray density
    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.zoomFactor = 1;
    this.minZoomFactor = 0.1; // Set the minimum zoom factor for zooming out
    this.maxZoomFactor = 10;  // Set the maximum zoom factor for zooming in

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

this.initScrollBars = function(scrollPoint = null) {
    var image = this.getImage();
    if (image == null || image.width <= 0 || image.height <= 0) {
        this.setHorizontalScrollRange(0, 0);
        this.setVerticalScrollRange(0, 0);
        this.scrollPosition = new Point(0, 0);
    } else {
        let zoomFactor = this.zoomFactor;
        this.setHorizontalScrollRange(0, Math.max(0, (image.width * zoomFactor)));
        this.setVerticalScrollRange(0, Math.max(0, (image.height * zoomFactor)));
        if (scrollPoint) {
            this.scrollPosition = scrollPoint;
        } else {
            this.scrollPosition = new Point(
                Math.min(this.scrollPosition.x, (image.width * zoomFactor)),
                Math.min(this.scrollPosition.y, (image.height * zoomFactor))
            );
        }
    }
    if (this.viewport) {
        this.viewport.update();
    }
};



    this.calculateTransformCenter = function(shape) {
        let sumX = 0;
        let sumY = 0;
        shape.forEach(point => {
            sumX += point[0];
            sumY += point[1];
        });
        return [sumX / shape.length, sumY / shape.length];
    };

    this.calculateDistance = function(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    };

    this.calculateAngle = function(x1, y1, x2, y2) {
        return Math.atan2(y2 - y1, x2 - x1);
    };

    this.transformShape = function(shape, angle, scaleX, scaleY, centerX, centerY) {
        return shape.map(point => {
            let translatedX = point[0] - centerX;
            let translatedY = point[1] - centerY;
            let rotatedX = translatedX * Math.cos(angle) - translatedY * Math.sin(angle);
            let rotatedY = translatedX * Math.sin(angle) + translatedY * Math.cos(angle);
            let resizedX = rotatedX * scaleX;
            let resizedY = rotatedY * scaleY;
            return [resizedX + centerX, resizedY + centerY];
        });
    };

this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;


    // Handle gradient mask point selection with the right mouse button (button === 2)
    if (button === 2) {
        if (!parent.gradientStartPoint) {
            parent.gradientStartPoint = [adjustedX, adjustedY];
            console.writeln("Gradient start point set at: (" + adjustedX + ", " + adjustedY + ")");
parent.viewport.update();
        } else if (!parent.gradientEndPoint) {
            parent.gradientEndPoint = [adjustedX, adjustedY];
            console.writeln("Gradient end point set at: (" + adjustedX + ", " + adjustedY + ")");
parent.viewport.update();
        }
        return;  // Exit after setting the points
    }

    // Existing logic for drawing, moving, or transforming shapes
    if (modifiers === 1) { // Shift key detection for drawing
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isDrawing = true;
        parent.dragging = false; // Prevent scrolling while drawing

        // Handle different shape types
        if (parent.shapeType === "Ellipse" || parent.shapeType === "Rectangle") {
            parent.currentShape = [[parent.startX, parent.startY], [parent.startX, parent.startY]];
        } else if (parent.shapeType === "SprayCan") {
            parent.currentShape = []; // Initialize currentShape for spray can
        } else if (parent.shapeType === "Brush") {
            parent.currentShape = []; // Initialize currentShape for brush strokes
        }
    } else if (modifiers === 2) { // Ctrl key detection for moving
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isMoving = true;
        parent.dragging = false; // Prevent scrolling while moving

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
    } else if (modifiers === 4) { // Alt key detection for transforming
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isTransforming = true;
        parent.transformCenter = parent.calculateTransformCenter(parent.shapes[parent.activeShapeIndex]);
        parent.initialAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], parent.startX, parent.startY);
        parent.initialDistance = parent.calculateDistance(parent.startX, parent.startY, parent.transformCenter[0], parent.transformCenter[1]);

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
    } else {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        parent.dragging = true;
    }
};



this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;
    if (parent.isDrawing) {
        let endX = adjustedX;
        let endY = adjustedY;

        if (parent.shapeType === "Freehand") {
            parent.currentShape.push([endX, endY]);
        } else if (parent.shapeType === "Ellipse") {
            let centerX = (parent.startX + endX) / 2;
            let centerY = (parent.startY + endY) / 2;
            let radiusX = Math.abs(endX - parent.startX) / 2;
            let radiusY = Math.abs(endY - parent.startY) / 2;
            parent.currentShape = [];
            for (let angle = 0; angle < 2 * Math.PI; angle += 0.01) {
                parent.currentShape.push([
                    centerX + radiusX * Math.cos(angle),
                    centerY + radiusY * Math.sin(angle)
                ]);
            }
            parent.currentShape.push(parent.currentShape[0]); // Close the shape
        } else if (parent.shapeType === "Rectangle") {
            parent.currentShape = [
                [parent.startX, parent.startY],
                [endX, parent.startY],
                [endX, endY],
                [parent.startX, endY],
                [parent.startX, parent.startY]
            ];
        } else if (parent.shapeType === "SprayCan") {
            let radius = parent.brushRadius;
            let density = parent.sprayDensity;
            let startX = endX - radius;
            let endXCoord = endX + radius;
            let startY = endY - radius;
            let endYCoord = endY + radius;
            for (let ix = startX; ix <= endXCoord; ix++) {
                for (let iy = startY; iy <= endYCoord; iy++) {
                    let dx = ix - endX;
                    let dy = iy - endY;
                    let distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance <= radius) {
                        let threshold = (1 - distance / radius) * density;
                        if (Math.random() < threshold) {
                            parent.currentShape.push([ix, iy, 1]); // Save spray can points
                        }
                    }
                }
            }
        } else if (parent.shapeType === "Brush") {
            let radius = parent.brushRadius;
            let newPoints = [];
            for (let angle = 0; angle < 2 * Math.PI; angle += Math.PI / 8) { // 16 points per circle
                let ix = endX + radius * Math.cos(angle);
                let iy = endY + radius * Math.sin(angle);
                newPoints.push([Math.round(ix), Math.round(iy)]);
            }

            // Add the center point of each circle
            newPoints.push([endX, endY]);

            if (parent.currentShape.length > 0) {
                let lastPoints = parent.currentShape[parent.currentShape.length - 1];
                if (lastPoints.length === newPoints.length) {
                    for (let i = 0; i < lastPoints.length; i++) {
                        let startX = lastPoints[i][0];
                        let startY = lastPoints[i][1];
                        let endX = newPoints[i][0];
                        let endY = newPoints[i][1];

                        if (!isNaN(startX) && !isNaN(startY) && !isNaN(endX) && !isNaN(endY)) {
                            // Add the original points
                            parent.currentShape.push([startX, startY, endX, endY]);

                            // Add points at 1/4, 1/2, and 3/4 of the way along the line
                            let quarterX1 = startX + 0.25 * (endX - startX);
                            let quarterY1 = startY + 0.25 * (endY - startY);
                            let halfX = startX + 0.5 * (endX - startX);
                            let halfY = startY + 0.5 * (endY - startY);
                            let quarterX3 = startX + 0.75 * (endX - startX);
                            let quarterY3 = startY + 0.75 * (endY - startY);

                            if (!isNaN(quarterX1) && !isNaN(quarterY1) && !isNaN(halfX) && !isNaN(halfY) && !isNaN(quarterX3) && !isNaN(quarterY3)) {
                                parent.currentShape.push([startX, startY, quarterX1, quarterY1]);
                                parent.currentShape.push([quarterX1, quarterY1, halfX, halfY]);
                                parent.currentShape.push([halfX, halfY, quarterX3, quarterY3]);
                                parent.currentShape.push([quarterX3, quarterY3, endX, endY]);
                            }
                        }
                    }
                }
            }
            parent.currentShape.push(newPoints);
        }

        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        let dx = adjustedX - parent.startX;
        let dy = adjustedY - parent.startY;
        parent.shapes[parent.activeShapeIndex] = parent.originalShape.map(point => [point[0] + dx, point[1] + dy]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        let currentAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], adjustedX, adjustedY);
        let angleDifference = currentAngle - parent.initialAngle;
        let currentDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter[0], parent.transformCenter[1]);
        let scale = currentDistance / parent.initialDistance;
        parent.shapes[parent.activeShapeIndex] = parent.transformShape(parent.originalShape, angleDifference, scale, scale, parent.transformCenter[0], parent.transformCenter[1]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.dragging) {
        let dx = (parent.dragOrigin.x - x) / zoomFactor;
        let dy = (parent.dragOrigin.y - y) / zoomFactor;
        parent.scrollPosition = new Point(parent.scrollPosition.x + dx, parent.scrollPosition.y + dy);
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        if (parent.viewport) {
            parent.viewport.update();
        }
    }
};


this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;

    if (parent.isDrawing) {
        parent.isDrawing = false;
        if (parent.shapeType === "Freehand") {
            parent.currentShape.push([adjustedX, adjustedY]);
            parent.currentShape.push(parent.currentShape[0]); // Close the shape
        }

        // Finalize the shape and ensure no extraneous points are added
        parent.shapes.push(parent.currentShape.filter(point => !isNaN(point[0]) && !isNaN(point[1])));
        parent.shapeTypes.push(parent.shapeType); // Save the shape type
        parent.currentShape = [];
        parent.activeShapeIndex = parent.shapes.length - 1; // Set the newly drawn shape as the active shape
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        parent.isMoving = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        parent.isTransforming = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else {
        this.cursor = new Cursor(StdCursor_Cross);
        parent.dragging = false;
    }
};



this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent

    if (!parent.displayImage) {
        console.error("No display image set.");
        return;
    }

    let oldZoomFactor = parent.zoomFactor;

    // Calculate the old scroll position percentage
    let maxHorizontalScroll = (parent.displayImage.width * oldZoomFactor) - parent.viewport.width;
    let maxVerticalScroll = (parent.displayImage.height * oldZoomFactor) - parent.viewport.height;
    let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

    // Update the zoom factor based on the wheel delta
    if (delta > 0) {
        parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
    } else if (delta < 0) {
        parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
    }
    let newZoomFactor = parent.zoomFactor;

    // Reinitialize scrollbars to reflect the new zoom level
    parent.initScrollBars();

    // Calculate the new scroll position using the old scroll percentage
    maxHorizontalScroll = (parent.displayImage.width * newZoomFactor) - parent.viewport.width;
    maxVerticalScroll = (parent.displayImage.height * newZoomFactor) - parent.viewport.height;
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    // Ensure the new scroll position stays within valid bounds
    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    // Update the scroll position to keep the same relative position
    parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    parent.viewport.update();
};

// Zoom In Function
this.zoomIn = function() {
    this.zoomFactor = Math.min(this.zoomFactor * 1.25, this.maxZoomFactor);
    this.initScrollBars();
    if (this.viewport) {
        this.viewport.update();
    }
};

// Zoom Out Function
this.zoomOut = function() {
    this.zoomFactor = Math.max(this.zoomFactor * 0.8, this.minZoomFactor);
    this.initScrollBars();
    if (this.viewport) {
        this.viewport.update();
    }
};



// Updated onPaint with Gradient Start/End Points
this.viewport.onPaint = function(x0, y0, x1, y1) {
    var g = new Graphics(this);
    var result = this.parent.getImage();
    let zoomFactor = this.parent.zoomFactor;

    if (result == null) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
    } else {
        // Apply the scaling transformation
        g.scaleTransformation(zoomFactor);

        // Translate the image to account for scrolling
        g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);

        // Draw the image
        g.drawBitmap(0, 0, result.render());

        // Draw the user-defined shapes if they exist
        this.parent.shapes.forEach((shape, index) => {
            g.pen = new Pen(index === this.parent.activeShapeIndex ? 0xff00ff00 : 0xffff0000);
            if (this.parent.shapeTypes[index] === "SprayCan" || this.parent.shapeTypes[index] === "Brush") {
                shape.forEach(point => {
                    if (Number.isFinite(point[0]) && Number.isFinite(point[1])) {
                        g.drawPoint(point[0], point[1]);
                    }
                });
            } else {
                for (let i = 0; i < shape.length - 1; i++) {
                    if (Number.isFinite(shape[i][0]) && Number.isFinite(shape[i][1]) && Number.isFinite(shape[i + 1][0]) && Number.isFinite(shape[i + 1][1])) {
                        g.drawLine(shape[i][0], shape[i][1], shape[i + 1][0], shape[i + 1][1]);
                    }
                }
            }
        });

        // Draw the current shape if it exists
        if (this.parent.currentShape.length > 0) {
            g.pen = new Pen(0xff00ff00);
            if (this.parent.shapeType === "SprayCan" || this.parent.shapeType === "Brush") {
                this.parent.currentShape.forEach(point => {
                    if (Number.isFinite(point[0]) && Number.isFinite(point[1])) {
                        g.drawPoint(point[0], point[1]);
                    }
                });
            } else {
                for (let i = 0; i < this.parent.currentShape.length - 1; i++) {
                    if (Number.isFinite(this.parent.currentShape[i][0]) && Number.isFinite(this.parent.currentShape[i][1]) && Number.isFinite(this.parent.currentShape[i + 1][0]) && Number.isFinite(this.parent.currentShape[i + 1][1])) {
                        g.drawLine(this.parent.currentShape[i][0], this.parent.currentShape[i][1],
                                   this.parent.currentShape[i + 1][0], this.parent.currentShape[i + 1][1]);
                    }
                }
            }
        }

// Draw gradient start and end points, if they exist
if (this.parent.gradientStartPoint) {
    g.pen = new Pen(0xff00ff00); // Green for start point
    g.brush = new Brush(0xff00ff00); // Solid green brush for filled circle
    g.drawCircle(this.parent.gradientStartPoint[0], this.parent.gradientStartPoint[1], 5); // Draw a small circle with radius 5
}
if (this.parent.gradientEndPoint) {
    g.pen = new Pen(0xffff0000); // Red for end point
    g.brush = new Brush(0xffff0000); // Solid red brush for filled circle
    g.drawCircle(this.parent.gradientEndPoint[0], this.parent.gradientEndPoint[1], 5); // Draw a small circle with radius 5
}

    }

    g.end();
    gc();
};






    this.setFocus = function() {
        this.viewport.onKeyPress = (keyCode, modifiers) => {
            if (keyCode === 0x20) { // Spacebar key
                this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
                this.viewport.update();
            }
        };
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

// Function to scale spray can points
ScrollControl.prototype.scaleSprayCanPoints = function(points, scaleRatio) {
    let scaledPoints = [];
    points.forEach(point => {
        let x = Math.round(point[0] * scaleRatio);
        let y = Math.round(point[1] * scaleRatio);
        if (!isNaN(x) && !isNaN(y)) { // Ensure coordinates are valid numbers
            // Create a region of points around the original point based on the scale ratio
            for (let dx = -Math.floor(scaleRatio / 2); dx <= Math.floor(scaleRatio / 2); dx++) {
                for (let dy = -Math.floor(scaleRatio / 2); dy <= Math.floor(scaleRatio / 2); dy++) {
                    let newX = x + dx;
                    let newY = y + dy;
                    if (newX >= 0 && newX < this.displayImage.width && newY >= 0 && newY < this.displayImage.height) {
                        scaledPoints.push([newX, newY]);
                    }
                }
            }
        } else {
            console.warningln("Invalid point detected during scaling: x=" + x + ", y=" + y);
        }
    });
    return scaledPoints;
};

// Function to scale brush points
ScrollControl.prototype.scaleBrushPoints = function(points, scaleRatio) {
    let scaledPoints = [];
    points.forEach(point => {
        let x = Math.round(point[0] * scaleRatio);
        let y = Math.round(point[1] * scaleRatio);
        if (!isNaN(x) && !isNaN(y)) { // Ensure coordinates are valid numbers
            scaledPoints.push([x, y]);
        } else {
            console.warningln("Invalid point detected during scaling: x=" + x + ", y=" + y);
        }
    });
    return scaledPoints;
};

// Function to scale all shapes when zoom changes
ScrollControl.prototype.scaleShapes = function(newZoomLevel) {
    try {
        let scaleRatio = this.previousZoomLevel / newZoomLevel;
        this.shapes = this.shapes.map((shape, index) => {
            if (this.shapeTypes[index] === "SprayCan") {
                return this.scaleSprayCanPoints(shape, scaleRatio);
            } else if (this.shapeTypes[index] === "Brush") {
                return this.scaleBrushPoints(shape, scaleRatio);
            } else {
                return shape.map(point => [
                    Math.round(point[0] * scaleRatio),
                    Math.round(point[1] * scaleRatio)
                ]);
            }
        });
        this.previousZoomLevel = newZoomLevel;
        if (this.viewport) {
            this.viewport.update();
        }
    } catch (error) {
        // Suppress any warnings or errors
        console.warningln("Error during shape scaling: " + error);
    }
};

// Ensure this function is called whenever the zoom level changes
FAMEDialog.prototype.updateZoomLevel = function(newZoomLevel) {
    if (this.previewControl) {
        this.previewControl.scaleShapes(newZoomLevel);
    }
};


function FAMEDialog() {
    this.__base__ = Dialog;
    this.__base__();
        this.maskType = "Binary";  // Initialize the maskType with a default value

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>Freehand Adaptive Mask Editor (FAME) " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

    this.instructions_Lbl = new TextBox(this);
    this.instructions_Lbl.readOnly = true;
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.text = "Instructions:\n\nShift + Click and drag to draw a shape.\n\nMultiple Shapes can be drawn.\n\nCTRL+Click and Drag to MOVE the drawn shape.\nALT+Click and Drag to ROTATE and RESIZE\nRight Click to define start and end points for Gradient\nSPACEBAR cycles through the active shapes\n\nGrey undo button removes the active shape\nRed Reset Button removes all shapes.";
    this.instructions_Lbl.setScaledMinWidth(450); // Set a fixed width for the instructions

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

    this.windowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
            if (window && !window.isNull) {
                parameters.targetWindow = window;
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                } else {
                    console.error("Selected image is undefined.");
                }
            } else {
                console.writeln("No valid window selected for preview!");
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };

    // Update this section to include the imageLabel
    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel); // Add the label to the sizer
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.shapeType = "Freehand"; // Default shape type

    this.freehandShape_Rb = new RadioButton(this);
    this.freehandShape_Rb.text = "Freehand Shape (Lasso Tool)";
    this.freehandShape_Rb.checked = true;
    this.freehandShape_Rb.onCheck = () => {
        if (this.freehandShape_Rb.checked) {
            this.shapeType = "Freehand";
            this.previewControl.shapeType = "Freehand";
            this.brushRadiusSlider.hide();
            this.sprayDensitySlider.hide();
        }
    };

    this.brushRadiusSlider = new NumericControl(this);
    this.brushRadiusSlider.label.text = "Radius:";
    this.brushRadiusSlider.setRange(1, 100);
    this.brushRadiusSlider.setPrecision(1);
    this.brushRadiusSlider.slider.setRange(1, 100);
    this.brushRadiusSlider.setValue(10);
    this.brushRadiusSlider.hide(); // Hide initially
    this.brushRadiusSlider.onValueUpdated = (value) => {
        this.previewControl.brushRadius = value;
    };

    this.sprayDensitySlider = new NumericControl(this);
    this.sprayDensitySlider.label.text = "Spray Density:";
    this.sprayDensitySlider.setRange(0, 1);
    this.sprayDensitySlider.setPrecision(2);
    this.sprayDensitySlider.slider.setRange(0, 100);
    this.sprayDensitySlider.setValue(0.5);
    this.sprayDensitySlider.hide(); // Hide initially
    this.sprayDensitySlider.onValueUpdated = (value) => {
        this.previewControl.sprayDensity = value;
    };

    this.sprayCanTool_Rb = new RadioButton(this);
    this.sprayCanTool_Rb.text = "Spray Can";
    this.sprayCanTool_Rb.onCheck = () => {
        if (this.sprayCanTool_Rb.checked) {
            this.shapeType = "SprayCan";
            this.previewControl.shapeType = "SprayCan";
            this.brushRadiusSlider.show();
            this.sprayDensitySlider.show();
        }
    };

    this.brushTool_Rb = new RadioButton(this);
    this.brushTool_Rb.text = "Brush";
    this.brushTool_Rb.onCheck = () => {
        if (this.brushTool_Rb.checked) {
            this.shapeType = "Brush";
            this.previewControl.shapeType = "Brush";
            this.brushRadiusSlider.show();
            this.sprayDensitySlider.hide();
        }
    };

    this.ellipseShape_Rb = new RadioButton(this);
    this.ellipseShape_Rb.text = "Ellipse";
    this.ellipseShape_Rb.onCheck = () => {
        if (this.ellipseShape_Rb.checked) {
            this.shapeType = "Ellipse";
            this.previewControl.shapeType = "Ellipse";
            this.brushRadiusSlider.hide();
            this.sprayDensitySlider.hide();
        }
    };

    this.rectangleShape_Rb = new RadioButton(this);
    this.rectangleShape_Rb.text = "Rectangle";
    this.rectangleShape_Rb.onCheck = () => {
        if (this.rectangleShape_Rb.checked) {
            this.shapeType = "Rectangle";
            this.previewControl.shapeType = "Rectangle";
            this.brushRadiusSlider.hide();
            this.sprayDensitySlider.hide();
        }
    };

    this.shapeSizer = new VerticalSizer;
    this.shapeSizer.spacing = 4;
    this.shapeSizer.add(this.freehandShape_Rb);
    this.shapeSizer.add(this.brushTool_Rb); // Add brush tool radio button
    this.shapeSizer.add(this.brushRadiusSlider); // Add brush radius slider
    this.shapeSizer.add(this.sprayCanTool_Rb); // Add spray can tool radio button
    this.shapeSizer.add(this.sprayDensitySlider); // Add spray density slider
    this.shapeSizer.add(this.ellipseShape_Rb);
    this.shapeSizer.add(this.rectangleShape_Rb);

    this.maskTypeLabel = new Label(this);
    this.maskTypeLabel.text = "Mask Type:";
    this.maskTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.maskType = "Binary";

    this.binaryMask_Cb = new CheckBox(this);
    this.binaryMask_Cb.text = "Binary";
    this.binaryMask_Cb.toolTip = "Binary:\nBest for Linear Images.\nCreates a mask with binary values (0 or 1)\ninside the selected shapes.";
    this.binaryMask_Cb.checked = true; // Default to Binary
    this.binaryMask_Cb.onCheck = () => {
        if (this.binaryMask_Cb.checked) {
            this.lightnessMask_Cb.checked = false;
            this.chrominanceMask_Cb.checked = false;
            this.colorMask_Cb.checked = false;
            this.gradientMask_Cb.checked = false;
            this.maskType = "Binary";
	this.previewControl.maskType = "Binary";
        }
    };

    this.lightnessMask_Cb = new CheckBox(this);
    this.lightnessMask_Cb.text = "Lightness";
    this.lightnessMask_Cb.toolTip = "Lightness:\nCreates a mask based on the brightness values\nof the original image inside the selected shapes.\nWill look black if applied to linear images!";
    this.lightnessMask_Cb.onCheck = () => {
        if (this.lightnessMask_Cb.checked) {
            this.binaryMask_Cb.checked = false;
            this.chrominanceMask_Cb.checked = false;
            this.colorMask_Cb.checked = false;
            this.gradientMask_Cb.checked = false;
            this.maskType = "Lightness";
	this.previewControl.maskType = "Lightness";
        }
    };

    this.chrominanceMask_Cb = new CheckBox(this);
    this.chrominanceMask_Cb.text = "Chrominance";
    this.chrominanceMask_Cb.toolTip = "Chrominance:\nCreates a mask based on the chrominance (color saturation)\nvalues of the original image inside the selected shapes.";
    this.chrominanceMask_Cb.onCheck = () => {
        if (this.chrominanceMask_Cb.checked) {
            this.binaryMask_Cb.checked = false;
            this.lightnessMask_Cb.checked = false;
            this.colorMask_Cb.checked = false;
            this.gradientMask_Cb.checked = false;
            this.maskType = "Chrominance";
	this.previewControl.maskType = "Chrominance";
        }
    };

    // Add new elements for the Color mask type
    this.colorMask_Cb = new CheckBox(this);
    this.colorMask_Cb.text = "Color";
    this.colorMask_Cb.toolTip = "Color:\nCreates a mask based on the specified color saturation values\ninside the selected shapes.";
    this.colorMask_Cb.onCheck = () => {
        if (this.colorMask_Cb.checked) {
            this.binaryMask_Cb.checked = false;
            this.lightnessMask_Cb.checked = false;
            this.chrominanceMask_Cb.checked = false;
            this.gradientMask_Cb.checked = false;
            this.maskType = "Color";
	this.previewControl.maskType = "Color";
        }
    };

this.gradientMask_Cb = new CheckBox(this);
this.gradientMask_Cb.text = "Gradient Mask";
this.gradientMask_Cb.toolTip = "Create a gradient mask between two points.";
this.gradientMask_Cb.onCheck = () => {
    if (this.gradientMask_Cb.checked) {
        this.maskType = "Gradient"; // Set the mask type to gradient
	this.previewControl.maskType = "Gradient";
        // Uncheck other mask types
        this.binaryMask_Cb.checked = false;
        this.lightnessMask_Cb.checked = false;
        this.chrominanceMask_Cb.checked = false;
        this.colorMask_Cb.checked = false;
    }
};


    // Add dropdown menu for selecting specific colors
    this.colorDropdown = new ComboBox(this);
    this.colorDropdown.addItem("Red");
    this.colorDropdown.addItem("Yellow");
    this.colorDropdown.addItem("Green");
    this.colorDropdown.addItem("Cyan");
    this.colorDropdown.addItem("Blue");
    this.colorDropdown.addItem("Magenta");
    this.colorDropdown.toolTip = "Select the color for the mask.";

    // Create a new HorizontalSizer for the "Color" checkbox and dropdown menu
    this.colorMaskSizer = new HorizontalSizer;
    this.colorMaskSizer.spacing = 4;
    this.colorMaskSizer.addStretch();
    this.colorMaskSizer.add(this.gradientMask_Cb);
    this.colorMaskSizer.addStretch();
    this.colorMaskSizer.add(this.colorMask_Cb);
    this.colorMaskSizer.add(this.colorDropdown);
    this.colorMaskSizer.addStretch();



    this.maskTypeSizer = new HorizontalSizer;
    this.maskTypeSizer.spacing = 4;
    this.maskTypeSizer.add(this.maskTypeLabel);
    this.maskTypeSizer.add(this.binaryMask_Cb);
    this.maskTypeSizer.add(this.lightnessMask_Cb);
    this.maskTypeSizer.add(this.chrominanceMask_Cb);

    this.blurAmount_Slider = new NumericControl(this);
    this.blurAmount_Slider.label.text = "Blur Amount: ";
    this.blurAmount_Slider.setRange(0, 200);
    this.blurAmount_Slider.slider.setRange(0, 200);
    this.blurAmount_Slider.setValue(25); // Default value

    // Add the AutoSTF checkbox
    this.autoSTF_Cb = new CheckBox(this);
    this.autoSTF_Cb.text = "AutoSTF";
    this.autoSTF_Cb.checked = false; // Default to unchecked
    this.autoSTF_Cb.onCheck = () => {
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            }
        }
    };

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Preview Zoom Level: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.zoomLevelComboBox = new ComboBox(this);
    this.zoomLevelComboBox.addItem("1:1");
    this.zoomLevelComboBox.addItem("1:2");
    this.zoomLevelComboBox.addItem("1:4");
    this.zoomLevelComboBox.addItem("1:8");
    this.zoomLevelComboBox.addItem("Fit to Preview");
    this.zoomLevelComboBox.currentItem = 1;

    // Add a variable to store the previous zoom level
    this.previousZoomLevel = this.zoomLevelComboBox.currentItem;

    this.zoomLevelComboBox.onItemSelected = (index) => {
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Adjusting preview for image with ID: " + parameters.targetWindow.mainView.id);
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();

                // Scale shapes according to the new zoom level
                let newZoomLevel = this.downsamplingFactor;
                this.scaleShapes(newZoomLevel);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for preview!");
        }
    };

    this.resetButton = new ToolButton(this);
    this.resetButton.icon = this.scaledResource(":/icons/execute.png"); // Updated to use the red lightning bolt icon
    this.resetButton.toolTip = "Reset selections";
    this.resetButton.onMousePress = () => {
        this.previewControl.shapes = [];
        this.previewControl.viewport.update();
            // Reset gradient start and end points
    this.previewControl.gradientStartPoint = null;
    this.previewControl.gradientEndPoint = null;
    };

    this.undoButton = new ToolButton(this);
    this.undoButton.icon = this.scaledResource(":/icons/reload.png"); // Updated to use the grey icon for undo
    this.undoButton.toolTip = "Undo last shape";
    this.undoButton.onMousePress = () => {
        if (this.previewControl.shapes.length > 0) {
            // Remove the active shape
            this.previewControl.shapes.splice(this.previewControl.activeShapeIndex, 1);

            // Adjust activeShapeIndex
            if (this.previewControl.shapes.length === 0) {
                this.previewControl.activeShapeIndex = 0; // Reset to 0 if no shapes are left
            } else {
                this.previewControl.activeShapeIndex = this.previewControl.activeShapeIndex % this.previewControl.shapes.length;
            }

            this.previewControl.viewport.update();
        }
    };

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 4;
    this.zoomSizer.add(this.autoSTF_Cb); // Add the AutoSTF checkbox to the sizer
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.add(this.zoomLevelComboBox);
    this.zoomSizer.add(this.undoButton); // Add the undo button next to the zoom control
    this.zoomSizer.add(this.resetButton); // Add the reset button next to the zoom control

    // Define the label for the authorship information
    this.authorship_Lbl = new Label(this);
    this.authorship_Lbl.frameStyle = FrameStyle_Box;
    this.authorship_Lbl.margin = 6;
    this.authorship_Lbl.useRichText = true;
    this.authorship_Lbl.text = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
    this.authorship_Lbl.textAlignment = TextAlign_Center;

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Execute";
    this.execute_Btn.toolTip = "Generate the mask based on the user-defined shapes.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.execute_Btn.onClick = () => {
        console.writeln("Executing the script with the selected parameters.");
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.generateMaskImage(selectedImage);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 6;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.addStretch();
    this.buttonSizerHorizontal.add(this.execute_Btn);

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);


// Zoom In Button
this.zoomInButton = new PushButton(this);
this.zoomInButton.text = "";
this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
this.zoomInButton.toolTip = "Zoom In";
this.zoomInButton.onClick = () => {
    this.previewControl.zoomIn();
};

// Zoom Out Button
this.zoomOutButton = new PushButton(this);
this.zoomOutButton.text = "";
this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
this.zoomOutButton.toolTip = "Zoom Out";
this.zoomOutButton.onClick = () => {
    this.previewControl.zoomOut();
};

// Zoom Label
this.zoomLabel = new Label(this);
this.zoomLabel.text = "Zoom In/Out (Mouse Wheel Supported)";

// Zoom Sizer
this.zoomSizer2 = new HorizontalSizer;
this.zoomSizer2.spacing = 6;
this.zoomSizer2.add(this.zoomInButton);
this.zoomSizer2.add(this.zoomOutButton);
this.zoomSizer2.add(this.zoomLabel);
this.zoomSizer2.addStretch();


// Create a vertical sizer to hold the label and the previewControl
this.previewSizer = new VerticalSizer;
this.previewSizer.spacing = 4;
this.previewSizer.add(this.zoomSizer2);  // Add zoomSizer for buttons
this.previewSizer.add(this.previewControl, 1);

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 4;

    // Define a spacer control with a fixed width
    this.leftSideSpacer = new Control(this);
    this.leftSideSpacer.setFixedWidth(5); // Adjust the width as needed

    // Insert the spacer control at the beginning of the mainSizer
    this.mainSizer.insert(0, this.leftSideSpacer);
    this.mainSizer.addSpacing(0); // Add some spacing after the spacer

    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;
    this.leftSizer.add(this.title_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.instructions_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.imageSelectionSizer); // Add the image selection sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.shapeSizer); // Add the shape type sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.blurAmount_Slider); // Add the blur amount slider
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.maskTypeSizer);
    this.leftSizer.add(this.colorMaskSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.zoomSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.authorship_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.buttonSizerHorizontal);

// Create a control to fix the width of the left panel
this.leftPanel = new Control(this);
this.leftPanel.sizer = this.leftSizer;
this.leftPanel.setFixedWidth(450); // Adjust this value as needed

// Add the leftSizer and the previewSizer to the mainSizer
this.mainSizer.add(this.leftPanel);
this.mainSizer.add(this.previewSizer);

    this.sizer = this.mainSizer;

    this.windowTitle = "Freehand Adaptive Mask Editor (FAME)";
    this.adjustToContents();

    // Add key event listener
    this.onKeyDown = function(keyCode, modifiers) {
        if (keyCode === 0x20) { // Spacebar key
            if (this.previewControl.shapes.length > 0) {
                this.previewControl.activeShapeIndex = (this.previewControl.activeShapeIndex + 1) % this.previewControl.shapes.length;
                this.previewControl.viewport.update();
            }
        }
    }.bind(this);

    // Ensure the initial display setup calls the correct function
    this.onShow = () => {
        if (this.windowSelector_Cb.currentItem >= 0) { // Adjust for "Select Image:" item
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
            if (window && !window.isNull) {
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the initial image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();

                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                }
            }
        } else {
            console.noteln("No image selected for preview.");
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents(); // Adjust the dialog size to fit the initial content
        }

        this.previewControl.setFocus(); // Set focus to handle key events
    };

    // Add a variable to store the downsampling factor
    //this.downsamplingFactor = 1;

    // Function to scale shapes according to the new zoom level
    this.scaleShapes = function(newZoomLevel) {
        try {
            let scaleRatio = this.previousZoomLevel / newZoomLevel;
            this.previewControl.shapes = this.previewControl.shapes.map(shape => shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]));
            this.previousZoomLevel = newZoomLevel;
            if (this.previewControl.viewport) {
                this.previewControl.viewport.update();
            }
        } catch (error) {
            // Suppress any warnings or errors
        }
    };

    // Function to create, resize, and display a temporary image
    this.createAndDisplayTemporaryImage = function(selectedImage) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

        if (this.autoSTF_Cb.checked) {
            var P = new PixelMath;
            P.expression =
                "C = -2.8  ;\n" +
                "B = 0.20  ;\n" +
                "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
            P.expression1 = "";
            P.expression2 = "";
            P.expression3 = "";
            P.useSingleExpression = true;
            P.symbols = "C,B,c";
            P.clearImageCacheAndExit = false;
            P.cacheGeneratedImages = false;
            P.generateOutput = true;
            P.singleThreaded = false;
            P.optimization = true;
            P.use64BitWorkingImage = false;
            P.rescale = false;
            P.rescaleLower = 0;
            P.rescaleUpper = 1;
            P.truncate = true;
            P.truncateLower = 0;
            P.truncateUpper = 1;
            P.createNewImage = false;
            P.showNewImage = true;
            P.newImageId = "";
            P.newImageWidth = 0;
            P.newImageHeight = 0;
            P.newImageAlpha = false;
            P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
            P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
            P.executeOn(window.mainView);
        }

        var P = new IntegerResample;
        switch (this.zoomLevelComboBox.currentItem) {
            case 0: // 1:1
                P.zoomFactor = -1;
                this.downsamplingFactor = 1;
                break;
            case 1: // 1:2
                P.zoomFactor = -2;
                this.downsamplingFactor = 2;
                break;
            case 2: // 1:4
                P.zoomFactor = -4;
                this.downsamplingFactor = 4;
                break;
            case 3: // 1:8
                P.zoomFactor = -8;
                this.downsamplingFactor = 8;
                break;
            case 4: // Fit to Preview
                const previewWidth = this.previewControl.width;
                const widthScale = Math.floor(selectedImage.width / previewWidth);
                P.zoomFactor = -Math.max(widthScale, 1);
                this.downsamplingFactor = Math.max(widthScale, 1);
                break;
            default:
                P.zoomFactor = -2; // Default to 1:2 if nothing is selected
                this.downsamplingFactor = 2;
                break;
        }

        P.executeOn(window.mainView);

        let resizedImage = new Image(window.mainView.image);

        if (resizedImage.width > 0 && resizedImage.height > 0) {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage(resizedImage);
            this.previewControl.initScrollBars();
        } else {
            console.error("Resized image has invalid dimensions.");
        }

        window.forceClose();

        return resizedImage;
    };
}
FAMEDialog.prototype = new Dialog;


// Update mask generation logic to handle the "Color" mask type
function getColorRange(color) {
    switch (color) {
        case "Red":
            return { min: 330, max: 40 }; // Adjusted to be narrower in the orange region
        case "Yellow":
            return { min: 40, max: 85 }; // Adjusted to be narrower in the red region
        case "Green":
            return { min: 85, max: 160 }; // Kept as is
        case "Cyan":
            return { min: 160, max: 200 }; // Kept as is
        case "Blue":
            return { min: 200, max: 270 }; // Kept as is
        case "Magenta":
            return { min: 270, max: 330 }; // Extended into the purple region
        default:
            return { min: 0, max: 0 }; // Default to no range
    }
}

FAMEDialog.prototype.generateMaskImage = function(selectedImage) {
    console.noteln("Mask Creation Started!");
    console.flush();

    let self = this; // Store reference to 'this'

    let gradientStartPoint = this.previewControl.gradientStartPoint;
    let gradientEndPoint = this.previewControl.gradientEndPoint;

    // Check if the image is a mono image
    if (selectedImage.numberOfChannels < 3 && this.maskType === "Color") {
        (new MessageBox("Cannot create a Color Mask from a mono image.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    // Create a new grayscale image with the same dimensions as the original image
    let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let maskImageView = maskWindow.mainView;
    maskImageView.beginProcess(UndoFlag_NoSwapFile);
    let maskImage = maskImageView.image;
    maskImage.fill(0); // Initialize the mask image with black (0)

    // Scale shapes according to the full-size image dimensions
    let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image

    // Function to find the minimum and maximum y-coordinates in the polygon
    function findMinMaxY(polygon) {
        let minY = polygon[0][1];
        let maxY = polygon[0][1];
        for (let i = 1; i < polygon.length; i++) {
            if (polygon[i][1] < minY) minY = polygon[i][1];
            if (polygon[i][1] > maxY) maxY = polygon[i][1];
        }
        return { minY: minY, maxY: maxY };
    }

    // Function to calculate the linear interpolation between two points for the gradient
function interpolateGradient(x, y, startX, startY, endX, endY) {
    let dx = endX - startX;
    let dy = endY - startY;
    let length = Math.sqrt(dx * dx + dy * dy); // Calculate the actual distance (length)

    // Avoid division by zero
    if (length === 0) {
        return 0;
    }

    // Compute the vector from the start point to the current point
    let vx = x - startX;
    let vy = y - startY;

    // Compute the dot product of the vector (vx, vy) with the direction vector (dx, dy)
    let dotProduct = (vx * dx + vy * dy) / length;

    // Normalize the dot product to get t in the range [0, 1]
    let t = dotProduct / length;

    // Clamp the value between 0 and 1 to ensure the gradient doesn't go beyond the endpoints
    return Math.max(0, Math.min(1, t));
}



    // Function to fill a polygon using the scan-line filling algorithm
    function fillPolygon(image, polygon) {
        let { minY, maxY } = findMinMaxY(polygon);

        for (let y = minY; y <= maxY; y++) {
            if (y < 0 || y >= image.height) continue; // Skip out-of-bounds y-coordinates
            let intersections = [];
            for (let i = 0; i < polygon.length; i++) {
                let j = (i + 1) % polygon.length;
                let x1 = polygon[i][0], y1 = polygon[i][1];
                let x2 = polygon[j][0], y2 = polygon[j][1];

                if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) {
                    let x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                    intersections.push(Math.round(x));
                }
            }
            intersections.sort((a, b) => a - b);

            for (let k = 0; k < intersections.length; k += 2) {
                let xStart = Math.max(intersections[k], 0);
                let xEnd = Math.min(intersections[k + 1], image.width - 1);
                for (let x = xStart; x <= xEnd; x++) {
                    if (self.maskType === "Binary") {
                        image.setSample(1, x, y, 0); // Set the pixel to white (1) for binary mask
                    } else if (self.maskType === "Lightness") {
                        let brightness = selectedImage.sample(x, y, 0); // Get the brightness value
                        image.setSample(brightness, x, y, 0); // Set the pixel to brightness value for lightness mask
                    } else if (self.maskType === "Chrominance") {
                        if (selectedImage.numberOfChannels < 3) {
                            console.warningln("Cannot Create a Chrominance Mask of a Grey Scale Image!!!");
                            return;
                        }
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let maxChannel = Math.max(r, g, b);
                        let minChannel = Math.min(r, g, b);
                        let chrominance = (maxChannel - minChannel) / maxChannel; // Calculate chrominance value
                        if (isNaN(chrominance)) chrominance = 0;
                        image.setSample(chrominance, x, y, 0); // Set the pixel to chrominance value for chrominance mask
                    } else if (self.maskType === "Color") {
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let hue = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
                        if (hue < 0) hue += 360;
                        let { min, max } = getColorRange(self.colorDropdown.itemText(self.colorDropdown.currentItem));
                        let colorValue = (min < max)
                            ? (hue >= min && hue <= max ? 1 : 0)
                            : ((hue >= min || hue <= max) ? 1 : 0);
                        let chrominance = (Math.max(r, g, b) - Math.min(r, g, b)) / Math.max(r, g, b); // Calculate chrominance value
                        let sampleValue = colorValue * chrominance; // Scale color value by chrominance
                        if (isNaN(sampleValue)) sampleValue = 0; // Replace NaN with 0
                        image.setSample(sampleValue, x, y, 0); // Scale color value by chrominance
                    } else if (self.maskType === "Gradient") {
    // Scale the gradient start and end points by scaleRatio
    let scaledStartX = gradientStartPoint[0] * scaleRatio;
    let scaledStartY = gradientStartPoint[1] * scaleRatio;
    let scaledEndX = gradientEndPoint[0] * scaleRatio;
    let scaledEndY = gradientEndPoint[1] * scaleRatio;

    // Calculate gradient value for the current pixel within the polygon
    let gradientValue = interpolateGradient(
        x, y,
        scaledStartX, scaledStartY,
        scaledEndX, scaledEndY
    );
    image.setSample(gradientValue, x, y, 0); // Set pixel value to gradient value
}
                }
            }
        }
    }

    // Function to draw thick polylines
    function drawBrushStrokes(image, strokes, thickness, scaleRatio) {
        strokes = strokes.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        thickness = thickness * scaleRatio; // Scale the thickness
        for (let i = 0; i < strokes.length - 1; i++) {
            let p1 = strokes[i];
            let p2 = strokes[i + 1];
            let dx = p2[0] - p1[0];
            let dy = p2[1] - p1[1];
            let length = Math.sqrt(dx * dx + dy * dy);
            let offsetX = -dy / length * thickness / 2;
            let offsetY = dx / length * thickness / 2;

            let polyline = [
                [p1[0] + offsetX, p1[1] + offsetY],
                [p1[0] - offsetX, p1[1] - offsetY],
                [p2[0] - offsetX, p2[1] - offsetY],
                [p2[0] + offsetX, p2[1] + offsetY]
            ];

            fillPolygon(image, polyline);
        }
    }

    // Function to draw spray can points directly onto the mask image
    function drawSprayCanPoints(image, strokes) {
        strokes.forEach(point => {
            let x = point[0];
            let y = point[1];
            if (x >= 0 && x < image.width && y >= 0 && y < image.height) {
                image.setSample(1, x, y, 0); // Set the pixel value to 1 for spray can points
            }
        });
    }

    // Function to scale spray can points according to the full-size image dimensions
    function scaleSprayCanPoints(points, scaleRatio) {
        let scaledPoints = [];
        points.forEach(point => {
            let x = Math.round(point[0] * scaleRatio);
            let y = Math.round(point[1] * scaleRatio);
            for (let dx = 0; dx < scaleRatio; dx++) {
                for (let dy = 0; dy < scaleRatio; dy++) {
                    scaledPoints.push([x + dx, y + dy]);
                }
            }
        });
        return scaledPoints;
    }

    // Fill the mask image with the appropriate values inside the user-defined shapes
    this.previewControl.shapes.forEach((shape, index) => {
        let scaledShape = shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        if (self.previewControl.shapeTypes[index] === "Brush") {
            drawBrushStrokes(maskImage, shape, self.previewControl.brushRadius, scaleRatio);
        } else if (self.previewControl.shapeTypes[index] === "SprayCan") {
            let scaledSprayCanPoints = scaleSprayCanPoints(shape, scaleRatio);
            drawSprayCanPoints(maskImage, scaledSprayCanPoints);
        } else {
            fillPolygon(maskImage, scaledShape);
        }
    });

    maskImageView.endProcess();

    // Set mask window ID based on mask type
    let maskSuffix = "";
    if (this.maskType === "Binary") {
        maskSuffix = "_bin";
    } else if (this.maskType === "Lightness") {
        maskSuffix = "_lght";
    } else if (this.maskType === "Chrominance") {
        maskSuffix = "_chrm";
    } else if (this.maskType === "Color") {
        maskSuffix = "_color";
    } else if (self.gradientMask_Cb && self.gradientMask_Cb.checked) {
        maskSuffix = "_gradient";
    }

    maskImageView.id = parameters.targetWindow.mainView.id + "_FAME_Mask" + maskSuffix;
    maskWindow.show();

// Apply convolution to blur the mask image
var blurAmount = this.blurAmount_Slider.value;
if (blurAmount > 0) {
    var P = new Convolution;
    P.mode = Convolution.prototype.Parametric;
    P.sigma = blurAmount;
    P.executeOn(maskImageView);
} else {
    console.writeln("Skipping convolution as blurAmount is 0.");
    console.flush();
}

};


function main() {
    console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new FAMEDialog();
    dialog.execute();
}

main();
