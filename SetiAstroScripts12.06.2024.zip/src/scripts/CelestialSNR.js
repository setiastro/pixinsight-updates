#feature-id    ObjectSNR : SetiAstro > Object SNR Calculation

#feature-info  This script calculates the Signal-to-Noise Ratio (SNR) for a selected region of interest (signal) against a background region. The user can select the regions from the available previews in the active image.<br/>

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>

// include constants
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

function ImprovedSNRDialog() {
    this.__base__ = Dialog;
    this.__base__();

    var window = ImageWindow.activeWindow;
    if (window.isNull) {
        throw new Error("No active image window!");
    }

    var previews = window.previews;
    if (previews.length == 0) {
        (new MessageBox("You must define the target and background preview first.", "Error", StdIcon_Error, StdButton_Ok)).execute();
throw new Error("No previews found in the active image!");
      this.cancel();
        return;
    }


        // Instruction Box
    this.instructions = new Label(this);
    this.instructions.text = "Instructions: Select the regions for Signal of Interest and Background.\n"
                           + "The script will calculate the Signal-to-Noise Ratio (SNR) for each channel\n"
                           + "of the selected regions and display the results in the console.";
    this.instructions.wordWrap = true;

    // Create dropdown for Signal Region
    this.signalLabel = new Label(this);
    this.signalLabel.text = "Select Signal of Interest Region:";

    this.signalComboBox = new ComboBox(this);
    this.signalComboBox.editEnabled = false;
    for (var i = 0; i < previews.length; ++i) {
        this.signalComboBox.addItem(window.mainView.id + "->" + previews[i].id);
    }

    // Create dropdown for Background Region
    this.backgroundLabel = new Label(this);
    this.backgroundLabel.text = "Select Background Region:";

    this.backgroundComboBox = new ComboBox(this);
    this.backgroundComboBox.editEnabled = false;
    for (var i = 0; i < previews.length; ++i) {
        this.backgroundComboBox.addItem(window.mainView.id + "->" + previews[i].id);
    }

    // Execute button
    this.executeButton = new PushButton(this);
    this.executeButton.text = "Calculate SNR";
    this.executeButton.onClick = function () {
        var signalPreview = window.previewById(previews[this.dialog.signalComboBox.currentItem].id).image;
        var backgroundPreview = window.previewById(previews[this.dialog.backgroundComboBox.currentItem].id).image;

        calculateImprovedSNR(signalPreview, backgroundPreview);
    };

    // Set layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 4;
    this.sizer.add(this.instructions);
    this.sizer.addSpacing(8);
    this.sizer.add(this.signalLabel);
    this.sizer.add(this.signalComboBox);
    this.sizer.addSpacing(8);
    this.sizer.add(this.backgroundLabel);
    this.sizer.add(this.backgroundComboBox);
    this.sizer.addSpacing(8);
    this.sizer.add(this.executeButton);

    this.windowTitle = "Object's SNR Calculation";
    this.adjustToContents();
    this.setFixedSize();
}

ImprovedSNRDialog.prototype = new Dialog;

function calculateImprovedSNR(signalRegion, backgroundRegion) {
    console.show();
    console.writeln("<end><cbr><br>Calculating Improved SNR");
    console.abortEnabled = true;

    for (var c = 0; c < signalRegion.numberOfChannels; ++c) {
        console.writeln("<end><cbr><br>* Channel #", c);
        console.flush();

        signalRegion.selectedChannel = c;
        backgroundRegion.selectedChannel = c;

        // Measure the total signal in the object region (including background)
        var Stotal = signalRegion.median();

        // Measure the background signal and noise from the background region
        var backgroundMedian = backgroundRegion.median();
        var backgroundStdDev = backgroundRegion.stdDev();

        // Subtract the background to get the true object signal
        var So = Math.max(Stotal - backgroundMedian, 0);  // Ensure So is non-negative

        // Estimate noise (combining sky background, dark current, and read noise)
        var noise = backgroundStdDev;  // Assume noise estimate from std dev
        var Sd = 0; // Dark current could be assumed as a constant if known
        var R2 = noise * noise; // Read noise squared

        // Calculate SNR using the improved formula
        var snr = So / Math.sqrt(Sd + R2);

        // Convert SNR to decibels
        var snr_db = 10 * Math.log10(snr);

        console.writeln(format("Object SNR = %.3e, %.2f dB", snr, snr_db));
        console.flush();
    }

    console.writeln("<end><cbr><br>SNR Calculation Complete.");
}

function main() {
       Console.show();  // Show the console
Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");

    var dialog = new ImprovedSNRDialog();
    dialog.execute();
}

main();
