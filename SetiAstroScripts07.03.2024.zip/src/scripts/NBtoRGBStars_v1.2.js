#feature-id NBtoRGBStars_v1.5 : SetiAstro > NB to RGB Star Combination
#feature-info This script performs a combination of NB stars only images and produces a realistic RGB star image. It also has the option to perform a non-linear Star Stretch on the output.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * NB to RGB Stars Script
 * Version: 1.5
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is designed for the automatic removal of gradients in
 * astrophotographic images.  It includes finding starting points via
 * gradient descent, custom weighting scores, and custom rejection algorithms
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>

var SHOParameters = {
    HaView: undefined,
    OIIIView: undefined,
    SIIView: undefined, // Optional
    OSCView: undefined, // OSC image for dual band filter
    applyStarStretch: false, // Store the state of the star stretch feature
    stretchFactor: 5, // Default stretch factor
    colorBoost: 1.0, // Default value
    haToOiiRatio: 0.3, // Default ratio value
    showPreview: false, // Default Show Preview option

    save: function() {
        Parameters.set("HaView", this.HaView ? this.HaView.id : "");
        Parameters.set("OIIIView", this.OIIIView ? this.OIIIView.id : "");
        Parameters.set("SIIView", this.SIIView ? this.SIIView.id : "");
        Parameters.set("OSCView", this.OSCView ? this.OSCView.id : "");
        Parameters.set("applyStarStretch", this.applyStarStretch);
        Parameters.set("stretchFactor", this.stretchFactor);
        Parameters.set("colorBoost", this.colorBoost);
        Parameters.set("haToOiiRatio", this.haToOiiRatio);
        Parameters.set("showPreview", this.showPreview);
    },

    load: function() {
        if (Parameters.has("HaView"))
            this.HaView = ImageWindow.windowById(Parameters.getString("HaView")).mainView;
        if (Parameters.has("OIIIView"))
            this.OIIIView = ImageWindow.windowById(Parameters.getString("OIIIView")).mainView;
        if (Parameters.has("SIIView") && Parameters.getString("SIIView") !== "")
            this.SIIView = ImageWindow.windowById(Parameters.getString("SIIView")).mainView;
        if (Parameters.has("OSCView") && Parameters.getString("OSCView") !== "")
            this.OSCView = ImageWindow.windowById(Parameters.getString("OSCView")).mainView;
        if (Parameters.has("applyStarStretch"))
            this.applyStarStretch = Parameters.getBoolean("applyStarStretch");
        if (Parameters.has("stretchFactor"))
            this.stretchFactor = Parameters.getReal("stretchFactor");
        if (Parameters.has("colorBoost"))
            this.colorBoost = Parameters.getReal("colorBoost");
        if (Parameters.has("haToOiiRatio"))
            this.haToOiiRatio = Parameters.getReal("haToOiiRatio");
        if (Parameters.has("showPreview"))
            this.showPreview = Parameters.getBoolean("showPreview");
    }
};

// ScrollControl class definition
function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function SHODialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.userResizable = true;
    this.scaledMinWidth = 450;

    // Title setup
    this.title = new TextBox(this);
    this.title.text = "<b>NB to RGB Star Combination Tool v1.5</b><br>Select the H-alpha, OIII, and optionally SII star images for combination. \n\nYou can also select your OSC Image if a dual NB filter is used.  \n\nIf checked it will also perform a linear to non-linear Star Stretch on the output image.";
    this.title.readOnly = true;
    this.title.backgroundColor = 0xf7f7c625;
    this.title.minHeight = 140;
    this.title.maxHeight = 140;

    // Ha setup
    this.HaLabel = new Label(this);
    this.HaLabel.text = "Ha Stars Image:";
    this.HaViewList = new ViewList(this);
    this.HaViewList.getAll();
    this.HaViewList.onViewSelected = (view) => { SHOParameters.HaView = view; };
    this.HaViewList.maxWidth = 275; // Set the maximum width to 250 pixels

    this.HaSizer = new HorizontalSizer;
    this.HaSizer.add(this.HaLabel);
    this.HaSizer.add(this.HaViewList);

    // OIII setup
    this.OIIILabel = new Label(this);
    this.OIIILabel.text = "OIII Stars Image:";
    this.OIIIViewList = new ViewList(this);
    this.OIIIViewList.getAll();
    this.OIIIViewList.onViewSelected = (view) => { SHOParameters.OIIIView = view; };
    this.OIIIViewList.maxWidth = 275; // Set the maximum width to 250 pixels

    this.OIIISizer = new HorizontalSizer;
    this.OIIISizer.add(this.OIIILabel);
    this.OIIISizer.add(this.OIIIViewList);

    // SII setup
    this.SIILabel = new Label(this);
    this.SIILabel.text = "SII Stars Image (optional):";
    this.SIIViewList = new ViewList(this);
    this.SIIViewList.getAll();
    this.SIIViewList.onViewSelected = (view) => { SHOParameters.SIIView = view; };
    this.SIIViewList.maxWidth = 275; // Set the maximum width to 250 pixels

    this.SIISizer = new HorizontalSizer;
    this.SIISizer.add(this.SIILabel);
    this.SIISizer.add(this.SIIViewList);

    // OR label
    this.orLabel = new Label(this);
    this.orLabel.text = "OR";
    this.orLabel.textAlignment = TextAlign_Center;

    // OSC setup
    this.OSCLabel = new Label(this);
    this.OSCLabel.text = "OSC (for dual band filter) Image:";
    this.OSCViewList = new ViewList(this);
    this.OSCViewList.getAll();
    this.OSCViewList.onViewSelected = (view) => { SHOParameters.OSCView = view; };
    this.OSCViewList.maxWidth = 275; // Set the maximum width to 250 pixels

    this.OSCSizer = new HorizontalSizer;
    this.OSCSizer.add(this.OSCLabel);
    this.OSCSizer.add(this.OSCViewList);

    // Checkbox for Green Channel Blend Ratio
    this.greenChannelCheckBox = new CheckBox(this);
    this.greenChannelCheckBox.text = "Green Channel Blend Ratio (Optional)";
    this.greenChannelCheckBox.checked = false; // Start unchecked
    this.greenChannelCheckBox.toolTip = "Enable the green channel blend ratio adjustment.";
    this.greenChannelCheckBox.onCheck = function(checked) {
        SHOParameters.haToOiiRatio = checked ? SHOParameters.haToOiiRatio : 0.3;
        this.dialog.haToOiiRatioControl.visible = checked;
    }.bind(this); // Ensure 'this' within the function refers to the dialog instance

    // NumericControl for Ha to OIII Ratio
    this.haToOiiRatioControl = new NumericControl(this);
    this.haToOiiRatioControl.label.text = "Ha to OIII ratio:";
    this.haToOiiRatioControl.setRange(0, 1);
    this.haToOiiRatioControl.slider.setRange(0, 100);
    this.haToOiiRatioControl.setValue(SHOParameters.haToOiiRatio);
    this.haToOiiRatioControl.setPrecision(2);
    this.haToOiiRatioControl.onValueUpdated = function(value) {
        SHOParameters.haToOiiRatio = value;
    };
    this.haToOiiRatioControl.visible = false; // Initially hidden

    // Checkbox for Star Stretch
    this.starStretchCheckBox = new CheckBox(this);
    this.starStretchCheckBox.text = "Apply Star Stretch (Recommended)";
    this.starStretchCheckBox.checked = false; // Start unchecked
    this.starStretchCheckBox.toolTip = "Enable additional stretching and color saturation adjustments.";
    this.starStretchCheckBox.onCheck = function(checked) {
        SHOParameters.applyStarStretch = checked;
        // Update visibility based on checkbox state
        this.dialog.stretchFactorControl.visible = checked;
        this.dialog.colorBoostControl.visible = checked;
    }.bind(this); // Ensure 'this' within the function refers to the dialog instance

    // NumericControl for stretchFactor
    this.stretchFactorControl = new NumericControl(this);
    this.stretchFactorControl.label.text = "Stretch Factor:";
    this.stretchFactorControl.setRange(0, 8);
    this.stretchFactorControl.slider.setRange(10, 100);
    this.stretchFactorControl.setValue(5);
    this.stretchFactorControl.setPrecision(2);
    this.stretchFactorControl.onValueUpdated = function(value) {
        SHOParameters.stretchFactor = value;
    };
    this.stretchFactorControl.visible = false; // Initially hidden

    // NumericControl for Color Boost
    this.colorBoostControl = new NumericControl(this);
    this.colorBoostControl.label.text = "Color Boost:";
    this.colorBoostControl.setRange(0, 3); // Range from 0 to 3
    this.colorBoostControl.slider.setRange(0, 300); // 300 steps
    this.colorBoostControl.setValue(SHOParameters.colorBoost);
    this.colorBoostControl.setPrecision(2);
    this.colorBoostControl.onValueUpdated = function(value) {
        SHOParameters.colorBoost = value;
    };
    this.colorBoostControl.visible = false; // Initially hidden

    // Checkbox for Show Preview
    this.showPreviewCheckBox = new CheckBox(this);
    this.showPreviewCheckBox.text = "Show Preview";
    this.showPreviewCheckBox.checked = SHOParameters.showPreview;
    this.showPreviewCheckBox.toolTip = "<p>Enable or disable preview of the stretch.</p>";
    this.showPreviewCheckBox.onCheck = function(checked) {
        SHOParameters.showPreview = checked;
        this.previewControl.visible = checked;
        this.zoomSizer.visible = checked;
        if (checked && (SHOParameters.HaView || SHOParameters.OSCView)) {
            let tmpImage = this.createAndDisplayTemporaryImage();
            if (tmpImage) {
                this.previewControl.displayImage = tmpImage;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
            }
        }
        this.adjustToContents();
    }.bind(this);

    // Add create instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = () => {
        SHOParameters.save();
        this.newInstance();
    };

    // Create zoom dropdown
    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Zoom: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.zoomComboBox = new ComboBox(this);
    this.zoomComboBox.addItem("1:1");
    this.zoomComboBox.addItem("1:2");
    this.zoomComboBox.addItem("1:4");
    this.zoomComboBox.addItem("1:8");
    this.zoomComboBox.addItem("Fit to Preview");
    this.zoomComboBox.currentItem = 2; // Set default to "1:4"
    this.zoomComboBox.minWidth = 120; // Set minimum width
    this.zoomComboBox.onItemSelected = (index) => {
        this.previewControl.zoomFactor = -Math.pow(2, index);
        if (SHOParameters.showPreview) {
            this.refreshPreview();
        }
    };

    // Create preview refresh button
    this.previewRefreshButton = new PushButton(this);
    this.previewRefreshButton.text = "Refresh Preview";
    this.previewRefreshButton.minWidth = 120; // Set minimum width
    this.previewRefreshButton.onClick = () => {
        this.refreshPreview();
    };

    // Create a sizer for zoom controls and refresh button
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.margin = 4;
    this.zoomSizer.spacing = 4;
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.add(this.zoomComboBox);
    this.zoomSizer.addSpacing(12);
    this.zoomSizer.add(this.previewRefreshButton);

    // prepare the execution button
    this.execButton = new PushButton(this);
    this.execButton.text = "Execute";
    this.execButton.width = 80; // Increased width
    this.execButton.onClick = () => {
        this.processImages();
        this.ok();
    };

    // create a horizontal slider to layout the execution button
    this.execButtonSizer = new HorizontalSizer;
    this.execButtonSizer.margin = 8;
    this.execButtonSizer.add(this.newInstanceButton)
    this.execButtonSizer.addSpacing(12);
    this.execButtonSizer.add(this.zoomSizer);
    this.execButtonSizer.addStretch();
    this.execButtonSizer.add(this.execButton)

    // Create a preview control
    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(300);  // Set minimum width to avoid taking too much space
    this.previewControl.setMinHeight(300); // Set minimum height
    this.previewControl.visible = false;   // Hide preview control initially

    // layout the dialog
    this.leftSizer = new VerticalSizer;
    this.leftSizer.margin = 8;
    this.leftSizer.spacing = 8;
    this.leftSizer.add(this.title);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.HaSizer);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.OIIISizer);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.SIISizer);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.orLabel);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.OSCSizer);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.greenChannelCheckBox);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.haToOiiRatioControl);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.starStretchCheckBox);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.stretchFactorControl);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.colorBoostControl);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.showPreviewCheckBox);
    this.leftSizer.addSpacing(8);
    this.leftSizer.add(this.execButtonSizer);
    this.leftSizer.addStretch();
    this.leftSizer.minWidth = 300; // Set minimum width for left sizer

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.margin = 8;
    this.mainSizer.spacing = 8;
    this.mainSizer.add(this.leftSizer);
    this.mainSizer.add(this.previewControl, 1, Align_Expand);  // Ensure preview control gets allocated proper space

    this.sizer = this.mainSizer;

    this.adjustToContents();

    this.onShow = () => {
        this.previewControl.visible = false;
        this.zoomSizer.visible = false;
        this.adjustToContents();
    };

    this.createAndDisplayTemporaryImage = function() {
        let oldIDs = getAllImageIDs();
        let newImageId = combineNBtoRGB(true); // Pass a flag to skip showing the image
        if (newImageId) {
            applyAdjustments(newImageId, true); // Pass a flag to skip showing the image
            let newImage = ImageWindow.windowById(newImageId).mainView.image;

            let window = new ImageWindow(
                newImage.width, newImage.height,
                newImage.numberOfChannels,
                newImage.bitsPerSample,
                newImage.isReal,
                newImage.isColor
            );

            window.mainView.beginProcess();
            window.mainView.image.assign(newImage);
            window.mainView.endProcess();

            var P = new IntegerResample;
            switch (this.zoomComboBox.currentItem) {
                case 0:
                    P.zoomFactor = -1;
                    break;
                case 1:
                    P.zoomFactor = -2;
                    break;
                case 2:
                    P.zoomFactor = -4;
                    break;
                case 3:
                    P.zoomFactor = -8;
                    break;
                case 4:
                    const previewWidth = this.previewControl.width;
                    const widthScale = Math.floor(newImage.width / previewWidth);
                    P.zoomFactor = -Math.max(widthScale, 1);
                    break;
                default:
                    P.zoomFactor = -2;
                    break;
            }

            P.executeOn(window.mainView);

            let resizedImage = new Image(window.mainView.image);

            if (resizedImage.width > 0 && resizedImage.height > 0) {
                this.previewControl.displayImage = resizedImage;
                this.previewControl.doUpdateImage(resizedImage);
                this.previewControl.initScrollBars();
            } else {
                console.error("Resized image has invalid dimensions.");
            }

            window.forceClose();

            // Clean up the temporary image
            ImageWindow.windowById(newImageId).forceClose();

            return resizedImage;
        } else {
            Console.criticalln("Error creating the new image. Please check the settings.");
            return null;
        }
    };

    this.refreshPreview = function() {
        if (SHOParameters.showPreview && (SHOParameters.HaView || SHOParameters.OSCView)) {
            let tmpImage = this.createAndDisplayTemporaryImage();
            if (tmpImage) {
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            } else {
                console.writeln("Failed to create a temporary image for preview.");
            }
        }
    };

    this.processImages = function() {
        if ((!SHOParameters.HaView || !SHOParameters.OIIIView) && !SHOParameters.OSCView) {
            Console.warningln("Please ensure H-alpha and OIII images are selected, or an OSC image is selected.");
            return;
        }

        let extractedChannels = [];
        if (SHOParameters.OSCView) {
            extractChannelsFromOSC(SHOParameters.OSCView.id, extractedChannels);
        }

        let newImageId = combineNBtoRGB();
        if (newImageId) {
            applyAdjustments(newImageId);
            closeExtractedChannels(extractedChannels);
            Console.noteln("NB to RGB Star Process Complete");
        } else {
            Console.criticalln("Error creating the new image. Please check the settings.");
        }

        Console.show();
    };
}

SHODialog.prototype = new Dialog;

function main() {
    Console.show();
    console.criticalln("        ___     __      ___       __                               \n       / __/___/ /__   / _ | ___ / /________                       ");
    console.warningln("        _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                     \n      /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                      ");

    if (Parameters.isGlobalTarget) {
        // Block execution in global context to prevent issues
        Console.criticalln("This script cannot run in a global context.");
        return;
    }

    // Allow dialog to open in both direct view and normal contexts
    let dialog = new SHODialog();
    dialog.execute();
}

function processImages() {
    if ((!SHOParameters.HaView || !SHOParameters.OIIIView) && !SHOParameters.OSCView) {
        Console.warningln("Please ensure H-alpha and OIII images are selected, or an OSC image is selected.");
        return;
    }

    let extractedChannels = [];
    if (SHOParameters.OSCView) {
        extractChannelsFromOSC(SHOParameters.OSCView.id, extractedChannels);
    }

    let newImageId = combineNBtoRGB();
    if (newImageId) {
        applyAdjustments(newImageId);
        closeExtractedChannels(extractedChannels);
        Console.noteln("NB to RGB Star Process Complete");
    } else {
        Console.criticalln("Error creating the new image. Please check the settings.");
    }

    Console.show();
}

function getAllImageIDs() {
    var windows = ImageWindow.windows;
    var ids = [];
    for (var i = 0; i < windows.length; ++i) {
        ids.push(windows[i].mainView.id);
    }
    return ids;
}

function findNewImageID(oldIDs, newIDs) {
    for (var i = 0; i < newIDs.length; i++) {
        var found = false;
        // Check if newIDs[i] is in oldIDs
        for (var j = 0; j < oldIDs.length; j++) {
            if (newIDs[i] === oldIDs[j]) {
                found = true;
                break;
            }
        }
        // If newIDs[i] was not found in oldIDs, return it
        if (!found) {
            return newIDs[i];
        }
    }
    return null; // Return null if no new ID is found
}

function extractChannel(imageId, channelIndex, suffix, extractedChannels) {
    let P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.prototype.RGB;
    P.channels = [
        [channelIndex === 0, ""],
        [channelIndex === 1, ""],
        [channelIndex === 2, ""]
    ];
    P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
    P.inheritAstrometricSolution = true;
    P.executeOn(ImageWindow.windowById(imageId).mainView);
    let extractedImage = ImageWindow.activeWindow;
    extractedImage.mainView.id = imageId + suffix;
    extractedChannels.push(extractedImage.mainView.id);
    return extractedImage.mainView.id;
}

function extractChannelsFromOSC(imageId, extractedChannels) {
    SHOParameters.HaView = ImageWindow.windowById(extractChannel(imageId, 0, "_Ha", extractedChannels)).mainView;
    SHOParameters.OIIIView = ImageWindow.windowById(extractChannel(imageId, 1, "_OIII", extractedChannels)).mainView;
}

function closeExtractedChannels(extractedChannels) {
    for (let i = 0; i < extractedChannels.length; i++) {
        let window = ImageWindow.windowById(extractedChannels[i]);
        if (window) {
            window.forceClose();
        }
    }
}

function combineNBtoRGB(skipShowingImage) {
    var oldIDs = getAllImageIDs(); // Get all image IDs before execution
    console.writeln("Old IDs: " + oldIDs.join(", "));  // Debug output to check IDs

    var P = new PixelMath;
    P.expression = "0.5*" + SHOParameters.HaView.id + " + 0.5*" + (SHOParameters.SIIView ? SHOParameters.SIIView.id : SHOParameters.HaView.id);
    P.expression1 = SHOParameters.haToOiiRatio + "*" + SHOParameters.HaView.id + " + ~" + SHOParameters.haToOiiRatio + "*" + SHOParameters.OIIIView.id;
    P.expression2 = SHOParameters.OIIIView.id;
    P.expression3 = "";
    P.useSingleExpression = false;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = true;
    P.showNewImage = !skipShowingImage;
    P.newImageId = "NBtoRGB_stars";  // Let PixInsight handle suffixes automatically
    P.newImageWidth = 0; // Use existing width
    P.newImageHeight = 0; // Use existing height
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.RGB;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
    P.executeOn(SHOParameters.HaView);

    var newIDs = getAllImageIDs(); // Get all image IDs after execution
    console.writeln("Check newIDs after PixelMath: " + newIDs.join(", "));  // Debug output to check IDs
    var newImageId = findNewImageID(oldIDs, newIDs); // Determine the new image ID using the modified function

    return newImageId; // Return the actual new image ID created by PixelMath
}

function applyAdjustments(newImageId, skipShowingImage) {
    var targetView = ImageWindow.windowById(newImageId) ? ImageWindow.windowById(newImageId).mainView : null;
    if (!targetView) {
        Console.criticalln("Error: Image view not found for ID " + newImageId);
        return;
    }

    // Apply initial adjustments
    applySCNR(targetView);
    applyMTF(targetView);

    // Apply second SCNR to clean up any green noise introduced
    applySCNR(targetView);

    // Reverse the MTF adjustments to normalize the tone mapping
    reverseMTF(targetView);

    // Apply star stretch last if enabled
    if (SHOParameters.applyStarStretch) {
        applyStarStretch(targetView);
    }

    // Optionally, output a console message indicating completion of all adjustments
    Console.noteln("All adjustments including optional star stretch (if applied) are complete.");

    if (skipShowingImage) {
        ImageWindow.windowById(newImageId).hide();
    }
}

function applySCNR(view) {
    var P = new SCNR;
    P.amount = 1.00;
    P.protectionMethod = SCNR.prototype.AverageNeutral;
    P.colorToRemove = SCNR.prototype.Green;
    P.preserveLightness = true;
    P.executeOn(view);
}

function applyMTF(view) {
    var P = new PixelMath;
    P.expression = "mtf(0.01, $T)";
    P.useSingleExpression = true;
    P.executeOn(view);
}

function reverseMTF(view) {
    var P = new PixelMath;
    P.expression = "mtf(~0.01, $T)";
    P.useSingleExpression = true;
    P.executeOn(view);
}

function applyStarStretch(view) {
    // Retrieve stretchFactor from SHOParameters
    var stretchFactor = SHOParameters.stretchFactor || 5; // Default to 5 if undefined
    var colorBoost = SHOParameters.colorBoost || 1.0; // Ensure a default value

    // Apply PixelMath for stretching
    var P = new PixelMath;
    P.expression = "((3^" + stretchFactor + ")*$T)/((3^" + stretchFactor + "-1)*$T+1)"; // Dynamic PixelMath formula using stretchFactor
    P.useSingleExpression = true;
    P.executeOn(view);

    // Apply ColorSaturation with the provided matrix
    var C = new ColorSaturation;
    C.HS = [
        [0.00000, colorBoost * 0.40000],
        [0.50000, colorBoost * 0.70000],
        [1.00000, colorBoost * 0.40000]
    ];
    C.HSt = ColorSaturation.prototype.AkimaSubsplines;
    C.hueShift = 0.000; // No hue shift by default

    C.executeOn(view);
}

main();
