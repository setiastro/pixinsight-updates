#feature-id BlemishBlaster : SetiAstro > Blemish Blaster
#feature-info This script allows blemish removal in astrophotographic images by averaging the surrounding area to replace the selected spot.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blemish Blaster
 * Version: V2.4.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows blemish removal in astrophotographic images by averaging
 * the surrounding area to replace the selected spot.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/BitmapInterpolation.jsh>
#include <pjsr/StarDetector.jsh>


#define TITLE "Blemish Blaster"
#define VERSION "V2.4.1"

let parameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    autoSTFApplied: false,
    drawingMode: "Circle", // "Circle" or "Freehand"
    save: function() {
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        Parameters.set("autoSTFApplied", this.autoSTFApplied ? "true" : "false");
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function() {
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("autoSTFApplied")) {
            this.autoSTFApplied = Parameters.getBoolean("autoSTFApplied");
        }
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
    },
    newInstance: function() {
        console.writeln("New instance created.");
    }
};

/// Function to detect and draw the satellite trail
function detectAndDrawSatelliteTrail(parent, startX, startY) {
    const searchRadius = 20; // Increased search radius
    const brightnessThreshold = 1.5 * parent.displayImage.median(); // Adjusted brightness threshold to 1.5 * image median
    let allTrailPoints = [{ x: startX, y: startY }]; // Initialize array to store all points

    // Calculate the maximum number of steps based on image diagonal
    const imageWidth = parent.displayImage.width;
    const imageHeight = parent.displayImage.height;
    const maxSteps = 10*Math.floor(Math.sqrt(imageWidth * imageWidth + imageHeight * imageHeight) / searchRadius);

    console.writeln("Starting trail detection...");
    console.flush();

    // Search for the trail points in both directions from the starting point
    searchTrail(parent, startX, startY, searchRadius, brightnessThreshold, -1, allTrailPoints, maxSteps);
    searchTrail(parent, startX, startY, searchRadius, brightnessThreshold, 1, allTrailPoints, maxSteps);

    // Sort the points based on their x-coordinates (and y-coordinates if x-coordinates are the same)
    allTrailPoints.sort((a, b) => (a.x - b.x) || (a.y - b.y));

    if (allTrailPoints.length > 1) {
        parent.satelliteTrails.push({ start: allTrailPoints[0], end: allTrailPoints[allTrailPoints.length - 1] });
        parent.viewport.update();
    }
}

function searchTrail(parent, startX, startY, searchRadius, brightnessThreshold, directionMultiplier, trailPoints, maxSteps) {
    let endX = startX;
    let endY = startY;
    let steps = 0;
    let previousBrightness = getPointBrightness(parent.displayImage, startX, startY);

    while (steps < maxSteps) {
        const direction = findTrailDirection(parent, endX, endY, searchRadius, brightnessThreshold, directionMultiplier * Math.PI, Math.PI);
        if (!direction) {
            break;
        }

        let nextX = Math.round(endX + directionMultiplier * direction.dx);
        let nextY = Math.round(endY + directionMultiplier * direction.dy);

        if (!isPointWithinImageBounds(parent.displayImage, nextX, nextY)) {
            break;
        }

        let brightestY = nextY;
        let brightestBrightness = getPointBrightness(parent.displayImage, nextX, nextY);

        // Search for a brighter point within a vertical range around the new point
        for (let offsetY = -5; offsetY <= 5; offsetY++) {
            let checkY = nextY + offsetY;
            if (isPointWithinImageBounds(parent.displayImage, nextX, checkY)) {
                let brightness = getPointBrightness(parent.displayImage, nextX, checkY);
                if (brightness > brightestBrightness) {
                    brightestBrightness = brightness;
                    brightestY = checkY;
                }
            }
        }

        nextY = brightestY;

        if (isBrightPoint(parent.displayImage, nextX, nextY, brightnessThreshold)) {
            endX = nextX;
            endY = nextY;
            trailPoints.push({ x: endX, y: endY });
        } else {
            endX = nextX;
            endY = nextY;
        }

        steps++;
    }
}

// Function to find the direction of the trail
function findTrailDirection(parent, startX, startY, searchRadius, brightnessThreshold, startAngle, angleRange) {
    const numDirections = 18; // Number of directions to sample around the half circle
    const angleIncrement = angleRange / numDirections;
    let bestDirection = null;
    let bestSumBrightness = 0;

    for (let i = 0; i <= numDirections; i++) {
        const angle = startAngle + i * angleIncrement;
        const dir = { dx: Math.cos(angle), dy: Math.sin(angle) };

        let sumBrightness = 0;
        let validPoints = 0;
        for (let step = -searchRadius; step <= searchRadius; step++) {
            let x = startX + step * dir.dx;
            let y = startY + step * dir.dy;
            if (isPointWithinImageBounds(parent.displayImage, x, y)) {
                sumBrightness += getPointBrightness(parent.displayImage, x, y);
                validPoints++;
            }
        }

        if (validPoints > 0) {
            sumBrightness /= validPoints;
        }

        if (sumBrightness > bestSumBrightness) {
            bestSumBrightness = sumBrightness;
            bestDirection = dir;
        }
    }
    return bestDirection && bestSumBrightness > brightnessThreshold ? bestDirection : null;
}

// Helper functions
function isPointWithinImageBounds(image, x, y) {
    return x >= 0 && x < image.width && y >= 0 && y < image.height;
}

function getPointBrightness(image, x, y) {
    let brightness = 0;
    for (let c = 0; c < image.numberOfChannels; c++) {
        brightness += image.sample(x, y, c);
    }
    return brightness / image.numberOfChannels;
}

function isBrightPoint(image, x, y, threshold) {
    return getPointBrightness(image, x, y) > threshold;
}

// Determine if a point is inside the freehand shape using the ray-casting algorithm
function isPointInShape(x, y, shape) {
    let crossings = 0;
    for (let i = 0; i < shape.length; i++) {
        let x1 = shape[i].x;
        let y1 = shape[i].y;
        let x2 = shape[(i + 1) % shape.length].x;
        let y2 = shape[(i + 1) % shape.length].y;

        if (((y1 <= y && y < y2) || (y2 <= y && y < y1)) &&
            (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1)) {
            crossings++;
        }
    }
    return crossings % 2 != 0;
}

// Calculate the center point and radius for the freehand shape
function calculateFreehandCenterAndRadius(shape) {
    let sumX = 0, sumY = 0;
    for (let i = 0; i < shape.length; i++) {
        sumX += shape[i].x;
        sumY += shape[i].y;
    }
    let centerX = sumX / shape.length;
    let centerY = sumY / shape.length;

    let maxDistance = 0;
    for (let i = 0; i < shape.length; i++) {
        let distance = Math.sqrt(Math.pow(shape[i].x - centerX, 2) + Math.pow(shape[i].y - centerY, 2));
        if (distance > maxDistance) {
            maxDistance = distance;
        }
    }

    return { centerX: centerX, centerY: centerY, radius: maxDistance };
}

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.displayImageWindow = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.debugPoints = [];
    this.currentCircle = null;
    this.currentLine = null;
    this.satelliteTrails = [];
    this.freehandShapes = [];
    this.currentFreehandShape = null;

    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.zoom = 1;
    this.scale = 1;
    this.zoomOutLimit = -5;
    this.minZoomFactor = 0.05;
    this.maxZoomFactor = 4;

    this.currentMousePosition = { x: 0, y: 0 };

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.SetZoomOutLimit = function() {
        if (this.displayImage) {
            let scaleX = Math.ceil(this.displayImage.width / this.viewport.width);
            let scaleY = Math.ceil(this.displayImage.height / this.viewport.height);
            let scale = Math.max(scaleX, scaleY);
            this.zoomOutLimit = -scale + 2;
        }
    };

this.UpdateZoom = function(newZoom, refPoint) {
    newZoom = Math.max(this.zoomOutLimit, Math.min(this.maxZoomFactor, newZoom));
    if (newZoom == this.zoom && this.scaledImage) return;

    if (refPoint == null) refPoint = new Point(this.viewport.width / 2, this.viewport.height / 2);

    let imgx = null;
    if (this.maxHorizontalScrollPosition > 0)
        imgx = (refPoint.x + this.scrollPosition.x) / this.scale;

    let imgy = null;
    if (this.maxVerticalScrollPosition > 0)
        imgy = (refPoint.y + this.scrollPosition.y) / this.scale;

    this.zoom = newZoom;
    this.scaledImage = null;
    gc(true);

    if (this.zoom > 0) {
        this.scale = this.zoom;
    } else {
        this.scale = 1 / (-this.zoom + 2);
    }

    if (this.displayImage) {
        let scaledWidth = Math.round(this.displayImage.width * this.scale);
        let scaledHeight = Math.round(this.displayImage.height * this.scale);


        // Adjust scroll position based on the refPoint and new scale
          this.scrollPosition.x = imgx * this.scale - refPoint.x;
          this.scrollPosition.y = imgy * this.scale - refPoint.y;

        this.scrollPosition.x = this.scrollPosition.x;
        this.scrollPosition.y = this.scrollPosition.y;

        this.viewport.update();
    }
};

    this.initScrollBars = function(scrollPoint = null) {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
            this.scrollPosition = new Point(0, 0);
        } else {
            let zoomFactor = this.scale;
            this.setHorizontalScrollRange(0, Math.max(0, 3 * image.width * zoomFactor));
            this.setVerticalScrollRange(0, Math.max(0, 3 * image.height * zoomFactor));
            if (scrollPoint) {
                this.scrollPosition = scrollPoint;
            } else {
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, 3 * image.width * zoomFactor),
                    Math.min(this.scrollPosition.y, 3 * image.height * zoomFactor)
                );
            }
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        let zoomFactor = parent.scale;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        if (modifiers === 1) {
            if (parameters.drawingMode === "Circle") {
                parent.currentCircle = { x: adjustedX, y: adjustedY, radius: 0 };
            } else if (parameters.drawingMode === "Freehand") {
                parent.currentFreehandShape = [{ x: adjustedX, y: adjustedY }];
            }
        } else if (modifiers === 4) {
            detectAndDrawSatelliteTrail(parent, adjustedX, adjustedY);
        } else if (modifiers === 2) {
            if (!parent.currentLine) {
                parent.currentLine = { start: { x: adjustedX, y: adjustedY }, end: null };
            } else {
                parent.currentLine.end = { x: adjustedX, y: adjustedY };
                parent.satelliteTrails.push(parent.currentLine);
                parent.currentLine = null;
            }
        } else if (button === 2) {
            parent.removeClosestElement(adjustedX, adjustedY);
        } else {
            this.cursor = new Cursor(StdCursor_ClosedHand);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            parent.dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        var parent = this.parent;
        if (!parent) return;

        let zoomFactor = parent.scale;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        parent.currentMousePosition = { x: adjustedX, y: adjustedY };

        if (parent.currentCircle) {
            let dx = adjustedX - parent.currentCircle.x;
            let dy = adjustedY - parent.currentCircle.y;
            parent.currentCircle.radius = Math.sqrt(dx * dx + dy * dy);
        }

        if (parent.currentFreehandShape) {
            parent.currentFreehandShape.push({ x: adjustedX, y: adjustedY });
        }

        if (parent.currentLine && modifiers === 2) {
            parent.currentLine.end = { x: adjustedX, y: adjustedY };
        }

        if (parent.dragging) {
            let dx = (parent.dragOrigin.x - x) / parent.scale;
            let dy = (parent.dragOrigin.y - y) / parent.scale;
            parent.scrollPosition = new Point(parent.scrollPosition.x + dx, parent.scrollPosition.y + dy);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
        }
        if (parent.viewport) {
            parent.viewport.update();
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        if (!parent) return;
        this.cursor = new Cursor(StdCursor_Cross);
        parent.dragging = false;

        if (parent.currentCircle && parent.currentCircle.radius > 0) {
            parent.placeBlemishPoint(parent.currentCircle.x, parent.currentCircle.y, parent.currentCircle.radius);
            parent.currentCircle = null;
        }

        if (parent.currentFreehandShape && parent.currentFreehandShape.length > 2) {
            parent.currentFreehandShape.push(parent.currentFreehandShape[0]);
            parent.placeFreehandShape(parent.currentFreehandShape);
            parent.currentFreehandShape = null;
        }

        if (parent.currentLine && parent.currentLine.end) {
            parent.satelliteTrails.push(parent.currentLine);
            parent.currentLine = null;
        }
    };

    this.placeFreehandShape = function(shape) {
        this.freehandShapes.push(shape);
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
        var parent = this.parent;

        if (!parent.displayImage) {
            console.writeln("No display image set.");
            return;
        }

            let refPoint = new Point(x, y);

    if (delta > 0) {
        parent.UpdateZoom(parent.zoom - 1, refPoint);
    } else if (delta < 0) {
        parent.UpdateZoom(parent.zoom + 1, refPoint);
    }
    };

    this.zoomIn = function() {
        this.UpdateZoom(this.zoom + 1);
                if (this.viewport) {
            this.viewport.update();
                }
    };

    this.zoomOut = function() {
        this.UpdateZoom(this.zoom - 1);
                if (this.viewport) {
            this.viewport.update();
                }
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        let zoomFactor = this.parent.scale;

        if (result == null || result.isNull || result.isEmpty) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            g.scaleTransformation(zoomFactor);
            g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
            g.drawBitmap(0, 0, result.render());

            g.pen = new Pen(0xffffff00, 1);
            if (this.parent.currentCircle) {
                g.drawCircle(this.parent.currentCircle.x, this.parent.currentCircle.y, this.parent.currentCircle.radius);
            } else {
                g.drawCircle(this.parent.currentMousePosition.x, this.parent.currentMousePosition.y, 0);
            }

            if (this.parent.currentLine && this.parent.currentLine.end) {
                g.pen = new Pen(0xff00ff00, 1);
                g.drawLine(this.parent.currentLine.start.x, this.parent.currentLine.start.y, this.parent.currentLine.end.x, this.parent.currentLine.end.y);
            } else if (this.parent.currentLine) {
                g.pen = new Pen(0xff00ff00, 1);
                g.drawLine(this.parent.currentLine.start.x, this.parent.currentLine.start.y, this.parent.currentMousePosition.x, this.parent.currentMousePosition.y);
            }

            if (this.parent.satelliteTrails.length > 0) {
                g.pen = new Pen(0xff00ff00, 1);
                this.parent.satelliteTrails.forEach(trail => {
                    g.drawLine(trail.start.x, trail.start.y, trail.end.x, trail.end.y);
                });
            }

            if (this.parent.blemishPoints.length > 0) {
                g.pen = new Pen(0xff00ff00, 1);
                this.parent.blemishPoints.forEach(point => {
                    g.drawCircle(point.x, point.y, point.radius);
                });
            }

            if (this.parent.freehandShapes.length > 0) {
                g.pen = new Pen(0xff00ff00, 1);
                this.parent.freehandShapes.forEach(shape => {
                    for (let i = 0; i < shape.length - 1; i++) {
                        g.drawLine(shape[i].x, shape[i].y, shape[i + 1].x, shape[i + 1].y);
                    }
                });
            }

            if (this.parent.currentFreehandShape && this.parent.currentFreehandShape.length > 1) {
                g.pen = new Pen(0xff00ff00, 1);
                for (let i = 0; i < this.parent.currentFreehandShape.length - 1; i++) {
                    g.drawLine(this.parent.currentFreehandShape[i].x, this.parent.currentFreehandShape[i].y, this.parent.currentFreehandShape[i + 1].x, this.parent.currentFreehandShape[i + 1].y);
                }
            }
        }

        g.end();
        gc();
    };

    this.blemishPoints = [];
    this.placeBlemishPoint = function(x, y, radius) {
        this.blemishPoints.push({ x: x, y: y, radius: radius });
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.removeClosestElement = function(x, y) {
        let closestDistance = Infinity;
        let closestIndex = -1;
        let closestType = '';

        for (let i = 0; i < this.blemishPoints.length; i++) {
            let point = this.blemishPoints[i];
            let distance = Math.sqrt(Math.pow(point.x - x, 2) + Math.pow(point.y - y, 2));
            if (distance < closestDistance) {
                closestDistance = distance;
                closestIndex = i;
                closestType = 'blemish';
            }
        }

        for (let i = 0; i < this.satelliteTrails.length; i++) {
            let trail = this.satelliteTrails[i];
            let startDistance = Math.sqrt(Math.pow(trail.start.x - x, 2) + Math.pow(trail.start.y - y, 2));
            let endDistance = Math.sqrt(Math.pow(trail.end.x - x, 2) + Math.pow(trail.end.y - y, 2));
            let distance = Math.min(startDistance, endDistance);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestIndex = i;
                closestType = 'trail';
            }
        }

        for (let i = 0; i < this.freehandShapes.length; i++) {
            let shape = this.freehandShapes[i];
            for (let j = 0; j < shape.length - 1; j++) {
                let point1 = shape[j];
                let point2 = shape[j + 1];
                let distance = this.distanceToSegment({ x: x, y: y }, point1, point2);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestIndex = i;
                    closestType = 'freehand';
                }
            }
        }

        if (closestType === 'blemish') {
            this.blemishPoints.splice(closestIndex, 1);
        } else if (closestType === 'trail') {
            this.satelliteTrails.splice(closestIndex, 1);
        } else if (closestType === 'freehand') {
            this.freehandShapes.splice(closestIndex, 1);
        }

        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.distanceToSegment = function(p, v, w) {
        const l2 = Math.pow(v.x - w.x, 2) + Math.pow(v.y - w.y, 2);
        if (l2 === 0) return Math.sqrt(Math.pow(p.x - v.x, 2) + Math.pow(p.y - v.y, 2));
        const t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        if (t < 0) return Math.sqrt(Math.pow(p.x - v.x, 2) + Math.pow(p.y - v.y, 2));
        if (t > 1) return Math.sqrt(Math.pow(p.x - w.x, 2) + Math.pow(p.y - w.y, 2));
        return Math.sqrt(Math.pow(p.x - (v.x + t * (w.x - v.x)), 2) + Math.pow(p.y - (v.y + t * (w.y - v.y)), 2));
    };

    this.tempImageStack = [];

    // MedianCalculator function to calculate the median of an array of numbers
    function MedianCalculator() {
        this.calculate = function(arr) {
            arr.sort((a, b) => a - b);
            const mid = Math.floor(arr.length / 2);
            if (arr.length % 2 === 0) {
                return (arr[mid - 1] + arr[mid]) / 2;
            }
            return arr[mid];
        };
    }

    this.executeCounter = 0;
    this.undoStack = []; // Stack to store image states for undo
    this.redoStack = []; // Stack to store image states for redo

// Function to detect the brightest point within a circle and calculate FWHM
function starCentroid(img_x, img_y, radius, image) {
    let maxBrightness = -Infinity;
    let brightestPoint = { x: img_x, y: img_y };

    for (let y = Math.max(0, img_y - radius); y < Math.min(image.height, img_y + radius); y++) {
        for (let x = Math.max(0, img_x - radius); x < Math.min(image.width, img_x + radius); x++) {
            if (Math.sqrt(Math.pow(x - img_x, 2) + Math.pow(y - img_y, 2)) <= radius) {
                let brightness = image.sample(x, y);
                if (brightness > maxBrightness) {
                    maxBrightness = brightness;
                    brightestPoint = { x: x, y: y };
                }
            }
        }
    }

    console.writeln("Brightest point detected at: (" + brightestPoint.x + ", " + brightestPoint.y + ")");

    let FWHM = calculateFWHM(brightestPoint.x, brightestPoint.y, image);
    console.writeln("FWHM: " + FWHM);

    return { x: brightestPoint.x, y: brightestPoint.y, FWHM: FWHM };
}

// Function to calculate the FWHM of a star centered at (starX, starY)
function calculateFWHM(starX, starY, image) {
    let intensityProfile = [];
    let radius = 50;  // Arbitrary radius for sampling the star profile

    for (let r = 0; r <= radius; r++) {
        let sum = 0;
        let count = 0;

        for (let theta = 0; theta < 360; theta += 1) {
            let rad = (theta * Math.PI) / 180;
            let x = Math.round(starX + r * Math.cos(rad));
            let y = Math.round(starY + r * Math.sin(rad));

            if (x >= 0 && x < image.width && y >= 0 && y < image.height) {
                sum += image.sample(x, y, 0);
                count++;
            }
        }

        intensityProfile.push(sum / count);
    }

    let maxIntensity = Math.max.apply(Math, intensityProfile);
    let halfMaxIntensity = maxIntensity / 2;

    for (let r = 0; r < intensityProfile.length; r++) {
        if (intensityProfile[r] <= halfMaxIntensity) {
            return r;
        }
    }

    return radius;  // Fallback in case we don't find a proper FWHM
}

// Function to extract a circular region from an image
function extractCircularRegion(image, centerX, centerY, radius) {
    let circleRegion = [];
    for (let y = Math.max(0, centerY - radius); y < Math.min(image.height, centerY + radius); y++) {
        for (let x = Math.max(0, centerX - radius); x < Math.min(image.width, centerX + radius); x++) {
            if (Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)) <= radius) {
                circleRegion.push(image.sample(x, y));
            }
        }
    }
    return circleRegion;
}


// Function to apply blemish removal
this.applyBlemishRemoval = function() {
    if (typeof this.displayImageWindow.mainView.id === 'string') {
        this.undoStack.push({
            imageId: this.displayImageWindow.mainView.id,
            blemishPoints: JSON.parse(JSON.stringify(this.blemishPoints)),
            satelliteTrails: JSON.parse(JSON.stringify(this.satelliteTrails)),
            freehandShapes: JSON.parse(JSON.stringify(this.freehandShapes))
        });
    } else {
        console.writeln("Invalid image ID: ", this.displayImageWindow.mainView.id);
    }

    this.redoStack = [];
    this.executeCounter++;

    let tempImageWindow = new ImageWindow(
        this.displayImage.width,
        this.displayImage.height,
        this.displayImage.numberOfChannels,
        this.displayImage.bitsPerSample,
        this.displayImage.sampleType === SampleType_Real,
        false,
        "TempImage"
    );

    with (tempImageWindow.mainView) {
        beginProcess(UndoFlag_NoSwapFile);
        image.assign(this.displayImage);
        endProcess();
    }

    let image = tempImageWindow.mainView.image;
    let numChannels = image.numberOfChannels;
    let selectedChannel = parameters.selectedChannel || 0;

    console.writeln("Starting blemish removal process...");
    console.flush();

    let channelsToProcess = [];
    if (selectedChannel === 0 || numChannels === 1) {
        // "All Channels" selected or mono image
        for (let i = 0; i < numChannels; i++) {
            channelsToProcess.push(i);
        }
    } else {
        // Single channel selected (Red, Green, or Blue)
        channelsToProcess = [selectedChannel - 1]; // Adjusting index for 0-based indexing
    }

    if (parameters.correctStar) {
        for (let point of this.blemishPoints) {
            let x = point.x;
            let y = point.y;
            let radius = point.radius;

            console.writeln("Processing star correction at coordinates: (" + x + ", " + y + ")");
            console.flush();

            let starCenter = starCentroid(x, y, radius, image);
            if (!starCenter) {
                console.writeln("No star detected at coordinates: (" + x + ", " + y + ")");
                continue;
            }
            let starX = starCenter.x;
            let starY = starCenter.y;
            let starFWHM = 0.75 * starCenter.FWHM;

            console.writeln("Star detected at: (" + starX + ", " + starY + ") with FWHM: " + starFWHM);
            console.flush();

            let surroundingRadius = radius * Math.sqrt(3);
            let angle = Math.PI / 3;
            let dx = [], dy = [];

            for (let i = 0; i < 6; i++) {
                dx.push(Math.cos(angle * i) * surroundingRadius);
                dy.push(Math.sin(angle * i) * surroundingRadius);
            }

            // Calculate the median of all 7 circles (center + 6 surrounding)
            let circleMedians = {};
            let medianCalculator = new MedianCalculator();

            for (let c of channelsToProcess) {
                circleMedians[c] = []; // Initialize the median array for each channel
            }

            for (let i = 0; i < 7; i++) {
                let sx = i === 0 ? starX : Math.round(starX + dx[i - 1]);
                let sy = i === 0 ? starY : Math.round(starY + dy[i - 1]);

                if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                    let circlePixels = {};
                    for (let c of channelsToProcess) {
                        circlePixels[c] = []; // Initialize if not already
                    }

                    for (let dxCenter = -starFWHM; dxCenter <= starFWHM; dxCenter += 3) {
                        for (let dyCenter = -starFWHM; dyCenter <= starFWHM; dyCenter += 3) {
                            let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                            if (distCenter <= starFWHM) {
                                let cx = sx + dxCenter;
                                let cy = sy + dyCenter;
                                if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                    for (let c of channelsToProcess) {
                                        circlePixels[c].push(image.sample(cx, cy, c));
                                    }
                                }
                            }
                        }
                    }

                    for (let c of channelsToProcess) {
                        circleMedians[c].push(medianCalculator.calculate(circlePixels[c]));
                    }
                } else {
                    for (let c of channelsToProcess) {
                        circleMedians[c].push(Number.POSITIVE_INFINITY); // If out of bounds, use a large value
                    }
                }
            }

            // Calculate the median of the center circle for each channel
            let centerMedians = [];
            for (let c of channelsToProcess) {
                centerMedians[c] = circleMedians[c][0];
            }

            // Determine the 3 surrounding circles closest to the median of the center circle
            let closestCircles = [];
            for (let i = 1; i < 7; i++) {
                for (let c of channelsToProcess) {
                    closestCircles.push({
                        index: i,
                        distance: Math.abs(circleMedians[c][i] - centerMedians[c]) // Correct access for channel-specific values
                    });
                }
            }

            closestCircles.sort((a, b) => a.distance - b.distance);
            let selectedCircles = closestCircles.slice(0, 3);

            // First pass: Store the values we are going to use
            let sampleValues = [];
            for (let dxCenter = -surroundingRadius; dxCenter <= surroundingRadius; dxCenter++) {
                for (let dyCenter = -surroundingRadius; dyCenter <= surroundingRadius; dyCenter++) {
                    let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                    if (distCenter > 0.0 * starFWHM && distCenter <= radius) { // Only process beyond the FWHM and within the user-defined radius
                        let featherValue = this.parent.featherSlider.value;

                        let featherProfile;
                        if (distCenter <= 1 * starFWHM) {
                            featherProfile = Math.pow(distCenter / (1 * starFWHM), 2);  // Smooth transition from 0 at the center to 1 at 2*FWHM
                        } else {
                            featherProfile = 1;  // Fully applied beyond 2*FWHM
                        }

                        // Introduce an additional factor for feathering towards the user-defined circle's edge
                        let edgeFeatherFactor;
                        if (distCenter <= radius / 2) {
                            // Feathering factor is 1 for any point within half the radius
                            edgeFeatherFactor = 1;
                        } else if (distCenter > radius / 2 && distCenter <= radius) {
                            // Feathering decreases from 1 to 0 between radius/2 and radius
                            edgeFeatherFactor = 1 - ((distCenter - radius / 2) / (radius / 2));
                        } else {
                            edgeFeatherFactor = 0;  // No effect outside the radius
                        }

                        // Combine the feather factors
                        let combinedFeatherFactor = featherValue * featherProfile * edgeFeatherFactor;
                        let medianPixel = {};
                        for (let c of channelsToProcess) {
                            medianPixel[c] = []; // Ensure each channel has its own array
                        }
                        let validSurroundingPixels = 0;

                        for (let i of selectedCircles) {
                            let sx = Math.round(starX + dxCenter + dx[i.index - 1]);
                            let sy = Math.round(starY + dyCenter + dy[i.index - 1]);
                            if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                                for (let c of channelsToProcess) {
                                    let sampleValue = image.sample(sx, sy, c);
                                    if (sampleValue <= 2 * centerMedians[c]) { // Disregard any pixels with values greater than 2*median
                                        medianPixel[c].push(sampleValue);
                                    }
                                }
                                validSurroundingPixels++;
                            }
                        }

                        if (validSurroundingPixels > 0) {
                            for (let c of channelsToProcess) {
                                medianPixel[c].sort((a, b) => a - b); // Sort the values
                                let median = medianPixel[c].length % 2 === 0
                                    ? (medianPixel[c][medianPixel[c].length / 2 - 1] + medianPixel[c][medianPixel[c].length / 2]) / 2
                                    : medianPixel[c][Math.floor(medianPixel[c].length / 2)];
                                medianPixel[c] = median;
                            }

                            let cx = Math.round(starX + dxCenter);
                            let cy = Math.round(starY + dyCenter);
                            if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                for (let c of channelsToProcess) {
                                    let originalSample = image.sample(cx, cy, c);
                                    let newSample = combinedFeatherFactor * medianPixel[c] + (1 - combinedFeatherFactor) * originalSample;
                                    sampleValues.push({ cx: cx, cy: cy, c: c, newSample: newSample });
                                }
                            }
                        }
                    }
                }
            }

            // Second pass: Set the samples with error handling and batching
            let batchSize = 100;
            for (let i = 0; i < sampleValues.length; i += batchSize) {
                tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
                for (let j = i; j < i + batchSize && j < sampleValues.length; j++) {
                    let sample = sampleValues[j];
                    try {
                        image.setSample(sample.newSample, sample.cx, sample.cy, sample.c);
                    } catch (error) {
                        // Handle error if needed
                    }
                }
                try{
                tempImageWindow.mainView.endProcess();
                }catch (error){
                   //Handle error if needed
                }
            }
        }
    } else {
        for (let point of this.blemishPoints) {
            let x = point.x;
            let y = point.y;
            console.writeln("Processing blemish point at coordinates: (" + x + ", " + y + ")");
            console.flush();

            let radius = point.radius;
            let centerRadius = radius;
            let surroundingRadius = radius * Math.sqrt(3);
            let angle = Math.PI / 3;
            let dx = [], dy = [];

            for (let i = 0; i < 6; i++) {
                dx.push(Math.cos(angle * i) * surroundingRadius);
                dy.push(Math.sin(angle * i) * surroundingRadius);
            }

            // Calculate the median of all 7 circles (center + 6 surrounding)
            let circleMedians = {};
            let medianCalculator = new MedianCalculator();

            for (let c of channelsToProcess) {
                circleMedians[c] = []; // Initialize the median array for each channel
            }

            for (let i = 0; i < 7; i++) {
                let sx = i === 0 ? x : Math.round(x + dx[i - 1]);
                let sy = i === 0 ? y : Math.round(y + dy[i - 1]);

                if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                    let circlePixels = {};
                    for (let c of channelsToProcess) {
                        circlePixels[c] = []; // Initialize if not already
                    }

                    for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter += 3) {
                        for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter += 3) {
                            let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                            if (distCenter <= centerRadius) {
                                let cx = sx + dxCenter;
                                let cy = sy + dyCenter;
                                if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                    for (let c of channelsToProcess) {
                                        circlePixels[c].push(image.sample(cx, cy, c));
                                    }
                                }
                            }
                        }
                    }

                    for (let c of channelsToProcess) {
                        circleMedians[c].push(medianCalculator.calculate(circlePixels[c]));
                    }
                } else {
                    for (let c of channelsToProcess) {
                        circleMedians[c].push(Number.POSITIVE_INFINITY); // If out of bounds, use a large value
                    }
                }
            }

            // Calculate the median of the center circle for each channel
            let centerMedians = [];
            for (let c of channelsToProcess) {
                centerMedians[c] = circleMedians[c][0];
            }

            // Determine the 3 surrounding circles closest to the median of the center circle
            let closestCircles = [];
            for (let i = 1; i < 7; i++) {
                for (let c of channelsToProcess) {
                    closestCircles.push({
                        index: i,
                        distance: Math.abs(circleMedians[c][i] - centerMedians[c]) // Correct access for channel-specific values
                    });
                }
            }

            closestCircles.sort((a, b) => a.distance - b.distance);
            let selectedCircles = closestCircles.slice(0, 3);

            // First pass: Store the values we are going to use
            let sampleValues = [];
            for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter++) {
                for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter++) {
                    let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                    if (distCenter <= centerRadius) {
                        let featherValue = this.parent.featherSlider.value;
                        let opacityValue = this.parent.opacitySlider.value; // Get opacity value from slider
                        let featherFactor = featherValue === 0 ? 1 : Math.min(1, (1 / featherValue) * (centerRadius - distCenter) / centerRadius);
                        let medianPixel = {};
                        for (let c of channelsToProcess) {
                            medianPixel[c] = []; // Ensure each channel has its own array
                        }
                        let validSurroundingPixels = 0;

                        for (let i of selectedCircles) {
                            let sx = Math.round(x + dxCenter + dx[i.index - 1]);
                            let sy = Math.round(y + dyCenter + dy[i.index - 1]);
                            if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                                for (let c of channelsToProcess) {
                                    medianPixel[c].push(image.sample(sx, sy, c));
                                }
                                validSurroundingPixels++;
                            }
                        }

                        if (validSurroundingPixels > 0) {
                            for (let c of channelsToProcess) {
                                medianPixel[c].sort((a, b) => a - b); // Sort the values
                                let median = medianPixel[c].length % 2 === 0
                                    ? (medianPixel[c][medianPixel[c].length / 2 - 1] + medianPixel[c][medianPixel[c].length / 2]) / 2
                                    : medianPixel[c][Math.floor(medianPixel[c].length / 2)];
                                medianPixel[c] = median;
                            }

                            let cx = Math.round(x + dxCenter);
                            let cy = Math.round(y + dyCenter);
                            if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                for (let c of channelsToProcess) {
                                    let originalSample = image.sample(cx, cy, c);
                                    let newSample = opacityValue * (featherFactor * medianPixel[c] + (1 - featherFactor) * originalSample) + (1 - opacityValue) * originalSample;

                                    sampleValues.push({ cx: cx, cy: cy, c: c, newSample: newSample });
                                }
                            }
                        }
                    }
                }
            }

            // Second pass: Set the samples with error handling and batching
            let batchSize = 100;
            for (let i = 0; i < sampleValues.length; i += batchSize) {
                tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
                for (let j = i; j < i + batchSize && j < sampleValues.length; j++) {
                    let sample = sampleValues[j];
                    try {
                        image.setSample(sample.newSample, sample.cx, sample.cy, sample.c);
                    } catch (error) {
                        // Handle error if needed
                    }
                }
                try{
                tempImageWindow.mainView.endProcess();
                }catch (error){
                   //Handle error if needed
                }
            }
        }
    }

    // Process freehand shapes
    for (let shape of this.freehandShapes) {
        console.writeln("Processing freehand shape...");
        console.flush();

        let { centerX, centerY, radius } = calculateFreehandCenterAndRadius(shape);
        let centerRadius = radius;
        let surroundingRadius = radius * Math.sqrt(3);
        let angle = Math.PI / 3;
        let dx = [], dy = [];

        for (let i = 0; i < 6; i++) {
            dx.push(Math.cos(angle * i) * surroundingRadius);
            dy.push(Math.sin(angle * i) * surroundingRadius);
        }

        // Calculate the median of all 7 circles (center + 6 surrounding)
        let circleMedians = {};
        let medianCalculator = new MedianCalculator();

        for (let c of channelsToProcess) {
            circleMedians[c] = []; // Initialize the median array for each channel
        }

        for (let i = 0; i < 7; i++) {
            let sx = i === 0 ? centerX : Math.round(centerX + dx[i - 1]);
            let sy = i === 0 ? centerY : Math.round(centerY + dy[i - 1]);

            if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                let circlePixels = {};
                for (let c of channelsToProcess) {
                    circlePixels[c] = []; // Initialize if not already
                }

                for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter++) {
                    for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter++) {
                        let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                        if (distCenter <= centerRadius) {
                            let cx = sx + dxCenter;
                            let cy = sy + dyCenter;
                            if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                for (let c of channelsToProcess) {
                                    circlePixels[c].push(image.sample(cx, cy, c));
                                }
                            }
                        }
                    }
                }

                for (let c of channelsToProcess) {
                    circleMedians[c].push(medianCalculator.calculate(circlePixels[c]));
                }
            } else {
                for (let c of channelsToProcess) {
                    circleMedians[c].push(Number.POSITIVE_INFINITY); // If out of bounds, use a large value
                }
            }
        }

        // Calculate the median of the center circle for each channel
        let centerMedians = [];
        for (let c of channelsToProcess) {
            centerMedians[c] = circleMedians[c][0];
        }

        // Determine the 3 surrounding circles closest to the median of the center circle
        let closestCircles = [];
        for (let i = 1; i < 7; i++) {
            for (let c of channelsToProcess) {
                closestCircles.push({
                    index: i,
                    distance: Math.abs(circleMedians[c][i] - centerMedians[c]) // Correct access for channel-specific values
                });
            }
        }

        closestCircles.sort((a, b) => a.distance - b.distance);
        let selectedCircles = closestCircles.slice(0, 3);

        // First pass: Store the values we are going to use
        let sampleValues = [];
        let featherValue = this.parent.featherSlider.value;
        let opacityValue = this.parent.opacitySlider.value; // Get opacity value from slider

        for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter++) {
            for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter++) {
                let cx = Math.round(centerX + dxCenter);
                let cy = Math.round(centerY + dyCenter);

                if (isPointInShape(cx, cy, shape) && cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                    let minDistanceToEdge = getMinDistanceToEdge(cx, cy, shape);
                    let featherFactor = featherValue === 0 ? 1 : Math.min(1, (1 / featherValue) * minDistanceToEdge / centerRadius);
                    let medianPixel = {};
                    for (let c of channelsToProcess) {
                        medianPixel[c] = []; // Ensure each channel has its own array
                    }
                    let validSurroundingPixels = 0;

                    for (let i of selectedCircles) {
                        let sx = Math.round(cx + dx[i.index - 1]);
                        let sy = Math.round(cy + dy[i.index - 1]);
                        if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                            for (let c of channelsToProcess) {
                                medianPixel[c].push(image.sample(sx, sy, c));
                            }
                            validSurroundingPixels++;
                        }
                    }

                    if (validSurroundingPixels > 0) {
                        for (let c of channelsToProcess) {
                            medianPixel[c].sort((a, b) => a - b); // Sort the values
                            let median = medianPixel[c].length % 2 === 0
                                ? (medianPixel[c][medianPixel[c].length / 2 - 1] + medianPixel[c][medianPixel[c].length / 2]) / 2
                                : medianPixel[c][Math.floor(medianPixel[c].length / 2)];
                            medianPixel[c] = median;
                        }

                        for (let c of channelsToProcess) {
                            let originalSample = image.sample(cx, cy, c);
                            let newSample = opacityValue * (featherFactor * medianPixel[c] + (1 - featherFactor) * originalSample) + (1 - opacityValue) * originalSample;
                            sampleValues.push({ cx: cx, cy: cy, c: c, newSample: newSample });
                        }
                    }
                }
            }
        }

        // Second pass: Set the samples with error handling and batching
        let batchSize = 100;
        for (let i = 0; i < sampleValues.length; i += batchSize) {
            tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
            for (let j = i; j < i + batchSize && j < sampleValues.length; j++) {
                let sample = sampleValues[j];
                try {
                    //console.writeln("Setting sample at (" + sample.cx + ", " + sample.cy + "): " + sample.newSample);
                    image.setSample(sample.newSample, sample.cx, sample.cy, sample.c);
                } catch (error) {
                    console.writeln("Error setting sample at (" + sample.cx + ", " + sample.cy + "): " + error.message);
                }
            }
                try{
                tempImageWindow.mainView.endProcess();
                }catch (error){
                   //Handle error if needed
                }
        }
    }

    // Custom function to extract a circular region from the image
Image.prototype.extractCircle = function(x, y, radius) {
    let circleImage = new Image(radius * 2, radius * 2, this.numberOfChannels, this.bitsPerSample, this.sampleType == SampleType_Real);
    for (let dx = -radius; dx < radius; dx++) {
        for (let dy = -radius; dy < radius; dy++) {
            if (Math.sqrt(dx * dx + dy * dy) <= radius) {
                let sampleX = x + dx;
                let sampleY = y + dy;
                if (sampleX >= 0 && sampleX < this.width && sampleY >= 0 && sampleY < this.height) {
                    for (let c = 0; c < this.numberOfChannels; c++) {
                        circleImage.setSample(this.sample(sampleX, sampleY, c), dx + radius, dy + radius, c);
                    }
                }
            }
        }
    }
    return circleImage;
};

// Function to determine if a point is inside the freehand shape using the ray-casting algorithm
function isPointInShape(x, y, shape) {
    let crossings = 0;
    for (let i = 0; i < shape.length; i++) {
        let x1 = shape[i].x;
        let y1 = shape[i].y;
        let x2 = shape[(i + 1) % shape.length].x;
        let y2 = shape[(i + 1) % shape.length].y;

        if (((y1 <= y && y < y2) || (y2 <= y && y < y1)) &&
            (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1)) {
            crossings++;
        }
    }
    return crossings % 2 != 0;
}

// Function to get the minimum distance from a point to any edge of the shape
function getMinDistanceToEdge(x, y, shape) {
    let minDistance = Infinity;
    for (let i = 0; i < shape.length; i++) {
        let x1 = shape[i].x;
        let y1 = shape[i].y;
        let x2 = shape[(i + 1) % shape.length].x;
        let y2 = shape[(i + 1) % shape.length].y;
        let distance = pointLineDistance(x, y, x1, y1, x2, y2);
        if (distance < minDistance) {
            minDistance = distance;
        }
    }
    return minDistance;
}

// Function to calculate the distance from a point to a line segment
function pointLineDistance(px, py, x1, y1, x2, y2) {
    let A = px - x1;
    let B = py - y1;
    let C = x2 - x1;
    let D = y2 - y1;

    let dot = A * C + B * D;
    let len_sq = C * C + D * D;
    let param = -1;
    if (len_sq != 0) { // in case of 0 length line
        param = dot / len_sq;
    }

    let xx, yy;

    if (param < 0) {
        xx = x1;
        yy = y1;
    } else if (param > 1) {
        xx = x2;
        yy = y2;
    } else {
        xx = x1 + param * C;
        yy = y1 + param * D;
    }

    let dx = px - xx;
    let dy = py - yy;
    return Math.sqrt(dx * dx + dy * dy);
}


// Loop the process twice
for (let iteration = 0; iteration < 2; iteration++) {
    // Process satellite trails
    for (let trail of this.satelliteTrails) {
        let startX = trail.start.x;
        let startY = trail.start.y;
        let endX = trail.end.x;
        let endY = trail.end.y;

        let dx = endX - startX;
        let dy = endY - startY;
        let length = Math.sqrt(dx * dx + dy * dy);

        // Handle horizontal and vertical lines
        let stepX, stepY;
        if (length === 0) {
            stepX = 0;
            stepY = 0;
        } else {
            stepX = dx / length;
            stepY = dy / length;
        }

        let satelliteSize = this.parent.satelliteSizeSlider.value;

        let sampleValues = [];
        let perpendicularLength = 2 * satelliteSize * iteration; // Distance from the trail to the regions

        for (let i = 0; i <= length; i++) {
            let currentX = startX + i * stepX;
            let currentY = startY + i * stepY;

            // Define the positions for the regions
            let upperUpperX = currentX - 2 * perpendicularLength * stepY;
            let upperUpperY = currentY + 2 * perpendicularLength * stepX;
            let upperX = currentX - perpendicularLength * stepY;
            let upperY = currentY + perpendicularLength * stepX;
            let lowerX = currentX + perpendicularLength * stepY;
            let lowerY = currentY - perpendicularLength * stepX;
            let lowerLowerX = currentX + 2 * perpendicularLength * stepY;
            let lowerLowerY = currentY - 2 * perpendicularLength * stepX;

            for (let dx = -Math.floor(satelliteSize / 2); dx <= Math.floor(satelliteSize / 2); dx++) {
                for (let dy = -Math.floor(satelliteSize / 2); dy <= Math.floor(satelliteSize / 2); dy++) {
                    let uux = Math.round(upperUpperX + dx);
                    let uuy = Math.round(upperUpperY + dy);
                    let ux = Math.round(upperX + dx);
                    let uy = Math.round(upperY + dy);
                    let mx = Math.round(currentX + dx);
                    let my = Math.round(currentY + dy);
                    let lx = Math.round(lowerX + dx);
                    let ly = Math.round(lowerY + dy);
                    let llx = Math.round(lowerLowerX + dx);
                    let lly = Math.round(lowerLowerY + dy);

                    if (mx >= 0 && mx < image.width && my >= 0 && my < image.height) {
                        let upperUpperPixels = [];
                        let upperPixels = [];
                        let middlePixels = [];
                        let lowerPixels = [];
                        let lowerLowerPixels = [];

                        if (uux >= 0 && uux < image.width && uuy >= 0 && uuy < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                upperUpperPixels.push(image.sample(uux, uuy, c));
                            }
                        }
                        if (ux >= 0 && ux < image.width && uy >= 0 && uy < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                upperPixels.push(image.sample(ux, uy, c));
                            }
                        }
                        for (let c = 0; c < numChannels; c++) {
                            middlePixels.push(image.sample(mx, my, c));
                        }
                        if (lx >= 0 && lx < image.width && ly >= 0 && ly < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                lowerPixels.push(image.sample(lx, ly, c));
                            }
                        }
                        if (llx >= 0 && llx < image.width && lly >= 0 && lly < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                lowerLowerPixels.push(image.sample(llx, lly, c));
                            }
                        }

                        let medianCalculator = new MedianCalculator();
                        let finalPixels = [];
                        for (let c = 0; c < numChannels; c++) {
                            let combinedPixels = [];
                            if (upperUpperPixels[c] !== undefined) combinedPixels.push(upperUpperPixels[c]);
                            if (upperPixels[c] !== undefined) combinedPixels.push(upperPixels[c]);
                            combinedPixels.push(middlePixels[c]);
                            if (lowerPixels[c] !== undefined) combinedPixels.push(lowerPixels[c]);
                            if (lowerLowerPixels[c] !== undefined) combinedPixels.push(lowerLowerPixels[c]);

                            finalPixels.push(medianCalculator.calculate(combinedPixels));
                        }

                        for (let c = 0; c < numChannels; c++) {
                            let value = finalPixels[c];
                            if (isFinite(value)) {
                                sampleValues.push({ mx: mx, my: my, c: c, value: value });
                                //console.writeln("Set sample at (" + mx + ", " + my + ", " + c + "): " + value);
                            }
                        }
                    }
                }
            }
        }

        // Apply the pixel updates in batches
        let batchSize = 50;
        for (let i = 0; i < sampleValues.length; i += batchSize) {
            tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
            for (let j = i; j < i + batchSize && j < sampleValues.length; j++) {
                let sample = sampleValues[j];
                try {
                    image.setSample(sample.value, sample.mx, sample.my, sample.c);
                } catch (error) {
                    //console.writeln("Error setting sample at (" + sample.mx + ", " + sample.my + "): " + error.message);
                    tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
                    image.setSample(sample.value, sample.mx, sample.my, sample.c);

                }
            }
                try{
                tempImageWindow.mainView.endProcess();
                }catch (error){
                   //Handle error if needed
                }
        }
    }
}



// Push the tempImageWindow ID to the temp image stack only if it is not the main image
if (typeof tempImageWindow.mainView.id === 'string' && tempImageWindow.mainView.id !== parameters.targetWindow.mainView.id) {
    this.tempImageStack.push(tempImageWindow.mainView.id);
} else if (typeof tempImageWindow.mainView.id === 'string') {
    console.writeln("Skipping adding main image to temp stack: ", tempImageWindow.mainView.id);
} else {
    console.writeln("Invalid image ID: ", tempImageWindow.mainView.id);
}

    console.noteln("Ready for more blemish removal.");
    console.flush();

    this.displayImage = tempImageWindow.mainView.image;
    this.displayImageWindow = tempImageWindow; // Store the tempImageWindow
    this.doUpdateImage(this.displayImage);

    // Clear the blemish points after processing
    this.blemishPoints = [];
    this.satelliteTrails = [];
    this.freehandShapes = [];
    this.refreshPreview();

        // Debug: print stack contents
        //console.writeln("undoStack: " + JSON.stringify(this.undoStack));
        //console.writeln("tempImageStack: " + JSON.stringify(this.tempImageStack));
    };

this.undoLastBlemishRemoval = function() {
    if (this.undoStack.length > 0) {
        let lastState = this.undoStack.pop();
        //console.writeln("Popped from undoStack: " + lastState.imageId);
        this.redoStack.push({
            imageId: this.displayImageWindow.mainView.id,
            blemishPoints: this.blemishPoints,
            satelliteTrails: this.satelliteTrails,
            freehandShapes: this.freehandShapes
        }); // Save current state to redo stack
        //console.writeln("Pushed to redoStack: " + this.displayImageWindow.mainView.id);

        let window = ImageWindow.windowById(lastState.imageId);
        if (window && !window.isNull) {
            this.displayImage = window.mainView.image;
            this.displayImageWindow = window; // Update the display image window
            this.blemishPoints = lastState.blemishPoints || [];
            this.satelliteTrails = lastState.satelliteTrails || [];
            this.freehandShapes = lastState.freehandShapes || [];
            this.doUpdateImage(this.displayImage);
            this.refreshPreview();
            console.writeln("Last blemish removal undone.");
        } else {
            console.writeln("Image window not found or already closed: " + lastState.imageId);
        }
    } else {
        console.writeln("No blemish removals to undo.");
    }

    // Debug: print stack contents
    //console.writeln("undoStack: " + JSON.stringify(this.undoStack));
    //console.writeln("redoStack: " + JSON.stringify(this.redoStack));
};




this.applyChangesToMainImage = function() {
    if (parameters.autoSTFApplied) {
        let originalMedian = parameters.originalMedian;
        let originalMin = parameters.originalMin;

        // Create the PixelMath instance for the first operation
        let pixelMath1 = new PixelMath;
        if (parameters.targetWindow.mainView.image.numberOfChannels === 1) {
            pixelMath1.expression = "((Med($T)-1)*" + originalMedian + "*$T)/(Med($T)*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
        } else {
            pixelMath1.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                                    "((MedianColor-1)*" + originalMedian + "*$T)/(MedianColor*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
            pixelMath1.symbols = "L, MedianColor, S";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.clearImageCacheAndExit = false;
        pixelMath1.cacheGeneratedImages = false;
        pixelMath1.generateOutput = true;
        pixelMath1.singleThreaded = false;
        pixelMath1.optimization = true;
        pixelMath1.use64BitWorkingImage = true;
        pixelMath1.rescale = false;
        pixelMath1.rescaleLower = 0;
        pixelMath1.rescaleUpper = 1;
        pixelMath1.truncate = true;
        pixelMath1.truncateLower = 0;
        pixelMath1.truncateUpper = 1;
        pixelMath1.createNewImage = false;
        pixelMath1.showNewImage = false;
        pixelMath1.newImageId = "";
        pixelMath1.newImageWidth = 0;
        pixelMath1.newImageHeight = 0;
        pixelMath1.newImageAlpha = false;
        pixelMath1.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath1.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        let targetView = this.displayImageWindow.mainView;
        pixelMath1.executeOn(targetView);

        // Create the PixelMath instance for the second operation
        let pixelMath2 = new PixelMath;
        if (parameters.targetWindow.mainView.image.numberOfChannels === 1) {
            pixelMath2.expression = "($T*(1-" + originalMin + ")+" + originalMin + ")";
        } else {
            pixelMath2.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                                    "BlackPoint = MinColor;\n" +
                                    "($T*(1-" + 0.87*originalMin + ")+" + 0.87*originalMin + ")";
            pixelMath2.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.clearImageCacheAndExit = false;
        pixelMath2.cacheGeneratedImages = false;
        pixelMath2.generateOutput = true;
        pixelMath2.singleThreaded = false;
        pixelMath2.optimization = true;
        pixelMath2.use64BitWorkingImage = true;
        pixelMath2.rescale = false;
        pixelMath2.rescaleLower = 0;
        pixelMath2.rescaleUpper = 1;
        pixelMath2.truncate = true;
        pixelMath2.truncateLower = 0;
        pixelMath2.truncateUpper = 1;
        pixelMath2.createNewImage = false;
        pixelMath2.showNewImage = false;
        pixelMath2.newImageId = "";
        pixelMath2.newImageWidth = 0;
        pixelMath2.newImageHeight = 0;
        pixelMath2.newImageAlpha = false;
        pixelMath2.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath2.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        pixelMath2.executeOn(targetView);

        // Third PixelMath operation to replace the main image with the modified preview image
        let pixelMath3 = new PixelMath;
        pixelMath3.expression = this.displayImageWindow.mainView.id; // The preview image ID after modifications
        pixelMath3.useSingleExpression = true;
        pixelMath3.clearImageCacheAndExit = false;
        pixelMath3.cacheGeneratedImages = false;
        pixelMath3.generateOutput = true;
        pixelMath3.singleThreaded = false;
        pixelMath3.optimization = true;
        pixelMath3.use64BitWorkingImage = false;
        pixelMath3.rescale = false;
        pixelMath3.rescaleLower = 0;
        pixelMath3.rescaleUpper = 1;
        pixelMath3.truncate = true;
        pixelMath3.truncateLower = 0;
        pixelMath3.truncateUpper = 1;
        pixelMath3.createNewImage = false;
        pixelMath3.showNewImage = false;
        pixelMath3.newImageId = "";
        pixelMath3.newImageWidth = 0;
        pixelMath3.newImageHeight = 0;
        pixelMath3.newImageAlpha = false;
        pixelMath3.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath3.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        pixelMath3.executeOn(parameters.targetWindow.mainView); // Apply on the main image

        // Apply AutoSTF again to the main image
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.parent.createAndDisplayTemporaryImage(parameters.targetWindow.mainView.image, true);
                this.displayImage = tmpImage;
                this.displayImageWindow = parameters.targetWindow;
                this.initScrollBars();
                this.viewport.update();
                parameters.autoSTFApplied = true;
            }
        }
        //console.noteln("Blemish Removal on Main Image Complete! \nReady to remove more blemishes!");
        //console.flush();
    } else {
        let pixelMath = new PixelMath;
        pixelMath.expression = this.displayImageWindow.mainView.id;
        pixelMath.useSingleExpression = true;
        pixelMath.clearImageCacheAndExit = false;
        pixelMath.cacheGeneratedImages = false;
        pixelMath.generateOutput = true;
        pixelMath.singleThreaded = false;
        pixelMath.optimization = true;
        pixelMath.use64BitWorkingImage = false;
        pixelMath.rescale = false;
        pixelMath.rescaleLower = 0;
        pixelMath.rescaleUpper = 1;
        pixelMath.truncate = true;
        pixelMath.truncateLower = 0;
        pixelMath.truncateUpper = 1;
        pixelMath.createNewImage = false;
        pixelMath.showNewImage = false;
        pixelMath.newImageId = "";
        pixelMath.newImageWidth = 0;
        pixelMath.newImageHeight = 0;
        pixelMath.newImageAlpha = false;
        pixelMath.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        let targetView = parameters.targetWindow.mainView;
        pixelMath.executeOn(targetView);
    }

    console.noteln("Blemish Removal on Main Image Complete! \nReady to remove more blemishes!");
    console.flush();

    // Reset the AutoSTF flag
    //parameters.autoSTFApplied = false;
};




    this.refreshPreview = function() {
        this.viewport.update();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function MiniViewport(parent) {
    this.__base__ = Control;
    this.__base__(parent);

    this.feather = 0.5;
    this.opacity = 1.0;

    this.setFixedSize(100, 100);

    this.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        g.fillRect(0, 0, this.width, this.height, new Brush(0xff000000)); // Black background

        let centerX = this.width / 2;
        let centerY = this.height / 2;
        let radius = 25;

        // Draw white circle with variable opacity and feathering
        for (let y = 0; y < this.height; y++) {
            for (let x = 0; x < this.width; x++) {
                let distance = Math.sqrt((x - centerX) * (x - centerX) + (y - centerY) * (y - centerY));
                if (distance <= radius) {
                    let featherFactor = this.feather === 0 ? 1 : Math.min(1, (1 / this.feather) * (radius - distance) / radius);
                    let alpha = Math.floor(this.opacity * 255 * featherFactor); // Calculate alpha value based on opacity and feathering
                    let alphaHex = alpha.toString(16);
                    if (alphaHex.length < 2) {
                        alphaHex = '0' + alphaHex; // Pad with leading zero if needed
                    }
                    let color = parseInt('0x' + alphaHex + 'ffffff', 16); // Combine alpha with white color
                    g.pen = new Pen(color); // Set pen with calculated color
                    g.drawPoint(x, y);
                }
            }
        }

        g.end();
    };

    this.updatePreview = function(feather, opacity) {
        this.feather = feather === 0 ? 1 : feather;
        this.opacity = opacity;
        this.update();
    };
}
MiniViewport.prototype = new Control;



function BlemishEraserDialog() {
    this.__base__ = Dialog;
    this.__base__();

    let selectedImages = [];


    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text ="<b>" + TITLE + " " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

this.instructionBox = new Label(this);
this.instructionBox.frameStyle = FrameStyle_Box;
this.instructionBox.margin = 6;
this.instructionBox.useRichText = true;
this.instructionBox.text = "<b>Instructions:</b><br>1. Select the image.<br>2. Use AutoSTF if needed.<br>3. Shift-click and drag to draw a circle or freehand.<br>3a. CTRL-click and drag to define Satellite Trail Removal Line.<br>3b. Alt-click to auto find the Satellite Trail Removal Line<br>4. Right-click to remove a point.<br>.....Multiple Areas Allowed!<br>5. Click Execute to apply blemish removal.<br>6. Click Apply to Main Image to save changes.";
this.instructionBox.textAlignment = TextAlign_Left;


    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

this.windowSelector_Cb.onItemSelected = (index) => {
    if (index >= 0) {
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
        if (window && !window.isNull) {
            parameters.targetWindow = window;
            let selectedImage = window.mainView.image;
            if (selectedImage) {
                // Add selected image ID to selectedImages array if not already added
                if (!isImageInSelectedList(window.mainView.id)) {
                    selectedImages.push(window.mainView.id);
                }

                // Proceed with displaying the image in the preview
                var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.displayImageWindow = window;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
            } else {
                console.writeln("Selected image is undefined.");
            }
        } else {
            console.writeln("No valid window selected for preview!");
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents();
        }
    }
};



    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel);
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.autoSTFButton = new PushButton(this);
    this.autoSTFButton.text = "AutoSTF";
    this.autoSTFButton.toolTip = "Apply AutoSTF to the preview image.";
    this.autoSTFButton.icon =":/icons/burn.png"
    this.autoSTFButton.onClick = () => {
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage, true);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.displayImageWindow = parameters.targetWindow;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
                parameters.autoSTFApplied = true;
            }
        }
        this.previewControl.applyBlemishRemoval();
    };


this.drawingModeSizer = new HorizontalSizer;
this.drawingModeSizer.spacing = 4;

this.circleCheckbox = new CheckBox(this);
this.circleCheckbox.text = "Circle";
this.circleCheckbox.checked = (parameters.drawingMode === "Circle");
let parent = this; // Capture the class context
this.circleCheckbox.onCheck = function(checked) {
    if (checked) {
        parameters.drawingMode = "Circle";
        parameters.correctStar = false;  // Reset the correctStar flag
        parent.freehandCheckbox.checked = false;
        parent.correctStarCheckbox.checked = false;
    }
};
this.drawingModeSizer.add(this.circleCheckbox);

this.freehandCheckbox = new CheckBox(this);
this.freehandCheckbox.text = "Freehand";
this.freehandCheckbox.checked = (parameters.drawingMode === "Freehand");
this.freehandCheckbox.onCheck = function(checked) {
    if (checked) {
        parameters.drawingMode = "Freehand";
        parameters.correctStar = false;  // Reset the correctStar flag
        parent.circleCheckbox.checked = false;
        parent.correctStarCheckbox.checked = false;
    }
};
this.drawingModeSizer.add(this.freehandCheckbox);

this.correctStarCheckbox = new CheckBox(this);
this.correctStarCheckbox.text = "Correct Star (Experimental!)";
this.correctStarCheckbox.checked = parameters.correctStar || false;
this.correctStarCheckbox.onCheck = function(checked) {
    parameters.correctStar = checked;
    if (checked) {
        parent.circleCheckbox.checked = false;
        parent.freehandCheckbox.checked = false;
    }
};
this.drawingModeSizer.add(this.correctStarCheckbox);

this.featherSlider = new NumericControl(this);
this.featherSlider.label.text = "Feather:";
this.featherSlider.setRange(0.01, 1);
this.featherSlider.setPrecision(2);
this.featherSlider.slider.setRange(0, 100);
this.featherSlider.setValue(0.5);
this.featherSlider.onValueUpdated = (value) => {
    this.miniViewport.updatePreview(value, this.opacitySlider.value);
};

this.opacitySlider = new NumericControl(this);
this.opacitySlider.label.text = "Opacity:";
this.opacitySlider.setRange(0, 1);
this.opacitySlider.setPrecision(2);
this.opacitySlider.slider.setRange(0, 100);
this.opacitySlider.setValue(1);
this.opacitySlider.onValueUpdated = (value) => {
    this.miniViewport.updatePreview(this.featherSlider.value, value);
};

// Create a label for the dropdown
this.channelDropdownLabel = new Label(this);
this.channelDropdownLabel.text = "Perform Blemish Blaster On:";
this.channelDropdownLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

// Create dropdown for channel selection
this.channelDropdown = new ComboBox(this);
this.channelDropdown.addItem("All Channels");
this.channelDropdown.addItem("Red");
this.channelDropdown.addItem("Green");
this.channelDropdown.addItem("Blue");
this.channelDropdown.currentItem = 0; // Default to "All Channels"

this.channelDropdown.onItemSelected = function(index) {
    parameters.selectedChannel = index;
};

// Create a sizer to arrange the label and dropdown horizontally
this.channelDropdownSizer = new HorizontalSizer;
this.channelDropdownSizer.spacing = 6;
this.channelDropdownSizer.add(this.channelDropdownLabel);
this.channelDropdownSizer.add(this.channelDropdown);
this.channelDropdownSizer.addStretch();

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.toolTip = "Apply blemish removal to all marked points.";
    this.executeButton.icon =":/icons/ok.png"
    this.executeButton.onClick = () => {
        this.previewControl.applyBlemishRemoval();
    };

    this.undoButton = new PushButton(this);
    this.undoButton.text = "Undo";
    this.undoButton.toolTip = "Undo the last blemish removal.";
    this.undoButton.icon = ":/icons/undo.png";
    this.undoButton.onClick = () => {
        this.previewControl.undoLastBlemishRemoval();
    };

    this.applyButton = new PushButton(this);
    this.applyButton.text = "Apply to Main Image";
    this.applyButton.toolTip = "Apply the changes to the main image.";
    this.applyButton.icon = ":/icons/execute.png";
    this.applyButton.onClick = () => {
        this.previewControl.applyChangesToMainImage();
    };

    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "<p style='text-align:center;'>Written by Franklin Marek 2024.<br><a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
    this.authorshipLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.authorshipLabel.useRichText = true;

    this.blemishLabel = new Label(this);
    this.blemishLabel.text = "<p style='text-align:center;'>Blemish Area Options</p>";
    this.blemishLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.blemishLabel.useRichText = true;

        this.satelliteLabel = new Label(this);
    this.satelliteLabel.text = "<p style='text-align:center;'>Satellite Trail Options</p>";
    this.satelliteLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.satelliteLabel.useRichText = true;

    this.satelliteSizeSlider = new NumericControl(this);
this.satelliteSizeSlider.label.text = "Satellite Trail Width:";
this.satelliteSizeSlider.setRange(1, 20); // Set appropriate range based on your requirements
this.satelliteSizeSlider.setPrecision(0);
this.satelliteSizeSlider.slider.setScaledMinWidth(250);
this.satelliteSizeSlider.setValue(5); // Default value

    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = () => {
        this.newInstance();
    };

// Button Exit
this.exitButton = new PushButton(this);
this.exitButton.text = "Exit";
this.exitButton.icon = ":/toolbar/file-exit.png";
this.exitButton.toolTip = "Close the dialog and clean up.";
this.exitButton.onClick = () => {
    var msg = new MessageBox("Are you sure you want to exit? All temporary images will be closed.", "Confirm Exit", StdIcon_Question, StdButton_Yes, StdButton_No);
    if (msg.execute() == StdButton_Yes) {
        this.cleanupAndClose();
    }
};

this.cleanupAndClose = function() {
    // Close images in the undo stack
    while (this.previewControl.undoStack.length > 0) {
        let imageId = this.previewControl.undoStack.pop().imageId;
        if (!isImageInSelectedList(imageId)) { // Skip images that were selected in the dropdown
            let window = ImageWindow.windowById(imageId);
            if (window && !window.isNull) {
                window.forceClose();
            } else {
                console.writeln("Image window not found or already closed: " + imageId);
            }
        }
    }

    // Close images in the temp image stack
    while (this.previewControl.tempImageStack.length > 0) {
        let imageId = this.previewControl.tempImageStack.pop();
        if (typeof imageId === 'string' && !isImageInSelectedList(imageId)) { // Skip images that were selected in the dropdown
            let window = ImageWindow.windowById(imageId);
            if (window && !window.isNull) {
                window.forceClose();
            } else {
                console.writeln("Image window not found or already closed: " + imageId);
            }
        } else {
            console.writeln("Invalid image ID in tempImageStack: ", imageId);
        }
    }

    console.writeln("Cleanup complete. Closing dialog.");
    this.cancel();
};

function isImageInSelectedList(imageId) {
    for (let i = 0; i < selectedImages.length; i++) {
        if (selectedImages[i] === imageId) {
            return true;
        }
    }
    return false;
}



        this.miniViewport = new MiniViewport(this);

              // Create a horizontal sizer for the miniViewport
      let miniViewportSizer = new HorizontalSizer;
      miniViewportSizer.spacing = 6;
      miniViewportSizer.addStretch(); // Add stretch before the miniViewport
      miniViewportSizer.add(this.miniViewport); // Add the miniViewport
      miniViewportSizer.addStretch(); // Add stretch after the miniViewport

    let leftPanel = new VerticalSizer;
    leftPanel.spacing = 6;
    leftPanel.margin = 6;
    leftPanel.add(this.title_Lbl);
    leftPanel.add(this.instructionBox);
    leftPanel.add(this.imageSelectionSizer);
    leftPanel.add(this.autoSTFButton);
    leftPanel.addStretch();
    leftPanel.add(this.blemishLabel);
    leftPanel.add(this.drawingModeSizer);
        leftPanel.add(this.featherSlider); // Add feather slider here
        leftPanel.add(this.opacitySlider);
        leftPanel.add(this.channelDropdownSizer);


    let executeUndoSizer = new HorizontalSizer;
    executeUndoSizer.spacing = 6;
    executeUndoSizer.add(this.executeButton);
    executeUndoSizer.add(this.undoButton);


    leftPanel.add(miniViewportSizer);
    leftPanel.addStretch();
    leftPanel.add(this.satelliteLabel);
    leftPanel.add(this.satelliteSizeSlider); // Add the slider here
    leftPanel.addStretch();
        leftPanel.add(executeUndoSizer);
        leftPanel.add(this.applyButton);
    leftPanel.add(this.authorshipLabel);

        let instanceExitSizer = new HorizontalSizer;
    instanceExitSizer.spacing = 6;
    instanceExitSizer.add(this.newInstanceButton);
    instanceExitSizer.add(this.exitButton);
    leftPanel.add(instanceExitSizer);


    this.zoomInButton = new PushButton(this);
    this.zoomInButton.text = "";
    this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
    this.zoomInButton.toolTip = "Zoom In";
    this.zoomInButton.onClick = () => {
        this.previewControl.zoomIn();
    };

    this.zoomOutButton = new PushButton(this);
    this.zoomOutButton.text = "";
    this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
    this.zoomOutButton.toolTip = "Zoom Out";
    this.zoomOutButton.onClick = () => {
        this.previewControl.zoomOut();
    };

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Buttons to Zoom In/Out or Use Mouse Wheel";

    // Zoom sizer to hold the zoom in and zoom out buttons
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 6;
    this.zoomSizer.add(this.zoomInButton);
    this.zoomSizer.add(this.zoomOutButton);
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.addStretch();

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(900);
    this.previewControl.setMinHeight(700);

        // Right panel to hold zoom buttons and preview control
    let rightPanel = new VerticalSizer;
    rightPanel.spacing = 6;
    rightPanel.margin = 6;
    rightPanel.add(this.zoomSizer);
    rightPanel.add(this.previewControl, 1);

    let mainSizer = new HorizontalSizer;
    mainSizer.spacing = 6;
    mainSizer.margin = 6;
    mainSizer.add(leftPanel);
    mainSizer.add(rightPanel, 1);

    this.sizer = mainSizer;
    this.adjustToContents();

    this.windowTitle = TITLE;

this.onShow = function() {
    // Get the active window at the start
    let activeWindow = ImageWindow.activeWindow;

    // Check if an image is selected in the dropdown
    if (this.windowSelector_Cb.currentItem >= 0) {
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));

        // Add the active window to selectedImages array if not already added
        if (!isImageInSelectedList(activeWindow.mainView.id)) {
            selectedImages.push(activeWindow.mainView.id);
        }

        if (window && !window.isNull) {
            let selectedImage = window.mainView.image;
            if (selectedImage) {
                console.writeln("Displaying the initial image in the preview.");
                var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.displayImageWindow = window;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
            }
        }
    } else {
        // No image selected, add active window by default
        if (!isImageInSelectedList(activeWindow.mainView.id)) {
            selectedImages.push(activeWindow.mainView.id);
        }

        console.noteln("No image selected for preview.");
        this.previewControl.visible = false;
        this.zoomSizer.visible = false;
        this.adjustToContents();
    }
};


this.onClose = function() {
    parameters.save();
    this.cleanupAndClose(); // Ensure cleanup is done when closing the dialog
};


this.createAndDisplayTemporaryImage = function(selectedImage, applyAutoSTF = false) {
    let window = new ImageWindow(
        selectedImage.width, selectedImage.height,
        selectedImage.numberOfChannels,
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        selectedImage.isColor
    );

    window.mainView.beginProcess(UndoFlag_NoSwapFile);
    window.mainView.image.assign(selectedImage);
    window.mainView.endProcess();

    if (applyAutoSTF) {
        let imageMin = window.mainView.image.minimum();
        parameters.originalMin = imageMin;

        // First PixelMath operation: ($T-min($T))/(1-min($T))
        let pixelMath1 = new PixelMath;
        if (selectedImage.numberOfChannels === 1) {
            pixelMath1.expression = "($T-min($T))/(1-min($T))";
        } else {
            pixelMath1.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                                    "BlackPoint = MinColor;\n" +
                                    "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
            pixelMath1.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.executeOn(window.mainView);

        let imageMedian = window.mainView.image.median();
        parameters.originalMedian = imageMedian;
        let targetMedian = 0.25;

        // Second PixelMath operation: ((Med($T)-1)*.25*$T)/(Med($T)*(.25+$T-1)-.25*$T)
        let pixelMath2 = new PixelMath;
        if (selectedImage.numberOfChannels === 1) {
            pixelMath2.expression = "((Med($T)-1)*0.25*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)";
        } else {
            pixelMath2.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                                    "((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
            pixelMath2.symbols = "L, MedianColor, S";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.executeOn(window.mainView);
  }

    let resizedImage = new Image(window.mainView.image);

    if (resizedImage.width > 0 && resizedImage.height > 0) {
        this.previewControl.displayImage = resizedImage;
        this.previewControl.displayImageWindow = window;
        this.previewControl.doUpdateImage(resizedImage);
        this.previewControl.initScrollBars();
    } else {
        console.writeln("Resized image has invalid dimensions.");
    }
    window.forceClose();

    return resizedImage;
};

}
BlemishEraserDialog.prototype = new Dialog;



function main() {
    console.show();
     Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new BlemishEraserDialog();
    dialog.execute();
}

main();
