
#feature-id FAME : SetiAstro > FAME
#feature-info This script allows freehand, ellipse, and rectangular drawing of masks.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Freehand Adaptive Mask Editor
 * Version: V1.1.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is designed for freehand drawing, creating ellipses,
 * and drawing rectangles that can then be used as masks.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/


#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define TITLE "Freehand Adaptive Mask Editor"
#define VERSION "V1.1.1"

let parameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    shapes: [],
    save: function() {
        Parameters.set("shapes", JSON.stringify(this.shapes));
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function() {
        if (Parameters.has("shapes")) {
            this.shapes = JSON.parse(Parameters.getString("shapes"));
        }
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
    }
};


function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.isDrawing = false; // Flag for detecting drawing
    this.isTransforming = false; // Flag for detecting transforming (rotate + resize)
    this.currentShape = [];
    this.shapes = [];
    this.activeShapeIndex = 0; // Initialize activeShapeIndex
    this.scrollPosition = new Point(0, 0); // Ensure scrollPosition is always defined
    this.previousZoomLevel = 1;
    this.shapeType = "Freehand"; // Default shape type
    this.transformCenter = null; // Center point for transformations
    this.initialDistance = null; // Initial distance for resizing
    this.initialAngle = null; // Initial angle for rotating

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.calculateTransformCenter = function(shape) {
        let sumX = 0;
        let sumY = 0;
        shape.forEach(point => {
            sumX += point[0];
            sumY += point[1];
        });
        return [sumX / shape.length, sumY / shape.length];
    };

    this.calculateDistance = function(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    };

    this.calculateAngle = function(x1, y1, x2, y2) {
        return Math.atan2(y2 - y1, x2 - x1);
    };

    this.transformShape = function(shape, angle, scaleX, scaleY, centerX, centerY) {
        return shape.map(point => {
            let translatedX = point[0] - centerX;
            let translatedY = point[1] - centerY;
            let rotatedX = translatedX * Math.cos(angle) - translatedY * Math.sin(angle);
            let rotatedY = translatedX * Math.sin(angle) + translatedY * Math.cos(angle);
            let resizedX = rotatedX * scaleX;
            let resizedY = rotatedY * scaleY;
            return [resizedX + centerX, resizedY + centerY];
        });
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        var parent = this.parent; // Store reference to parent
        if (modifiers === 1) { // Shift key detection
            parent.startX = x + parent.scrollPosition.x;
            parent.startY = y + parent.scrollPosition.y;
            parent.isDrawing = true;
            parent.dragging = false; // Prevent scrolling while drawing

            // Handle different shape types
            if (parent.shapeType === "Ellipse" || parent.shapeType === "Rectangle") {
                parent.currentShape = [[parent.startX, parent.startY], [parent.startX, parent.startY]];
            }
        } else if (modifiers === 2) { // Ctrl key detection
            parent.startX = x + parent.scrollPosition.x;
            parent.startY = y + parent.scrollPosition.y;
            parent.isMoving = true;
            parent.dragging = false; // Prevent scrolling while moving
            parent.originalShape = [...parent.shapes[parent.activeShapeIndex]]; // Save original shape
        } else if (modifiers === 4) { // Alt key detection
            parent.startX = x + parent.scrollPosition.x;
            parent.startY = y + parent.scrollPosition.y;
            parent.isTransforming = true;
            parent.transformCenter = parent.calculateTransformCenter(parent.shapes[parent.activeShapeIndex]);
            parent.initialAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], parent.startX, parent.startY);
            parent.initialDistance = parent.calculateDistance(parent.startX, parent.startY, parent.transformCenter[0], parent.transformCenter[1]);
            parent.originalShape = [...parent.shapes[parent.activeShapeIndex]]; // Save original shape
        } else {
            this.cursor = new Cursor(StdCursor_ClosedHand);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            parent.dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        var parent = this.parent; // Store reference to parent
        if (!parent) return;
        if (parent.isDrawing) {
            let endX = x + parent.scrollPosition.x;
            let endY = y + parent.scrollPosition.y;

            if (parent.shapeType === "Freehand") {
                parent.currentShape.push([endX, endY]);
            } else if (parent.shapeType === "Ellipse") {
                let centerX = (parent.startX + endX) / 2;
                let centerY = (parent.startY + endY) / 2;
                let radiusX = Math.abs(endX - parent.startX) / 2;
                let radiusY = Math.abs(endY - parent.startY) / 2;
                parent.currentShape = [];
                for (let angle = 0; angle < 2 * Math.PI; angle += 0.01) {
                    parent.currentShape.push([
                        centerX + radiusX * Math.cos(angle),
                        centerY + radiusY * Math.sin(angle)
                    ]);
                }
                parent.currentShape.push(parent.currentShape[0]); // Close the shape
            } else if (parent.shapeType === "Rectangle") {
                parent.currentShape = [
                    [parent.startX, parent.startY],
                    [endX, parent.startY],
                    [endX, endY],
                    [parent.startX, endY],
                    [parent.startX, parent.startY]
                ];
            }

            if (parent.viewport) {
                parent.viewport.update();
            }
        } else if (parent.isMoving) {
            let dx = x + parent.scrollPosition.x - parent.startX;
            let dy = y + parent.scrollPosition.y - parent.startY;
            parent.shapes[parent.activeShapeIndex] = parent.originalShape.map(point => [point[0] + dx, point[1] + dy]);
            if (parent.viewport) {
                parent.viewport.update();
            }
        } else if (parent.isTransforming) {
            let currentAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], x + parent.scrollPosition.x, y + parent.scrollPosition.y);
            let angleDifference = currentAngle - parent.initialAngle;
            let currentDistance = parent.calculateDistance(x + parent.scrollPosition.x, y + parent.scrollPosition.y, parent.transformCenter[0], parent.transformCenter[1]);
            let scale = currentDistance / parent.initialDistance;
            parent.shapes[parent.activeShapeIndex] = parent.transformShape(parent.originalShape, angleDifference, scale, scale, parent.transformCenter[0], parent.transformCenter[1]);
            if (parent.viewport) {
                parent.viewport.update();
            }
        } else if (parent.dragging) {
            parent.scrollPosition = new Point(parent.scrollPosition).translatedBy(parent.dragOrigin.x - x, parent.dragOrigin.y - y);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            if (parent.viewport) {
                parent.viewport.update();
            }
        }
    };

this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    if (!parent) return;
    if (parent.isDrawing) {
        parent.isDrawing = false;
        if (parent.shapeType === "Freehand") {
            parent.currentShape.push([x + parent.scrollPosition.x, y + parent.scrollPosition.y]);
            parent.currentShape.push(parent.currentShape[0]); // Close the shape
        }
        parent.shapes.push(parent.currentShape);
        parent.currentShape = [];
        parent.activeShapeIndex = parent.shapes.length - 1; // Set the newly drawn shape as the active shape
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        parent.isMoving = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        parent.isTransforming = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else {
        this.cursor = new Cursor(StdCursor_OpenHand);
        parent.dragging = false;
    }
};


    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = new Rect(x0, y0, x1, y1).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();

            // Draw the user-defined shapes if they exist
            this.parent.shapes.forEach((shape, index) => {
                g.pen = new Pen(index === this.parent.activeShapeIndex ? 0xff00ff00 : 0xffff0000);
                for (let i = 0; i < shape.length - 1; i++) {
                    g.drawLine(shape[i][0] - this.parent.scrollPosition.x, shape[i][1] - this.parent.scrollPosition.y,
                        shape[i + 1][0] - this.parent.scrollPosition.x, shape[i + 1][1] - this.parent.scrollPosition.y);
                }
            });

            // Draw the current shape if it exists
            if (this.parent.currentShape.length > 0) {
                g.pen = new Pen(0xff00ff00);
                for (let i = 0; i < this.parent.currentShape.length - 1; i++) {
                    g.drawLine(this.parent.currentShape[i][0] - this.parent.scrollPosition.x, this.parent.currentShape[i][1] - this.parent.scrollPosition.y,
                        this.parent.currentShape[i + 1][0] - this.parent.scrollPosition.x, this.parent.currentShape[i + 1][1] - this.parent.scrollPosition.y);
                }
            }
        }

        g.end();
        gc();
    };

    this.setFocus = function() {
        this.viewport.onKeyPress = (keyCode, modifiers) => {
            if (keyCode === 0x20) { // Spacebar key
                this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
                this.viewport.update();
            }
        };
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;


ScrollControl.prototype.setFocus = function() {
    this.viewport.onKeyPress = (keyCode, modifiers) => {
        if (keyCode === 0x20) { // Spacebar key
            this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
            this.viewport.update();
        }
    };
};

function FAMEDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>Freehand Adaptive Mask Editor (FAME) " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

    this.instructions_Lbl = new TextBox(this);
    this.instructions_Lbl.readOnly = true;
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.text = "Instructions:\n\nShift + Click and drag to draw a shape.\n\nMultiple Shapes can be drawn.\n\nCTRL+Click and Drag to MOVE the drawn shape.\nALT+Click and Drag to ROTATE and RESIZE\nSPACEBAR cycles through the active shapes\n\nGrey undo button removes the active shape\nRed Reset Button removes all shapes.";
    this.instructions_Lbl.setScaledMinWidth(450); // Set a fixed width for the instructions

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

    this.windowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
            if (window && !window.isNull) {
                parameters.targetWindow = window;
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                } else {
                    console.error("Selected image is undefined.");
                }
            } else {
                console.writeln("No valid window selected for preview!");
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };

    // Update this section to include the imageLabel
    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel); // Add the label to the sizer
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.shapeType = "Freehand"; // Default shape type

    this.freehandShape_Rb = new RadioButton(this);
    this.freehandShape_Rb.text = "Freehand Shape";
    this.freehandShape_Rb.checked = true;
    this.freehandShape_Rb.onCheck = () => {
        if (this.freehandShape_Rb.checked) {
            this.shapeType = "Freehand";
            this.previewControl.shapeType = "Freehand";
        }
    };

    this.ellipseShape_Rb = new RadioButton(this);
    this.ellipseShape_Rb.text = "Ellipse";
    this.ellipseShape_Rb.onCheck = () => {
        if (this.ellipseShape_Rb.checked) {
            this.shapeType = "Ellipse";
            this.previewControl.shapeType = "Ellipse";
        }
    };

    this.rectangleShape_Rb = new RadioButton(this);
    this.rectangleShape_Rb.text = "Rectangle";
    this.rectangleShape_Rb.onCheck = () => {
        if (this.rectangleShape_Rb.checked) {
            this.shapeType = "Rectangle";
            this.previewControl.shapeType = "Rectangle";
        }
    };

    this.shapeSizer = new VerticalSizer;
    this.shapeSizer.spacing = 4;
    this.shapeSizer.add(this.freehandShape_Rb);
    this.shapeSizer.add(this.ellipseShape_Rb);
    this.shapeSizer.add(this.rectangleShape_Rb);

      this.maskTypeLabel = new Label(this);
      this.maskTypeLabel.text = "Mask Type:";
      this.maskTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

      this.maskType = "Binary";

this.binaryMask_Cb = new CheckBox(this);
this.binaryMask_Cb.text = "Binary";
this.binaryMask_Cb.toolTip = "Binary:\nBest for Linear Images.\nCreates a mask with binary values (0 or 1)\ninside the selected shapes.";
this.binaryMask_Cb.checked = true; // Default to Binary
this.binaryMask_Cb.onCheck = () => {
    if (this.binaryMask_Cb.checked) {
        this.lightnessMask_Cb.checked = false;
        this.chrominanceMask_Cb.checked = false;
        this.colorMask_Cb.checked = false;
        this.maskType = "Binary";
    }
};

this.lightnessMask_Cb = new CheckBox(this);
this.lightnessMask_Cb.text = "Lightness";
this.lightnessMask_Cb.toolTip = "Lightness:\nCreates a mask based on the brightness values\nof the original image inside the selected shapes.\nWill look black if applied to linear images!";
this.lightnessMask_Cb.onCheck = () => {
    if (this.lightnessMask_Cb.checked) {
        this.binaryMask_Cb.checked = false;
        this.chrominanceMask_Cb.checked = false;
        this.colorMask_Cb.checked = false;
        this.maskType = "Lightness";
    }
};

this.chrominanceMask_Cb = new CheckBox(this);
this.chrominanceMask_Cb.text = "Chrominance";
this.chrominanceMask_Cb.toolTip = "Chrominance:\nCreates a mask based on the chrominance (color saturation)\nvalues of the original image inside the selected shapes.";
this.chrominanceMask_Cb.onCheck = () => {
    if (this.chrominanceMask_Cb.checked) {
        this.binaryMask_Cb.checked = false;
        this.lightnessMask_Cb.checked = false;
        this.colorMask_Cb.checked = false;
        this.maskType = "Chrominance";
    }
};
      // Add new elements for the Color mask type
this.colorMask_Cb = new CheckBox(this);
this.colorMask_Cb.text = "Color";
this.colorMask_Cb.toolTip = "Color:\nCreates a mask based on the specified color saturation values\ninside the selected shapes.";
this.colorMask_Cb.onCheck = () => {
    if (this.colorMask_Cb.checked) {
        this.binaryMask_Cb.checked = false;
        this.lightnessMask_Cb.checked = false;
        this.chrominanceMask_Cb.checked = false;
        this.maskType = "Color";
    }
};

// Add dropdown menu for selecting specific colors
this.colorDropdown = new ComboBox(this);
this.colorDropdown.addItem("Red");
this.colorDropdown.addItem("Yellow");
this.colorDropdown.addItem("Green");
this.colorDropdown.addItem("Cyan");
this.colorDropdown.addItem("Blue");
this.colorDropdown.addItem("Magenta");
this.colorDropdown.toolTip = "Select the color for the mask.";

// Create a new HorizontalSizer for the "Color" checkbox and dropdown menu
this.colorMaskSizer = new HorizontalSizer;
this.colorMaskSizer.spacing = 4;
this.colorMaskSizer.addStretch();
this.colorMaskSizer.add(this.colorMask_Cb);
this.colorMaskSizer.add(this.colorDropdown);
this.colorMaskSizer.addStretch();


      this.maskTypeSizer = new HorizontalSizer;
      this.maskTypeSizer.spacing = 4;
      this.maskTypeSizer.add(this.maskTypeLabel);
      this.maskTypeSizer.add(this.binaryMask_Cb);
      this.maskTypeSizer.add(this.lightnessMask_Cb);
      this.maskTypeSizer.add(this.chrominanceMask_Cb);




        this.blurAmount_Slider = new NumericControl(this);
    this.blurAmount_Slider.label.text = "Blur Amount: ";
    this.blurAmount_Slider.setRange(1, 200);
    this.blurAmount_Slider.slider.setRange(1, 200);
    this.blurAmount_Slider.setValue(25); // Default value

    // Add the AutoSTF checkbox
this.autoSTF_Cb = new CheckBox(this);
this.autoSTF_Cb.text = "AutoSTF";
this.autoSTF_Cb.checked = false; // Default to unchecked
this.autoSTF_Cb.onCheck = () => {
    if (parameters.targetWindow) {
        var selectedImage = parameters.targetWindow.mainView.image;
        if (selectedImage) {
            let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
            this.previewControl.displayImage = tmpImage;
            this.previewControl.viewport.update();
        }
    }
};

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Preview Zoom Level: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.zoomLevelComboBox = new ComboBox(this);
    this.zoomLevelComboBox.addItem("1:1");
    this.zoomLevelComboBox.addItem("1:2");
    this.zoomLevelComboBox.addItem("1:4");
    this.zoomLevelComboBox.addItem("1:8");
    this.zoomLevelComboBox.addItem("Fit to Preview");
    this.zoomLevelComboBox.currentItem = 4;

    // Add a variable to store the previous zoom level
    this.previousZoomLevel = this.zoomLevelComboBox.currentItem;

    this.zoomLevelComboBox.onItemSelected = (index) => {
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Adjusting preview for image with ID: " + parameters.targetWindow.mainView.id);
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();

                // Scale shapes according to the new zoom level
                let newZoomLevel = this.downsamplingFactor;
                this.scaleShapes(newZoomLevel);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for preview!");
        }
    };

    this.resetButton = new ToolButton(this);
    this.resetButton.icon = this.scaledResource(":/icons/execute.png"); // Updated to use the red lightning bolt icon
    this.resetButton.toolTip = "Reset selections";
    this.resetButton.onMousePress = () => {
        this.previewControl.shapes = [];
        this.previewControl.viewport.update();
    };

this.undoButton = new ToolButton(this);
this.undoButton.icon = this.scaledResource(":/icons/reload.png"); // Updated to use the grey icon for undo
this.undoButton.toolTip = "Undo last shape";
this.undoButton.onMousePress = () => {
    if (this.previewControl.shapes.length > 0) {
        // Remove the active shape
        this.previewControl.shapes.splice(this.previewControl.activeShapeIndex, 1);

        // Adjust activeShapeIndex
        if (this.previewControl.shapes.length === 0) {
            this.previewControl.activeShapeIndex = 0; // Reset to 0 if no shapes are left
        } else {
            this.previewControl.activeShapeIndex = this.previewControl.activeShapeIndex % this.previewControl.shapes.length;
        }

        this.previewControl.viewport.update();
    }
};


// Update this section to include the AutoSTF checkbox in the zoomSizer
this.zoomSizer = new HorizontalSizer;
this.zoomSizer.spacing = 4;
this.zoomSizer.add(this.autoSTF_Cb); // Add the AutoSTF checkbox to the sizer
this.zoomSizer.add(this.zoomLabel);
this.zoomSizer.add(this.zoomLevelComboBox);
this.zoomSizer.add(this.undoButton); // Add the undo button next to the zoom control
this.zoomSizer.add(this.resetButton); // Add the reset button next to the zoom control

// Define the label for the authorship information
this.authorship_Lbl = new Label(this);
this.authorship_Lbl.frameStyle = FrameStyle_Box;
this.authorship_Lbl.margin = 6;
this.authorship_Lbl.useRichText = true;
this.authorship_Lbl.text = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
this.authorship_Lbl.textAlignment = TextAlign_Center;

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Execute";
    this.execute_Btn.toolTip = "Generate the mask based on the user-defined shapes.";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.execute_Btn.onClick = () => {
        console.writeln("Executing the script with the selected parameters.");
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.generateMaskImage(selectedImage);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 6;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.addStretch();
    this.buttonSizerHorizontal.add(this.execute_Btn);

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 4;

    // Define a spacer control with a fixed width
this.leftSideSpacer = new Control(this);
this.leftSideSpacer.setFixedWidth(5); // Adjust the width as needed

// Insert the spacer control at the beginning of the mainSizer
this.mainSizer.insert(0, this.leftSideSpacer);
this.mainSizer.addSpacing(0); // Add some spacing after the spacer

    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;
    this.leftSizer.add(this.title_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.instructions_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.imageSelectionSizer); // Add the image selection sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.shapeSizer); // Add the shape type sizer
    this.leftSizer.addSpacing(10);
        this.leftSizer.add(this.blurAmount_Slider); // Add the blur amount slider
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.maskTypeSizer);
    this.leftSizer.add(this.colorMaskSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.zoomSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.authorship_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.buttonSizerHorizontal);

    this.mainSizer.add(this.leftSizer);
    this.mainSizer.add(this.previewControl, 1, Align_Expand);

    this.sizer = this.mainSizer;

    this.windowTitle = "Freehand Adaptive Mask Editor (FAME)";
    this.adjustToContents();

        // Add key event listener
    this.onKeyDown = function(keyCode, modifiers) {
        if (keyCode === 0x20) { // Spacebar key
            if (this.previewControl.shapes.length > 0) {
                this.previewControl.activeShapeIndex = (this.previewControl.activeShapeIndex + 1) % this.previewControl.shapes.length;
                this.previewControl.viewport.update();
            }
        }
    }.bind(this);

    // Ensure the initial display setup calls the correct function
this.onShow = () => {
    if (this.windowSelector_Cb.currentItem >= 0) { // Adjust for "Select Image:" item
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
        if (window && !window.isNull) {
            let selectedImage = window.mainView.image;
            if (selectedImage) {
                console.writeln("Displaying the initial image in the preview.");
                var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();

                // Set the previous zoom level to the initial downsampling factor
                this.previousZoomLevel = this.downsamplingFactor;
            }
        }
    } else {
        console.noteln("No image selected for preview.");
        this.previewControl.visible = false;
        this.zoomSizer.visible = false;
        this.adjustToContents(); // Adjust the dialog size to fit the initial content
    }

    this.previewControl.setFocus(); // Set focus to handle key events
};

    // Add a variable to store the downsampling factor
    //this.downsamplingFactor = 1;

// Function to scale shapes according to the new zoom level
this.scaleShapes = function(newZoomLevel) {
    try {
        let scaleRatio = this.previousZoomLevel / newZoomLevel;
        this.previewControl.shapes = this.previewControl.shapes.map(shape => shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]));
        this.previousZoomLevel = newZoomLevel;
        if (this.previewControl.viewport) {
            this.previewControl.viewport.update();
        }
    } catch (error) {
        // Suppress any warnings or errors
    }
};

    // Function to create, resize, and display a temporary image
      this.createAndDisplayTemporaryImage = function(selectedImage) {
          let window = new ImageWindow(selectedImage.width, selectedImage.height,
              selectedImage.numberOfChannels,
              selectedImage.bitsPerSample,
              selectedImage.isReal,
              selectedImage.isColor
          );

          window.mainView.beginProcess();
          window.mainView.image.assign(selectedImage);
          window.mainView.endProcess();

          if (this.autoSTF_Cb.checked) {
              var P = new PixelMath;
              P.expression =
                  "C = -2.8  ;\n" +
                  "B = 0.20  ;\n" +
                  "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                  "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
              P.expression1 = "";
              P.expression2 = "";
              P.expression3 = "";
              P.useSingleExpression = true;
              P.symbols = "C,B,c";
              P.clearImageCacheAndExit = false;
              P.cacheGeneratedImages = false;
              P.generateOutput = true;
              P.singleThreaded = false;
              P.optimization = true;
              P.use64BitWorkingImage = false;
              P.rescale = false;
              P.rescaleLower = 0;
              P.rescaleUpper = 1;
              P.truncate = true;
              P.truncateLower = 0;
              P.truncateUpper = 1;
              P.createNewImage = false;
              P.showNewImage = true;
              P.newImageId = "";
              P.newImageWidth = 0;
              P.newImageHeight = 0;
              P.newImageAlpha = false;
              P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
              P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
              P.executeOn(window.mainView);
          }

          var P = new IntegerResample;
          switch (this.zoomLevelComboBox.currentItem) {
              case 0: // 1:1
                  P.zoomFactor = -1;
                  this.downsamplingFactor = 1;
                  break;
              case 1: // 1:2
                  P.zoomFactor = -2;
                  this.downsamplingFactor = 2;
                  break;
              case 2: // 1:4
                  P.zoomFactor = -4;
                  this.downsamplingFactor = 4;
                  break;
              case 3: // 1:8
                  P.zoomFactor = -8;
                  this.downsamplingFactor = 8;
                  break;
              case 4: // Fit to Preview
                  const previewWidth = this.previewControl.width;
                  const widthScale = Math.floor(selectedImage.width / previewWidth);
                  P.zoomFactor = -Math.max(widthScale, 1);
                  this.downsamplingFactor = Math.max(widthScale, 1);
                  break;
              default:
                  P.zoomFactor = -2; // Default to 1:2 if nothing is selected
                  this.downsamplingFactor = 2;
                  break;
          }

          P.executeOn(window.mainView);

          let resizedImage = new Image(window.mainView.image);

          if (resizedImage.width > 0 && resizedImage.height > 0) {
              this.previewControl.displayImage = resizedImage;
              this.previewControl.doUpdateImage(resizedImage);
              this.previewControl.initScrollBars();
          } else {
              console.error("Resized image has invalid dimensions.");
          }

          window.forceClose();

          return resizedImage;
      };
}
FAMEDialog.prototype = new Dialog;

// Update mask generation logic to handle the "Color" mask type
function getColorRange(color) {
    switch (color) {
        case "Red":
            return { min: 330, max: 40 }; // Adjusted to be narrower in the orange region
        case "Yellow":
            return { min: 40, max: 85 }; // Adjusted to be narrower in the red region
        case "Green":
            return { min: 85, max: 160 }; // Kept as is
        case "Cyan":
            return { min: 160, max: 200 }; // Kept as is
        case "Blue":
            return { min: 200, max: 270 }; // Kept as is
        case "Magenta":
            return { min: 270, max: 330 }; // Extended into the purple region
        default:
            return { min: 0, max: 0 }; // Default to no range
    }
}

FAMEDialog.prototype.generateMaskImage = function(selectedImage) {
   Console.noteln("Mask Creation Started!");
   console.flush();
    // Check if the image is a mono image
    if (selectedImage.numberOfChannels < 3 && this.maskType === "Color") {
        (new MessageBox("Cannot create a Color Mask from a mono image.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    // Create a new grayscale image with the same dimensions as the original image
    let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    maskWindow.mainView.beginProcess();
    let maskImage = maskWindow.mainView.image;
    maskImage.fill(0); // Initialize the mask image with black (0)

    // Scale shapes according to the full-size image dimensions
    let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image
    let scaledShapes = this.previewControl.shapes.map(shape => shape.map(point => [
        Math.round(point[0] * scaleRatio),
        Math.round(point[1] * scaleRatio)
    ]));

    // Function to find the minimum and maximum y-coordinates in the polygon
    function findMinMaxY(polygon) {
        let minY = polygon[0][1];
        let maxY = polygon[0][1];
        for (let i = 1; i < polygon.length; i++) {
            if (polygon[i][1] < minY) minY = polygon[i][1];
            if (polygon[i][1] > maxY) maxY = polygon[i][1];
        }
        return { minY: minY, maxY: maxY };
    }

    // Function to fill a polygon using the scan-line filling algorithm
    function fillPolygon(image, polygon) {
        let { minY, maxY } = findMinMaxY(polygon);

        for (let y = minY; y <= maxY; y++) {
            if (y < 0 || y >= image.height) continue; // Skip out-of-bounds y-coordinates
            let intersections = [];
            for (let i = 0; i < polygon.length; i++) {
                let j = (i + 1) % polygon.length;
                let x1 = polygon[i][0], y1 = polygon[i][1];
                let x2 = polygon[j][0], y2 = polygon[j][1];

                if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) {
                    let x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                    intersections.push(Math.round(x));
                }
            }
            intersections.sort((a, b) => a - b);

            for (let k = 0; k < intersections.length; k += 2) {
                let xStart = Math.max(intersections[k], 0);
                let xEnd = Math.min(intersections[k + 1], image.width - 1);
                for (let x = xStart; x <= xEnd; x++) {
                    if (this.maskType === "Binary") {
                        image.setSample(1, x, y, 0); // Set the pixel to white (1) for binary mask
                    } else if (this.maskType === "Lightness") {
                        let brightness = selectedImage.sample(x, y, 0); // Get the brightness value
                        image.setSample(brightness, x, y, 0); // Set the pixel to brightness value for lightness mask
                    } else if (this.maskType === "Chrominance") {
                        if (selectedImage.numberOfChannels < 3) {
                            console.warningln("Cannot Create a Chrominance Mask of a Grey Scale Image!!!");
                            return;
                        }
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let maxChannel = Math.max(r, g, b);
                        let minChannel = Math.min(r, g, b);
                        let chrominance = (maxChannel - minChannel) / maxChannel; // Calculate chrominance value
                        image.setSample(chrominance, x, y, 0); // Set the pixel to chrominance value for chrominance mask
                    } else if (this.maskType === "Color") {
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let hue = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
                        if (hue < 0) hue += 360;
                        let { min, max } = getColorRange(this.colorDropdown.itemText(this.colorDropdown.currentItem));
                        let colorValue = (min < max)
                            ? (hue >= min && hue <= max ? 1 : 0)
                            : ((hue >= min || hue <= max) ? 1 : 0);
                        let chrominance = (Math.max(r, g, b) - Math.min(r, g, b)) / Math.max(r, g, b); // Calculate chrominance value
                        image.setSample(colorValue * chrominance, x, y, 0); // Scale color value by chrominance
                    }
                }
            }
        }
    }

    // Fill the mask image with the appropriate values inside the user-defined shapes
    scaledShapes.forEach(shape => {
        fillPolygon.call(this, maskImage, shape);
    });

    maskWindow.mainView.endProcess();

    // Set mask window ID based on mask type
    let maskSuffix = "";
    if (this.maskType === "Binary") {
        maskSuffix = "_bin";
    } else if (this.maskType === "Lightness") {
        maskSuffix = "_lght";
    } else if (this.maskType === "Chrominance") {
        maskSuffix = "_chrm";
    } else if (this.maskType === "Color") {
        maskSuffix = "_color";
    }

    maskWindow.mainView.id = parameters.targetWindow.mainView.id + "_FAME_Mask" + maskSuffix;
    maskWindow.show();

    // Apply convolution to blur the mask image
    var blurAmount = this.blurAmount_Slider.value;
    var P = new Convolution;
    P.mode = Convolution.prototype.Parametric;
    P.sigma = blurAmount;
    P.executeOn(maskWindow.mainView);

    console.noteln("Mask Created Successfully!");
};

function main() {
    console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new FAMEDialog();
    dialog.execute();
}

main();
