
#feature-id    PerfectPalettePicker : SetiAstro > Perfect Palette Picker
#feature-icon  palettepicker.svg
#feature-info  Perfect Palette Picker script. Creates 12 popular NB palettes


/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * Perfect Palette Picker
 * Version: 1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script facilitates the creation of 12 popular narrowband (NB) palettes
 * such as SHO, HOO, HSO, etc., derived from Ha/OIII/SII or extracted OSC channels.
 * Key functionalities include:
 * - Gathering Ha, OIII, SII, or OSC images from the user
 * - Downsampling and stretching each channel to a target median of ~0.25
 * - Generating 12 palette previews for user selection
 * - Allowing users to click on a palette preview to create a final combined image
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license,
 *    and indicate if changes were made. You may do so in any reasonable manner,
 *    but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2025 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/



#include <pjsr/Sizer.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/FrameStyle.jsh>

#define VERSION "1.0"

/* ---------------------------------------------------------------------------
 *                PixelMath-based: Stretch channel to target median=0.25
 * --------------------------------------------------------------------------- */
function processMonoImage( targetView, targetMedian, iteration )
{
   // For demonstration, we’ll call iteration for logging, but you can do multi-pass.
   console.writeln( "processMonoImage(", targetView.id,
                    ") iteration #", iteration,
                    " => targetMedian=", targetMedian );

   var P = new ProcessContainer;

   // Step 1) BlackPoint offset + initial rescale
   var P001 = new PixelMath;
   P001.expression =
      "BlackPoint = iif((med($T) - 2.7*sdev($T))<min($T), min($T), med($T) - 2.7*sdev($T));\n" +
      "Rescaled   = ($T - BlackPoint) / (1 - BlackPoint);";
   P001.useSingleExpression      = true;
   P001.symbols = "BlackPoint, Rescaled, CurrentMedian, DesiredMedian, Alpha";
   P001.clearImageCacheAndExit   = false;
   P001.cacheGeneratedImages     = false;
   P001.generateOutput           = true;
   P001.singleThreaded           = false;
   P001.optimization             = true;
   P001.use64BitWorkingImage     = true;
   P001.rescale                  = false;
   P001.truncate                 = true;
   P001.truncateLower            = 0;
   P001.truncateUpper            = 1;
   P001.createNewImage           = false;
   P001.showNewImage             = true;
   P.add(P001);

   // Step 2) Attempt to bring median => targetMedian
   var P002 = new PixelMath;
   P002.expression =
      "((Med($T)-1)*" + targetMedian + "*$T)/" +
      "(Med($T)*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
   P002.useSingleExpression      = true;
   P002.clearImageCacheAndExit   = false;
   P002.cacheGeneratedImages     = false;
   P002.generateOutput           = true;
   P002.singleThreaded           = false;
   P002.optimization             = true;
   P002.use64BitWorkingImage     = true;
   P002.symbols = "L, S";
   P002.rescale                  = false;
   P002.truncate                 = true;
   P002.truncateLower            = 0;
   P002.truncateUpper            = 1;
   P002.createNewImage           = false;
   P002.showNewImage             = true;
   P.add(P002);

   // Execute the ProcessContainer steps
   P.executeOn( targetView );
}

/* ---------------------------------------------------------------------------
 *      Helper: Downsample a View by 4× using IntegerResample
 * --------------------------------------------------------------------------- */
function downsample4x( view )
{
   console.writeln("Downsampling: ", view.id, " by 4× ...");
   let P = new IntegerResample;
   P.zoomFactor = -4;
   P.downsamplingMode = IntegerResample.prototype.Average;
   P.xResolution = 72.000;
   P.yResolution = 72.000;
   P.metric = false;
   P.forceResolution = false;
   P.gammaCorrection = false;
   P.noGUIMessages = true;
   P.executeOn( view );
}

function extractOSCchannels( mainView )
{
   // 1) Verify we have at least 3 channels
   if (mainView.image.numberOfChannels < 3)
   {
      console.warningln("[!] The image has fewer than 3 channels—skipping extraction.");
      return [];
   }

   // 2) Configure ChannelExtraction
   let P = new ChannelExtraction;
   // We want to extract an RGB color space
   P.colorSpace = ChannelExtraction.prototype.RGB;


   // For each channel, set "enabled"=true and supply a postfix or prefix for the output ID
   // e.g. we’ll name them _R, _G, _B
   P.channels = [
      [ true, "" ],
      [ true, "" ],
      [ true, "" ]
   ];

   // We can inherit the same sample format as the source
   P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
   // Optionally preserve astrometric solution if the image has it
   P.inheritAstrometricSolution = true;

   // Optionally set prefix/suffix if you want to rename the extracted windows, e.g.:
   // P.outputPrefix = "Extracted_";
   // or P.outputPostfix = "_Ch";
   // If left empty, the script uses the channel postfix from P.channels above.

   // 3) Execute on the source mainView
   P.executeOn( mainView );

   // 4) At this point, PixInsight has created up to 3 new ImageWindows:
   //    [ originalId + "_R", originalId + "_G", originalId + "_B" ]
   let baseId = mainView.id;    // e.g. "M101" => "M101_R", "M101_G", "M101_B"
   let Rwin = ImageWindow.windowById( baseId + "_R" );
   let Gwin = ImageWindow.windowById( baseId + "_G" );
   let Bwin = ImageWindow.windowById( baseId + "_B" );

   // 5) Verify we got all three
   if (!Rwin || !Gwin || !Bwin)
   {
      console.warningln("[!] ChannelExtraction: some channel windows not found for base ID:", baseId);
      return [];
   }
       // 6) Hide the extracted channel windows to prevent them from showing to the user
    Rwin.hide();
    Gwin.hide();
    Bwin.hide();

   // 7) Return their mainViews in [R, G, B] order
   return [ Rwin.mainView, Gwin.mainView, Bwin.mainView ];
}




/*
 * Helper: Combine 3 mono channel Views => single color ImageWindow
 * via PixelMath.  chViews is [ Rview, Gview, Bview ], each possibly null.
 */
function combineChannelsToColor( chViews, outputId )
{
   // chViews is [ Rview, Gview, Bview ], each possibly null.
   // We'll create a new 3-channel color ImageWindow, then use PixelMath in
   // multi-expression mode with expression=chViews[0].id, expression1=..., etc.

   // Find a non-null reference view for dimensions/bit depth
   let referenceView = chViews[0] || chViews[1] || chViews[2];
   if ( !referenceView )
   {
      console.warningln("No valid channels to combine—aborting.");
      return null;
   }

   // Create a new empty 3-channel color ImageWindow
   let width  = referenceView.image.width;
   let height = referenceView.image.height;
   let bits   = referenceView.image.bitsPerSample;
   let real   = referenceView.image.isReal;

   let targetWin = new ImageWindow( width, height, 3, bits, real, /*isColor=*/true, outputId );
   targetWin.mainView.beginProcess();
   targetWin.mainView.image.fill( 0 );  // Initialize to black
   targetWin.mainView.endProcess();

   // Build the PixelMath expressions for each channel:
   //   If chViews[c] is non-null, use its .id; otherwise "0"
   let exprR = chViews[0] ? chViews[0].id : "0";
   let exprG = chViews[1] ? chViews[1].id : "0";
   let exprB = chViews[2] ? chViews[2].id : "0";

   // Configure PixelMath in multiple-expressions mode
   let PM = new PixelMath;
   PM.useSingleExpression = false;
   PM.expression  = exprR;  // Red channel
   PM.expression1 = exprG;  // Green channel
   PM.expression2 = exprB;  // Blue channel
   PM.expression3 = "";     // No alpha

   // We already created the target image window, so do NOT create new image in PM
   PM.createNewImage         = false;
   PM.showNewImage           = false;
   PM.clearImageCacheAndExit = false;
   PM.cacheGeneratedImages   = false;
   PM.generateOutput         = true;
   PM.singleThreaded         = false;
   PM.optimization           = true;
   PM.use64BitWorkingImage   = false; // or true, if you prefer
   PM.rescale               = false;
   PM.truncate              = true;
   PM.truncateLower         = 0;
   PM.truncateUpper         = 1;

   // Apply PixelMath on the new 3-channel color view
   PM.executeOn( targetWin.mainView );

   // Return the final color View for further use
   return targetWin.mainView;
}

/**
 * combineChannelsToColorExpressions( outId, exprR, exprG, exprB ):
 *  1) Create a new 3-channel color ImageWindow of the same size as one of your preview images
 *  2) Runs PixelMath multi-expressions (exprR, exprG, exprB) on it
 *  3) Returns the new mainView
 */


/* ---------------------------------------------------------------------------
 *      Helper: Map palette name => [R, G, B] channel
 * --------------------------------------------------------------------------- */
function mapChannels( paletteName, Ha, OIII, SII )
{
   let usedSII = (SII !== null && SII !== undefined) ? SII : Ha;
   // If any are null, this function should handle fallback logic.
   switch ( paletteName )
   {
      case "SHO":       return [ usedSII, Ha,  OIII ];
      case "HOO":       return [ Ha,  OIII, OIII ];
      case "HSO":       return [ Ha,  usedSII,  OIII ];
      case "HOS":       return [ Ha,  OIII, usedSII  ];
      case "OSS":       return [ OIII, usedSII,  usedSII  ];
      case "OHH":       return [ OIII, Ha,  Ha   ];
      case "OSH":       return [ OIII, usedSII,  Ha   ];
      case "OHS":       return [ OIII, Ha,  usedSII  ];
      case "HSS":       return [ Ha,  usedSII,  usedSII  ];

   }
   // fallback
   return [ Ha, OIII, SII ];
}

function PerfectPalettePickerDialog()
{
   /************************************************************
    * Base constructor
    ************************************************************/
   this.__base__ = Dialog;
   this.__base__();



   /************************************************************
    * 1) Left panel as a pinned Control
    ************************************************************/
   this.leftPanel = new Control( this );
   // This is where we attach a vertical sizer
   this.leftPanel.sizer = new VerticalSizer;
   this.leftPanel.sizer.margin = 4;
   this.leftPanel.sizer.spacing = 4;

   // Fix the width:
   this.leftPanel.setFixedWidth( 300 );

   // Title label
   this.titleLabel = new Label( this.leftPanel );
   this.titleLabel.text = "Perfect Palette Picker v" + VERSION +"";
   this.titleLabel.textAlignment = TextAlign_Center;
   this.titleLabel.styleSheet = "font-size:14pt; font-weight:bold;";

this.instructionLabel = new Label(this.leftPanel);
this.instructionLabel.text =
    "Instructions:\n" +
    "1. Add narrowband images or an OSC camera\n image.\n" +
    "2. Check the 'Linear Data' checkbox if the\n images are linear.\n" +
    "3. Click 'Create Palettes' to generate the\n palettes.\n" +
    "4. Use the Zoom buttons to zoom in and out.\n" +
    "5. Resize the UI by dragging the lower right\n corner.\n" +
    "6. Click on a palette from the preview\n selection to generate that palette. \n\nMultiple palettes can be generated.";

this.instructionLabel.textAlignment = TextAlign_Left;
this.instructionLabel.frameStyle = FrameStyle_Box; // Adds a border around the label
this.instructionLabel.styleSheet = "font-size: 8pt; padding: 10px; background-color: #e6e6fa;"; // Sets font size, padding, and background color
this.instructionLabel.setFixedHeight(210); // Sets a fixed height; adjust as needed



   // “Linear Input Data” checkbox
   this.linearCheckbox = new CheckBox( this.leftPanel );
   this.linearCheckbox.text = "Linear Input Data";
   this.linearCheckbox.checked = true;
   this.linearCheckbox.toolTip =
      "<p>When checked, we apply the 0.25 stretch for previews/final images.</p>";

   // Ha / OIII / SII / OSC labels/combos
   this.labelHa  = new Label( this.leftPanel );
   this.labelHa.text  = "Ha:";
   this.comboHa  = new ComboBox( this.leftPanel );
   this.comboHa.addItem(" — None — ");

   this.labelOIII= new Label( this.leftPanel );
   this.labelOIII.text= "OIII:";
   this.comboOIII= new ComboBox( this.leftPanel );
   this.comboOIII.addItem(" — None — ");

   this.labelSII = new Label( this.leftPanel );
   this.labelSII.text = "SII:";
   this.comboSII = new ComboBox( this.leftPanel );
   this.comboSII.addItem(" — None — ");

   this.labelOSC = new Label( this.leftPanel );
   this.labelOSC.text = "OSC:";
   this.comboOSC = new ComboBox( this.leftPanel );
   this.comboOSC.addItem(" — None — ");

   // Populate combos with open windows
   let wList = ImageWindow.windows;
   for ( let i = 0; i < wList.length; i++ ) {
      let wId = wList[i].mainView.id;
      this.comboHa.addItem(wId);
      this.comboOIII.addItem(wId);
      this.comboSII.addItem(wId);
      this.comboOSC.addItem(wId);
   }

   // We'll arrange these combos in a small vertical sizer
   this.comboSizer = new VerticalSizer;
   this.comboSizer.margin = 0;
   this.comboSizer.spacing = 4;

   let rowHa = new HorizontalSizer;
   rowHa.add( this.labelHa );
   rowHa.add( this.comboHa, 1 );

   let rowO3 = new HorizontalSizer;
   rowO3.add( this.labelOIII );
   rowO3.add( this.comboOIII, 1 );

   let rowS2 = new HorizontalSizer;
   rowS2.add( this.labelSII );
   rowS2.add( this.comboSII, 1 );

   let rowOSC= new HorizontalSizer;
   rowOSC.add( this.labelOSC );
   rowOSC.add( this.comboOSC, 1 );

   this.comboSizer.add( rowHa );
   this.comboSizer.add( rowO3 );
   this.comboSizer.add( rowS2 );
   this.comboSizer.add( rowOSC );

   // Add the combos + linearCheckbox into the leftPanel
   this.leftPanel.sizer.add( this.titleLabel );
   this.leftPanel.sizer.addSpacing( 6 );
   this.leftPanel.sizer.add(this.instructionLabel);
   this.leftPanel.sizer.addStretch();
   this.leftPanel.sizer.add( this.comboSizer );
   this.leftPanel.sizer.addSpacing( 6 );
   this.leftPanel.sizer.add( this.linearCheckbox );
   this.leftPanel.sizer.addSpacing( 6 );

   /************************************************************
    * "Create Palettes" button
    ************************************************************/
   this.btnCreatePalettes = new PushButton( this.leftPanel );
   this.btnCreatePalettes.text = "Create Palettes";
   this.btnCreatePalettes.onClick = function() {
      this.dialog.preparePreviewPalettes();
   }.bind(this);
   this.leftPanel.sizer.add( this.btnCreatePalettes );
   this.leftPanel.sizer.addStretch();
   this.leftPanel.sizer.addSpacing( 6 );

   /************************************************************
    * OK / Cancel
    ************************************************************/
   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;


   // 1) The new instance button
   this.newInstanceButton = new ToolButton( this.leftPanel );
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = () => {
      // If you have no global parameters to save, do nothing or a pass
      // or call some hypothetical parameters object if needed
      // e.g. MyParameters.save();
      this.newInstance();
   };
   this.buttonsSizer.add( this.newInstanceButton );
   this.buttonsSizer.addSpacing( 12 );

   // 2) Stretch to push OK/Cancel to the right
   this.buttonsSizer.addStretch();




   this.cancelButton = new PushButton( this.leftPanel );
   this.cancelButton.text = "Exit";
   this.cancelButton.onClick = function(){ this.dialog.cancel(); }.bind(this);
   this.buttonsSizer.add( this.cancelButton );

   this.leftPanel.sizer.add( this.buttonsSizer );
   this.leftPanel.sizer.addSpacing( 6 );


/****************************************************************************
 * 1) We define two buttons: "Zoom In" and "Zoom Out" above the thumbsBox.
 *    We store a global scale factor in the dialog, e.g. this.previewScale = 1.0
 ****************************************************************************/
this.previewScale = 1.0;  // Start at no scaling
this.zoomButtonsSizer = new HorizontalSizer;
this.zoomButtonsSizer.spacing = 6;

// Zoom In button
this.zoomInButton = new PushButton( this );
this.zoomInButton.text = "Zoom In";
this.zoomInButton.toolTip = "Scale up the preview images by +25%";
this.zoomInButton.onClick = function()
{
   this.dialog.previewScale += 0.25;  // Increase scale
   this.dialog.updateAllTilePreviews(); // refresh all tiles
}.bind(this);

this.zoomOutButton = new PushButton( this );
this.zoomOutButton.text = "Zoom Out";
this.zoomOutButton.toolTip = "Scale down the preview images by 25%";
this.zoomOutButton.onClick = function()
{
   // Keep it above some minimum, say 0.25
   this.dialog.previewScale = Math.max(0.25, this.dialog.previewScale - 0.25);
   this.dialog.updateAllTilePreviews();
}.bind(this);

this.zoomButtonsSizer.add( this.zoomInButton );
this.zoomButtonsSizer.addSpacing( 8 );
this.zoomButtonsSizer.add( this.zoomOutButton );
// If you want them left-aligned, remove the stretch
this.zoomButtonsSizer.addStretch();

/****************************************************************************
 * 2) Create a vertical sizer that has the zoomButtons on top, and the grid below
 ****************************************************************************/
this.rightSizer = new VerticalSizer;
this.rightSizer.margin = 0;
this.rightSizer.spacing = 8;

// Add the zoom buttons on top
this.rightSizer.add( this.zoomButtonsSizer );

// Now build the 3×4 grid as before
this.thumbsBox = new VerticalSizer;
this.thumbsBox.margin = 0;
this.thumbsBox.spacing = 6;

// We'll hold references to the tile controls in an array
this.thumbnailArray = [];

   this.paletteNames = [
      "SHO","HOO","HSO","HOS",
      "OSS","OHH","OSH","OHS",
      "HSS","Realistic1","Realistic2","Foraxx"
   ];

   this.thumbsBox = new VerticalSizer;
   this.thumbsBox.margin = 0;
   this.thumbsBox.spacing = 6;

   // We'll hold references to the thumbnail controls in an array
   this.thumbnailArray = [];

   let index = 0;
   for ( let row = 0; row < 3; row++ )
   {
      let rowSizer = new HorizontalSizer;
      rowSizer.spacing = 6;

      for ( let col = 0; col < 4; col++ )
      {
         let pName = this.paletteNames[index++];

         let ctrl = new Control( this );
         ctrl.setMinSize( 200, 130 );  // each preview tile size
         ctrl.paletteName   = pName;
         ctrl.selected      = false;
         ctrl.previewBitmap = null;

         ctrl.refreshMe = function() {
            this.update();
         };

      ctrl.onPaint = function()
      {
         let g = new Graphics(this);
         // Fill background
         g.fillRect( 0, 0, this.width, this.height, new Brush(0xFF202020) );

         // If we have a preview image
         if ( this.previewBitmap )
         {
            // Let's retrieve the scale factor from the dialog
            let scale = this.dialog.previewScale;

            // We'll scale the entire coordinate system around the origin (0,0)
            g.scaleTransformation( scale );

            // The *unscaled* width/height of the bitmap
            let bmpW = this.previewBitmap.width;
            let bmpH = this.previewBitmap.height;

            // The *scaled* width/height
            let scaledW = bmpW * scale;
            let scaledH = bmpH * scale;

            // We want the scaled image centered in the tile
            // But after scaling, coordinates are effectively smaller by “scale,”
            // so we do something like:
            let centerX = (this.width  - scaledW) / 2;
            let centerY = (this.height - scaledH) / 2;

            // Because we already did g.scaleTransformation(...),
            // we must transform the center coords by 1/scale:
            let drawX = centerX / scale;
            let drawY = centerY / scale;

            // Now draw the original-size bitmap at (drawX, drawY)
            g.drawBitmap( drawX, drawY, this.previewBitmap );

            // Reset transformations if we wish
            g.resetTransformation();
         }

         // Always draw the text label
         g.font = new Font("Helvetica", 12);
         let textColor = this.selected ? 0xFF00FF00 : 0xFFFFFFFF;
         g.pen = new Pen( textColor );

         // We want to draw text in the bottom-left corner *outside* the scaled region,
         // so we do it AFTER g.resetTransformation():
         let textX = 5;
         let textY = this.height - 5;
         g.drawText( textX, textY, this.paletteName );

         g.end();
      };

      ctrl.onMousePress = function()
      {
         // Unselect all
         for ( let t = 0; t < this.dialog.thumbnailArray.length; t++ )
         {
            this.dialog.thumbnailArray[t].selected = false;
            this.dialog.thumbnailArray[t].refreshMe();
         }
         this.selected = true;
         this.refreshMe();

         // Generate the final big image for this palette
         this.dialog.generateFinalPaletteImage( this.paletteName );
      }.bind(ctrl);

      rowSizer.add( ctrl, 1 );
      this.thumbnailArray.push(ctrl);
   }
   this.thumbsBox.add( rowSizer );
}

// Finally add thumbsBox to rightSizer
this.rightSizer.add( this.thumbsBox, 1 );

   /************************************************************
    * 3) Main Horizontal Sizer
    ************************************************************/
   this.mainSizer = new HorizontalSizer;
   this.mainSizer.margin = 6;
   this.mainSizer.spacing = 8;

   // Add leftPanel (fixed at 300 px)
   this.mainSizer.add( this.leftPanel );
      this.adjustToContents();

   // Some spacing
   this.mainSizer.addSpacing( 8 );

   // Add the rightSizer sizer with stretch factor => it expands on resizing
   this.mainSizer.add( this.rightSizer, 1 );

   this.sizer = this.mainSizer;

   this.windowTitle = "Perfect Palette Picker v1.0";

this.updateAllTilePreviews = function()
{
   for ( let i = 0; i < this.thumbnailArray.length; i++ )
      this.thumbnailArray[i].refreshMe();
};

   /* ------------------------------------------------------------------------
    * We keep references to the "preview" channels so the user sees the effect
    * in the thumbnails. In a minimal version, we’re not painting actual color
    * previews, but you can extend it to do so if you want (via custom painting).
    * ------------------------------------------------------------------------*/
this.previewHa    = null;
this.previewOIII  = null;
this.previewSII   = null;
this.previewR     = null; // Extracted from OSC
this.previewG     = null;
this.previewB     = null;

// New variables for final channels
this.finalHa      = null;
this.finalOIII    = null;
this.finalSII     = null;

/* ------------------------------------------------------------------------
 * makeFinalCopy( inView, newId ) => return a new ImageView
 * with the same data but new ID. We can apply stretching on it if needed.
 * ------------------------------------------------------------------------*/
this.makeFinalCopy = function( inView, newId )
{
    let w = new ImageWindow(
        inView.image.width,
        inView.image.height,
        inView.image.numberOfChannels,
        inView.image.bitsPerSample,
        inView.image.isReal,
        inView.image.isColor,
        newId
    );
    w.mainView.beginProcess();
    w.mainView.image.assign( inView.image );
    w.mainView.endProcess();
    return w.mainView;
};


/* ------------------------------------------------------------------------
 * preparePreviewPalettes():
 *   1. Check combos for Ha/OIII/SII
 *   2. If all are None, fallback to OSC => Extract R/G/B
 *   3. Stretch final channels if linearCheckbox is checked
 *   4. Downsample stretched final channels for previews
 * ------------------------------------------------------------------------*/
this.preparePreviewPalettes = function () {
    let selHa = this.comboHa.currentItem;
    let selOIII = this.comboOIII.currentItem;
    let selSII = this.comboSII.currentItem;
    let selOSC = this.comboOSC.currentItem;

    let haId = (selHa > 0) ? this.comboHa.itemText(selHa) : "";
    let oiiiId = (selOIII > 0) ? this.comboOIII.itemText(selOIII) : "";
    let siiId = (selSII > 0) ? this.comboSII.itemText(selSII) : "";
    let oscId = (selOSC > 0) ? this.comboOSC.itemText(selOSC) : "";

    let haveHa = (haId.length > 0);
    let haveOIII = (oiiiId.length > 0);
    let haveSII = (siiId.length > 0);

    // If *all three* are missing, fallback to OSC
    let useOSC = (!haveHa && !haveOIII && !haveSII);

    console.writeln("preparePreviewPalettes() => Ha:", haId,
        "  OIII:", oiiiId, "  SII:", siiId,
        "  OSC:", oscId, " => useOSC=", useOSC);

    // Clean up any previous preview windows
    this.cleanupPreviewWindows();

    if (!useOSC) {
        // Non-OSC path: use individual Ha, OIII, SII channels
        if (haveHa) {
            let W = ImageWindow.windowById(haId);
            if (!W) {
                console.warningln("[!] Ha window not found: ", haId);
            } else {
                // Assign full-resolution Ha for final image
                if (this.linearCheckbox.checked) {
                    // Create a stretched copy without downsampling
                    let finalHaCopy = this.makeFinalCopy(W.mainView, "Ha_final");
                    processMonoImage(finalHaCopy, 0.25, 1);
                    this.finalHa = finalHaCopy;
                } else {
                    // Assign original mainView directly
                    this.finalHa = W.mainView;
                }

                // Create a downsampled preview copy from the finalHa
                let previewHa = this.makePreviewCopy(this.finalHa, "Ha_preview");
                downsample4x(previewHa);
                this.previewHa = previewHa;
            }
        }
        if (haveOIII) {
            let W = ImageWindow.windowById(oiiiId);
            if (!W) {
                console.warningln("[!] OIII window not found: ", oiiiId);
            } else {
                // Assign full-resolution OIII for final image
                if (this.linearCheckbox.checked) {
                    // Create a stretched copy without downsampling
                    let finalOIIICopy = this.makeFinalCopy(W.mainView, "OIII_final");
                    processMonoImage(finalOIIICopy, 0.25, 1);
                    this.finalOIII = finalOIIICopy;
                } else {
                    // Assign original mainView directly
                    this.finalOIII = W.mainView;
                }

                // Create a downsampled preview copy from the finalOIII
                let previewOIII = this.makePreviewCopy(this.finalOIII, "OIII_preview");
                downsample4x(previewOIII);
                this.previewOIII = previewOIII;
            }
        }
        if (haveSII) {
            let W = ImageWindow.windowById(siiId);
            if (!W) {
                console.warningln("[!] SII window not found: ", siiId);
            } else {
                // Assign full-resolution SII for final image
                if (this.linearCheckbox.checked) {
                    // Create a stretched copy without downsampling
                    let finalSICopy = this.makeFinalCopy(W.mainView, "SII_final");
                    processMonoImage(finalSICopy, 0.25, 1);
                    this.finalSII = finalSICopy;
                } else {
                    // Assign original mainView directly
                    this.finalSII = W.mainView;
                }

                // Create a downsampled preview copy from the finalSII
                let previewSII = this.makePreviewCopy(this.finalSII, "SII_preview");
                downsample4x(previewSII);
                this.previewSII = previewSII;
            }
        }

        // Assign null to OSC previews
        this.previewR = null;
        this.previewG = null;
        this.previewB = null;
    }
    else {
        // OSC path: Map R → Ha, average G and B → OIII, handle SII accordingly
        if (oscId.length <= 0) {
            new MessageBox("No valid Ha/OIII/SII, and OSC is also None! Nothing to do.",
                "PerfectPalettePicker", StdIcon_Error, StdButton_Ok).execute();
            return;
        }
        let W = ImageWindow.windowById(oscId);
        if (!W) {
            console.warningln("[!] OSC window not found: ", oscId);
            return;
        }
        let channels = extractOSCchannels(W.mainView); // [Rview, Gview, Bview]
        if (channels.length < 3) {
            console.warningln("[!] Could not extract 3 channels from OSC!");
            return;
        }

        // Assign OSC channels
        if (this.linearCheckbox.checked) {
            // Stretch Ha (R channel)
            let finalHaOSC = this.makeFinalCopy(channels[0], "Ha_OSC_final");
            processMonoImage(finalHaOSC, 0.25, 1);
            this.finalHa = finalHaOSC;
        } else {
            this.finalHa = channels[0];
        }

        // Average G and B channels for OIII
        this.finalOIII = this.averageChannels(channels[1], channels[2], "OIII_OSC_final");
        if (this.linearCheckbox.checked) {
            processMonoImage(this.finalOIII, 0.25, 1);
        }

        // Create a downsampled preview copy from the finalHaOSC
        let previewHaOSC = this.makePreviewCopy(this.finalHa, "Ha_preview");
        downsample4x(previewHaOSC);
        this.previewHa = previewHaOSC;

        // Create a downsampled preview copy from the finalOIII
        let previewOIIIOSC = this.makePreviewCopy(this.finalOIII, "OIII_preview");
        downsample4x(previewOIIIOSC);
        this.previewOIII = previewOIIIOSC;

        // Since OSC doesn't provide a true SII, set it to null
        this.finalSII = null;
        this.previewSII = null;

        console.writeln("OSC => R => Ha, (G + B)/2 => OIII, no SII");
    }

    console.writeln("[*] Now building each palette’s mini-preview...");
    for (let i = 0; i < this.thumbnailArray.length; i++) {
        let paletteName = this.thumbnailArray[i].paletteName;

        // Combine the preview channels to produce a small color preview image
        let miniView = this.createMiniPalettePreview(paletteName);

        if (miniView) {
            // Convert miniView.mainView.image => a Bitmap
            let bmp = miniView.image.render(); // returns a Bitmap
            // Store in the thumbnail’s previewBitmap
            this.thumbnailArray[i].previewBitmap = bmp;
            this.thumbnailArray[i].refreshMe(); // repaint
            // Optionally close miniView’s window
            miniView.window.forceClose();
        }
        else {
            this.thumbnailArray[i].previewBitmap = null;
        }
    }
    console.writeln("[*] Palette mini-previews done.");
};




/**
 * averageChannels(view1, view2, outName):
 *   Averages two channels and returns the resulting mainView.
 *
 * @param {View} view1 - First channel view
 * @param {View} view2 - Second channel view
 * @param {string} outName - Output image ID
 * @returns {View} - Averaged channel mainView
 */
this.averageChannels = function(view1, view2, outName) {
    // Create a new image window for the averaged channel
    let width = view1.image.width;
    let height = view1.image.height;
    let bits = view1.image.bitsPerSample;
    let real = view1.image.isReal;

    let targetWin = new ImageWindow(width, height, 1, bits, real, /*isColor=*/false, outName);
    targetWin.mainView.beginProcess();
    targetWin.mainView.image.fill(0);  // Initialize to black
    targetWin.mainView.endProcess();

    // Use PixelMath to average the two channels
    let P = new PixelMath;
    P.useSingleExpression = true;
    P.expression = "(" + view1.id + " + " + view2.id + ") / 2";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = true;
    P.rescale = false;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false; // Apply to existing image
    P.showNewImage = false;

    P.executeOn(targetWin.mainView);

    return targetWin.mainView;
};


/**
 * createMiniPalettePreview(paletteName):
 *   Creates a mini-preview image for the given palette, based on the
 *   already downsampled, optionally stretched "preview" channels
 *   (this.previewHa, this.previewOIII, this.previewSII).
 *
 *   Returns an ImageWindow's mainView, or null on failure.
 */
this.createMiniPalettePreview = function (paletteName) {
    console.writeln("createMiniPalettePreview(", paletteName, ")");

    let finalR = null, finalG = null, finalB = null;

    // We'll produce an output ID like "Preview_SHO"
    let outName = "Preview_" + paletteName;

    // At this point, regardless of OSC or non-OSC, we have:
    // - this.previewHa
    // - this.previewOIII
    // - this.previewSII (could be null)

    // Ensure we have Ha and OIII at minimum
    if (!this.previewHa && !this.previewOIII) {
        console.warningln("[!] Missing both Ha and OIII channels for palette:", paletteName);
        return null;
    }

    // Handle SII: if null, you might want to set it to "0" or Ha as per your requirement
    // Here, we pass it as is; mapChannels should handle null appropriately
    let HaView = this.previewHa;       // Might be null if using OSC without Ha
    let OIIIView = this.previewOIII;   // Might be null if missing
    let SIIView = this.previewSII;     // Might be null

    // Now, apply the same palette logic regardless of OSC or non-OSC
    switch (paletteName) {
        // =======================
        // Standard older palettes: SHO, HOO, etc.
        // =======================
        case "SHO": case "HOO": case "HSO": case "HOS":
        case "OSS": case "OHH": case "OSH": case "OHS":
        case "HSS":
        {
            // Re-use mapChannels just like the final code
            let mapped = mapChannels(paletteName, HaView, OIIIView, SIIView);
            finalR = mapped[0];
            finalG = mapped[1];
            finalB = mapped[2];
            // Combine them => new color image
            let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
            return colorView;
        }

        // =======================
        // Realistic1 partial merges
        // =======================
        case "Realistic1":
        {
            // Redchannel = (Ha + SII)/2 if SII present, else just Ha
            let exprR = (HaView && SIIView)
                ? "(" + HaView.id + " + " + SIIView.id + ") / 2"
                : (HaView ? HaView.id : "0");

            // Greenchannel = 0.3*Ha + 0.7*OIII
            let exprG = (HaView ? "0.3*" + HaView.id : "0")
                + (OIIIView ? " + 0.7*" + OIIIView.id : "");

            // BlueChannel = 0.9*OIII + 0.1*Ha
            let exprB = (OIIIView ? "0.9*" + OIIIView.id : "0")
                + (HaView ? " + 0.1*" + HaView.id : "");

            let colorView = this.combineChannelsToColorExpressionsMini(outName, exprR, exprG, exprB);
            return colorView;
        }

        // =======================
        // Realistic2 partial merges
        // =======================
        case "Realistic2":
        {
            // Red = 0.7*Ha + 0.3*SII (if SII missing => just Ha)
            let exprR;
            if (HaView && SIIView)
                exprR = "0.7*" + HaView.id + " + 0.3*" + SIIView.id;
            else if (HaView)
                exprR = HaView.id;
            else
                exprR = "0";

            // Green = 0.3*SII + 0.7*OIII
            let exprG;
            if (SIIView && OIIIView)
                exprG = "0.3*" + SIIView.id + " + 0.7*" + OIIIView.id;
            else if (OIIIView)
                exprG = OIIIView.id;
            else
                exprG = "0";

            // Blue = OIII
            let exprB = (OIIIView ? OIIIView.id : "0");

            let colorView = this.combineChannelsToColorExpressionsMini(outName, exprR, exprG, exprB);
            return colorView;
        }

        // =======================
        // Foraxx
        // =======================
        case "Foraxx":
        {
            if (HaView && OIIIView && !SIIView) {
                // Red => Ha
                let exprR = HaView.id;

                // Green => ((Ha*OIII)^(~(Ha*OIII)))*Ha + ~((Ha*OIII)^(~(Ha*OIII)))*OIII
                let ho = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id
                    + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;

                // Blue => OIII
                let exprB = OIIIView.id;

                let colorView = this.combineChannelsToColorExpressionsMini(outName, exprR, exprG, exprB);
                return colorView;
            }
            else if (HaView && OIIIView && SIIView) {
                // Red => (OIII^~OIII)*SII + ~(OIII^~OIII)*Ha
                let o = OIIIView.id;
                let exprR = "(" + o + " ^ ~" + o + ") * " + SIIView.id
                    + " + ~(" + o + " ^ ~" + o + ") * " + HaView.id;

                // Green => ((Ha*OIII)^(~(Ha*OIII)))*Ha + ~((Ha*OIII)^(~(Ha*OIII)))*OIII
                let ho = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id
                    + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;

                // Blue => OIII
                let exprB = OIIIView.id;

                let colorView = this.combineChannelsToColorExpressionsMini(outName, exprR, exprG, exprB);
                return colorView;
            }
            else {
                console.warningln("Foraxx: not enough channels to do advanced merges. Using fallback.");
                // Fallback => just do SHO or similar
                let mapped = mapChannels("SHO", HaView, OIIIView, SIIView);
                finalR = mapped[0];
                finalG = mapped[1];
                finalB = mapped[2];
                let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
                return colorView;
            }
        }

        default:
        {
            // Fallback => SHO
            let mapped = mapChannels("SHO", HaView, OIIIView, SIIView);
            finalR = mapped[0];
            finalG = mapped[1];
            finalB = mapped[2];
            let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
            return colorView;
        }
    }
};



/* ------------------------------------------------------------------------
 * generateFinalPaletteImage(paletteName):
 *   - Use already extracted and processed finalHa, finalOIII, finalSII
 *   - For standard SHO/HOO/etc., call mapChannels() + combineChannelsToColor().
 *   - For Realistic1, Realistic2, Foraxx, build PixelMath expressions
 *     and call combineChannelsToColorExpressions().
 * ------------------------------------------------------------------------*/
this.generateFinalPaletteImage = function (paletteName) {
    console.writeln("generateFinalPaletteImage(", paletteName, ")");

    // Retrieve the already extracted and processed final channels
    let HaView = this.finalHa;         // Full-res Ha channel (from individual or OSC)
    let OIIIView = this.finalOIII;     // Full-res OIII channel (from individual or OSC)
    let SIIView = this.finalSII;       // Full-res SII channel (from individual or null)

    // Check if at least Ha or OIII is available
    if (!HaView && !OIIIView) {
        console.warningln("[!] Missing both Ha and OIII channels. Cannot generate final palette image for:", paletteName);
        return;
    }

    // Prepare the final palette name
    let outName = "Final_" + paletteName;

    // Initialize final channels
    let finalR = null, finalG = null, finalB = null;

    switch (paletteName) {
        // =======================
        // Standard older palettes: SHO, HOO, etc.
        // =======================
        case "SHO": case "HOO": case "HSO": case "HOS":
        case "OSS": case "OHH": case "OSH": case "OHS":
        case "HSS":
        {
            // Re-use mapChannels just like the final code
            let mapped = mapChannels(paletteName, HaView, OIIIView, SIIView);
            finalR = mapped[0];
            finalG = mapped[1];
            finalB = mapped[2];
            // Combine them => new color image
            let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
            if (colorView) {
                colorView.window.show();
                colorView.window.bringToFront();
                console.writeln("   => Created final image: ", colorView.id);
            }
            else
                console.warningln("   [!] Could not combine channels for palette=", paletteName);

            break;
        }

        // =======================
        // Realistic1 partial merges
        // =======================
        case "Realistic1":
        {
            // Redchannel = (Ha + SII)/2 if SII present, else just Ha
            let exprR = (HaView && SIIView)
                ? "(" + HaView.id + " + " + SIIView.id + ") / 2"
                : (HaView ? HaView.id : "0");

            // Greenchannel = 0.3*Ha + 0.7*OIII
            let exprG = (HaView ? "0.3*" + HaView.id : "0")
                + (OIIIView ? " + 0.7*" + OIIIView.id : "");

            // BlueChannel = 0.9*OIII + 0.1*Ha
            let exprB = (OIIIView ? "0.9*" + OIIIView.id : "0")
                + (HaView ? " + 0.1*" + HaView.id : "");

            let colorView = this.combineChannelsToColorExpressions(outName, exprR, exprG, exprB);
            if (colorView) {
                colorView.window.show();
                colorView.window.bringToFront();
                console.writeln("   => Created final Realistic1 image: ", colorView.id);
            }
            break;
        }

        // =======================
        // Realistic2 partial merges
        // =======================
        case "Realistic2":
        {
            // Red = 0.7*Ha + 0.3*SII (if SII missing => just Ha)
            let exprR;
            if (HaView && SIIView)
                exprR = "0.7*" + HaView.id + " + 0.3*" + SIIView.id;
            else if (HaView)
                exprR = HaView.id;
            else
                exprR = "0";

            // Green = 0.3*SII + 0.7*OIII
            let exprG;
            if (SIIView && OIIIView)
                exprG = "0.3*" + SIIView.id + " + 0.7*" + OIIIView.id;
            else if (OIIIView)
                exprG = OIIIView.id;
            else
                exprG = "0";

            // Blue = OIII
            let exprB = (OIIIView ? OIIIView.id : "0");

            let colorView = this.combineChannelsToColorExpressions(outName, exprR, exprG, exprB);
            if (colorView) {
                colorView.window.show();
                colorView.window.bringToFront();
                console.writeln("   => Created final Realistic2 image: ", colorView.id);
            }
            break;
        }

        // =======================
        // Foraxx
        // =======================
        case "Foraxx":
        {
            if (HaView && OIIIView && !SIIView) {
                // Red => Ha
                let exprR = HaView.id;

                // Green => ((Ha*OIII)^(~(Ha*OIII)))*Ha + ~((Ha*OIII)^(~(Ha*OIII)))*OIII
                let ho = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id
                    + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;

                // Blue => OIII
                let exprB = OIIIView.id;

                let colorView = this.combineChannelsToColorExpressions(outName, exprR, exprG, exprB);
                if (colorView) {
                    colorView.window.show();
                    colorView.window.bringToFront();
                    console.writeln("   => Created final Foraxx(Ha/OIII) image: ", colorView.id);
                }
            }
            else if (HaView && OIIIView && SIIView) {
                // Red => (OIII^~OIII)*SII + ~(OIII^~OIII)*Ha
                let o = OIIIView.id;
                let exprR = "(" + o + " ^ ~" + o + ") * " + SIIView.id
                    + " + ~(" + o + " ^ ~" + o + ") * " + HaView.id;

                // Green => ((Ha*OIII)^(~(Ha*OIII)))*Ha + ~((Ha*OIII)^(~(Ha*OIII)))*OIII
                let ho = "(" + HaView.id + "*" + OIIIView.id + ")";
                let exprG = "(" + ho + " ^ ~" + ho + ") * " + HaView.id
                    + " + ~(" + ho + " ^ ~" + ho + ") * " + OIIIView.id;

                // Blue => OIII
                let exprB = OIIIView.id;

                let colorView = this.combineChannelsToColorExpressions(outName, exprR, exprG, exprB);
                if (colorView) {
                    colorView.window.show();
                    colorView.window.bringToFront();
                    console.writeln("   => Created final Foraxx(S,H,O) image: ", colorView.id);
                }
            }
            else {
                console.warningln("Foraxx: not enough channels to do advanced merges. Using fallback.");
                // Fallback => just do SHO or similar
                let mapped = mapChannels("SHO", HaView, OIIIView, SIIView);
                finalR = mapped[0];
                finalG = mapped[1];
                finalB = mapped[2];
                let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
                if (colorView) {
                    colorView.window.show();
                    colorView.window.bringToFront();
                    console.writeln("   => Created final fallback Foraxx image: ", colorView.id);
                }
            }
            break;
        }

        default:
        {
            // Fallback => SHO
            let mapped = mapChannels("SHO", HaView, OIIIView, SIIView);
            finalR = mapped[0];
            finalG = mapped[1];
            finalB = mapped[2];
            let colorView = combineChannelsToColor([finalR, finalG, finalB], outName);
            if (colorView) {
                colorView.window.show();
                colorView.window.bringToFront();
                console.writeln("   => Created final fallback image: ", colorView.id);
            }
            break;
        }
    }


};


this.combineChannelsToColorExpressions = function( outId, exprR, exprG, exprB )
{
   let refView = null;
   if (this.finalHa) {
       refView = this.finalHa;
   } else if (this.finalOIII) {
       refView = this.finalOIII;
   } else if (this.finalSII) {
       refView = this.finalSII;
   } else if (this.previewR) { // Fallback to preview if necessary
       refView = this.previewR;
   }

   if (!refView) {
       console.warningln("No reference final channel available for image dimensions. Cannot build partial merges.");
       return null;
   }

   let w    = refView.image.width;
   let h    = refView.image.height;
   let bits = refView.image.bitsPerSample;
   let real = refView.image.isReal;

   // 1) Make a brand-new color image
   let targetWin = new ImageWindow( w, h, 3, bits, real, /*isColor=*/true, outId );
   targetWin.mainView.beginProcess();
   targetWin.mainView.image.fill( 0 );
   targetWin.mainView.endProcess();

   // 2) Setup PixelMath in multi-expression mode
   let PM = new PixelMath;
   PM.useSingleExpression = false;
   PM.expression  = exprR;
   PM.expression1 = exprG;
   PM.expression2 = exprB;
   PM.expression3 = "";

   PM.clearImageCacheAndExit = false;
   PM.cacheGeneratedImages   = false;
   PM.generateOutput         = true;
   PM.singleThreaded         = false;
   PM.optimization           = true;
   PM.use64BitWorkingImage   = false;
   PM.rescale               = false;
   PM.truncate              = true;
   PM.truncateLower         = 0;
   PM.truncateUpper         = 1;

   // We do NOT create a new image => apply onto our target
   PM.createNewImage = false;
   PM.showNewImage   = false;

   PM.executeOn( targetWin.mainView );

   return targetWin.mainView;
};

this.combineChannelsToColorExpressionsMini = function( outId, exprR, exprG, exprB )
{
   // We'll pick any existing "preview" reference for dimension/bit-depth
   let refId = "";
   if (this.previewHa)   refId = this.previewHa.id;
   else if (this.previewOIII) refId = this.previewOIII.id;
   else if (this.previewSII)  refId = this.previewSII.id;
   else if (this.previewR)    refId = this.previewR.id;
   // if still no ref => fallback or error
   if ( refId === "" )
   {
      console.warningln("No reference preview for dimension—cannot build partial merges.");
      return null;
   }

   let refWin = ImageWindow.windowById(refId);
   if ( !refWin || refWin.isNull )
   {
      console.warningln("Ref window not found for ID=", refId);
      return null;
   }

   let w    = refWin.mainView.image.width;
   let h    = refWin.mainView.image.height;
   let bits = refWin.mainView.image.bitsPerSample;
   let real = refWin.mainView.image.isReal;

   // 1) Make a brand-new color image
   let targetWin = new ImageWindow( w, h, 3, bits, real, /*isColor=*/true, outId );
   targetWin.mainView.beginProcess();
   targetWin.mainView.image.fill( 0 );
   targetWin.mainView.endProcess();

   // 2) Setup PixelMath in multi-expression mode
   let PM = new PixelMath;
   PM.useSingleExpression = false;
   PM.expression  = exprR;
   PM.expression1 = exprG;
   PM.expression2 = exprB;
   PM.expression3 = "";

   PM.clearImageCacheAndExit = false;
   PM.cacheGeneratedImages   = false;
   PM.generateOutput         = true;
   PM.singleThreaded         = false;
   PM.optimization           = true;
   PM.use64BitWorkingImage   = false;
   PM.rescale               = false;
   PM.truncate              = true;
   PM.truncateLower         = 0;
   PM.truncateUpper         = 1;

   // We do NOT create a new image => apply onto our target
   PM.createNewImage = false;
   PM.showNewImage   = false;

   PM.executeOn( targetWin.mainView );

   return targetWin.mainView;
};

   /* ------------------------------------------------------------------------
    * makePreviewCopy( inView, newId ) => return a new ImageView
    * with the same data but new ID. We can do the stretch on it.
    * ------------------------------------------------------------------------*/
   this.makePreviewCopy = function( inView, newId )
   {
      let w = new ImageWindow(
         inView.image.width,
         inView.image.height,
         inView.image.numberOfChannels,
         inView.image.bitsPerSample,
         inView.image.isReal,
         inView.image.isColor,
         newId
      );
      w.mainView.beginProcess();
      w.mainView.image.assign( inView.image );
      w.mainView.endProcess();
      return w.mainView;
   };



/* ------------------------------------------------------------------------
 * cleanupPreviewWindows():
 *   Closes temporary "_preview", "_final", and "_R", "_G", "_B" images
 *   while preserving the main "Final_" images.
 * ------------------------------------------------------------------------*/
this.cleanupPreviewWindows = function()
{
    let allW = ImageWindow.windows;

    // Iterate backwards to safely remove windows during iteration
    for ( let i = allW.length - 1; i >= 0; i-- )
    {
        let id      = allW[i].mainView.id;
        let lowerId = id.toLowerCase();

        // Check if it's some sort of “preview” or “_final” temp image:
        let hasPreview = (lowerId.indexOf("_preview") >= 0);
        let hasFinal   = (lowerId.indexOf("_final") >= 0);

        // Check if it *starts* with "final_" (the user’s real final images):
        // e.g. "Final_SHO". Lowercase => "final_sho". Then we check:
        let isMainFinal = (lowerId.indexOf("final_") === 0);

        // Check for uppercase RGB suffixes on the original ID
        let hasRGBSuffix = false;
        if (id.length >= 2) {
            let suffix = id.substring(id.length - 2, id.length);
            hasRGBSuffix = (suffix === "_R" || suffix === "_G" || suffix === "_B");
        }

        // If it has _preview, _final, or RGB suffixes
        // but is NOT one of our main "Final_" images, close it.
        if ( (hasPreview || hasFinal || hasRGBSuffix) && !isMainFinal )
        {
            allW[i].forceClose();
            console.writeln("Closed temporary window: " + id);
        }
    }

    // Reset preview references
    this.previewHa   = null;
    this.previewOIII = null;
    this.previewSII  = null;
    this.previewR    = null;
    this.previewG    = null;
    this.previewB    = null;

    // Note: Do NOT reset final channel references here to keep them available for final images
    // this.finalHa = null;
    // this.finalOIII = null;
    // this.finalSII = null;
};
/**
 * hasSuffix(id, suffixes):
 *   Checks if the given id ends with any of the provided suffixes.
 *
 * @param {string} id - The image ID to check.
 * @param {Array} suffixes - Array of suffix strings to check against.
 * @returns {boolean} - True if any suffix matches, else false.
 */
function hasSuffix(id, suffixes) {
    for (let i = 0; i < suffixes.length; i++) {
        if (id.substring(id.length - suffixes[i].length) === suffixes[i]) {
            return true;
        }
    }
    return false;
}

}

// IMPORTANT: Properly set the prototype and constructor:
PerfectPalettePickerDialog.prototype = new Dialog;
PerfectPalettePickerDialog.prototype.constructor = PerfectPalettePickerDialog;

PerfectPalettePickerDialog.prototype.onHide = function()
{
   // Perform your cleanup
   this.cleanupPreviewWindows();

   // Then call the base class's onHide() to preserve default behavior
   Dialog.prototype.onHide.call( this );
};

// -----------------------------------------------------------------------------
// MAIN
// -----------------------------------------------------------------------------
function main()
{
   Console.show();
Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");

   console.writeln(" Perfect Palette Picker (v1.0) by Franklin Marek");


   let D = new PerfectPalettePickerDialog();
   D.execute();  // Blocks until user closes the dialog (OK, Cancel, or X)

   // The dialog has been closed at this point.
   D.cleanupPreviewWindows(); // <--- Perform your cleanup now
}

main();
