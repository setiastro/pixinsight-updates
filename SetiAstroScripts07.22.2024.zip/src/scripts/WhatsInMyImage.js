#feature-id WhatsInMyImage : SetiAstro > Whats In My Image
#feature-info This script will use Simbad lookup to identify objects in your image

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * What's In My Image Script
 * Version: V1.8
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script is designed to search within a defined area
 * all objects queried from the Simbad catalog
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StarDetector.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/ColorSpace.jsh>


var typeLookupTable = [{"cond":"?","extd":"Object of unknown nature"},
{"cond":"ev","extd":"transient event"},
{"cond":"","extd":""},
{"cond":"Rad","extd":"Radio-source"},
{"cond":"mR","extd":"metric Radio-source"},
{"cond":"cm","extd":"centimetric Radio-source"},
{"cond":"mm","extd":"millimetric Radio-source"},
{"cond":"smm","extd":"sub-millimetric source"},
{"cond":"HI","extd":"HI (21cm) source"},
{"cond":"rB","extd":"radio Burst"},
{"cond":"Mas","extd":"Maser"},
{"cond":"","extd":""},
{"cond":"IR","extd":"Infra-Red source"},
{"cond":"FIR","extd":"Far-Infrared source"},
{"cond":"MIR","extd":"Mid-Infrared source"},
{"cond":"NIR","extd":"Near-Infrared source"},
{"cond":"","extd":""},
{"cond":"blu","extd":"Blue object"},
{"cond":"","extd":""},
{"cond":"UV","extd":"UV-emission source"},
{"cond":"","extd":""},
{"cond":"X","extd":"X-ray source"},
{"cond":"UX?","extd":"Ultra-luminous X-ray candidate"},
{"cond":"ULX","extd":"Ultra-luminous X-ray source"},
{"cond":"","extd":""},
{"cond":"gam","extd":"gamma-ray source"},
{"cond":"gB","extd":"gamma-ray Burst"},
{"cond":"","extd":""},
{"cond":"err","extd":"Not an object (error, artefact, ...)"},
{"cond":"","extd":""},
{"cond":"grv","extd":"Gravitational Source"},
{"cond":"Lev","extd":"(Micro)Lensing Event"},
{"cond":"LS?","extd":"Possible gravitational lens System"},
{"cond":"Le?","extd":"Possible gravitational lens"},
{"cond":"LI?","extd":"Possible gravitationally lensed image"},
{"cond":"gLe","extd":"Gravitational Lens"},
{"cond":"gLS","extd":"Gravitational Lens System (lens+images)"},
{"cond":"GWE","extd":"Gravitational Wave Event"},
{"cond":"","extd":""},
{"cond":"..?","extd":"Candidate objects"},
{"cond":"G?","extd":"Possible Galaxy"},
{"cond":"SC?","extd":"Possible Supercluster of Galaxies"},
{"cond":"C?G","extd":"Possible Cluster of Galaxies"},
{"cond":"Gr?","extd":"Possible Group of Galaxies"},
{"cond":"As?","extd":""},
{"cond":"**?","extd":"Physical Binary Candidate"},
{"cond":"EB?","extd":"Eclipsing Binary Candidate"},
{"cond":"Sy?","extd":"Symbiotic Star Candidate"},
{"cond":"CV?","extd":"Cataclysmic Binary Candidate"},
{"cond":"No?","extd":"Nova Candidate"},
{"cond":"XB?","extd":"X-ray binary Candidate"},
{"cond":"LX?","extd":"Low-Mass X-ray binary Candidate"},
{"cond":"HX?","extd":"High-Mass X-ray binary Candidate"},
{"cond":"Pec?","extd":"Possible Peculiar Star"},
{"cond":"Y*?","extd":"Young Stellar Object Candidate"},
{"cond":"TT?","extd":"T Tau star Candidate"},
{"cond":"C*?","extd":"Possible Carbon Star"},
{"cond":"S*?","extd":"Possible S Star"},
{"cond":"OH?","extd":"Possible Star with envelope of OH/IR type"},
{"cond":"WR?","extd":"Possible Wolf-Rayet Star"},
{"cond":"Be?","extd":"Possible Be Star"},
{"cond":"Ae?","extd":"Possible Herbig Ae/Be Star"},
{"cond":"HB?","extd":"Possible Horizontal Branch Star"},
{"cond":"RR?","extd":"Possible Star of RR Lyr type"},
{"cond":"Ce?","extd":"Possible Cepheid"},
{"cond":"WV?","extd":"Possible Variable Star of W Vir type"},
{"cond":"RB?","extd":"Possible Red Giant Branch star"},
{"cond":"sg?","extd":"Possible Supergiant star"},
{"cond":"s?r","extd":"Possible Red supergiant star"},
{"cond":"s?y","extd":"Possible Yellow supergiant star"},
{"cond":"s?b","extd":"Possible Blue supergiant star"},
{"cond":"AB?","extd":"Asymptotic Giant Branch Star candidate"},
{"cond":"LP?","extd":"Long Period Variable candidate"},
{"cond":"Mi?","extd":"Mira candidate"},
{"cond":"pA?","extd":"Post-AGB Star Candidate"},
{"cond":"BS?","extd":"Candidate blue Straggler Star"},
{"cond":"HS?","extd":"Hot subdwarf candidate"},
{"cond":"WD?","extd":"White Dwarf Candidate"},
{"cond":"N*?","extd":"Neutron Star Candidate"},
{"cond":"BH?","extd":"Black Hole Candidate"},
{"cond":"SN?","extd":"SuperNova Candidate"},
{"cond":"LM?","extd":"Low-mass star candidate"},
{"cond":"BD?","extd":"Brown Dwarf Candidate"},
{"cond":"","extd":""},
{"cond":"mul","extd":"Composite object"},
{"cond":"reg","extd":"Region defined in the sky"},
{"cond":"vid","extd":"Underdense region of the Universe"},
{"cond":"SCG","extd":"Supercluster of Galaxies"},
{"cond":"ClG","extd":"Cluster of Galaxies"},
{"cond":"GrG","extd":"Group of Galaxies"},
{"cond":"CGG","extd":"Compact Group of Galaxies"},
{"cond":"PaG","extd":"Pair of Galaxies"},
{"cond":"IG","extd":"Interacting Galaxies"},
{"cond":"C?*","extd":"Possible (open) star cluster"},
{"cond":"Gl?","extd":"Possible Globular Cluster"},
{"cond":"Cl*","extd":"Cluster of Stars"},
{"cond":"GlC","extd":"Globular Cluster"},
{"cond":"OpC","extd":"Open (galactic) Cluster"},
{"cond":"As*","extd":"Association of Stars"},
{"cond":"St*","extd":"Stellar Stream"},
{"cond":"MGr","extd":"Moving Group"},
{"cond":"**","extd":"Double or multiple star"},
{"cond":"EB*","extd":"Eclipsing binary"},
{"cond":"Al*","extd":"Eclipsing binary of Algol type"},
{"cond":"bL*","extd":"Eclipsing binary of beta Lyr type"},
{"cond":"WU*","extd":"Eclipsing binary of W UMa type"},
{"cond":"SB*","extd":"Spectroscopic binary"},
{"cond":"El*","extd":"Ellipsoidal variable Star"},
{"cond":"Sy*","extd":"Symbiotic Star"},
{"cond":"CV*","extd":"Cataclysmic Variable Star"},
{"cond":"DQ*","extd":"CV DQ Her type (intermediate polar)"},
{"cond":"AM*","extd":"CV of AM Her type (polar)"},
{"cond":"NL*","extd":"Nova-like Star"},
{"cond":"No*","extd":"Nova"},
{"cond":"DN*","extd":"Dwarf Nova"},
{"cond":"XB*","extd":"X-ray Binary"},
{"cond":"LXB","extd":"Low Mass X-ray Binary"},
{"cond":"HXB","extd":"High Mass X-ray Binary"},
{"cond":"","extd":""},
{"cond":"ISM","extd":"Interstellar matter"},
{"cond":"PoC","extd":"Part of Cloud"},
{"cond":"PN?","extd":"Possible Planetary Nebula"},
{"cond":"CGb","extd":"Cometary Globule"},
{"cond":"bub","extd":"Bubble"},
{"cond":"EmO","extd":"Emission Object"},
{"cond":"Cld","extd":"Cloud"},
{"cond":"GNe","extd":"Galactic Nebula"},
{"cond":"DNe","extd":"Dark Cloud (nebula)"},
{"cond":"RNe","extd":"Reflection Nebula"},
{"cond":"MoC","extd":"Molecular Cloud"},
{"cond":"glb","extd":"Globule (low-mass dark cloud)"},
{"cond":"cor","extd":"Dense core"},
{"cond":"SFR","extd":"Star forming region"},
{"cond":"HVC","extd":"High-velocity Cloud"},
{"cond":"HII","extd":"HII (ionized) region"},
{"cond":"PN","extd":"Planetary Nebula"},
{"cond":"sh","extd":"HI shell"},
{"cond":"SR?","extd":"SuperNova Remnant Candidate"},
{"cond":"SNR","extd":"SuperNova Remnant"},
{"cond":"of?","extd":"Outflow candidate"},
{"cond":"out","extd":"Outflow"},
{"cond":"HH","extd":"Herbig-Haro Object"},
{"cond":"","extd":""},
{"cond":"*","extd":"Star"},
{"cond":"V*?","extd":"Star suspected of Variability"},
{"cond":"Pe*","extd":"Peculiar Star"},
{"cond":"HB*","extd":"Horizontal Branch Star"},
{"cond":"Y*O","extd":"Young Stellar Object"},
{"cond":"Ae*","extd":"Herbig Ae/Be star"},
{"cond":"Em*","extd":"Emission-line Star"},
{"cond":"Be*","extd":"Be Star"},
{"cond":"BS*","extd":"Blue Straggler Star"},
{"cond":"RG*","extd":"Red Giant Branch star"},
{"cond":"AB*","extd":"Asymptotic Giant Branch Star (He-burning)"},
{"cond":"C*","extd":"Carbon Star"},
{"cond":"S*","extd":"S Star"},
{"cond":"sg*","extd":"Evolved supergiant star"},
{"cond":"s*r","extd":"Red supergiant star"},
{"cond":"s*y","extd":"Yellow supergiant star"},
{"cond":"s*b","extd":"Blue supergiant star"},
{"cond":"HS*","extd":"Hot subdwarf"},
{"cond":"pA*","extd":"Post-AGB Star (proto-PN)"},
{"cond":"WD*","extd":"White Dwarf"},
{"cond":"LM*","extd":"Low-mass star (M<1solMass)"},
{"cond":"BD*","extd":"Brown Dwarf (M<0.08solMass)"},
{"cond":"N*","extd":"Confirmed Neutron Star"},
{"cond":"OH*","extd":"OH/IR star"},
{"cond":"TT*","extd":"T Tau-type Star"},
{"cond":"WR*","extd":"Wolf-Rayet Star"},
{"cond":"PM*","extd":"High proper-motion Star"},
{"cond":"HV*","extd":"High-velocity Star"},
{"cond":"V*","extd":"Variable Star"},
{"cond":"Ir*","extd":"Variable Star of irregular type"},
{"cond":"Or*","extd":"Variable Star of Orion Type"},
{"cond":"Er*","extd":"Eruptive variable Star"},
{"cond":"RC*","extd":"Variable Star of R CrB type"},
{"cond":"RC?","extd":"Variable Star of R CrB type candiate"},
{"cond":"Ro*","extd":"Rotationally variable Star"},
{"cond":"a2*","extd":"Variable Star of alpha2 CVn type"},
{"cond":"Psr","extd":"Pulsar"},
{"cond":"BY*","extd":"Variable of BY Dra type"},
{"cond":"RS*","extd":"Variable of RS CVn type"},
{"cond":"Pu*","extd":"Pulsating variable Star"},
{"cond":"RR*","extd":"Variable Star of RR Lyr type"},
{"cond":"Ce*","extd":"Cepheid variable Star"},
{"cond":"dS*","extd":"Variable Star of delta Sct type"},
{"cond":"RV*","extd":"Variable Star of RV Tau type"},
{"cond":"WV*","extd":"Variable Star of W Vir type"},
{"cond":"bC*","extd":"Variable Star of beta Cep type"},
{"cond":"cC*","extd":"Classical Cepheid (delta Cep type)"},
{"cond":"gD*","extd":"Variable Star of gamma Dor type"},
{"cond":"SX*","extd":"Variable Star of SX Phe type (subdwarf)"},
{"cond":"LP*","extd":"Long-period variable star"},
{"cond":"Mi*","extd":"Variable Star of Mira Cet type"},
{"cond":"SN*","extd":"SuperNova"},
{"cond":"su*","extd":"Sub-stellar object"},
{"cond":"Pl?","extd":"Extra-solar Planet Candidate"},
{"cond":"Pl","extd":"Extra-solar Confirmed Planet"},
{"cond":"","extd":""},
{"cond":"G","extd":"Galaxy"},
{"cond":"PoG","extd":"Part of a Galaxy"},
{"cond":"GiC","extd":"Galaxy in Cluster of Galaxies"},
{"cond":"BiC","extd":"Brightest galaxy in a Cluster (BCG)"},
{"cond":"GiG","extd":"Galaxy in Group of Galaxies"},
{"cond":"GiP","extd":"Galaxy in Pair of Galaxies"},
{"cond":"rG","extd":"Radio Galaxy"},
{"cond":"H2G","extd":"HII Galaxy"},
{"cond":"LSB","extd":"Low Surface Brightness Galaxy"},
{"cond":"AG?","extd":"Possible Active Galaxy Nucleus"},
{"cond":"Q?","extd":"Possible Quasar"},
{"cond":"Bz?","extd":"Possible Blazar"},
{"cond":"BL?","extd":"Possible BL Lac"},
{"cond":"EmG","extd":"Emission-line galaxy"},
{"cond":"SBG","extd":"Starburst Galaxy"},
{"cond":"bCG","extd":"Blue compact Galaxy"},
{"cond":"LeI","extd":"Gravitationally Lensed Image"},
{"cond":"LeG","extd":"Gravitationally Lensed Image of a Galaxy"},
{"cond":"LeQ","extd":"Gravitationally Lensed Image of a Quasar"},
{"cond":"AGN","extd":"Active Galaxy Nucleus"},
{"cond":"LIN","extd":"LINER-type Active Galaxy Nucleus"},
{"cond":"SyG","extd":"Seyfert Galaxy"},
{"cond":"Sy1","extd":"Seyfert 1 Galaxy"},
{"cond":"Sy2","extd":"Seyfert 2 Galaxy"},
{"cond":"Bla","extd":"Blazar"},
{"cond":"BLL","extd":"BL Lac - type object"},
{"cond":"OVV","extd":"Optically Violently Variable object"},
{"cond":"QSO","extd":"Quasar"}];





#define TITLE     "What's In My Image"
#define VERSION   "1.8"

// Alpha (R.A.) Format
var formatModesAlpha = [
    ['Decimal Degrees', 1],
    ['HHh MMm SSs', 2]
];

// Delta (Dec) Format
var formatModesDelta = [
    ['Decimal Degrees', 1],
    ['DDº MM\' SS"', 2]
];

var scriptParameters = {
    imageActiveWindow: null,
    zoomFactor: 1,
    formatAlpha: formatModesAlpha[1][1],
    formatDelta: formatModesDelta[1][1],
    imageImage: null,
    rectangle: null,
    maxDownloads: 500,
    scrollPosition: new Point(0, 0),
    rectangleCoordinates: null,
    centerPoint: null,
    markers: [],
    highlightedMarker: null, // Initialize highlighted marker index
    selectedFont: "DejaVu Sans", // Default font
    selectedFontSize: 10, // Default font size
    selectedFontColor: 0xffffffff, // Default font color (white)
    saveCroppedViewOnly: false, // Default setting for saving cropped view
    isStretched: false, // Flag to track if STF is applied
    originalImageState: null, // Store original image state before STF
    selectedObjectTypes: [], // Add this line to store selected object types

    newInstance: function() {
        console.writeln("New instance created.");
    },

    save: function() {
        Parameters.set("imageActiveWindow", this.imageActiveWindow.mainView.id);
        Parameters.set("zoomFactor", this.zoomFactor);
        Parameters.set("formatAlpha", this.formatAlpha);
        Parameters.set("formatDelta", this.formatDelta);
        Parameters.set("maxDownloads", this.maxDownloads);
        Parameters.set("selectedFont", this.selectedFont); // Save selected font
        Parameters.set("selectedFontSize", this.selectedFontSize); // Save selected font size
        Parameters.set("selectedFontColor", this.selectedFontColor); // Save selected font color
        Parameters.set("saveCroppedViewOnly", this.saveCroppedViewOnly); // Save cropped view setting
        Parameters.set("isStretched", this.isStretched); // Save STF state
        Parameters.set("selectedObjectTypes", this.selectedObjectTypes); // Save selected object types
    if (this.originalImageState) {
        Parameters.set("originalImageState", this.originalImageState.toSource()); // Save original image state
    }
    },

    load: function() {
        if (Parameters.has("imageActiveWindow")) {
            let imageId = Parameters.getString("imageActiveWindow");
            this.imageActiveWindow = ImageWindow.windowById(imageId);
        }
        if (Parameters.has("zoomFactor")) {
            this.zoomFactor = Parameters.getReal("zoomFactor");
        }
        if (Parameters.has("formatAlpha")) {
            this.formatAlpha = Parameters.getInteger("formatAlpha");
        }
        if (Parameters.has("formatDelta")) {
            this.formatDelta = Parameters.getInteger("formatDelta");
        }
        if (Parameters.has("maxDownloads")) {
            this.maxDownloads = Parameters.getInteger("maxDownloads");
        }
        if (Parameters.has("selectedFont")) {
            this.selectedFont = Parameters.getString("selectedFont"); // Load selected font
        }
        if (Parameters.has("selectedFontSize")) {
            this.selectedFontSize = Parameters.getInteger("selectedFontSize"); // Load selected font size
        }
        if (Parameters.has("selectedFontColor")) {
            this.selectedFontColor = Parameters.getInteger("selectedFontColor"); // Load selected font color
        }
        if (Parameters.has("saveCroppedViewOnly")) {
            this.saveCroppedViewOnly = Parameters.getBoolean("saveCroppedViewOnly"); // Load cropped view setting
        }
        if (Parameters.has("isStretched")) {
            this.isStretched = Parameters.getBoolean("isStretched"); // Load STF state
        }
                if (Parameters.has("selectedObjectTypes")) {
            this.selectedObjectTypes = Parameters.getArray("selectedObjectTypes"); // Load selected object types
        }
            if (Parameters.has("originalImageState")) {
        this.originalImageState = eval(Parameters.getString("originalImageState")); // Load original image state
    }
    }
};


function findMarkerIndex(markers, point) {
    if (!Array.isArray(markers)) {
        return -1;
    }
    return markers.findIndex(marker => marker.x === point.x && marker.y === point.y);
}

function mainDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.userResizable = true;
    this.scaledMinWidth = 800;
    this.scaledMinHeight = 600;
    this.windowTitle = TITLE + " Script";

    // Adjust dialog size based on panel visibility
    this.adjustDialogSize = () => {
        let widthAdjustment = this.advancedSearchPanel.visible ? 300 : -300;
        this.scaledMinWidth += widthAdjustment;
        this.adjustToContents();
    };

    this.titleLabel = new Label(this);
    this.titleLabel.frameStyle = FrameStyle_Box;
    this.titleLabel.margin = 10;
    this.titleLabel.wordWrapping = true;
    this.titleLabel.useRichText = true;
    this.titleLabel.text = "<p><b>" + TITLE + " " + VERSION + "</b> &mdash; " + "Shift + Click and Drag to define a reference point and radius to perform a Simbad Lookup. Mouse wheel to zoom out or in.</p>";

    // Scroll Preview
    this.ScrollControl = new ScrollBox;
    this.ScrollControl.bmp = scriptParameters.imageImage;
    this.ScrollControl.autoScroll = true;
    this.ScrollControl.tracking = true;
    this.ScrollControl.setVariableWidth();
    this.ScrollControl.setMinSize(700, 500);

    // Mini-preview
this.MiniPreviewControl = new ScrollBox;
this.MiniPreviewControl.autoScroll = false;
this.MiniPreviewControl.tracking = false;

this.createTemporaryImage = function (activeWindow, previewControl) {
    let selectedImage = activeWindow.mainView.image;

    let window = new ImageWindow(selectedImage.width, selectedImage.height, selectedImage.numberOfChannels);
    window.mainView.beginProcess();
    window.mainView.image.assign(selectedImage);
    window.mainView.endProcess();

    let P = new IntegerResample;
    const previewWidth = previewControl.viewport.width;
    const widthScale = Math.floor(selectedImage.width / previewWidth);
    P.zoomFactor = -Math.max(widthScale, 1);
    P.executeOn(window.mainView);

    // Apply PixelMath for stretch
    var PM = new PixelMath;
    PM.expression = "mtf(mtf(0.2, med($T) - min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1)), max(0, ($T - min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1)) / ~(min(max(0, med($T) + -2.8 * 1.4826 * mdev($T)), 1))))";
    PM.useSingleExpression = true;
    PM.executeOn(window.mainView);

    let resizedImage = new Image(window.mainView.image);

    if (resizedImage.width > 0 && resizedImage.height > 0) {
        previewControl.displayImage = resizedImage.render();
        previewControl.viewport.update();
        this.updateMiniPreviewControlSize(resizedImage.width, resizedImage.height);
    } else {
        console.error("Resized image has invalid dimensions.");
    }

    window.forceClose();

    return resizedImage;
};

this.updateMiniPreviewControlSize = function (imageWidth, imageHeight) {
    const fixedWidth = 400;
    const aspectRatio = imageHeight / imageWidth;
    const fixedHeight = Math.floor(fixedWidth * aspectRatio);

    this.MiniPreviewControl.setFixedSize(fixedWidth, fixedHeight);
    this.adjustToContents();
};

this.updateMiniPreview = () => {
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && activeWindow.mainView) {
        this.createTemporaryImage(activeWindow, this.MiniPreviewControl);
    } else {
        console.error("No active window found or the active window has no main view.");
    }
};

this.MiniPreviewControl.setImage = function (image) {
    this.displayImage = image;
    this.viewport.update();
};

// Ensure the mini preview is updated immediately
this.updateMiniPreview();


this.MiniPreviewControl.viewport.onMousePress = (x, y, button, buttons, modifiers) => {
    let clickX = x * this.ScrollControl.bmp.width / this.MiniPreviewControl.viewport.width;
    let clickY = y * this.ScrollControl.bmp.height / this.MiniPreviewControl.viewport.height;

    let scrollToX = Math.max(0, Math.min(clickX - (this.ScrollControl.viewport.width / 2), (this.ScrollControl.bmp.width / scriptParameters.zoomFactor)));
    let scrollToY = Math.max(0, Math.min(clickY - (this.ScrollControl.viewport.height / 2), (this.ScrollControl.bmp.height / scriptParameters.zoomFactor)));

    this.ScrollControl.scrollPosition = new Point(scrollToX/scriptParameters.zoomFactor, scrollToY/scriptParameters.zoomFactor);
    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();

    this.MiniPreviewControl.dragOrigin = new Point(x, y);
    this.MiniPreviewControl.dragging = true;
};

this.MiniPreviewControl.viewport.onMouseMove = (x, y, buttons, modifiers) => {
    if (this.MiniPreviewControl.dragging) {
        let dx = (x - this.MiniPreviewControl.dragOrigin.x) / scriptParameters.zoomFactor;
        let dy = (y - this.MiniPreviewControl.dragOrigin.y) / scriptParameters.zoomFactor;

        let scaleX = this.ScrollControl.bmp.width / this.MiniPreviewControl.viewport.width;
        let scaleY = this.ScrollControl.bmp.height / this.MiniPreviewControl.viewport.height;

        let scrollToX = this.ScrollControl.scrollPosition.x + dx * scaleX;
        let scrollToY = this.ScrollControl.scrollPosition.y + dy * scaleY;

        scrollToX = Math.max(0, Math.min(scrollToX, (this.ScrollControl.bmp.width / scriptParameters.zoomFactor)));
        scrollToY = Math.max(0, Math.min(scrollToY, (this.ScrollControl.bmp.height / scriptParameters.zoomFactor)));

        this.ScrollControl.scrollPosition = new Point(scrollToX, scrollToY);
        this.ScrollControl.viewport.update();
        this.MiniPreviewControl.viewport.update();

        this.MiniPreviewControl.dragOrigin = new Point(x, y);
    }
};

this.MiniPreviewControl.viewport.onMouseRelease = () => {
    this.MiniPreviewControl.dragging = false;
};

this.MiniPreviewControl.viewport.onMouseWheel = (x, y, delta, buttons, modifiers) => {
    let oldZoomFactor = scriptParameters.zoomFactor;

    // Calculate the old scroll position percentage
    let maxHorizontalScroll = (this.ScrollControl.bmp.width / oldZoomFactor) - this.ScrollControl.viewport.width;
    let maxVerticalScroll = (this.ScrollControl.bmp.height / oldZoomFactor) - this.ScrollControl.viewport.height;
    let oldScrollPercentageX = this.ScrollControl.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = this.ScrollControl.scrollPosition.y / maxVerticalScroll;

    // Update the zoom factor based on the wheel delta
    if (delta > 0) {
        scriptParameters.zoomFactor = Math.min(scriptParameters.zoomFactor * 1.25, this.maxZoomFactor);
    } else if (delta < 0) {
        scriptParameters.zoomFactor = Math.max(scriptParameters.zoomFactor * 0.8, this.minZoomFactor);
    }
    let newZoomFactor = scriptParameters.zoomFactor;

    // Reinitialize scrollbars to reflect the new zoom level
    this.ScrollControl.initScrollBars();

    // Calculate the new scroll position using the old scroll percentage
    maxHorizontalScroll = (this.ScrollControl.bmp.width / newZoomFactor) - this.ScrollControl.viewport.width;
    maxVerticalScroll = (this.ScrollControl.bmp.height / newZoomFactor) - this.ScrollControl.viewport.height;
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    // Ensure the new scroll position stays within valid bounds
    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    // Update the scroll position to keep the same relative position
    this.ScrollControl.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};

// Ensure this part of the code is updated to consider the zoom factor
this.MiniPreviewControl.viewport.onPaint = () => {
    var g = new Graphics(this.MiniPreviewControl.viewport);
    var result = this.MiniPreviewControl.displayImage;
    if (result == null) {
        g.fillRect(0, 0, this.MiniPreviewControl.viewport.width, this.MiniPreviewControl.viewport.height, new Brush(0xff000000));
    } else {
        result.selectedRect = new Rect(0, 0, this.MiniPreviewControl.viewport.width, this.MiniPreviewControl.viewport.height).translated(this.MiniPreviewControl.scrollPosition);
        g.drawBitmap(0, 0, result);

        let scaleX = this.MiniPreviewControl.viewport.width / (this.ScrollControl.bmp.width / scriptParameters.zoomFactor);
        let scaleY = this.MiniPreviewControl.viewport.height / (this.ScrollControl.bmp.height / scriptParameters.zoomFactor);

        let rectX = this.ScrollControl.scrollPosition.x * scaleX;
        let rectY = this.ScrollControl.scrollPosition.y * scaleY;
        let rectWidth = (this.ScrollControl.viewport.width * scaleX / scriptParameters.zoomFactor) / scriptParameters.zoomFactor;
        let rectHeight = (this.ScrollControl.viewport.height * scaleY / scriptParameters.zoomFactor) / scriptParameters.zoomFactor;

        g.pen = new Pen(0xff00ff00, 1);
        g.drawRect(rectX, rectY, rectX + rectWidth, rectY + rectHeight);

        // Draw the circle if it exists
        if (scriptParameters.circle) {
            g.pen = new Pen(0xff00ff00);
            let centerX = scriptParameters.circle.center[0] * scaleX / scriptParameters.zoomFactor;
            let centerY = scriptParameters.circle.center[1] * scaleY / scriptParameters.zoomFactor;
            let radius = scriptParameters.circle.radius * scaleX / scriptParameters.zoomFactor;
            g.drawCircle(centerX, centerY, radius);
        }

        // Draw the current shape if it exists
        if (currentShape) {
            g.pen = new Pen(0xff00ff00);
            let centerX = currentShape.center[0] * scaleX / scriptParameters.zoomFactor;
            let centerY = currentShape.center[1] * scaleY / scriptParameters.zoomFactor;
            let radius = currentShape.radius * scaleX / scriptParameters.zoomFactor;
            g.drawCircle(centerX, centerY, radius);
        }

        // Draw markers
        for (let marker of scriptParameters.markers) {
            let markerX = marker.x * scaleX / scriptParameters.zoomFactor;
            let markerY = marker.y * scaleY / scriptParameters.zoomFactor;
            let radius = 2; // Adjust marker radius with zoom factor

            if (scriptParameters.highlightedMarker && marker.x === scriptParameters.highlightedMarker.x && marker.y === scriptParameters.highlightedMarker.y) {
                g.pen = new Pen(0xff00ff00, 2); // Green color for highlighted marker
            } else {
                g.pen = new Pen(0xffff0000, 2); // Red color for regular markers
            }
            g.drawCircle(markerX, markerY, radius);
        }
    }
    g.end();
    gc();
};





    this.MiniPreviewControl.setImage = function (image) {
        this.displayImage = image;
        this.viewport.update();
    };

    this.initialUpdateCompleted = false;
    this.miniPreviewInitialized = false;

    this.ScrollControl.viewport.onResize = () => {
        this.ScrollControl.initScrollBars(this.ScrollControl.scrollPosition);
        if (!this.miniPreviewInitialized) {
            this.updateMiniPreview();
            this.miniPreviewInitialized = true;
        }
    };

    var dragging = false;
    var drawing = false;
    var startX = 0;
    var startY = 0;
    var currentShape = null;
    this.ScrollControl.dragOrigin = new Point(0, 0);

    this.ScrollControl.viewport.cursor = new Cursor(StdCursor_Cross);

this.ScrollControl.initScrollBars = (scrollPoint = null) => {
    let maxHorizontalScroll = Math.max(0, (this.ScrollControl.bmp.width / scriptParameters.zoomFactor));
    let maxVerticalScroll = Math.max(0, (this.ScrollControl.bmp.height / scriptParameters.zoomFactor));

    this.ScrollControl.setHorizontalScrollRange(0, maxHorizontalScroll);
    this.ScrollControl.setVerticalScrollRange(0, maxVerticalScroll);

    if (scrollPoint) {
        this.ScrollControl.scrollPosition = scrollPoint;
    } else {
        this.ScrollControl.scrollPosition = new Point(
            Math.min(this.ScrollControl.scrollPosition.x, maxHorizontalScroll),
            Math.min(this.ScrollControl.scrollPosition.y, maxVerticalScroll)
        );
    }

    this.ScrollControl.viewport.update();
};



this.ScrollControl.viewport.onMousePress = (x, y, button, buttons, modifiers) => {
    if (button == 1) { // Left mouse button
        let img_x = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x* scriptParameters.zoomFactor;
        let img_y = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y* scriptParameters.zoomFactor;

        for (let i = 0; i < scriptParameters.markers.length; i++) {
            let marker = scriptParameters.markers[i];
            let markerX = (marker.x - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor)*scriptParameters.zoomFactor;
            let markerY = (marker.y - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor)*scriptParameters.zoomFactor;
            let distance = Math.sqrt(Math.pow(markerX - x, 2) + Math.pow(markerY - y, 2));

            if (distance <= 5 / scriptParameters.zoomFactor) { // Adjust for zoom factor
                // Deselect all rows
                for (let j = 0; j < this.resultTreeBox.numberOfChildren; j++) {
                    this.resultTreeBox.child(j).selected = false;
                }

                // Highlight the row corresponding to the marker
                for (let j = 0; j < this.resultTreeBox.numberOfChildren; j++) {
                    let node = this.resultTreeBox.child(j);
                    if (parseInt(node.text(6)) === marker.index + 1) { // Compare the row number
                        node.selected = true;
                         break;
                    }
                }

                // Set the highlighted marker
                scriptParameters.highlightedMarker = marker;
                this.ScrollControl.viewport.update();
                return; // Exit the loop once the marker is found
            }
        }
    }

    if (modifiers === 1) { // Shift key detection
        startX = (x / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor);
        startY = (y / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
        drawing = true;
        dragging = false; // Prevent scrolling while drawing
    } else {
        this.ScrollControl.viewport.cursor = new Cursor(StdCursor_ClosedHand);
        this.ScrollControl.dragOrigin.x = x;
        this.ScrollControl.dragOrigin.y = y;
        dragging = true;
    }
};

this.ScrollControl.viewport.onMouseDoubleClick = (x, y, button, buttons, modifiers) => {
    if (button == 1) { // Left mouse button
        let img_x = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor;
        let img_y = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor;

        for (let i = 0; i < scriptParameters.markers.length; i++) {
            let marker = scriptParameters.markers[i];
            let markerX = (marker.x - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
            let markerY = (marker.y - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor) * scriptParameters.zoomFactor;
            let distance = Math.sqrt(Math.pow(markerX - x, 2) + Math.pow(markerY - y, 2));

            if (distance <= 5 / scriptParameters.zoomFactor) { // Adjust for zoom factor
                // Deselect all rows
                for (let j = 0; j < this.resultTreeBox.numberOfChildren; j++) {
                    this.resultTreeBox.child(j).selected = false;
                }

                // Highlight the row corresponding to the marker
                for (let j = 0; j < this.resultTreeBox.numberOfChildren; j++) {
                    let node = this.resultTreeBox.child(j);
                    if (parseInt(node.text(6)) === marker.index + 1) { // Compare the row number
                        node.selected = true;

                        // Set the highlighted marker
                        scriptParameters.highlightedMarker = marker;

                        if (marker.isSimbad) {
                            // Open Simbad link
                            let objectName = node.text(2).trim(); // Assuming column 2 contains the object name
                            let url = "http://simbad.u-strasbg.fr/simbad/sim-id?Ident=" + encodeURIComponent(objectName) + "&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id";
                            Dialog.openBrowser(url);
                        } else {
                            // Open Vizier search at the coordinates
                            let url = "http://vizier.u-strasbg.fr/viz-bin/VizieR-3?-source=II/246&-c=" + marker.ra + "," + marker.dec + "&-c.rs=2";
                            Dialog.openBrowser(url);
                        }

                        this.ScrollControl.viewport.update();
                        return; // Exit the loop once the marker is found
                    }
                }
            }
        }

        scriptParameters.highlightedMarker = null;
        this.ScrollControl.viewport.update();
    }
};




this.ScrollControl.viewport.onMouseMove = (x, y, buttons, modifiers) => {
    if (drawing) {
        let endX = (x / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor);
        let endY = (y / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
        let radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));

        currentShape = {
            center: [startX, startY],
            radius: radius
        };

        this.ScrollControl.viewport.update();
    } else if (dragging) {
        let dx = (this.ScrollControl.dragOrigin.x - x) / (0.2*scriptParameters.zoomFactor);
        let dy = (this.ScrollControl.dragOrigin.y - y) / (0.2*scriptParameters.zoomFactor);

        this.ScrollControl.scrollPosition = new Point(this.ScrollControl.scrollPosition).translatedBy(dx, dy);
        this.ScrollControl.dragOrigin.x = x;
        this.ScrollControl.dragOrigin.y = y;
        this.ScrollControl.viewport.update();
        this.MiniPreviewControl.viewport.update();
    } else {
        this.ScrollControl.viewport.cursor = new Cursor(StdCursor_Cross);

        var img_x = (x / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.x;
        var img_y = (y / scriptParameters.zoomFactor) + this.ScrollControl.scrollPosition.y;

        var pointSelectedCelestial = getCelestial(img_x, img_y);

        switch (scriptParameters.formatAlpha) {
            case 1:
                this.cursorDataLabelAlpha.text = pointSelectedCelestial.x.toFixed(6) + "º";
                break;
            case 2:
                var alphaHMS = degreesToHMS(pointSelectedCelestial.x);
                this.cursorDataLabelAlpha.text = zeroPadding(alphaHMS[0]) + "<sup>h</sup> " + zeroPadding(alphaHMS[1]) + "<sup>m</sup> " + zeroPadding(alphaHMS[2].toFixed(3)) + "<sup>s</sup>";
                break;
        };

        switch (scriptParameters.formatDelta) {
            case 1:
                this.cursorDataLabelDelta.text = pointSelectedCelestial.y.toFixed(6) + "º";
                break;
            case 2:
                var deltaDMS = degreesToDMS(pointSelectedCelestial.y);
                var deltaDMSsign = deltaDMS[0] == -1 ? "-" : "+";
                this.cursorDataLabelDelta.text = deltaDMSsign + zeroPadding(deltaDMS[1]) + "º " + zeroPadding(deltaDMS[2]) + "' " + zeroPadding(deltaDMS[3].toFixed(3)) + "\"";
                break;
        };
    };
};

this.ScrollControl.viewport.onMouseRelease = (x, y, button, buttons, modifiers) => {
    if (drawing) {
        drawing = false;
        scriptParameters.circle = currentShape;
        currentShape = null;

        let centerCelestial = getCelestial(scriptParameters.circle.center[0], scriptParameters.circle.center[1]);
        scriptParameters.centerPoint = {
            ra: centerCelestial.x,
            dec: centerCelestial.y
        };

        let endX = (x / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor);
        let endY = (y / scriptParameters.zoomFactor) + (this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);
        let radius = angularSeparation(centerCelestial.x, centerCelestial.y, getCelestial(endX, endY).x, getCelestial(endX, endY).y);
        scriptParameters.radius = radius;

        console.writeln(format("Center Point: RA = %.6f, Dec = %.6f", scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec));
        console.writeln(format("Radius: %.6f degrees", scriptParameters.radius));

        this.ScrollControl.viewport.update();
    } else {
        this.ScrollControl.viewport.cursor = new Cursor(StdCursor_Cross);
        dragging = false;
    }
};


// Zoom control
this.zoomFactor = 1;
this.minZoomFactor = 0.1; // Set the minimum zoom factor for zooming out
this.maxZoomFactor = 10;  // Set the maximum zoom factor for zooming in

this.ScrollControl.viewport.onMouseWheel = (x, y, delta, buttons, modifiers) => {
    let oldZoomFactor = scriptParameters.zoomFactor;

    // Calculate the old scroll position percentage
    let maxHorizontalScroll = (this.ScrollControl.bmp.width / oldZoomFactor) - this.ScrollControl.viewport.width;
    let maxVerticalScroll = (this.ScrollControl.bmp.height / oldZoomFactor) - this.ScrollControl.viewport.height;
    let oldScrollPercentageX = this.ScrollControl.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = this.ScrollControl.scrollPosition.y / maxVerticalScroll;

    // Update the zoom factor based on the wheel delta
    if (delta > 0) {
        scriptParameters.zoomFactor = Math.min(scriptParameters.zoomFactor * 1.25, this.maxZoomFactor);
    } else if (delta < 0) {
        scriptParameters.zoomFactor = Math.max(scriptParameters.zoomFactor * 0.8, this.minZoomFactor);
    }
    let newZoomFactor = scriptParameters.zoomFactor;

    // Reinitialize scrollbars to reflect the new zoom level
    this.ScrollControl.initScrollBars();

    // Calculate the new scroll position using the old scroll percentage
    maxHorizontalScroll = (this.ScrollControl.bmp.width / newZoomFactor) - this.ScrollControl.viewport.width;
    maxVerticalScroll = (this.ScrollControl.bmp.height / newZoomFactor) - this.ScrollControl.viewport.height;
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    // Ensure the new scroll position stays within valid bounds
    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    // Update the scroll position to keep the same relative position
    this.ScrollControl.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};





this.ScrollControl.viewport.onPaint = (x0, y0, x1, y1) => {
    var g = new Graphics(this.ScrollControl.viewport);
    g.antialiasing = true;
    g.smoothInterpolation = false;

    // Calculate the scaled dimensions of the image
    let scaledWidth = scriptParameters.imageImage.width * scriptParameters.zoomFactor;
    let scaledHeight = scriptParameters.imageImage.height * scriptParameters.zoomFactor;

    // Calculate offsets to center the image in the viewport if it's smaller than the viewport
    let offsetX = Math.max(0, (this.ScrollControl.viewport.width - scaledWidth) / 2);
    let offsetY = Math.max(0, (this.ScrollControl.viewport.height - scaledHeight) / 2);

    // Apply the scaling transformation
    g.scaleTransformation(scriptParameters.zoomFactor);

    // Translate the image to account for scrolling and centering
    g.translateTransformation(offsetX - this.ScrollControl.scrollPosition.x * scriptParameters.zoomFactor,
                              offsetY - this.ScrollControl.scrollPosition.y * scriptParameters.zoomFactor);

    // Draw the image
    g.drawBitmap(0, 0, scriptParameters.imageImage.render());

    // Draw the circle if it exists
    if (scriptParameters.circle) {
        g.pen = new Pen(0xff00ff00);
        let centerX = scriptParameters.circle.center[0];
        let centerY = scriptParameters.circle.center[1];
        let radius = scriptParameters.circle.radius;
        g.drawCircle(centerX, centerY, radius);
    }

    // Draw the current shape if it exists
    if (currentShape) {
        g.pen = new Pen(0xff00ff00);
        let centerX = currentShape.center[0];
        let centerY = currentShape.center[1];
        let radius = currentShape.radius;
        g.drawCircle(centerX, centerY, radius);
    }

    // Draw markers
    for (let marker of scriptParameters.markers) {
        let markerX = marker.x;
        let markerY = marker.y;
        let radius = 5 / scriptParameters.zoomFactor; // Adjust marker radius with zoom factor

        if (scriptParameters.highlightedMarker && marker.x === scriptParameters.highlightedMarker.x && marker.y === scriptParameters.highlightedMarker.y) {
            g.pen = new Pen(0xff00ff00, 2); // Green color for highlighted marker
        } else {
            g.pen = new Pen(0xffff0000, 2); // Red color for regular markers
        }
        g.drawCircle(markerX, markerY, radius);

                // Draw the object name if the checkbox is checked
        if (this.showObjectNamesCheckbox.checked) {
            g.pen = new Pen(scriptParameters.selectedFontColor, 1); // Use selected font color for text
            g.font = new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize); // Use selected font and size
            g.drawText(markerX + 6 / scriptParameters.zoomFactor, markerY, marker.name);
        }
    }

    g.end();
    gc();
};


      this.ScrollControl.initScrollBars();

     // Alpha Format
    this.resultModeAlphaLabel = new Label(this);
    this.resultModeAlphaLabel.text = "RA Format (&alpha;)";
    this.resultModeAlphaLabel.useRichText = true;
    this.resultModeAlphaLabel.toolTip = "Right Ascension (RA) format.";
    this.resultModeAlphaLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.resultModeAlphaModeCombo = new ComboBox(this);
    this.resultModeAlphaModeCombo.minWidth = 150;

    with (this.resultModeAlphaModeCombo) {
        formatModesAlpha.forEach(type => {
            addItem(type[0]);
            if (scriptParameters.formatAlpha == type[1]) {
                this.resultModeAlphaModeCombo.currentItem = type[1] - 1;
            };
        });
        onItemSelected = function (index) {
            scriptParameters.formatAlpha = formatModesAlpha[index][1];
        };
    };

    // Delta Format
    this.resultModeDeltaLabel = new Label(this);
    this.resultModeDeltaLabel.text = "Dec Format (&delta;)";
    this.resultModeDeltaLabel.useRichText = true;
    this.resultModeDeltaLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.resultModeDeltaModeCombo = new ComboBox(this);
    this.resultModeDeltaModeCombo.toolTip = "Declination (Dec) format.";
    this.resultModeDeltaModeCombo.minWidth = 150;

    with (this.resultModeDeltaModeCombo) {
        formatModesDelta.forEach(type => {
            addItem(type[0]);
            if (scriptParameters.formatDelta == type[1]) {
                this.resultModeDeltaModeCombo.currentItem = type[1] - 1;
            };
        });
        onItemSelected = function (index) {
            scriptParameters.formatDelta = formatModesDelta[index][1];
        };
    };

    // Cursor Data RA Label
    this.cursorDataLabelTitleAlpha = new Label(this);
    this.cursorDataLabelTitleAlpha.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.cursorDataLabelTitleAlpha.wordWrapping = false;
    this.cursorDataLabelTitleAlpha.useRichText = true;
    this.cursorDataLabelTitleAlpha.text = "&alpha;";

    // Cursor Data RA
    this.cursorDataLabelAlpha = new Label(this);
    this.cursorDataLabelAlpha.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.cursorDataLabelAlpha.wordWrapping = false;
    this.cursorDataLabelAlpha.useRichText = true;
    this.cursorDataLabelAlpha.text = "-";

    // Cursor Data Dec Label
    this.cursorDataLabelTitleDelta = new Label(this);
    this.cursorDataLabelTitleDelta.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.cursorDataLabelTitleDelta.wordWrapping = false;
    this.cursorDataLabelTitleDelta.useRichText = true;
    this.cursorDataLabelTitleDelta.text = "&delta;";

    // Cursor Data Dec
    this.cursorDataLabelDelta = new Label(this);
    this.cursorDataLabelDelta.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.cursorDataLabelDelta.wordWrapping = false;
    this.cursorDataLabelDelta.useRichText = true;
    this.cursorDataLabelDelta.text = "-";

    // Alpha Result Format Horizontal Sizer
    this.resultAlphaFormatGroupBoxH = new HorizontalSizer;
    this.resultAlphaFormatGroupBoxH.margin = 0;
    this.resultAlphaFormatGroupBoxH.spacing = 10;
    this.resultAlphaFormatGroupBoxH.add(this.resultModeAlphaLabel);
    this.resultAlphaFormatGroupBoxH.add(this.resultModeAlphaModeCombo);

    // Delta Result Format Horizontal Sizer
    this.resultDeltaFormatGroupBoxH = new HorizontalSizer;
    this.resultDeltaFormatGroupBoxH.margin = 0;
    this.resultDeltaFormatGroupBoxH.spacing = 10;
    this.resultDeltaFormatGroupBoxH.add(this.resultModeDeltaLabel);
    this.resultDeltaFormatGroupBoxH.add(this.resultModeDeltaModeCombo);

    // Cursor Data
    this.cursorDataHorizontal = new HorizontalSizer;
    this.cursorDataHorizontal.margin = 10;
    this.cursorDataHorizontal.spacing = 0;
    this.cursorDataHorizontal.add(this.cursorDataLabelTitleAlpha);
    this.cursorDataHorizontal.add(this.cursorDataLabelAlpha);
    this.cursorDataHorizontal.addSpacing(10);
    this.cursorDataHorizontal.add(this.cursorDataLabelTitleDelta);
    this.cursorDataHorizontal.add(this.cursorDataLabelDelta);

// Button AutoStretch
this.autoStretchButton = new PushButton(this);
this.autoStretchButton.text = " Auto Stretch ";
this.autoStretchButton.icon = ":/icons/burn.png";
this.autoStretchButton.onClick = () => {
    if (scriptParameters.isStretched) {
        resetStretch(scriptParameters.workingPreview.mainView);
        scriptParameters.isStretched = false;
    } else {
        if (!scriptParameters.originalImageState) {
            scriptParameters.originalImageState = new Image(scriptParameters.workingPreview.mainView.image);
        }
        applyPixelMathStretch(scriptParameters.workingPreview.mainView);
        scriptParameters.isStretched = true;
    }
    this.ScrollControl.viewport.update();
};




// Button Query Simbad
this.simbadButton = new PushButton(this);
this.simbadButton.text = " Query Simbad ";
this.simbadButton.icon = ":/icons/ok.png"; // Adjust the path to your icon
this.simbadButton.onClick = () => {
    this.querySimbadWithRetry();
};

// Function to query Simbad with retry logic
this.querySimbadWithRetry = () => {
    if (scriptParameters.centerPoint && scriptParameters.radius) {
        console.writeln("Query Simbad for RA: " + scriptParameters.centerPoint.ra + ", Dec: " + scriptParameters.centerPoint.dec);

        // Perform the basic search
        let objects = adqlQuerySimbad("http://simbad.u-strasbg.fr/", scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec, scriptParameters.radius, scriptParameters.maxDownloads);

        if (objects) {
            console.writeln("Total objects found: " + objects.length);

            // Ensure selectedObjectTypes is an array
            let selectedObjectTypes = this.selectedObjectTypes || [];
            if (!Array.isArray(selectedObjectTypes)) {
                selectedObjectTypes = [selectedObjectTypes];
            }

            // Normalize selectedObjectTypes for comparison
            selectedObjectTypes = selectedObjectTypes.map(type => type.replace(/"/g, "").trim().toUpperCase());

            if (selectedObjectTypes.length > 0) {
                objects = objects.filter(obj => {
                    let objType = obj.type.replace(/"/g, "").trim().toUpperCase();
                    // Check if objType is in selectedObjectTypes
                    let matchFound = false;
                    for (let i = 0; i < selectedObjectTypes.length; i++) {
                        if (selectedObjectTypes[i] === objType) {
                            matchFound = true;
                            break;
                        }
                    }
                    return matchFound;
                });
                // Log the number of objects after filtering
                console.noteln("Objects remaining after filtering: " + objects.length);
            }

            // Check if any objects remain after filtering
            if (objects.length > 0) {
                this.resultTreeBox.clear();
                scriptParameters.markers = [];
                objects.forEach((obj, index) => {
                    let node = new TreeBoxNode(this.resultTreeBox);
                    node.setText(0, obj.ra.toFixed(6)); // Set RA to the first column
                    node.setText(1, obj.dec.toFixed(6)); // Set Dec to the second column
                    node.setText(2, obj.name); // Set Name to the third column
                    node.setText(3, obj.diameter.toFixed(3)); // Set Diameter to the fourth column
                    node.setText(4, obj.type); // Set Type to the fifth column
                    node.setText(5, getTypeLongName(obj.type)); // Set Long Type to the sixth column
                    node.setText(6, (index + 1).toString()); // Set row number to the seventh column
                    node.setText(7, 'Simbad'); // Set source as Simbad

                    let point = getCoordinates(parseFloat(obj.ra.toFixed(6)), parseFloat(obj.dec.toFixed(6)));
                    if (point) {
                        point.index = index; // Add the index to the marker manually
                        point.name = obj.name; // Add the name property to the marker
                        point.ra = parseFloat(obj.ra.toFixed(6)); // Add RA to the marker
                        point.dec = parseFloat(obj.dec.toFixed(6)); // Add Dec to the marker
                        point.isSimbad = true; // Indicate this is a Simbad object
                        scriptParameters.markers.push(point); // Add the modified point to markers
                    }
                });
                this.ScrollControl.viewport.update();
                this.MiniPreviewControl.viewport.update();
            } else {
                console.writeln("No objects found after filtering.");
            }
        } else {
            console.writeln("No objects found.");
        }
    }
};



// Function to filter objects based on selected types
this.filterObjectsByType = (objects, selectedObjectTypes) => {
    if (selectedObjectTypes.length > 0) {
        //console.writeln("Filtering objects by selected types: " + selectedObjectTypes.join(", "));
        return objects.filter(obj => {
            //console.writeln("Checking object type: " + obj.type);
            return selectedObjectTypes.includes(obj.type);
        });
    }
    return objects;
};

// Apply advanced search selection
this.applyAdvancedSearchSelection = (treeBox) => {
    this.selectedObjectTypes = [];
    for (let i = 0; i < treeBox.numberOfChildren; i++) {
        let node = treeBox.child(i);
        if (node.checked) {
            this.selectedObjectTypes.push(node.objectType);
        }
    }
    console.writeln("Selected object types: " + this.selectedObjectTypes.join(", "));
};

// Initialize the TreeBox for displaying search results
this.resultTreeBox = new TreeBox(this);
this.resultTreeBox.numberOfColumns = 6; // Exclude the row number column
this.resultTreeBox.headerVisible = true;
this.resultTreeBox.headerSorting = true; // Enable header sorting
this.resultTreeBox.setHeaderText(0, "RA");
this.resultTreeBox.setHeaderText(1, "Dec");
this.resultTreeBox.setHeaderText(2, "Name");
this.resultTreeBox.setHeaderText(3, "Diameter");
this.resultTreeBox.setHeaderText(4, "Type");
this.resultTreeBox.setHeaderText(5, "Long Type");
this.resultTreeBox.setMinHeight(200);
this.resultTreeBox.setMaxHeight(200);




// Add event listener for single click on resultTreeBox rows
this.resultTreeBox.onNodeClicked = (item) => {
    if (item) {
        let ra = parseFloat(item.text(0)); // Corrected column index for RA
        let dec = parseFloat(item.text(1)); // Corrected column index for Dec
        let point = getCoordinates(ra, dec);
        if (point) {
            scriptParameters.highlightedMarker = point;
        } else {
            scriptParameters.highlightedMarker = null;
        }
    } else {
        scriptParameters.highlightedMarker = null;
    }
    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};




// Corrected onNodeDoubleClicked function
this.resultTreeBox.onNodeDoubleClicked = (item) => {
    if (item) {
        // Assuming the last column (7th) contains a flag or identifier indicating the source
        let source = item.text(7).trim();
        let objectName = item.text(2).trim(); // Corrected column index for Name

        if (source === 'Simbad') {
            let url = "http://simbad.u-strasbg.fr/simbad/sim-id?Ident=" + encodeURIComponent(objectName) + "&NbIdent=1&Radius=2&Radius.unit=arcmin&submit=submit+id";
            Dialog.openBrowser(url);
        } else if (source === 'Vizier') {
            let ra = parseFloat(item.text(0)); // Assuming RA is in the 1st column
            let dec = parseFloat(item.text(1)); // Assuming Dec is in the 2nd column
            let url = "http://vizier.u-strasbg.fr/viz-bin/VizieR-3?-source=II/246&-c=" + ra + "," + dec + "&-c.rs=2";
            Dialog.openBrowser(url);
        }
    }
};



    // Button Save CSV
    this.saveCsvButton = new PushButton(this);
    this.saveCsvButton.text = " Save CSV ";
    this.saveCsvButton.icon = ":/icons/save.png";
    this.saveCsvButton.onClick = () => {
        let saveFileDialog = new SaveFileDialog();
        saveFileDialog.caption = "Save CSV";
        saveFileDialog.filters = [["CSV Files", "*.csv"]];
        saveFileDialog.initialPath = File.systemTempDirectory; // Using systemTempDirectory as a default path
        if (saveFileDialog.execute()) {
            let lines = ["RA,Dec,Name,Diameter,Type,LongType"];
            for (let i = 0; i < this.resultTreeBox.numberOfChildren; i++) {
                let node = this.resultTreeBox.child(i);
                lines.push([node.text(0), node.text(1), node.text(2), node.text(3), node.text(4), node.text(5)].join(","));
            }
            File.writeTextFile(saveFileDialog.fileName, lines.join("\n"));
        }
    };

    this.showObjectNamesCheckbox = new CheckBox(this);
this.showObjectNamesCheckbox.text = "Show Object Names";
this.showObjectNamesCheckbox.checked = true; // Default state
this.showObjectNamesCheckbox.toolTip = "Toggle to display object names next to markers on the main preview.";
this.showObjectNamesCheckbox.onClick = () => {
    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};

    // Button Exit
    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Exit";
    this.cancelButton.icon = ":/toolbar/file-exit.png";
    this.cancelButton.onClick = () => {
        var msg = new MessageBox("Exit?", "Confirm Exit", StdIcon_Question, StdButton_Yes, StdButton_No);
        if (msg.execute() == StdButton_Yes) {
            this.cancel();
        }
    };

// Updating the dialog call to properly update the script parameters
this.maxDownloadsButton = new PushButton(this);
this.maxDownloadsButton.text = "";
this.maxDownloadsButton.icon = ":/icons/wrench.png"; // Adjust the icon path as needed
this.maxDownloadsButton.onClick = () => {
    var dialog = new MaxDownloadsDialog(
        scriptParameters.maxDownloads || 500,
        scriptParameters.selectedFont || "DejaVu Sans",
        scriptParameters.selectedFontSize || 10,
        scriptParameters.selectedFontColor || 0xffffffff, // Default to White if not set
        scriptParameters.saveCroppedViewOnly || false,
        this.ScrollControl,
        this.MiniPreviewControl
    ); // Provide defaults if not set
    if (dialog.execute() === 1) { // OK button pressed
        scriptParameters.maxDownloads = dialog.maxDownloads;
        scriptParameters.selectedFont = dialog.selectedFont;
        scriptParameters.selectedFontSize = dialog.selectedFontSize;
        scriptParameters.selectedFontColor = dialog.selectedFontColor;
        scriptParameters.saveCroppedViewOnly = dialog.saveCroppedViewOnly;
        console.writeln("Max downloads set to: " + scriptParameters.maxDownloads);
        console.writeln("Selected font: " + scriptParameters.selectedFont);
        console.writeln("Selected font size: " + scriptParameters.selectedFontSize);
        console.writeln("Selected font color: " + scriptParameters.selectedFontColor.toString(16)); // Print color in hex
        console.writeln("Save cropped view only: " + scriptParameters.saveCroppedViewOnly);
    }
};


// Button to toggle all markers
this.toggleMarkersButton = new PushButton(this);
this.toggleMarkersButton.text = " Toggle All Markers ";
this.toggleMarkersButton.icon = ":/icons/clear.png";
this.toggleMarkersButton.onClick = () => {
    if (scriptParameters.markers.length > 0) {
        scriptParameters.markers = [];
    } else {
        for (let i = 0; i < this.resultTreeBox.numberOfChildren; i++) {
            let node = this.resultTreeBox.child(i);
            let ra = parseFloat(node.text(0));
            let dec = parseFloat(node.text(1));
            let point = getCoordinates(ra, dec);
            if (point) {
               point.name = node.text(2); // Assuming column 2 has the name
                scriptParameters.markers.push(point);
            }
        }
    }
    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};

// Initial population of markers after Simbad query
this.populateMarkers = () => {
    scriptParameters.markers = [];
    for (let i = 0; i < this.resultTreeBox.numberOfChildren; i++) {
        let node = this.resultTreeBox.child(i);
        let ra = parseFloat(node.text(0));
        let dec = parseFloat(node.text(1));
        let point = getCoordinates(ra, dec);
        if (point) {
            scriptParameters.markers.push(point);
        }
    }
    this.ScrollControl.viewport.update();
    this.MiniPreviewControl.viewport.update();
};

    this.instructionLabel = new Label(this);
this.instructionLabel.text = "Click and Drag in the MiniPreview to Zoom to that Location";
this.instructionLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;

this.clickLabel = new Label(this);
this.clickLabel.text = "Click any Row to highlight the Marker or Vice Versa on the Main Preview.\nDouble Click a Marker or Row to Open that object in Simbad.";
this.clickLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;



// Vertical sizer for Auto Stretch button
this.autoStretchButtonSizer = new VerticalSizer;
this.autoStretchButtonSizer.margin = 0;
this.autoStretchButtonSizer.add(this.autoStretchButton);

// Horizontal sizer for other buttons
this.utilButtonSizer = new HorizontalSizer;
this.utilButtonSizer.margin = 0;
this.utilButtonSizer.add(this.simbadButton);
this.utilButtonSizer.addSpacing(10);
this.utilButtonSizer.add(this.saveCsvButton);
this.utilButtonSizer.addSpacing(10);
this.utilButtonSizer.add(this.toggleMarkersButton);

// Horizontal sizer for Exit button
this.execButtonSizer = new HorizontalSizer;
this.execButtonSizer.margin = 0;
this.execButtonSizer.add(this.cancelButton);

// Authorship label
this.authorshipLabel = new Label(this);
this.authorshipLabel.text = "<p style='text-align:center;'>Written by Franklin Marek 2024.<br><a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
this.authorshipLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
this.authorshipLabel.useRichText = true;



    // Advanced Search Button
    this.advancedSearchButton = new PushButton(this);
    this.advancedSearchButton.text = "Advanced Search";
    this.advancedSearchButton.onClick = () => {
        console.writeln("Toggling advanced search panel...");
        this.toggleAdvancedSearchPanel();
    };

// Query NED function
this.queryNED = () => {
    if (scriptParameters.centerPoint && scriptParameters.radius) {
        let ra = scriptParameters.centerPoint.ra;
        let dec = scriptParameters.centerPoint.dec;
        let radius = Math.min(scriptParameters.radius * 60, 60); // Convert radius to arcminutes and cap at 60

        // Format the NED URL
        let decSign = dec >= 0 ? "%2B" : "-"; // Determine the sign for the declination
        let url = "http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search&ra=" + ra.toFixed(6) + "d&dec=" + decSign + Math.abs(dec).toFixed(6) + "d&radius=" + radius + "&in_csys=Equatorial&in_equinox=J2000.0";

        // Open the URL in the browser
        Dialog.openBrowser(url);
    }
};

function createAdvancedSearchPanel(parent) {
    let panel = new Control(parent);
    panel.sizer = new VerticalSizer;
    panel.sizer.spacing = 4;
    panel.hide();

    let treeBox = new TreeBox(panel);
    treeBox.numberOfColumns = 2;
    treeBox.headerVisible = true;
    treeBox.headerSorting = true; // Enable header sorting
    treeBox.setHeaderText(0, "Object Type");
    treeBox.setHeaderText(1, "Description");
    treeBox.setMinSize(300, 600);
    treeBox.setScaledMinSize(300, 600);
    treeBox.multipleSelection = true;
    treeBox.alternateRowColor = true;
    treeBox.setScaledMinHeight(600);
    treeBox.horizontalScrollBarVisible = true;  // Ensure horizontal scrollbar is visible
    treeBox.verticalScrollBarVisible = true;    // Ensure vertical scrollbar is visible

    console.writeln("Creating treebox items for object types...");
    // Create treebox items for each object type using typeLookupTable
    for (let i = 0; i < typeLookupTable.length; i++) {
        let type = typeLookupTable[i];
        if (type.cond !== "") {
            let node = new TreeBoxNode(treeBox);
            node.setText(0, type.cond);
            node.setText(1, type.extd);
            node.checked = false;
            node.objectType = type.cond;
        }
    }

    function populateSelections() {
        if (scriptParameters.selectedObjectTypes && scriptParameters.selectedObjectTypes.length > 0) {
            for (let i = 0; i < treeBox.numberOfChildren; i++) {
                let node = treeBox.child(i);
                if (scriptParameters.selectedObjectTypes.includes(node.objectType)) {
                    node.checked = true;
                }
            }
        }
    }

    // Call populateSelections to set checkboxes based on saved selections
    populateSelections();

    panel.sizer.add(treeBox);

    let toggleCheckboxesButton = new PushButton(panel);
    toggleCheckboxesButton.text = "Toggle All";
    toggleCheckboxesButton.onClick = () => {
        let allChecked = true;
        for (let i = 0; i < treeBox.numberOfChildren; i++) {
            if (!treeBox.child(i).checked) {
                allChecked = false;
                break;
            }
        }
        for (let i = 0; i < treeBox.numberOfChildren; i++) {
            treeBox.child(i).checked = !allChecked;
        }
    };
    panel.sizer.add(toggleCheckboxesButton);

    let buttonSizer = new HorizontalSizer;
    buttonSizer.spacing = 6;

    let confirmButton = new PushButton(panel);
    confirmButton.text = "Confirm Selections";
    confirmButton.icon = ":/icons/ok.png";
    confirmButton.onClick = () => {
        // Save selected object types to scriptParameters
        scriptParameters.selectedObjectTypes = [];
        for (let i = 0; i < treeBox.numberOfChildren; i++) {
            if (treeBox.child(i).checked) {
                scriptParameters.selectedObjectTypes.push(treeBox.child(i).objectType);
            }
        }
        console.writeln("Selections confirmed:", scriptParameters.selectedObjectTypes);
        parent.applyAdvancedSearchSelection(treeBox);
    };
    buttonSizer.add(confirmButton);

    let clearButton = new PushButton(panel);
    clearButton.text = "Clear Selections";
    clearButton.icon = ":/icons/cancel.png";
    clearButton.onClick = () => {
        for (let i = 0; i < treeBox.numberOfChildren; i++) {
            treeBox.child(i).checked = false;
        }
        scriptParameters.selectedObjectTypes = []; // Clear the selections in memory
        console.writeln("Selections cleared.");
    };
    buttonSizer.add(clearButton);

    panel.sizer.add(buttonSizer);

    // Sizer for the new buttons
    let queryButtonSizer = new HorizontalSizer;
    queryButtonSizer.spacing = 6;

    let queryDefinedRegionButton = new PushButton(panel);
    queryDefinedRegionButton.text = "Query Simbad Defined Region";
    queryDefinedRegionButton.icon = ":/icons/execute.png"; // Adjust the path to your icon
    queryDefinedRegionButton.onClick = () => {
        performSimbadQuery(parent, scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec, scriptParameters.radius, scriptParameters.maxDownloads);
    };
    queryButtonSizer.add(queryDefinedRegionButton);

    let queryEntireImageButton = new PushButton(panel);
    queryEntireImageButton.text = "Query Simbad Entire Image";
    queryEntireImageButton.icon = ":/icons/search.png"; // Adjust the path to your icon
    queryEntireImageButton.onClick = () => {
        let activeWindow = ImageWindow.activeWindow;
        if (activeWindow && activeWindow.mainView) {
            let width = activeWindow.mainView.image.width;
            let height = activeWindow.mainView.image.height;

            // Calculate RA and Dec for the four corners of the image
            let topLeft = getCelestial(0, 0);
            let topRight = getCelestial(width, 0);
            let bottomLeft = getCelestial(0, height);
            let bottomRight = getCelestial(width, height);

            if (!topLeft || !topRight || !bottomLeft || !bottomRight) {
                console.writeln("Could not calculate the coordinates for the corners.");
                return;
            }

            // Calculate the center RA and Dec
            let centerRA = (topLeft.x + topRight.x + bottomLeft.x + bottomRight.x) / 4;
            let centerDec = (topLeft.y + topRight.y + bottomLeft.y + bottomRight.y) / 4;

            // Calculate the radius as the maximum angular separation from the center to any corner
            let radius = Math.max(
                angularSeparation(centerRA, centerDec, topLeft.x, topLeft.y),
                angularSeparation(centerRA, centerDec, topRight.x, topRight.y),
                angularSeparation(centerRA, centerDec, bottomLeft.x, bottomLeft.y),
                angularSeparation(centerRA, centerDec, bottomRight.x, bottomRight.y)
            );

            performSimbadQuery(parent, centerRA, centerDec, radius, 25000);
        } else {
            console.writeln("No active image window found.");
        }
    };

    queryButtonSizer.add(queryEntireImageButton);

    panel.sizer.add(queryButtonSizer);

    // Sizer for the Vizier deep search button
    let deepSearchButtonSizer = new HorizontalSizer;
    deepSearchButtonSizer.spacing = 6;

    let deepSearchButton = new PushButton(panel);
    deepSearchButton.text = "CAUTION - Deep Search Query - Vizier";
    deepSearchButton.icon = ":/icons/burn.png"; // Adjust the path to your icon
    deepSearchButton.toolTip = "Searches GAIA, 2MASS, SDSS, UCAC4.... Use with CAUTION"; // Add tooltip here
    deepSearchButton.onClick = () => {
        if (!scriptParameters.centerPoint || !scriptParameters.radius) {
            console.writeln("Please select a region first.");
            return;
        }
        performVizierQuery(parent, scriptParameters.centerPoint.ra, scriptParameters.centerPoint.dec, scriptParameters.radius, scriptParameters.maxDownloads);
    };

    deepSearchButtonSizer.add(deepSearchButton);
    panel.sizer.add(deepSearchButtonSizer);

    // Label and Search N.E.D. button
    let nedSearchSizer = new HorizontalSizer;
    nedSearchSizer.spacing = 6;

    // Add a spacer to push the label and button to the right
    //nedSearchSizer.addStretch();

    let externalSearchLabel = new Label(panel);
    externalSearchLabel.text = "External Search:";
    nedSearchSizer.add(externalSearchLabel);

    let nedButton = new PushButton(panel);
    nedButton.text = "Search N.E.D.";
    nedButton.icon = ":/icons/search.png"; // Adjust the path to your icon
    nedButton.onClick = () => {
        parent.queryNED();
    };
    nedSearchSizer.add(nedButton);

    panel.sizer.add(nedSearchSizer);

    return panel;
}

function performSimbadQuery(parent, centerX, centerY, radius, maxDownloads) {
    console.writeln("Query Simbad for RA: " + centerX + ", Dec: " + centerY + ", Radius: " + radius);
    let simbadObjects = adqlQuerySimbad("http://simbad.u-strasbg.fr/", centerX, centerY, radius, maxDownloads);

    // Display results in TreeBox
    if (simbadObjects) {
        console.writeln("Total Simbad objects found: " + simbadObjects.length);

        // Ensure selectedObjectTypes is an array
        let selectedObjectTypes = parent.selectedObjectTypes || [];

        if (!Array.isArray(selectedObjectTypes)) {
            selectedObjectTypes = [selectedObjectTypes];
        }

        // Normalize selectedObjectTypes for comparison
        selectedObjectTypes = selectedObjectTypes.map(type => type.replace(/"/g, "").trim().toUpperCase());

        if (selectedObjectTypes.length > 0) {
            simbadObjects = simbadObjects.filter(obj => {
                let objType = obj.type.replace(/"/g, "").trim().toUpperCase();

                // Check if objType is in selectedObjectTypes
                let matchFound = false;
                for (let i = 0; i < selectedObjectTypes.length; i++) {
                    if (selectedObjectTypes[i] === objType) {
                        matchFound = true;
                        break;
                    }
                }
                return matchFound;
            });
            // Log the number of objects after filtering
            console.noteln("Objects remaining after filtering: " + simbadObjects.length);
        }

        // Check if any objects remain after filtering
        if (simbadObjects.length > 0) {
            parent.resultTreeBox.clear();
            scriptParameters.markers = [];
            simbadObjects.forEach((obj, index) => {
                let node = new TreeBoxNode(parent.resultTreeBox);
                node.setText(0, obj.ra ? obj.ra.toFixed(6) : "N/A"); // Set RA to the first column
                node.setText(1, obj.dec ? obj.dec.toFixed(6) : "N/A"); // Set Dec to the second column
                node.setText(2, obj.name || "N/A"); // Set Name to the third column
                node.setText(3, obj.diameter ? obj.diameter.toFixed(3) : "N/A"); // Set Diameter to the fourth column
                node.setText(4, obj.type || "N/A"); // Set Type to the fifth column
                node.setText(5, getTypeLongName(obj.type) || "Unknown"); // Set Long Type to the sixth column
                node.setText(6, (index + 1).toString()); // Set row number to the seventh column
                node.setText(7, 'Simbad'); // Set source as Simbad

                let point = getCoordinates(parseFloat(obj.ra.toFixed(6)), parseFloat(obj.dec.toFixed(6)));
                if (point) {
                    point.index = index; // Add the index to the marker manually
                    point.name = obj.name || "N/A"; // Add the name property to the marker
                    point.ra = parseFloat(obj.ra.toFixed(6)); // Add RA to the marker
                    point.dec = parseFloat(obj.dec.toFixed(6)); // Add Dec to the marker
                    point.isSimbad = true; // Indicate this is a Simbad object
                    scriptParameters.markers.push(point); // Add the modified point to markers
                }
            });
            parent.ScrollControl.viewport.update();
            parent.MiniPreviewControl.viewport.update();
        } else {
            console.writeln("No objects found after filtering.");
        }
    } else {
        console.writeln("No objects found.");
    }
}


// Perform Vizier Query function
function performVizierQuery(parent, centerX, centerY, radius, maxDownloads) {
    console.writeln("Query Vizier for RA: " + centerX + ", Dec: " + centerY + ", Radius: " + radius);

    // Convert radius from degrees to arcminutes for the Vizier query
    let radiusInArcminutes = 60 * radius;

    // Define the catalogs to search in VizieR
    let catalogs = [
        "II/246",    // 2MASS
        "I/350/gaiaedr3", // Gaia EDR3
        "V/147/sdss12",  // SDSS 12th data release
        "I/322A",  // UCAC4
        "V/154"  // SDSS DR16
    ];

    // Perform the Vizier query
    let vizierObjects = adqlQueryVizier("http://vizier.u-strasbg.fr/viz-bin/asu-tsv?", centerX, centerY, radiusInArcminutes, maxDownloads, catalogs);

    if (vizierObjects) {
        console.writeln("Total Vizier objects found: " + vizierObjects.length);

        // Ensure selectedObjectTypes is an array
        let selectedObjectTypes = parent.selectedObjectTypes || [];

        if (!Array.isArray(selectedObjectTypes)) {
            selectedObjectTypes = [selectedObjectTypes];
        }

        // Normalize selectedObjectTypes for comparison
        selectedObjectTypes = selectedObjectTypes.map(type => type.replace(/"/g, "").trim().toUpperCase());

        if (selectedObjectTypes.length > 0) {
            vizierObjects = vizierObjects.filter(obj => {
                let objType = obj.type.replace(/"/g, "").trim().toUpperCase();

                // Check if objType is in selectedObjectTypes
                let matchFound = false;
                for (let i = 0; i < selectedObjectTypes.length; i++) {
                    if (selectedObjectTypes[i] === objType) {
                        matchFound = true;
                        break;
                    }
                }
                return matchFound;
            });
            // Log the number of objects after filtering
            console.noteln("Objects remaining after filtering: " + vizierObjects.length);
        }

        // Check if any objects remain after filtering
        if (vizierObjects.length > 0) {
            parent.resultTreeBox.clear();
            scriptParameters.markers = [];
            vizierObjects.forEach((obj, index) => {
                let node = new TreeBoxNode(parent.resultTreeBox);
                node.setText(0, obj.ra ? obj.ra.toFixed(6) : "N/A"); // Set RA to the first column
                node.setText(1, obj.dec ? obj.dec.toFixed(6) : "N/A"); // Set Dec to the second column
                node.setText(2, obj.name || "N/A"); // Set Name to the third column
                node.setText(3, obj.diameter ? obj.diameter.toFixed(3) : "N/A"); // Set Diameter to the fourth column
                node.setText(4, obj.type || "N/A"); // Set Type to the fifth column
                node.setText(5, getTypeLongName(obj.type) || "Unknown"); // Set Long Type to the sixth column
                node.setText(6, (index + 1).toString()); // Set row number to the seventh column
                node.setText(7, 'Vizier'); // Set source as Vizier

                let point = getCoordinates(parseFloat(obj.ra.toFixed(6)), parseFloat(obj.dec.toFixed(6)));
                if (point) {
                    point.index = index; // Add the index to the marker manually
                    point.name = obj.name || "N/A"; // Add the name property to the marker
                    point.ra = parseFloat(obj.ra.toFixed(6)); // Add RA to the marker
                    point.dec = parseFloat(obj.dec.toFixed(6)); // Add Dec to the marker
                    point.isSimbad = false; // Indicate this is not a Simbad object
                    scriptParameters.markers.push(point); // Add the modified point to markers
                }
            });
            parent.ScrollControl.viewport.update();
            parent.MiniPreviewControl.viewport.update();
        } else {
            console.writeln("No objects found after filtering.");
        }
    } else {
        console.writeln("No objects found.");
    }
}


    this.toggleAdvancedSearchPanel = () => {
        if (this.advancedSearchPanel.visible) {
            this.advancedSearchPanel.hide();
        } else {
            this.advancedSearchPanel.show();
        }
        this.adjustDialogSize(); // Adjust the dialog size after toggling the panel
    };

this.applyAdvancedSearchSelection = (treeBox) => {
    this.selectedObjectTypes = [];
    for (let i = 0; i < treeBox.numberOfChildren; i++) {
        let node = treeBox.child(i);
        if (node.checked) {
            this.selectedObjectTypes.push(node.objectType);
        }
    }
    console.writeln("Selected object types: ", this.selectedObjectTypes.join(", "));
};


    this.selectedObjectTypes = [];

    this.advancedSearchPanel = createAdvancedSearchPanel(this);

this.copyRaDecButton = new PushButton(this);
this.copyRaDecButton.text = "Copy Center RA/DEC";
this.copyRaDecButton.icon = ":/icons/copy.png"; // Adjust the icon path as needed
this.copyRaDecButton.onClick = () => {
    if (scriptParameters.centerPoint) {
        let text = "RA: " + scriptParameters.centerPoint.ra.toFixed(6) + ", DEC: " + scriptParameters.centerPoint.dec.toFixed(6);
        console.writeln("Center RA/DEC ready for manual copy: " + text);

        // Display the RA/DEC in a popup dialog with instructions to copy manually
        let msgText = "Highlight and Copy Your Coordinates:\n\n" + text;
        let msg = new MessageBox(msgText, "Center RA/DEC", StdIcon_Information, StdButton_Ok);
        msg.execute();
    } else {
        console.writeln("No center point defined.");
    }
};

// Add a button for saving the annotated image
this.saveAnnotatedImageButton = new PushButton(this);
this.saveAnnotatedImageButton.text = "Save Annotated Image";
this.saveAnnotatedImageButton.icon = ":/icons/save.png";
this.saveAnnotatedImageButton.toolTip = "Save the annotated image as a .jpg file.";
this.saveAnnotatedImageButton.onClick = () => {
    this.saveAnnotatedImage();
};

// Function to save the annotated image
this.saveAnnotatedImage = () => {
    let width, height, croppedImage;
    let zoomFactor = scriptParameters.zoomFactor;

    // Create a temporary image window to draw the annotations
    let tempImageWindow = new ImageWindow(
        scriptParameters.imageImage.width,
        scriptParameters.imageImage.height,
        scriptParameters.imageImage.numberOfChannels,
        scriptParameters.imageImage.bitsPerSample,
        scriptParameters.imageImage.sampleType == SampleType_Real,
        scriptParameters.imageImage.colorSpace == ColorSpace_RGB  // Correct color space handling
    );

    // Assign the current image to the temporary image window
    tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    tempImageWindow.mainView.image.assign(scriptParameters.imageImage);
    tempImageWindow.mainView.endProcess();

    // Create a new bitmap to draw the annotations
    let bitmap = new Bitmap(tempImageWindow.mainView.image.width, tempImageWindow.mainView.image.height);
    let graphics = new Graphics(bitmap);
    graphics.antialiasing = true;

    // Get the selected font color
    let selectedFontColor = scriptParameters.selectedFontColor; // Ensure this variable is defined and used correctly

    // Draw annotations directly on the bitmap
    scriptParameters.markers.forEach(marker => {
        drawCircle(graphics, marker.x, marker.y, 5, new Pen(0xffff0000, 2)); // Red color for markers
        if (this.showObjectNamesCheckbox.checked) {
            drawText(graphics, marker.x + 10, marker.y, marker.name, new Pen(selectedFontColor), new Font(scriptParameters.selectedFont, scriptParameters.selectedFontSize));
        }
    });

    graphics.end();

    // Combine the original image and the annotations
    tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    tempImageWindow.mainView.image.blend(bitmap);
    tempImageWindow.mainView.endProcess();

    // Crop the image if needed
    if (scriptParameters.saveCroppedViewOnly) {
        // Calculate the DynamicCrop parameters
        let scrollX = Math.round(this.ScrollControl.scrollPosition.x * zoomFactor);
        let scrollY = Math.round(this.ScrollControl.scrollPosition.y * zoomFactor);
        let viewportWidth = Math.round(this.ScrollControl.viewport.width / zoomFactor);
        let viewportHeight = Math.round(this.ScrollControl.viewport.height / zoomFactor);

        let refWidth = scriptParameters.imageImage.width;
        let refHeight = scriptParameters.imageImage.height;

        let outWidth = Math.floor(viewportWidth);
        let outHeight = Math.floor(viewportHeight);

        let centerX = (scrollX + viewportWidth / 2) / refWidth;
        let centerY = (scrollY + viewportHeight / 2) / refHeight;

        // Create the DynamicCrop instance
        var P = new DynamicCrop;
        P.refWidth = refWidth;
        P.refHeight = refHeight;
        P.outWidth = outWidth;
        P.outHeight = outHeight;
        P.centerX = centerX;
        P.centerY = centerY;
        P.noGUIMessages = true;

        let croppedImageWindow = new ImageWindow(
            refWidth,
            refHeight,
            scriptParameters.imageImage.numberOfChannels,
            scriptParameters.imageImage.bitsPerSample,
            scriptParameters.imageImage.sampleType == SampleType_Real,
            scriptParameters.imageImage.colorSpace == ColorSpace_RGB
        );

        croppedImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
        croppedImageWindow.mainView.image.assign(tempImageWindow.mainView.image);
        croppedImageWindow.mainView.endProcess();

        P.executeOn(croppedImageWindow.mainView);

        tempImageWindow.forceClose();
        tempImageWindow = croppedImageWindow;
    }

    // Save the annotated image as a .jpg file
    let saveFileDialog = new SaveFileDialog;
    saveFileDialog.caption = "Save Annotated Image";
    saveFileDialog.filters = [
        ["JPEG Files", ".jpg"],
        ["All Files", "*"]
    ];
    if (saveFileDialog.execute()) {
        let outputFilePath = saveFileDialog.fileName;
        tempImageWindow.saveAs(outputFilePath); // Let PI handle the quality selection
        tempImageWindow.forceClose();
        console.writeln("Annotated image saved as: " + outputFilePath);
    } else {
        tempImageWindow.forceClose();
        console.writeln("Save operation canceled.");
    }
};

// Helper function to draw a circle
function drawCircle(graphics, centerX, centerY, radius, pen) {
    graphics.pen = pen;
    graphics.drawCircle(centerX, centerY, radius);
}

// Helper function to draw text
function drawText(graphics, startX, startY, text, pen, font) {
    graphics.pen = pen;
    graphics.font = font;
    graphics.drawText(startX, startY, text);
}


// Add the save button to the layout
this.saveButtonSizer = new HorizontalSizer;
this.saveButtonSizer.addStretch();
this.saveButtonSizer.add(this.saveAnnotatedImageButton);
this.saveButtonSizer.addStretch();

this.newInstanceButton = new ToolButton(this);
this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
this.newInstanceButton.setScaledFixedSize(24, 24);
this.newInstanceButton.toolTip = "New Instance";
this.newInstanceButton.onMousePress = () => {
    scriptParameters.save();
    this.newInstance();
};

// Horizontal sizer for search buttons
this.searchButtonSizer = new HorizontalSizer;
this.searchButtonSizer.margin = 0;
this.searchButtonSizer.add(this.simbadButton);
this.searchButtonSizer.addSpacing(10);
this.searchButtonSizer.add(this.saveCsvButton);


// Horizontal sizer for advanced search and NED buttons
this.advancedSearchButtonSizer = new HorizontalSizer;
this.advancedSearchButtonSizer.margin = 0;
this.advancedSearchButtonSizer.add(this.advancedSearchButton);
this.advancedSearchButtonSizer.addSpacing(10);
this.advancedSearchButtonSizer.add(this.toggleMarkersButton);


// Vertical sizer for utility buttons
this.utilButtonSizer = new VerticalSizer;
this.utilButtonSizer.margin = 0;
this.utilButtonSizer.add(this.advancedSearchButtonSizer);
this.utilButtonSizer.addSpacing(10);
this.utilButtonSizer.add(this.searchButtonSizer);

// Horizontal sizer for Exit button and new button
this.execButtonSizer = new HorizontalSizer;
this.execButtonSizer.margin = 0;
this.execButtonSizer.spacing = 10; // Ensure there is space between buttons
this.execButtonSizer.add(this.newInstanceButton);
this.execButtonSizer.add(this.cancelButton); // Add the Exit button second
this.execButtonSizer.add(this.maxDownloadsButton); // Add the new button first


// Vertical sizer for right sidebar
this.rightSidebarVertical = new VerticalSizer;
this.rightSidebarVertical.margin = 0;
//this.rightSidebarVertical.add(this.imageSizer);
//this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.resultAlphaFormatGroupBoxH);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.resultDeltaFormatGroupBoxH);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.autoStretchButtonSizer);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.utilButtonSizer);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.showObjectNamesCheckbox);
this.rightSidebarVertical.addStretch();
this.rightSidebarVertical.add(this.MiniPreviewControl);
this.rightSidebarVertical.add(this.instructionLabel);
this.rightSidebarVertical.addStretch();
this.rightSidebarVertical.add(this.authorshipLabel);
this.rightSidebarVertical.addStretch();
this.rightSidebarVertical.add(this.cursorDataHorizontal);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.copyRaDecButton);
this.rightSidebarVertical.addSpacing(10);
this.rightSidebarVertical.add(this.execButtonSizer);

// Vertical sizer for left body
this.leftBodyVertical = new VerticalSizer();
this.leftBodyVertical.margin = 0;
this.leftBodyVertical.add(this.ScrollControl);
this.leftBodyVertical.add(this.saveButtonSizer);
this.leftBodyVertical.add(this.clickLabel);
this.leftBodyVertical.add(this.resultTreeBox);

// Vertical sizer for advanced search
this.advancedSearchVertical = new VerticalSizer;
this.advancedSearchVertical.margin = 0;
this.advancedSearchVertical.add(this.advancedSearchPanel);
//this.advancedSearchVertical.addStretch();

// Horizontal sizer for main grid
this.mainHorizontal = new HorizontalSizer;
this.mainHorizontal.margin = 0;
this.mainHorizontal.add(this.rightSidebarVertical);
this.mainHorizontal.addSpacing(10);
this.mainHorizontal.add(this.leftBodyVertical);
this.mainHorizontal.addSpacing(10);
this.mainHorizontal.add(this.advancedSearchVertical); // Add advanced search vertical section

// Vertical sizer for dialog
this.sizer = new VerticalSizer;
this.sizer.margin = 10;
this.sizer.add(this.titleLabel);
this.sizer.addSpacing(10);
this.sizer.add(this.mainHorizontal);

}
mainDialog.prototype = new Dialog;

function MaxDownloadsDialog(initialValue, initialFont, initialFontSize, initialFontColor, initialSaveCroppedViewOnly, scrollControl, miniPreviewControl) {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "Max Downloads Options";

    // Store references to the controls
    this.scrollControl = scrollControl;
    this.miniPreviewControl = miniPreviewControl;

    // Label for Max Downloads
    this.maxDownloadsLabel = new Label(this);
    this.maxDownloadsLabel.text = "Max Downloads: (not to exceed 25,000)";
    this.maxDownloadsLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    // Input for Max Downloads
    this.maxDownloadsSpinBox = new SpinBox(this);
    this.maxDownloadsSpinBox.minValue = 1; // Minimum value
    this.maxDownloadsSpinBox.maxValue = 25000; // Maximum value
    this.maxDownloadsSpinBox.value = initialValue;
    this.maxDownloadsSpinBox.toolTip = "Set the maximum number of downloads (whole numbers only).";

    // Label for Font Selection
    this.fontLabel = new Label(this);
    this.fontLabel.text = "Font:";
    this.fontLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    // Dropdown for Font Selection
    this.fontComboBox = new ComboBox(this);
    this.fontComboBox.addItem("Arial");
    this.fontComboBox.addItem("Courier New");
    this.fontComboBox.addItem("Times New Roman");
    this.fontComboBox.addItem("Verdana");
    this.fontComboBox.addItem("DejaVu Sans");
    this.fontComboBox.toolTip = "Select the font for annotations.";
    this.fontComboBox.currentItem = this.fontComboBox.findItem(initialFont); // Set initial value

    // Label for Font Size Selection
    this.fontSizeLabel = new Label(this);
    this.fontSizeLabel.text = "Font Size:";
    this.fontSizeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    // Dropdown for Font Size Selection
    this.fontSizeComboBox = new ComboBox(this);
    for (let size = 8; size <= 36; size += 2) {
        this.fontSizeComboBox.addItem(size.toString());
    }
    this.fontSizeComboBox.toolTip = "Select the font size for annotations.";
    this.fontSizeComboBox.currentItem = this.fontSizeComboBox.findItem(initialFontSize.toString()); // Set initial value

    // Label for Font Color Selection
    this.fontColorLabel = new Label(this);
    this.fontColorLabel.text = "Font Color:";
    this.fontColorLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    // Dropdown for Font Color Selection
    this.fontColorComboBox = new ColorComboBox(this, initialFontColor);
    this.fontColorComboBox.toolTip = "Select the font color for annotations.";

    // Checkbox for Save Cropped View Only
    this.saveCroppedViewOnlyCheckbox = new CheckBox(this);
    this.saveCroppedViewOnlyCheckbox.text = "Save Annotated Cropped View Only";
    this.saveCroppedViewOnlyCheckbox.checked = initialSaveCroppedViewOnly;

    // OK and Cancel buttons
    this.okButton = new PushButton(this);
    this.okButton.text = "OK";
    this.okButton.onClick = () => {
        scriptParameters.selectedFontColor = this.fontColorComboBox.getColorValue(); // Store the selected font color
        if (this.scrollControl) {
            this.scrollControl.viewport.update();
        }
        if (this.miniPreviewControl) {
            this.miniPreviewControl.viewport.update();
        }
        this.ok();
    };

    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => {
        this.cancel();
    };

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 4;
    this.sizer.add(this.maxDownloadsLabel);
    this.sizer.add(this.maxDownloadsSpinBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.fontLabel);
    this.sizer.add(this.fontComboBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.fontSizeLabel);
    this.sizer.add(this.fontSizeComboBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.fontColorLabel);
    this.sizer.add(this.fontColorComboBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.saveCroppedViewOnlyCheckbox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.okButton);
    this.sizer.addSpacing(4);
    this.sizer.add(this.cancelButton);

    this.adjustToContents();
}

// Inherit Dialog prototype
MaxDownloadsDialog.prototype = new Dialog;

// Update to return the selected font, font size, font color, and save cropped view only setting
MaxDownloadsDialog.prototype.__defineGetter__("maxDownloads", function () {
    return this.maxDownloadsSpinBox.value;
});

MaxDownloadsDialog.prototype.__defineGetter__("selectedFont", function () {
    return this.fontComboBox.itemText(this.fontComboBox.currentItem);
});

MaxDownloadsDialog.prototype.__defineGetter__("selectedFontSize", function () {
    return parseInt(this.fontSizeComboBox.itemText(this.fontSizeComboBox.currentItem), 10);
});

MaxDownloadsDialog.prototype.__defineGetter__("selectedFontColor", function () {
    return this.fontColorComboBox.getColorValue();
});

MaxDownloadsDialog.prototype.__defineGetter__("saveCroppedViewOnly", function () {
    return this.saveCroppedViewOnlyCheckbox.checked;
});

function ColorComboBox(parent, initialColor) {
    this.__base__ = ComboBox;
    this.__base__(parent);

    this.addItem("Red");
    this.addItem("Green");
    this.addItem("Blue");
    this.addItem("Yellow");
    this.addItem("White");
    this.addItem("Black");

    this.toolTip = "Select the font color for annotations.";

    // Function to map color value to index
    function getColorIndex(color) {
        switch (color) {
            case 0xffff0000:
                return 0; // Red
            case 0xff00ff00:
                return 1; // Green
            case 0xff0000ff:
                return 2; // Blue
            case 0xffffff00:
                return 3; // Yellow
            case 0xffffffff:
                return 4; // White
            case 0xff000000:
                return 5; // Black
            default:
                return 4; // Default to White if unknown
        }
    }

    // Set default to the initial color
    this.currentItem = getColorIndex(initialColor);
}

ColorComboBox.prototype = new ComboBox;

ColorComboBox.prototype.getColorValue = function () {
    let colorName = this.itemText(this.currentItem);
    switch (colorName) {
        case "Red":
            return 0xffff0000;
        case "Green":
            return 0xff00ff00;
        case "Blue":
            return 0xff0000ff;
        case "Yellow":
            return 0xffffff00;
        case "White":
            return 0xffffffff;
        case "Black":
            return 0xff000000;
        default:
            return 0xffffffff; // Default to white if unknown
    }
};

// Vizier query function adapted from AnnotateImage
function adqlQueryVizier(server, ra, dec, radius, outputmax, catalogs) {
    var catalogQuery = catalogs.map(catalog => "-source=" + catalog).join("&");
    var query = catalogQuery + "&-c=" + ra.toFixed(6) + "+" + dec.toFixed(6) + "&-c.rs=" + (radius * 60).toFixed(3) + "&-out.max=" + outputmax;
    var filename = File.systemTempDirectory + '/vizier.txt';
    if (File.exists(filename)) File.remove(filename);

    var url = server + query;
    console.writeln('Download ' + url);
    var downloader = new FileDownload(url, filename);
    if (downloader.perform()) {
        if (File.exists(filename)) {
            var objects = [];
            var lines = File.readLines(filename);

            if (lines.length < 2)
                throw new Error("Empty catalog file");

            var catalogTitle = '';
            for (var i = 0; i < lines.length; ++i) {
                if (lines[i].startsWith("#Title:")) {
                    catalogTitle = lines[i].substring(8).trim();
                }
                if (lines[i].startsWith("RAJ2000") || lines[i].startsWith("RA_ICRS") || lines[i].startsWith("UCAC4") || lines[i].startsWith("objID")) {
                    parseDataBlock(lines, i, objects, catalogTitle);
                }
            }

            File.remove(filename);

            return objects;
        }
    }
    return null;
}

function parseDataBlock(lines, headerLineIndex, objects, catalogTitle) {
    var raIndex = -1;
    var decIndex = -1;
    var nameIndex = -1;

    // Identify columns
    var header = lines[headerLineIndex].split('\t');
    for (var i = 0; i < header.length; ++i) {
        var token = header[i].toLowerCase();
        if (token == "raj2000" || token == "ra_icrs")
            raIndex = i;
        else if (token == "dej2000" || token == "de_icrs")
            decIndex = i;
        else if (token == "source" || token == "2mass" || token == "ucac4" || token == "objid")
            nameIndex = i;
    }

    if (raIndex < 0 || decIndex < 0 || nameIndex < 0)
        throw new Error("Missing required columns in VizieR catalog file");

    // Parse data lines
    for (var j = headerLineIndex + 3; j < lines.length; ++j) {  // Skipping the units and dashed lines
        if (lines[j].startsWith("#")) continue;
        if (lines[j].trim() === "") break; // Stop at empty line

        var tokens = lines[j].split('\t');

        var obj = {
            name: tokens[nameIndex].trim(),
            ra: parseFloat(tokens[raIndex]),
            dec: parseFloat(tokens[decIndex]),
            type: catalogTitle, // Use catalog title as the type
            diameter: 0.0 // Placeholder, since the diameter is not provided in this dataset
        };

        if (!isNaN(obj.ra) && !isNaN(obj.dec))
            objects.push(obj);
    }
}


//Function to convert image coordinates to celestial coordinates
function getCelestial(x, y) {
    return scriptParameters.imageActiveWindow.imageToCelestial(x, y);
}

// Function to convert celestial coordinates to image coordinates
function getCoordinates(ra, dec) {
    return scriptParameters.imageActiveWindow.celestialToImage(ra, dec);
}


function degreesToHMS(degrees) {
    var hDecimal = (degrees * 24) / 360;  // decimal hours
    var h = Math.trunc(hDecimal);  // int hours
    var mDecimal = (hDecimal - h) * 60;  // decimal minutes
    var m = Math.trunc(mDecimal);  // int minutes
    var s = (mDecimal - m) * 60;  // decimal seconds
    return new Array(h, m, s);
}

function degreesToDMS(degrees) {
    return Math.decimalToSexagesimal(degrees);
}

function zeroPadding(number) {
    return number < 10 ? "0" + number.toString() : number.toString();
}

function angularSeparation(ra1, dec1, ra2, dec2) {
    var a1 = ra1 * Math.PI / 180;
    var a2 = ra2 * Math.PI / 180;
    var d1 = dec1 * Math.PI / 180;
    var d2 = dec2 * Math.PI / 180;
    var z = Math.acos(Math.sin(d1) * Math.sin(d2) + Math.cos(d1) * Math.cos(d2) * Math.cos(a1 - a2));
    return Math.abs(z) * 180 / Math.PI;
}

function getTypeLongName(typeCode) {
    typeCode = typeCode.replace(/"/g, "").trim().toUpperCase(); // Normalize the type code and remove any extra quotes
        for (let i = 0; i < typeLookupTable.length; i++) {
        let lookupCode = typeLookupTable[i].cond.trim().toUpperCase();
        if (lookupCode === typeCode) {
                   return typeLookupTable[i].extd;
        }
    }
        return typeCode; // Return the code if no match found
}



// Corrected adqlQuerySimbad function
function adqlQuerySimbad(server, ra, dec, radius, outputmax) {
    var query = "simbad/sim-tap/sync?";
    query += "request=doQuery&lang=adql&format=text&query=SELECT TOP " +
             outputmax.toString() + " MAIN_ID,RA,DEC,galdim_majaxis,otype FROM BASIC";
    query += " WHERE CONTAINS(POINT('ICRS',ra, dec),";
    query += " CIRCLE('ICRS'," + ra.toFixed(8) + "," + dec.toFixed(8) + "," + radius.toFixed(3) + ")) = 1";
    query += " AND ra IS NOT NULL AND dec IS NOT NULL";

    var filename = File.systemTempDirectory + '/adql.txt';
    if (File.exists(filename)) File.remove(filename);

    var url = server + query;
    console.writeln('Download ' + url);
    var downloader = new FileDownload(url, filename);
    if (downloader.perform()) {
        if (File.exists(filename)) {
            var objects = [];
            var datapart = false;
            var lines = File.readLines(filename);
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                var items = line.split('|');
                if (items.length != 5) continue;
                if (!datapart) {
                    datapart = line.startsWith('--------');
                    continue;
                }
                var name = items[0].trim().unquote();
                var raValue = parseFloat(items[1].trim());
                var decValue = parseFloat(items[2].trim());
                var diameter = parseFloat(items[3].trim() || 0);
                var type = items[4].trim();

                // Log the parsed values for debugging
                console.writeln('Parsed object:', 'Name:', name, 'RA:', raValue, 'DEC:', decValue, 'Diameter:', diameter, 'Type:', type);

                // Only add objects with valid RA and DEC
                if (!isNaN(raValue) && !isNaN(decValue)) {
                    objects.push({ ra: raValue, dec: decValue, name: name, diameter: diameter, type: type, isSimbad: true });
                } else {
                    console.warningln('Invalid RA or DEC for object:', name);
                }
            }
            File.remove(filename);
            console.writeln('Download completed: ' + objects.length + ' objects found');
            return objects;
        }
    }
    return null;
}




function applyPixelMathStretch(view) {
    var P = new PixelMath;
    P.expression =
    "C = -2.8  ;  //Shadow Clipping (Defualt value -2.8)\n" +
    "B = 0.20  ;  //Background value (Higher the value, more stretched)\n" +
    "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
    "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "C,B,c";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(view, false);
}



function resetStretch(view) {
    if (scriptParameters.originalImageState) {
        view.beginProcess(UndoFlag_NoSwapFile);
        view.image.assign(scriptParameters.originalImageState);
        view.endProcess();
    }
}




function main() {
       console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
console.noteln("Opening Dialog...");
console.flush();
    scriptParameters.imageActiveWindow = ImageWindow.activeWindow;
    if (scriptParameters.imageActiveWindow.isNull) {
        var msg = new MessageBox("<p>No active image.</p>", TITLE, StdIcon_Warning, StdButton_Ok);
        msg.execute();
    } else if (scriptParameters.imageActiveWindow.currentView.isPreview) {
        var msg = new MessageBox("<p>This script cannot work on previews</p>", TITLE, StdIcon_Warning, StdButton_Ok);
        msg.execute();
    } else {
        if (scriptParameters.imageActiveWindow.astrometricSolutionSummary() != "") {
            scriptParameters.imageMainView = scriptParameters.imageActiveWindow.mainView;
            scriptParameters.imageImage = scriptParameters.imageActiveWindow.mainView.image;
            scriptParameters.imageView = new View(scriptParameters.imageMainView);
            scriptParameters.imageID = scriptParameters.imageView.id;
            scriptParameters.workingPreview = new ImageWindow(
                1, 1, 1, scriptParameters.imageMainView.image.bitsPerSample,
                scriptParameters.imageMainView.image.sampleType == SampleType_Real,
                false, "WIMIPreviewImage"
            );
            with(scriptParameters.workingPreview.mainView) {
                beginProcess(UndoFlag_NoSwapFile);
                image.assign(scriptParameters.imageMainView.image);
                endProcess();
            }
            scriptParameters.imageMainView = scriptParameters.workingPreview.mainView;
            scriptParameters.imageImage = scriptParameters.workingPreview.mainView.image;

            let dialog = new mainDialog();
            dialog.ScrollControl.displayImage = scriptParameters.imageImage; // Ensure displayImage is set to main image
            if (dialog.execute()) {
                console.writeln("Execute -- OK");
            } else {
                console.writeln("Execute -- CANCEL");
                scriptParameters.workingPreview.forceClose();
            }
        } else {
            var msg = new MessageBox("<p>The image has no astrometric solution.</p>", TITLE, StdIcon_Warning, StdButton_Ok);
            msg.execute();
        }
    }
}

main();




