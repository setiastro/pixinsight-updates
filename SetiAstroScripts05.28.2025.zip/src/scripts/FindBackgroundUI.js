/*
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * FindBackground
 * File: FindBackgroundUI_1.2.2.js
 * Description: A script to find regions covering true background in astronomical images. This file handles the UI and interaction with the core functionality.
 *
 * Copyright (c) 2024, Gerrit Erdt
 * Copyright (c) 2024, Franklin Marek
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * In case you are interested in collaborating or have questions regarding the code, its use in other products or anything else, feel free to contact us at:
 *  - Gerrit Erdt: gerrit_erdt@hotmail.com
 *  - Franklin Marek: frank@setiastro.com
 */

#feature-id   FindBackground : SetiAstro > Find Background
#feature-icon  findbackground.svg
#feature-info This script utilizes gradient descent and various filters to quickly determine algorithmically an optimal background region of interest.

#define USE_FIND_BACKGROUND_JS_LIBRARY
#define FORCE_AVERAGE_FILTER

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#include "FindBackground_1.1.js"
#include "FindBackground_UserDefined.js"

#define TITLE "Find Background"
#define VERSION "1.2.2"
//#define targetMedian "0.25"

let parameters =
{
    targetWindow: null,
    filterAvg: true,
    filterSdev: true,
    filterPoisonIndex: false,
    filterMAAD: false,
    filterObjects: false,
    printInformation: true,
    generatePreview: true,
    previewName: "Background",
    slowSearch: false,
    fastSearch: true,
    size: 50,
    spacingRate: 2,
    searchGridSize: 100,
    startingPoints: 40,

    save: function()
    {
        Parameters.set("filterAvg", this.filterAvg);
        Parameters.set("filterSdev", this.filterSdev);
        Parameters.set("filterPoisonIndex", this.filterPoisonIndex);
        Parameters.set("filterMAAD", this.filterMAAD);
        Parameters.set("filterObjects", this.filterObjects);
        Parameters.set("printInformation", this.printInformation);
        Parameters.set("generatePreview", this.generatePreview);
        Parameters.set("previewName", this.previewName);
        Parameters.set("slowSearch", this.slowSearch);
        Parameters.set("fastSearch", this.fastSearch);
        Parameters.set("size", this.size);
        Parameters.set("spacingRate", this.spacingRate);
        Parameters.set("searchGridSize", this.searchGridSize);
        Parameters.set("startingPoints", this.startingPoints);
    },

    load: function()
    {
        if (Parameters.has("filterAvg"))
            this.filterAvg = Parameters.getBoolean("filterAvg");
        if (Parameters.has("filterSdev"))
            this.filterSdev = Parameters.getBoolean("filterSdev");
        if (Parameters.has("filterPoisonIndex"))
            this.filterPoisonIndex = Parameters.getBoolean("filterPoisonIndex");
        if (Parameters.has("filterMAAD"))
            this.filterMAAD = Parameters.getBoolean("filterMAAD");
        if (Parameters.has("filterObjects"))
            this.filterObjects = Parameters.getBoolean("filterObjects");
        if (Parameters.has("printInformation"))
            this.printInformation = Parameters.getBoolean("printInformation");
        if (Parameters.has("generatePreview"))
            this.generatePreview = Parameters.getBoolean("generatePreview");
        if (Parameters.has("previewName"))
            this.previewName = Parameters.getString("previewName");
        if (Parameters.has("slowSearch"))
            this.slowSearch = Parameters.getBoolean("slowSearch");
        if (Parameters.has("fastSearch"))
            this.fastSearch = Parameters.getBoolean("fastSearch");
        if (Parameters.has("size"))
            this.size = Parameters.getInteger("size");
        if (Parameters.has("spacingRate"))
            this.spacingRate = Parameters.getInteger("spacingRate");
        if (Parameters.has("searchGridSize"))
            this.searchGridSize = Parameters.getInteger("searchGridSize");
        if (Parameters.has("startingPoints"))
            this.startingPoints = Parameters.getInteger("startingPoints");
    }
};

let userDefinedRegion = null; // To store the user-defined region
let isDragging = false;
let startX, startY;

let constants =
{
    indent: 20,
    minLabelSize: 170
}

function mergeOverlappingRegions(regions) {
    let mergedRegions = [];
    for (let i = 0; i < regions.length; i++) {
        let region = regions[i];
        let isMerged = false;
        for (let j = 0; j < mergedRegions.length; j++) {
            if (isOverlapping(region, mergedRegions[j])) {
                mergedRegions[j] = mergeRegions(region, mergedRegions[j]);
                isMerged = true;
                break;
            }
        }
        if (!isMerged) {
            mergedRegions.push(region);
        }
    }
    return mergedRegions;
}

function isOverlapping(rect1, rect2) {
    return !(rect1.right < rect2.left || rect1.left > rect2.right || rect1.bottom < rect2.top || rect1.top > rect2.bottom);
}

function mergeRegions(rect1, rect2) {
    return new Rect(
        Math.min(rect1.left, rect2.left),
        Math.min(rect1.top, rect2.top),
        Math.max(rect1.right, rect2.right),
        Math.max(rect1.bottom, rect2.bottom)
    );
}


function normalizeRect(rect) {
    let left = Math.min(rect.left, rect.right);
    let top = Math.min(rect.top, rect.bottom);
    let right = Math.max(rect.left, rect.right);
    let bottom = Math.max(rect.top, rect.bottom);
    return new Rect(left, top, right, bottom);
}

function clampRectToBounds(rect, imageWidth, imageHeight) {
    let left = Math.max(0, Math.min(rect.left, imageWidth));
    let top = Math.max(0, Math.min(rect.top, imageHeight));
    let right = Math.max(0, Math.min(rect.right, imageWidth));
    let bottom = Math.max(0, Math.min(rect.bottom, imageHeight));
    return new Rect(left, top, right, bottom);
}

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.isDragging = false; // Flag for detecting dragging
    this.userDefinedRegions = [];
    this.exclusionAreas = []; // Initialize exclusion areas
    this.currentRegion = null;
    this.startX = 0;
    this.startY = 0;
    this.scrollPosition = new Point(0, 0); // Ensure scrollPosition is always defined

    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.viewport.onResize = function() {
        if (this.parent) {
            this.parent.initScrollBars();
        }
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.onVerticalScrollPosUpdated = function(y) {
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        var parent = this.parent; // Store reference to parent
        if (modifiers === 1) { // Shift key detection
            parent.startX = x + parent.scrollPosition.x;
            parent.startY = y + parent.scrollPosition.y;
            parent.isDragging = true;
            parent.dragging = false; // Prevent scrolling while drawing
        } else {
            this.cursor = new Cursor(StdCursor_ClosedHand);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            parent.dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        var parent = this.parent; // Store reference to parent
        if (!parent) return;
        if (parent.isDragging) {
            // Update current region while dragging
            parent.currentRegion = clampRectToBounds(
                normalizeRect(new Rect(parent.startX, parent.startY, x + parent.scrollPosition.x, y + parent.scrollPosition.y)),
                parent.displayImage.width,
                parent.displayImage.height
            );
            if (parent.viewport) {
                parent.viewport.update(); // Use parent reference and check if valid
            }
        } else if (parent.dragging) {
            parent.scrollPosition = new Point(parent.scrollPosition).translatedBy(parent.dragOrigin.x - x, parent.dragOrigin.y - y);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            parent.viewport.update(); // Ensure the viewport updates during dragging
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        var parent = this.parent; // Store reference to parent
        if (!parent) return;
        if (parent.isDragging) {
            parent.isDragging = false;
            // Finalize the current region
            let finalRegion = clampRectToBounds(
                normalizeRect(new Rect(parent.startX, parent.startY, x + parent.scrollPosition.x, y + parent.scrollPosition.y)),
                parent.displayImage.width,
                parent.displayImage.height
            );
            parent.userDefinedRegions.push(finalRegion);
            parent.currentRegion = null;
            if (parent.viewport) {
                parent.viewport.update(); // Use parent reference and check if valid
            }
            // Invoke the completion handler
            parent.onRectangleSelectionComplete();
        } else {
            this.cursor = new Cursor(StdCursor_Cross);
            parent.dragging = false;
        }
    };

    // Function to handle the completion of the rectangle selection and scale coordinates
    this.onRectangleSelectionComplete = function() {
        if (this.userDefinedRegions.length > 0) {
            let downsamplingFactor = this.parent.downsamplingFactor; // Access the parent's downsamplingFactor
            this.userDefinedRegions.forEach(function(region, index) {
                let scaledRegion = new Rect(
                    region.left * downsamplingFactor,
                    region.top * downsamplingFactor,
                    region.right * downsamplingFactor,
                    region.bottom * downsamplingFactor
                );

                console.writeln("Region " + (index + 1) + " (scaled):");
                console.writeln("Top-left: (" + scaledRegion.left + ", " + scaledRegion.top + ")");
                console.writeln("Bottom-right: (" + scaledRegion.right + ", " + scaledRegion.bottom + ")");
            });
        }
    };

this.viewport.onPaint = function(x0, y0, x1, y1) {
    var g = new Graphics(this);
    var result = this.parent.getImage();
    if (result == null) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
    } else {
        result.selectedRect = new Rect(x0, y0, x1, y1).translated(this.parent.scrollPosition);
        g.drawBitmap(x0, y0, result.render());
        result.resetRectSelection();

        // Draw the user-defined regions if they exist
        this.parent.userDefinedRegions.forEach(function(region) {
            let color = 0xff00ff00; // Default to Green
            if (this.dialog.userDefinedExclusionChk.checked) {
                color = 0xffff0000; // Red if exclusion
            }
            g.pen = new Pen(color);
            g.drawRect(region.translatedBy(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y));
        }.bind(this));

        // Draw the current region if it exists
        if (this.parent.currentRegion) {
            let color = 0xff00ff00; // Default to Green
            if (this.dialog.userDefinedExclusionChk.checked) {
                color = 0xffff0000; // Red if exclusion
            }
            g.pen = new Pen(color);
            g.drawRect(this.parent.currentRegion.translatedBy(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y));
        }

        // Draw the exclusion areas if they exist
        this.parent.exclusionAreas.forEach(function(area) {
            g.pen = new Pen(0xff0000ff); // Blue color for the exclusion areas
            g.drawRect(area.translatedBy(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y));
        }.bind(this));
    }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function FindBackgroundDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>FindBackground " + VERSION + "</b> - A script to find a region covering only true background in astronomical images.<br>" +
        "Copyright (C) 2024, Gerrit Erdt<br>" +
        "Copyright (C) 2024, Franklin Marek<br>";

    this.conditions_Lbl = new Label(this);
    this.conditions_Lbl.frameStyle = FrameStyle_Box;
    this.conditions_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.conditions_Lbl.useRichText = true;
    this.conditions_Lbl.text = "<b>Preconditions:</b>" +
        "<ul>" +
        "<li>The image has been corrected for background gradients.</li>" +
        "<li>Stacking artifacts at the edges have been removed/cropped.</li>" +
        "</ul>" +
        "<b>Results:</b>" +
        "<ul>" +
        "<li>A preview named 'Background' that covers the found background region.</li>" +
        "<li>Optionally: a console output of the background parameters and quality estimators.</li>" +
        "</ul>" +
        "For a complete documentation of all functionalities, see the tooltips of the respective elements.";

    this.instructions_Lbl = new Label(this);
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.instructions_Lbl.useRichText = true;
    this.instructions_Lbl.text = "<b>Instructions:</b> Shift + Click and drag to define a User Defined Areas (Multiple Areas allowed)<br>" +
      "Reset Button to Clear Selected Regions";

    // Full Image Checkbox
    this.fullImageChk = new CheckBox(this);
    this.fullImageChk.text = "Full Image";
    this.fullImageChk.checked = true;
    this.fullImageChk.toolTip = "Select this option to search the entire image for the background region.";
    this.fullImageChk.onCheck = function (checked) {
        if (checked) {
            this.dialog.userDefinedChk.checked = false;
            this.dialog.userDefinedExclusionChk.checked = false;
            this.dialog.previewControl.visible = false;
            this.dialog.zoomSizer.visible = false;
            this.dialog.adjustToContents();
        }
    };

// User Defined Search Area Checkbox
this.userDefinedChk = new CheckBox(this);
this.userDefinedChk.text = "User Defined Search Area";
this.userDefinedChk.checked = false;
this.userDefinedChk.toolTip = "Select this option to search a user-defined area for the background region.";
this.userDefinedChk.onCheck = function (checked) {
    if (checked) {
        this.dialog.fullImageChk.checked = false;
        this.dialog.userDefinedExclusionChk.checked = false;
        this.dialog.previewControl.userDefinedRegions = []; // Clear stored rectangles
        this.dialog.previewControl.exclusionAreas = []; // Clear exclusion areas if any
        this.dialog.previewControl.viewport.update();
        this.dialog.previewControl.visible = true;
        this.dialog.zoomSizer.visible = true;
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.dialog.createAndDisplayTemporaryImage(selectedImage);
                this.dialog.previewControl.displayImage = tmpImage;
                this.dialog.previewControl.viewport.update();
            }
        }
        this.dialog.adjustToContents();
    }
};

// User Defined Exclusion Area Checkbox
this.userDefinedExclusionChk = new CheckBox(this);
this.userDefinedExclusionChk.text = "User Defined Exclusion Area";
this.userDefinedExclusionChk.checked = false;
this.userDefinedExclusionChk.toolTip = "Select this option to exclude a user-defined area from the background region search.";
this.userDefinedExclusionChk.onCheck = function (checked) {
    if (checked) {
        this.dialog.fullImageChk.checked = false;
        this.dialog.userDefinedChk.checked = false;
        this.dialog.previewControl.userDefinedRegions = []; // Clear stored rectangles
        this.dialog.previewControl.exclusionAreas = []; // Clear exclusion areas if any
        this.dialog.previewControl.viewport.update();
        this.dialog.previewControl.visible = true;
        this.dialog.zoomSizer.visible = true;
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.dialog.createAndDisplayTemporaryImage(selectedImage);
                this.dialog.previewControl.displayImage = tmpImage;
                this.dialog.previewControl.viewport.update();
            }
        }
        this.dialog.adjustToContents();
    }
};

      // Reset Button
      this.resetButton = new ToolButton(this);
      this.resetButton.icon = this.scaledResource(":/icons/reload.png");
      this.resetButton.toolTip = "User Area Reset";
      this.resetButton.onMousePress = function () {
          this.dialog.previewControl.userDefinedRegions = [];  // Clear all regions
          this.dialog.previewControl.viewport.update();
      };

    // Add the checkboxes and reset button to the sizer
    this.searchAreaSizer = new HorizontalSizer;
    this.searchAreaSizer.spacing = 6;
    this.searchAreaSizer.add(this.fullImageChk);
    this.searchAreaSizer.add(this.userDefinedChk);
    this.searchAreaSizer.add(this.userDefinedExclusionChk);
    this.searchAreaSizer.add(this.resetButton);

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use for the background search.<br><br>" +
        "<b>Usage:</b> <br>The image you selected will be used for the background search.<br><br>" +
        "<b>Usage constraints:</b> <br>Selecting a preview is not possible.<br><br>" +
        "<b>Default value:</b> <br>The currently active window.<br>This is the window that is currently selected in the PixInsight workspace.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;

            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

    // Event handler for dropdown item selection
    this.windowSelector_Cb.onItemSelected = (index) => {
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
        if (window && !window.isNull) {
            parameters.targetWindow = window;
            var selectedImage = window.mainView.image;
            if (selectedImage) {
                console.writeln("Selected image with ID: " + window.mainView.id);
                this.createAndDisplayTemporaryImage(selectedImage); // Create and display the temporary image
            } else {
                console.error("Selected image is undefined.");
            }
        }
    };

    this.filterInformation_Lbl = new Label(this);
    this.filterInformation_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.filterInformation_Lbl.useRichText = true;
    this.filterInformation_Lbl.text = "Filters: ";
    this.filterInformation_Lbl.toolTip = "The background in the image is estimated by a combination of different filters.<br><br>" +
        "<b>Usage:</b> <br>Select the filters you want to apply for the background estimation. An average brightness filter is always applied.<br><br>" +
        "<b>Usage constraints:</b><br>Be careful with the use of the absolute median average deviation filter, as it can be very slow and may not work well.<br><br>" +
        "<b>Default value:</b> <br>Standard deviation is selected by default.<br>This finds a background region that is both dark and 'empty'.";
#ifndef FORCE_AVERAGE_FILTER
    this.filterAvg_Chk = new CheckBox(this);
    this.filterAvg_Chk.text = "Average brightness";
    this.filterAvg_Chk.checked = parameters.filterAvg;
    this.filterAvg_Chk.toolTip = "Filter background regions based on their average brightness.<br><br>" +
        "<b>Usage:</b> <br>Enabling this filter will find darker regions, while disabling it will find brighter regions.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Enabled.<br>Per definition, the background is darker than all the objects in the image.";
    this.filterAvg_Chk.onCheck = function (checked) {
        parameters.filterAvg = checked;
    };
#endif

    this.filterSdev_Chk = new CheckBox(this);
    this.filterSdev_Chk.text = "Standard deviation";
    this.filterSdev_Chk.checked = parameters.filterSdev;
    this.filterSdev_Chk.toolTip = "Filter background regions based on their standard deviation.<br><br>" +
        "<b>Usage:</b> <br>Enabling this filter will find regions with low variation in brightness, while disabling it will find regions with high variation.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Enabled.<br>Per definition, the background is empty which means it has low variation in brightness.";
    this.filterSdev_Chk.onCheck = function (checked) {
        parameters.filterSdev = checked;
    };

    this.filterPoisonIndex_Chk = new CheckBox(this);
    this.filterPoisonIndex_Chk.text = "Poisson distribution fit";
    this.filterPoisonIndex_Chk.checked = parameters.filterPoisonIndex;
    this.filterPoisonIndex_Chk.toolTip = "Filter background regions based on how good they fit a poisson distribution.<br><br>" +
        "<b>Usage:</b> <br>Enabling this filter will find regions that follow a poisson distribution, while disabling it will ignore the intensity distribution.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Disabled.<br>Normally, the default filters will already find a good solution. Enable this filter in case you have doubts that the found region is actually representative.";
    this.filterPoisonIndex_Chk.onCheck = function (checked) {
        parameters.filterPoisonIndex = checked;
    }

    this.filterMAAD_Chk = new CheckBox(this);
    this.filterMAAD_Chk.text = "Absolute median average deviation";
    this.filterMAAD_Chk.checked = parameters.filterMAAD;
    this.filterMAAD_Chk.toolTip = "Filter background regions based on their absolute median average deviation (do not confuse this with MAD!).<br><br>" +
        "<b>Usage:</b> <br>Enabling this filter will find regions with a low skewness, meaning that the intensity distribution is symmetrical.<br><br>" +
        "<b>Usage constraints:</b> <br>Be careful with enabling this filter.<br>True background will not necessarily follow a normal distribution, however any smooth brightness transition will.<br>" +
        "Also, this will dramatically increase computation time.<br>Only use this filter if you know what you are doing and you really want a symmetrical distribution!<br><br>" +
        "<b>Default value:</b> <br>Disabled.<br>This filter can be very slow and may not work well.";
    this.filterMAAD_Chk.onCheck = function (checked) {
        parameters.filterMAAD = checked;
    };

    this.filterObjects_Chk = new CheckBox(this);
    this.filterObjects_Chk.text = "Filters out objects";
    this.filterObjects_Chk.checked = parameters.filterObjects;
    this.filterObjects_Chk.toolTip = "Filter out regions that contain objects.<br><br>" +
        "<b>Usage:</b> <br>Enabling this filter will find regions that are not covered by objects, while disabling it can find regions that are covered by objects.<br><br>" +
        "<b>Usage constraints:</b> <br>Everything, that is brighter than the darkest detectable star, " +
        "is considered an object.<br>Normally, this filter is not needed, but can be helpful for 'crowded' images.<br><br>" +
        "<b>Default value:</b> <br>Disabled.<br>Normally, this filter is disabled since the regular combination is good at excluding bright objects. <br>You should try this filter in case the search converges on a field with objects in it.";
    this.filterObjects_Chk.onCheck = function (checked) {
        parameters.filterObjects = checked;
    };

    this.filterSizerVertical = new VerticalSizer;
    this.filterSizerVertical.spacing = 6;
#ifndef FORCE_AVERAGE_FILTER
    this.filterSizerVertical.add(this.filterAvg_Chk);
#endif
    this.filterSizerVertical.add(this.filterSdev_Chk);
    this.filterSizerVertical.add(this.filterPoisonIndex_Chk);
    this.filterSizerVertical.add(this.filterMAAD_Chk);
    this.filterSizerVertical.add(this.filterObjects_Chk);

    this.filterSizerHorizontal = new HorizontalSizer;
    this.filterSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.filterSizerHorizontal.add(this.filterSizerVertical);

    this.searchRoutine_Lbl = new Label(this);
    this.searchRoutine_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.searchRoutine_Lbl.useRichText = true;
    this.searchRoutine_Lbl.text = "Search routine: ";
    this.searchRoutine_Lbl.toolTip = "Select the search routine you want to use.<br><br>" +
        "<b>Usage:</b> <br>The slow search is guaranteed to find the best background region in the image, based on the selected filters, but takes a lot of computation time.<br>" +
        "The fast search is MUCH faster, but may only find a less than optimal solution. This is ideally suited for comparatively 'empty' images.<br><br>" +
        "<b>Usage constraints:</b><br>None<br><br>" +
        "<b>Default value:</b> <br>Fast search.<br>Normally, the fast search is sufficient to find a good background region.";

    this.slowSearch_Rdb = new RadioButton(this);
    this.slowSearch_Rdb.text = "Slow search";
    this.slowSearch_Rdb.checked = parameters.slowSearch;
    this.slowSearch_Rdb.toolTip = "The slow search routine is guaranteed to find the best possible background region in the image.<br><br>" +
        "<b>Usage:</b> <br>The slow search is guaranteed to find the best background region in the image, based on the selected filters, but takes a lot of computation time.<br><br>" +
        "Use the slow search in case you want to find the absolute best background region and don't care about the increased computation time.<br>This is often necessary for 'crowded' images.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Disabled.<br>Normally, the fast search is sufficient to find a good background region."
    this.slowSearch_Rdb.onCheck = (checked) => {
        parameters.slowSearch = checked;
        parameters.fastSearch = !checked;
        this.backgroundParameterSearchGridSize_NC.enabled = false;
        this.backgroundParameterStartingPoints_NC.enabled = false;
    };

    this.fastSearch_Rdb = new RadioButton(this);
    this.fastSearch_Rdb.text = "Fast search";
    this.fastSearch_Rdb.checked = parameters.fastSearch;
    this.fastSearch_Rdb.toolTip = "The fast search routine will find a region that is a good background representation, but maybe not the best possible.<br><br>" +
        "<b>Usage:</b> <br>The fast search is much faster than the slow search, but may only find a less than optimal solution.<br>" +
        "Use the fast search in case you want to find a good approximation of the background in the image and you want to save computation time.<br><br>" +
        "<b>Usage constraints:</b> <br>None<br><br>" +
        "<b>Default value:</b> <br>Enabled.<br>Normally, the fast search is sufficient to find a good background region."

    this.fastSearch_Rdb.onCheck = (checked) => {
        parameters.fastSearch = checked;
        parameters.slowSearch = !checked;
        this.backgroundParameterSearchGridSize_NC.enabled = true;
        this.backgroundParameterStartingPoints_NC.enabled = true;
    };

    this.searchOptionsSizerVertical = new VerticalSizer;
    this.searchOptionsSizerVertical.spacing = 6;
    this.searchOptionsSizerVertical.add(this.slowSearch_Rdb);
    this.searchOptionsSizerVertical.add(this.fastSearch_Rdb);

    this.searchOptionsSizerHorizontal = new HorizontalSizer;
    this.searchOptionsSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.searchOptionsSizerHorizontal.add(this.searchOptionsSizerVertical);

    this.backgroundRegionParameters_Lbl = new Label(this);
    this.backgroundRegionParameters_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundRegionParameters_Lbl.useRichText = true;
    this.backgroundRegionParameters_Lbl.text = "Search parameters: ";
    this.backgroundRegionParameters_Lbl.toolTip = "Set the available search parameters for the selected search routine.<br><br>" +
        "<b>Usage:</b> <br>Based on the selected search routine, different parameters are available. Tune them based on your needs and image<br><br>" +
        "<b>Usage constraints:</b> <br>'Search grid width' and 'Number of starting points' are only available with the fast search.<br><br>" +
        "<b>Default value:</b> <br>Size: 50, Spacing rate: 2, Search grid width: 100, Number of starting points: 40.<br>These values are a good starting point for most images.";

    this.backgroundParameterSize_NC = new NumericControl(this);
    this.backgroundParameterSize_NC.real = true;
    this.backgroundParameterSize_NC.label.text = "Size: ";
    this.backgroundParameterSize_NC.toolTip = "The size in pixels of the quadratic background region that is searched for. The size is the side length of the quadratic region.<br><br>" +
        "<b>Usage:</b> <br>Increase the size to find a larger region, which may be harder to fit between objects.<br>Decrease the size to find a smaller region, which may be easier to fit between objects.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>50.<br>This allows for a good statistical analysis of the background region, while still being small enough to fit between objects, even on wider images.";
    this.backgroundParameterSize_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSize_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSize_NC.setRange(2, 500);
    this.backgroundParameterSize_NC.setPrecision(0);
    this.backgroundParameterSize_NC.setValue(parameters.size);
    this.backgroundParameterSize_NC.slider.minWidth = 200;
    this.backgroundParameterSize_NC.edit.minWidth = 50;
    this.backgroundParameterSize_NC.onValueUpdated = function (value) {
        parameters.size = Math.round(value);
    };

    this.backgroundParameterSpacingRate_NC = new NumericControl(this);
    this.backgroundParameterSpacingRate_NC.real = true;
    this.backgroundParameterSpacingRate_NC.label.text = "Spacing rate: ";
    this.backgroundParameterSpacingRate_NC.toolTip = "The spacing rate that is used during the search.<br>" +
        "Both search routines work by measuring the filters inside different background regions. During the search, the background region is shifted through the image. " +
        "This parameter defines the fraction of the region size by which it is shifted in each iteration. <br><br>" +
        "<b>Usage:</b> <br>Increase this parameter to find a less perfect background region with less computation time. <br>" +
        "Decrease this parameter to find a better background region at the cost of higher computation time.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>2.<br>This is normally sufficient to find a good enough background region while still being fast enough for images with 'normal' resolution.<br>" +
        "Only change this value, if the script has trouble finding a good background region.";
    this.backgroundParameterSpacingRate_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSpacingRate_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSpacingRate_NC.setRange(1, 10);
    this.backgroundParameterSpacingRate_NC.setPrecision(0);
    this.backgroundParameterSpacingRate_NC.setValue(parameters.spacingRate);
    this.backgroundParameterSpacingRate_NC.slider.minWidth = 200;
    this.backgroundParameterSpacingRate_NC.edit.minWidth = 50;
    this.backgroundParameterSpacingRate_NC.onValueUpdated = function (value) {
        parameters.spacingRate = Math.round(value);
    };

    this.backgroundParameterSearchGridSize_NC = new NumericControl(this);
    this.backgroundParameterSearchGridSize_NC.real = true;
    this.backgroundParameterSearchGridSize_NC.label.text = "Search grid width: ";
    this.backgroundParameterSearchGridSize_NC.toolTip = "The width of the search grid that is used during the fast search.<br>" +
        "The fast search needs multiple starting points in the image.<br>For this purpose, the image is divided in width x width sized regions. " +
        "The n best regions are selected as starting points.<br>This parameter defines the length of the quadratic grid tiles.<br><br>" +
        "<b>Usage:</b> <br>Decrease this parameter to find a better background region at the cost of higher computation time.<br>Increase this parameter to find a less optimal background region with less computation time.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>100.<br>This is normally sufficient to find starting points that are located in comparatively 'empty' regions of the image while still being fast enough for images with 'normal' resolution.";
    this.backgroundParameterSearchGridSize_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSearchGridSize_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSearchGridSize_NC.setRange(10, 500);
    this.backgroundParameterSearchGridSize_NC.setPrecision(0);
    this.backgroundParameterSearchGridSize_NC.setValue(parameters.searchGridSize);
    this.backgroundParameterSearchGridSize_NC.slider.minWidth = 200;
    this.backgroundParameterSearchGridSize_NC.edit.minWidth = 50;
    this.backgroundParameterSearchGridSize_NC.onValueUpdated = function (value) {
        parameters.searchGridSize = Math.round(value);
    };

    this.backgroundParameterStartingPoints_NC = new NumericControl(this);
    this.backgroundParameterStartingPoints_NC.real = true;
    this.backgroundParameterStartingPoints_NC.label.text = "Number of starting points: ";
    this.backgroundParameterStartingPoints_NC.toolTip = "The number of starting points that are used during the fast search.<br>" +
        "The fast search needs multiple starting points in the image.<br>For this purpose, the image is divided in width x width sized regions." +
        " The n best regions are selected as starting points.<br>This parameter defines the number of starting points that will be used.<br><br>" +
        "<b>Usage:</b> <br>Increase this parameter to try more starting points to find a better background region, at the cost of higher computation time.<br>" +
        "Decrease this parameter to try less starting points to find a less optimal background region which less computation time.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>40.<br>This is normally sufficient to find a good enough background region while keeping the computation time low.<br>Increase this value, if the script has trouble finding a good background region.";
    this.backgroundParameterStartingPoints_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterStartingPoints_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterStartingPoints_NC.setRange(1, 1000);
    this.backgroundParameterStartingPoints_NC.setPrecision(0);
    this.backgroundParameterStartingPoints_NC.setValue(parameters.startingPoints);
    this.backgroundParameterStartingPoints_NC.slider.minWidth = 200;
    this.backgroundParameterStartingPoints_NC.edit.minWidth = 50;
    this.backgroundParameterStartingPoints_NC.onValueUpdated = function (value) {
        parameters.startingPoints = Math.round(value);
    };

    this.printInformation_Chk = new CheckBox(this);
    this.printInformation_Chk.text = "Print information to the console";
    this.printInformation_Chk.checked = parameters.printInformation;
    this.printInformation_Chk.toolTip = "Print information about the background region to the console.<br><br>" +
        "<b>Usage:</b> <br>Enabling this option will print the channel brightnesses, additive color correction constants, coordinates and quality assessment parameters of the found background region to the console.<br>" +
        "Disabling will just print the current progress to the console, without information about the found region. <br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Enabled.<br>It is advisable to manually verify the quality of the found background region, the console output can help with that.";
    this.printInformation_Chk.onCheck = function (checked) {
        parameters.printInformation = checked;
    }

    this.generatePreview_Chk = new CheckBox(this);
    this.generatePreview_Chk.text = "Generate background preview";
    this.generatePreview_Chk.checked = parameters.generatePreview;
    this.generatePreview_Chk.toolTip = "Generate a preview of the found background region.<br><br>" +
        "<b>Usage:</b> <br>Enabling this option will create a preview of the found background region.<br>" +
        "Disabling this option will not create a preview of the found background region.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Enabled.<br>It is advisable to visually verify the quality of the found background region. Additionally, the preview can be used for further processing.";
    this.generatePreview_Chk.onCheck = (checked) => {
        parameters.generatePreview = checked;
        parameters.previewName = checked ? parameters.previewName : "";
        this.previewName.enabled = checked;
    };

    this.previewName = new Edit(this);
    this.previewName.text = parameters.previewName;
    this.previewName.checked = parameters.generatePreview;
    this.previewName.toolTip = "The name of the preview that is generated.<br><br>" +
        "<b>Usage:</b> <br>Set the name of the preview that is generated for the found background region.<br><br>" +
        "<b>Usage constraints:</b> <br>This name is only used in case a preview is actually being generated.<br><br>" +
        "<b>Default value:</b> <br>Background. <br>This is pretty self explanatory ;)";
    this.previewName.onTextUpdated = function (text) {
        parameters.previewName = text;
    }

    this.previewSizerHorizontal = new HorizontalSizer;
    this.previewSizerHorizontal.spacing = 6;
    this.previewSizerHorizontal.add(this.generatePreview_Chk);
    this.previewSizerHorizontal.add(this.previewName);

    this.removePreview_Btn = new PushButton(this);
    this.removePreview_Btn.text = "Remove previous preview";
    this.removePreview_Btn.toolTip = "Removes the previously generated preview with the currently selected name.<br><br>" +
        "<b>Usage:</b> <br>Click this button to remove the preview with the currently selected name.<br><br>" +
        "<b>Usage constraints:</b> <br>None.<br><br>" +
        "<b>Default value:</b> <br>Not applicable.";
    this.removePreview_Btn.onClick = function () {
        let window = parameters.targetWindow;
        let previews = window.previews;
        for (let i = 0; i < previews.length; i++) {
            if (previews[i].id == parameters.previewName) {
                window.deletePreview(previews[i]);
                break;
            }
        }
    };

    this.removePreview_Sizer = new HorizontalSizer;
    this.removePreview_Sizer.add(this.removePreview_Btn);
    this.removePreview_Sizer.addStretch();

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

this.execute_Btn = new PushButton(this);
this.execute_Btn.text = "Search!";
this.execute_Btn.toolTip = "Start the search for the background region with the selected parameters.";
this.execute_Btn.onClick = function () {
    let dialog = this.dialog; // Reference to the dialog

    // Disable the dialog to speed up processing
    dialog.enabled = false;

    let window = ImageWindow.windowById(dialog.windowSelector_Cb.itemText(dialog.windowSelector_Cb.currentItem));
    parameters.targetWindow = window;

    let userDefinedRegions = [];
    if (dialog.userDefinedChk.checked || dialog.userDefinedExclusionChk.checked) {
        userDefinedRegions = dialog.previewControl.userDefinedRegions.map(function(region) {
            // Scaling the user-defined region
            let downsamplingFactor = dialog.downsamplingFactor;
            return new Rect(
                region.left * downsamplingFactor,
                region.top * downsamplingFactor,
                region.right * downsamplingFactor,
                region.bottom * downsamplingFactor
            );
        });

        userDefinedRegions = mergeOverlappingRegions(userDefinedRegions);

        console.writeln("Merged user-defined regions for execution (scaled):");
        userDefinedRegions.forEach(function(region, index) {
            console.writeln("Region " + (index + 1) + ": Top-left: (" + region.left + ", " + region.top + "), Bottom-right: (" + region.right + ", " + region.bottom + ")");
        });
    }

    let exclusionAreas = [];
    if (dialog.userDefinedExclusionChk.checked) {
        exclusionAreas = userDefinedRegions;

        console.writeln("Merged user-defined exclusion areas for execution (scaled):");
        exclusionAreas.forEach(function(area, index) {
            console.writeln("Exclusion Area " + (index + 1) + ": Top-left: (" + area.left + ", " + area.top + "), Bottom-right: (" + area.right + ", " + area.bottom + ")");
        });
    }

    let finder;
    if (dialog.fastSearch_Rdb.checked) {
        if (userDefinedRegions.length > 0 && !dialog.userDefinedExclusionChk.checked) {
            finder = new FindBackgroundUserDefined(parameters.size, parameters.spacingRate, userDefinedRegions);
            finder.setTarget(parameters.targetWindow);
            finder.fastSearchBackgroundUserDefined(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName, userDefinedRegions);
        } else {
            finder = new FindBackground(parameters.size, parameters.spacingRate);
            finder.exclusionAreas = exclusionAreas;
            finder.setTarget(parameters.targetWindow);
            finder.fastSearchBackground(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName);
        }
    } else {
        if (userDefinedRegions.length > 0 && !dialog.userDefinedExclusionChk.checked) {
            finder = new FindBackgroundUserDefined(parameters.size, parameters.spacingRate, userDefinedRegions);
            finder.setTarget(parameters.targetWindow);
            finder.searchBackgroundUserDefined(parameters.printInformation, parameters.previewName, userDefinedRegions);
        } else {
            finder = new FindBackground(parameters.size, parameters.spacingRate);
            finder.exclusionAreas = exclusionAreas;
            finder.setTarget(parameters.targetWindow);
            finder.searchBackground(parameters.printInformation, parameters.previewName);
        }
    }

    // Enable the dialog again after processing is complete
    dialog.enabled = true;

    // Uncomment this line if you want to close the dialog after processing
    // dialog.ok();
}.bind(this); // Ensuring the correct context for 'this'




    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 0;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.addStretch();
    this.buttonSizerHorizontal.add(this.execute_Btn);

    this.backgroundParameterSizerVertical = new VerticalSizer;
    this.backgroundParameterSizerVertical.spacing = 0;
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSize_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSpacingRate_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSearchGridSize_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterStartingPoints_NC);

    this.backgroundParametersSizerHorizontal = new HorizontalSizer;
    this.backgroundParametersSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.backgroundParametersSizerHorizontal.add(this.backgroundParameterSizerVertical);

    // Add Zoom Level Dropdown
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 0;

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Preview Zoom Level: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
    this.zoomSizer.add(this.zoomLabel);

    this.zoomLevelComboBox = new ComboBox(this);
    this.zoomLevelComboBox.addItem("1:1");
    this.zoomLevelComboBox.addItem("1:2");
    this.zoomLevelComboBox.addItem("1:4");
    this.zoomLevelComboBox.addItem("1:8");
    this.zoomLevelComboBox.addItem("Fit to Preview");

    // Set default to "Fit to Preview"
    this.zoomLevelComboBox.currentItem = 4;
    this.zoomSizer.add(this.zoomLevelComboBox, 1);

    // Add the preview control
    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);

    // Main layout sizer
    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 0;
    this.mainSizer.margin = 0;

    // Left column sizer
    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 0
    this.leftSizer.add(this.title_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.conditions_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.instructions_Lbl);
    this.leftSizer.add(this.searchAreaSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.windowSelector_Cb);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.filterInformation_Lbl);
    this.leftSizer.add(this.filterSizerHorizontal);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.searchRoutine_Lbl);
    this.leftSizer.add(this.searchOptionsSizerHorizontal);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.backgroundRegionParameters_Lbl);
    this.leftSizer.add(this.backgroundParametersSizerHorizontal);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.printInformation_Chk);
    this.leftSizer.add(this.previewSizerHorizontal);
    this.leftSizer.add(this.removePreview_Sizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.buttonSizerHorizontal);
    this.leftSizer.add(this.zoomSizer); // Add zoom controls to the leftSizer

    this.mainSizer.add(this.leftSizer);

    // Add the preview control to the main layout
    this.mainSizer.add(this.previewControl, 1, Align_Expand);

    this.sizer = this.mainSizer;

    this.windowTitle = "FindBackground";
    this.adjustToContents();

// Ensure the initial display setup calls the correct function
this.onShow = () => {
    if (this.windowSelector_Cb.currentItem >= 0 && this.userDefinedChk.checked) {
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
        if (window && !window.isNull) {
            let selectedImage = window.mainView.image;
            if (selectedImage) {
                console.writeln("Displaying the initial image in the preview.");
                var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
            }
        }
    } else {
        console.noteln("FindBackground Full image mode initialized.");
        this.previewControl.visible = false;
        this.zoomSizer.visible = false;
        this.adjustToContents(); // Adjust the dialog size to fit the initial content
    }
};

// Add a variable to store the downsampling factor
this.downsamplingFactor = 1;

    // Function to create, resize, and display a temporary image
    this.createAndDisplayTemporaryImage = function (selectedImage) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

        // Apply the appropriate processing function based on whether the image is mono or color
        if (selectedImage.numberOfChannels == 1) {
            processMonoImage(window.mainView, 0.25);
        } else {
            processUnlinkedColorImage(window.mainView, 0.25);
        }

        var P = new IntegerResample;
        switch (this.zoomLevelComboBox.currentItem) {
            case 0: // 1:1
                P.zoomFactor = -1;
                this.downsamplingFactor = 1;
                break;
            case 1: // 1:2
                P.zoomFactor = -2;
                this.downsamplingFactor = 2;
                break;
            case 2: // 1:4
                P.zoomFactor = -4;
                this.downsamplingFactor = 4;
                break;
            case 3: // 1:8
                P.zoomFactor = -8;
                this.downsamplingFactor = 8;
                break;
            case 4: // Fit to Preview
                const previewWidth = this.previewControl.width;
                const widthScale = Math.floor(selectedImage.width / previewWidth);
                P.zoomFactor = -Math.max(widthScale, 1);
                this.downsamplingFactor = Math.max(widthScale, 1);
                break;
            default:
                P.zoomFactor = -2; // Default to 1:2 if nothing is selected
                this.downsamplingFactor = 2;
                break;
        }

        P.executeOn(window.mainView);

        let resizedImage = new Image(window.mainView.image);

        if (resizedImage.width > 0 && resizedImage.height > 0) {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage(resizedImage);
            this.previewControl.initScrollBars();
        } else {
            console.error("Resized image has invalid dimensions.");
        }

        window.forceClose();

        return resizedImage;
    };

    // Update processPreview function to handle user-defined region
    this.processPreview = function(selectedImage) {
        console.writeln("Starting processPreview...");
        let processingWindow = new ImageWindow(
            selectedImage.width,
            selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        if (!processingWindow || processingWindow.isNull) {
            console.writeln("Failed to create processing window.");
            return;
        }

        processingWindow.hide();
        processingWindow.mainView.beginProcess();
        processingWindow.mainView.image.assign(selectedImage);
        processingWindow.mainView.endProcess();

        // Apply the appropriate processing function based on whether the image is mono or color
        if (selectedImage.numberOfChannels == 1) {
            processMonoImage(processingWindow.mainView, 0.25);
        } else {
            processUnlinkedColorImage(processingWindow.mainView, 0.25);
        }

        // If a user-defined region exists, restrict the search to that region
        if (userDefinedRegion) {
            // Implement the logic to restrict the search to userDefinedRegion
            // You will need to adjust the search algorithms to use this region
        }

        let tempImage = this.createAndDisplayTemporaryImage(processingWindow.mainView.image);
        if (tempImage) {
            this.previewControl.displayImage = tempImage;
            this.previewControl.update();
        } else {
            console.writeln("Failed to create a temporary image for preview.");
        }

        processingWindow.forceClose();
    };

    // Adjust the event handler for the zoom level dropdown to include Auto STF handling
    this.zoomLevelComboBox.onItemSelected = (index) => {
        console.noteln("Zoom Level Changed. Refreshing preview...");
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Adjusting preview for image with ID: " + parameters.targetWindow.mainView.id);
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for preview!");
        }
    };


// Initially hide the preview control and zoom sizer
this.previewControl.visible = false;
this.zoomSizer.visible = false;

}

FindBackgroundDialog.prototype = new Dialog;

function processMonoImage(targetView, targetMedian) {
    var P = new ProcessContainer;

    var P001 = new PixelMath;
    P001.expression = "BlackPoint = iif((med($T) - 2.7*sdev($T))<min($T),min($T),med($T) - 2.7*sdev($T));\n" +
                      "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
    P001.useSingleExpression = true;
    P001.symbols = "BlackPoint, Rescaled, CurrentMedian, DesiredMedian, Alpha";
    P001.clearImageCacheAndExit = false;
    P001.cacheGeneratedImages = false;
    P001.generateOutput = true;
    P001.singleThreaded = false;
    P001.optimization = true;
    P001.use64BitWorkingImage = false;
    P001.rescale = false;
    P001.rescaleLower = 0;
    P001.rescaleUpper = 1;
    P001.truncate = true;
    P001.truncateLower = 0;
    P001.truncateUpper = 1;
    P001.createNewImage = false;
    P001.showNewImage = true;
    P.add(P001);

    var P002 = new PixelMath;
    P002.expression = "((Med($T)-1)*" + targetMedian + "*$T)/(Med($T)*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
    P002.useSingleExpression = true;
    P002.symbols = "L, S";
    P002.clearImageCacheAndExit = false;
    P002.cacheGeneratedImages = false;
    P002.generateOutput = true;
    P002.singleThreaded = false;
    P002.optimization = true;
    P002.use64BitWorkingImage = false;
    P002.rescale = false;
    P002.rescaleLower = 0;
    P002.rescaleUpper = 1;
    P002.truncate = true;
    P002.truncateLower = 0;
    P002.truncateUpper = 1;
    P002.createNewImage = false;
    P002.showNewImage = true;
    P.add(P002);

    // Execute the process container on the selected target image
 P.executeOn(targetView);
}


function processUnlinkedColorImage(targetView, targetMedian) {
    var P = new ProcessContainer;

    var P001 = new PixelMath;
    P001.useSingleExpression = false;
    P001.expression = "BlackPoint = iif((med($T[0]) - 2.7*sdev($T[0]))<min($T[0]),min($T[0]),med($T[0]) - 2.7*sdev($T[0]));\n" +
                      "Rescaled = ($T[0] - BlackPoint) / (1 - BlackPoint);";
    P001.expression1 = "BlackPoint = iif((med($T[1]) - 2.7*sdev($T[1]))<min($T[1]),min($T[1]),med($T[1]) - 2.7*sdev($T[1]));\n" +
                       "Rescaled = ($T[1] - BlackPoint) / (1 - BlackPoint);";
    P001.expression2 = "BlackPoint = iif((med($T[2]) - 2.7*sdev($T[2]))<min($T[2]),min($T[2]),med($T[2]) - 2.7*sdev($T[2]));\n" +
                       "Rescaled = ($T[2] - BlackPoint) / (1 - BlackPoint);";
    P001.symbols = "BlackPoint, Rescaled";
    configurePixelMath(P001);
    P.add(P001);

    var P002 = new PixelMath;
    P002.useSingleExpression = false;
    P002.expression = "((Med($T[0])-1)*" + targetMedian + "*$T[0])/(Med($T[0])*(" + targetMedian + "+$T[0]-1)-" + targetMedian + "*$T[0])";
    P002.expression1 = "((Med($T[1])-1)*" + targetMedian + "*$T[1])/(Med($T[1])*(" + targetMedian + "+$T[1]-1)-" + targetMedian + "*$T[1])";
    P002.expression2 = "((Med($T[2])-1)*" + targetMedian + "*$T[2])/(Med($T[2])*(" + targetMedian + "+$T[2]-1)-" + targetMedian + "*$T[2])";
    P002.symbols = "L, S";
    configurePixelMath(P002);
    P.add(P002);

    P.executeOn(targetView);
}

function configurePixelMath(P) {
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
}

function getFinderInstance(userDefinedRegion) {
    let window = parameters.targetWindow;

    if (!window || window.isNull) {
        console.show();
        console.criticalln("No target window selected or the selected window is invalid. Please select a valid window and try again.");
        return null;
    }

    let finder;
    if (userDefinedRegion) {
        finder = new FindBackgroundUserDefined(parameters.size, parameters.spacingRate, userDefinedRegion);
    } else {
        finder = new FindBackground(parameters.size, parameters.spacingRate);
    }

    finder.filterAverage = parameters.filterAvg;
    finder.filterStandardDeviation = parameters.filterSdev;
    finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
    finder.filterPoissonIndex = parameters.filterPoisonIndex;
    finder.filterForObjects = parameters.filterObjects;

    finder.setTarget(window);

    return finder;
}



function main() {
    console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    if (Parameters.isGlobalTarget) {
        console.show();
        console.criticalln("FindBackground can only be executed on a single image and not in global context. Open an image and run the script again.");
        return false;
    }

    if (Parameters.isViewTarget) {
        parameters.load();

        let window = ImageWindow.activeWindow;
        parameters.targetWindow = window;

        let finder = getFinderInstance();
        if (!finder) {
            return false;
        }

        let userDefinedRegion = null;
        if (parameters.userDefinedChk) {
            userDefinedRegion = parameters.userDefinedRegion;
            let downsamplingFactor = parameters.downsamplingFactor;
            userDefinedRegion.left *= downsamplingFactor;
            userDefinedRegion.top *= downsamplingFactor;
            userDefinedRegion.right *= downsamplingFactor;
            userDefinedRegion.bottom *= downsamplingFactor;

            console.writeln("User-defined region for execution (scaled):");
            console.writeln("Top-left: (" + userDefinedRegion.left + ", " + userDefinedRegion.top + ")");
            console.writeln("Bottom-right: (" + userDefinedRegion.right + ", " + userDefinedRegion.bottom + ")");
        }

        if (parameters.slowSearch) {
            if (parameters.userDefinedChk) {
                finder.searchBackgroundUserDefined(parameters.printInformation, parameters.previewName, userDefinedRegion);
            } else {
                finder.searchBackground(parameters.printInformation, parameters.previewName);
            }
            console.noteln("Background Found! Preview Created!");
            return false;
        } else if (parameters.fastSearch) {
            if (parameters.userDefinedChk) {
                finder.fastSearchBackgroundUserDefined(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName, userDefinedRegion);
            } else {
                finder.fastSearchBackground(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName);
            }
            console.noteln("Background Found! Preview Created!");
            return false;
        } else {
            console.criticalln("No search routine selected. Please select a search routine.");
            return false;
        }
    } else {
        let dialog = new FindBackgroundDialog();
        if (dialog.execute()) {
            parameters.save();

            let window = ImageWindow.windowById(dialog.windowSelector_Cb.itemText(dialog.windowSelector_Cb.currentItem));
            parameters.targetWindow = window;

            let finder = getFinderInstance();
            if (!finder) {
                return false;
            }

            let userDefinedRegion = null;
            if (parameters.userDefinedChk) {
                userDefinedRegion = parameters.userDefinedRegion;
                let downsamplingFactor = parameters.downsamplingFactor;
                userDefinedRegion.left *= downsamplingFactor;
                userDefinedRegion.top *= downsamplingFactor;
                userDefinedRegion.right *= downsamplingFactor;
                userDefinedRegion.bottom *= downsamplingFactor;

                console.writeln("User-defined region for execution (scaled):");
                console.writeln("Top-left: (" + userDefinedRegion.left + ", " + userDefinedRegion.top + ")");
                console.writeln("Bottom-right: (" + userDefinedRegion.right + ", " + userDefinedRegion.bottom + ")");
            }

            if (parameters.slowSearch) {
                if (parameters.userDefinedChk) {
                    finder.searchBackgroundUserDefined(parameters.printInformation, parameters.previewName, userDefinedRegion);
                } else {
                    finder.searchBackground(parameters.printInformation, parameters.previewName);
                }
                console.noteln("Background Found! Preview Created!");
                return true;
            } else if (parameters.fastSearch) {
                if (parameters.userDefinedChk) {
                    finder.fastSearchBackgroundUserDefined(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName, userDefinedRegion);
                } else {
                    finder.fastSearchBackground(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName);
                }
                console.noteln("Background Found! Preview Created!");
                return true;
            } else {
                console.criticalln("No search routine selected. Please select a search routine.");
                return false;
            }
        } else {
            console.show();
            console.noteln("FindBackground dialog closed.");
            return false;
        }
    }
}

while (main());


