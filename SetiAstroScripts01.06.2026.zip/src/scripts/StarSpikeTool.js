#feature-id StarSpikeTool : SetiAstro > Star Spike Tool
#feature-icon  starspike.svg
#feature-info Add realistic diffraction spikes to bright stars using a Fourier-based PSF pupil model.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *######################################################################
 *
 * Star Spike Tool
 * Version: 1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This tool generates realistic diffraction spikes using FFT pupil masks.
 * Based on star detection and PSF fitting from LinearDeblur
 *
 * Licensed under CC BY-NC 4.0
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>
#define __PJSR_USE_STAR_DETECTOR_V2
#include <pjsr/StarDetector.jsh>

var deblurringParameters = {
    targetView: undefined,
    targetWindow: undefined,
    strideSize: 1024,
    maxDistortion: 0.6,
    sensitivity: 0.5,
    structureLayers: 5,
    xyStretch: 1.5,
    peakResponse: 0.5,
    deblurPythonToolsParentFolderPath: "",
    useGPU: true,
    linearImage: true,
    erosionLength: 4,
    erosionIterations: 1,
    erosionAmount: 0.5,
    deconvolutionAmount: 4,
    deconvolutionIterations: 10,
    deconvolutionDeringing: false,
    deconvolutionGlobalDark: 0.1,
    replaceWithSS: true,
    keepSyntheticStars: true,
    SSlinearCheckBox: true,
    ignoreHotPixels: true,
    SSminimumStarSize: 0,
    SSdenoiseFirst: true,
    SSdenoiseWithNN: true,
    SSdenoiseWithMMT: true,
    recombinationMethod: 'maximum',
   SSrecombinationExtraPercent: 0.5,
   starDetectorStars: [],
   dynamicPSFStars: [],
   SSstarSizeRange: 10,
   SSstarSizeAbove: true,
   SSstarIntensityRange: 0.04,
   scalingDivisor: 4.0,  // 🔧 Global scaling control for spike sizing
};

function StarSpikeDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "Star Spike Tool V1";
    this.adjustToContents();
    this.setMinWidth(400);

    // Title
    this.titleLabel = new Label(this);
    this.titleLabel.useRichText = true;
    this.titleLabel.text = "<b>Star Spike Tool V1</b><br><i>Add realistic diffraction spikes</i>";
    this.titleLabel.textAlignment = TextAlign_Center;

   // Image selector
   this.imageLabel = new Label(this);
   this.imageLabel.text = "Target Image:";
   this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.imageSelector = new ComboBox(this);
   this.imageSelector.editEnabled = false;

   let windowList = ImageWindow.windows;
   let activeWindowIndex = -1;
   for (let i = 0; i < windowList.length; i++) {
       this.imageSelector.addItem(windowList[i].mainView.id);
       if (!ImageWindow.activeWindow.isNull && windowList[i].mainView.id === ImageWindow.activeWindow.mainView.id) {
           activeWindowIndex = i;
       }
   }

   if (activeWindowIndex !== -1) {
       this.imageSelector.currentItem = activeWindowIndex;
   }


    // Vane count
    this.vaneCount = new SpinBox(this);
    this.vaneCount.minValue = 0;
    this.vaneCount.maxValue = 16;
    this.vaneCount.value = 2;
    this.vaneCount.toolTip = "Number of vanes (spikes).";

    this.vaneCountLabel = new Label(this);
    this.vaneCountLabel.text = "Vane Count:";

    // Vane width
    this.vaneWidth = new NumericControl(this);
    this.vaneWidth.label.text = "Vane Width:";
    this.vaneWidth.setRange(0.5, 10.0);
    this.vaneWidth.setPrecision(1);
    this.vaneWidth.slider.setRange(1, 100);
    this.vaneWidth.setValue(4);

    // Obstruction
    this.obstruction = new NumericControl(this);
    this.obstruction.label.text = "Central Obstruction:";
    this.obstruction.setRange(0.0, 1.0);
    this.obstruction.setPrecision(2);
    this.obstruction.setValue(0.3);

    // Pupil size
    this.pupilSize = new SpinBox(this);
    this.pupilSize.minValue = 32;
    this.pupilSize.maxValue = 1024;
    this.pupilSize.value = 256;

    this.pupilSizeLabel = new Label(this);
    this.pupilSizeLabel.text = "Aperture Size:";

    // Spike Boost Amount
this.spikeBoost = new NumericControl(this);
this.spikeBoost.label.text = "Spike Stretch:";
this.spikeBoost.setRange(1.0, 10.0);
this.spikeBoost.setPrecision(1);
this.spikeBoost.slider.setRange(1, 100);
this.spikeBoost.setValue(4.0);

// Spike Rotation Angle
this.rotationAngle = new NumericControl(this);
this.rotationAngle.label.text = "Spike Rotation Angle (deg):";
this.rotationAngle.setRange(0, 360);
this.rotationAngle.setPrecision(1);
this.rotationAngle.slider.setRange(0, 360);
this.rotationAngle.setValue(0.0);

// In StarSpikeDialog constructor – add below your existing controls:
this.starThreshold = new NumericControl(this);
this.starThreshold.label.text = "Star Threshold (% bright stars):";
this.starThreshold.setRange(0, 100);
this.starThreshold.setPrecision(0);
this.starThreshold.slider.setRange(0, 100);
this.starThreshold.setValue(20);  // default includes all stars
this.showGeneratedStars = new CheckBox(this);
this.showGeneratedStars.text = "Show Generated Stars";
this.showGeneratedStars.checked = false; // default (unchecked) means close the generated stars window


    // Execute button
    this.executeButton = new PushButton(this);
    this.executeButton.text = "Generate Spikes";
    this.executeButton.onClick = function () {
        this.executeSpikeGeneration();
    }.bind(this);

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 8;
    this.sizer.spacing = 6;
    this.sizer.add(this.titleLabel);
    this.sizer.addSpacing(6);

    this.sizer.add(this.imageLabel);
    this.sizer.add(this.imageSelector);
    this.sizer.addSpacing(6);
    this.sizer.add(this.pupilSizeLabel);
    this.sizer.add(this.pupilSize);
    this.sizer.add(this.vaneCountLabel);
    this.sizer.add(this.vaneCount);
    this.sizer.add(this.vaneWidth);
    this.sizer.add(this.obstruction);
        this.sizer.add(this.rotationAngle);



    this.sizer.addSpacing(8);
      this.sizer.add(this.starThreshold);
    this.sizer.add(this.spikeBoost);
        this.sizer.addSpacing(6);
this.sizer.add(this.showGeneratedStars);
    this.sizer.addSpacing(8);
    this.sizer.add(this.executeButton);

    this.adjustToContents();
}

StarSpikeDialog.prototype = new Dialog;


// Function to return a list of stars in an image
function getStars(workingImageView, dlg) {
    console.writeln("Detecting stars");
    processEvents();
    var std = new StarDetector();
    // std.sensitivity = Math.pow(10.0, sensitivity);
    std.sensitivity = deblurringParameters.sensitivity;
    std.xyStretch = deblurringParameters.xyStretch;
    std.maxDistortion = deblurringParameters.maxDistortion;
    std.structureLayers = deblurringParameters.structureLayers;
    std.peakResponse = deblurringParameters.peakResponse;
    std.minStructSize = 0;
    if (deblurringParameters.ignoreHotPixels) {
        std.ignoreHotPixels = 3;
    }
    else {
        std.ignoreHotPixels = 3;
    }

    Console.writeln('Sensitivity ' + std.sensitivity);
    Console.writeln('Upper limit ' + std.upperLimit);
    Console.writeln('structureLayers ' + std.structureLayers);
    Console.writeln('xyStretch ' + std.xyStretch);
    Console.writeln('peakResponse ' + std.peakResponse);
    // Console.writeln('bkgDelta ' + std.bkgDelta);
    Console.writeln('maxDistortion ' + std.maxDistortion);


    var stars = std.stars(workingImageView.image);

    Console.writeln('Number of stars detected by detector: ' + stars.length);

    Console.show();

    if (stars == null) return [];
    if (stars.length == 0) return [];

    var barycenters = new Array;
    var maxStars = 10;
    if (maxStars > stars.length) maxStars = stars.length;

    for (var i = 0; i != maxStars; ++i) {
        var s = stars[i];

        Console.writeln('First stars x: ' + s.pos.x + ' y: ' + s.pos.y);
    }

    // return;

    var keys = Object.keys(s);

    for (var k in keys) Console.writeln('Property ' + keys[k]);
    let minStructSize = 0;
    for (var i = 0; i != stars.length; ++i) {
        let newRadius = Math.max(3, Math.ceil(Math.sqrt(stars[i].size)));
        barycenters.push({
            position: stars[i].pos,
            radius: Math.max(3, Math.ceil(Math.sqrt(stars[i].size)))
        });
        if (newRadius > minStructSize) minStructSize = newRadius;
        // processEvents();
        // if (dlg.cancel) break;
    }

    console.writeln("Found " + barycenters.length.toString() + " stars - fitting PSF");
    processEvents();

    Console.writeln('Number of stars detected ' + barycenters.length);
    Console.flush();


    // P.stars = [ // viewIndex, channel, status, x0, y0, x1, y1, x, y

    var dynamicPSF = new DynamicPSF;
    var radius = Math.round(0.75 * dynamicPSF.searchRadius);

    Console.writeln('dynamicPSF radius: ' + dynamicPSF.searchRadius);
    Console.flush();

    // return;

    stars = [];

    for (var i = 0; i != barycenters.length; ++i) {
        stars.push(new Array(
            0, 0, DynamicPSF.prototype.Star_DetectedOk,
            barycenters[i].position.x - barycenters[i].radius,
            barycenters[i].position.y - barycenters[i].radius,
            barycenters[i].position.x + barycenters[i].radius,
            barycenters[i].position.y + barycenters[i].radius,
            barycenters[i].position.x,
            barycenters[i].position.y
        ));
    }
    Console.writeln("Detected stars barycenters " + barycenters.length);
    Console.writeln("Detected stars stars " + stars.length);
    Console.flush();

    // let S = std.stars(view.image);

    Console.writeln("Detected stars stars " + stars.length);

    let autoPSF = true;

    Console.writeln("Restructured stars: " + stars.length);

    Console.writeln("minStructSize pre dynamicPSF: " + minStructSize);
    Console.flush();


    let P = new DynamicPSF;
    P.views = [[workingImageView.id]];
    P.stars = stars;
    P.astrometry = false;
    P.autoAperture = true;
    P.searchRadius = 8;
    P.circularPSF = false;
    P.autoPSF = autoPSF;
    P.gaussianPSF = true;
    P.moffatPSF = P.moffat10PSF = P.moffat8PSF =
        P.moffat6PSF = P.moffat4PSF = P.moffat25PSF =
        P.moffat15PSF = P.lorentzianPSF = autoPSF;
    P.variableShapePSF = false;
    if (!P.executeGlobal())
        throw "Unable to execute DynamicPSF process.";

    Console.flush();
    Console.writeln('Post dynamicPSF: ');
    Console.flush();





    stars = [];

    for (let psf = P.psf, i = 0; i < psf.length; ++i) {
        let p = psf[i];
        if (p[3] == DynamicPSF.prototype.PSF_FittedOk) {
            let x = p[6];
            let y = p[7];
            let rx = p[8] / 2;
            let ry = p[9] / 2;
            stars.push({
                x: x, y: y,
                rect: {
                    x0: x - rx, y0: y - ry,
                    x1: x + rx, y1: y + ry
                }
            });
        }
    }

    Console.writeln('Number of stars post DynamicPSF: ' + stars.length);

    stars = [];
    const PSF_model = 0;
   const PSF_function = 1;
   const PSF_status = 3;
   const PSF_x = 6;
   const PSF_y = 7;
   const PSF_sx = 8;
   const PSF_sy = 9;
   const PSF_theta = 10;
   const PSF_beta = 11;
   const PSF_A = 12;
   const PSF_B = 13;
   const PSF_mad = 14;

    for (let psf = P.psf, i = 0; i < psf.length; ++i) {
        let p = psf[i];
        if (p[3] == DynamicPSF.prototype.PSF_FittedOk) {
            let x = p[6];
            let y = p[7];
            let rx = p[8] / 2;
            let ry = p[9] / 2;
            let sx = p[PSF_sx];
            let sy = p[PSF_sy];
            let aProp = p[PSF_A];
            let bProp = p[PSF_B];
            let theta = p[PSF_theta];
            let beta = p[PSF_beta];
            let mad = p[PSF_mad];
            stars.push({
                cx: x, cy: y, sx: sx, sy: sy, a: aProp, b: bProp, theta: theta, beta: beta, mad: mad,
                rect: {
                    x0: x - rx, y0: y - ry,
                    x1: x + rx, y1: y + ry
                }
            });
        }
    }

    var a = stars;

    return a;
}

function boxSize(b, a, beta, sx, sy, theta) {
   var max = moffat(0, 0, b, a, 0, 0, beta, sx, sy);

   // Console.writeln('boxSize max moffat: ' + max);

   var x = 0;
   var y = 0;
   var v = 2;

   while (true) {
      var t = new transformXY(x, 0, theta);
      var mx = moffat(x, 0, b, a, 0, 0, beta, sx, sy);
      mx /= max;
      // Console.writeln('boxSize mx moffat: ' + mx);

      if ((v - mx < 0.001) && (mx < 0.99)) break;

      v = mx;

      x += 1;

      if (x > 32) break;
   }

   // Console.writeln('boxSize x: ' + x);

   v = 2;

   while (true) {
      var t = new transformXY(x, y, theta);
      var my = moffat(0, y, b, a, 0, 0, beta, sx, sy);
      my /= max;
      // Console.writeln('boxSize mx moffat: ' + my);

      if ((v - my < 0.001) && (my < 0.99)) break;

      v = my;

      y += 1;

      if (y > 32) break;
   }

   // Console.writeln('boxSize y: ' + y);

   var box = Math.max(x - 1, y - 1);

   box *= 2;

   box += 1;

   return box;
}

function transformXY(x, y, theta) {
   this.x = x * Math.cos(theta * Math.RAD) + y * Math.sin(theta * Math.RAD);
   this.y = -x * Math.sin(theta * Math.RAD) + y * Math.cos(theta * Math.RAD);
}

function moffat(x, y, B, A, cx, cy, beta, sigmax, sigmay) {
   var sqx = sigmax * sigmax;
   var sqy = sigmay * sigmay;
   var dx2 = Math.pow(x - cx, 2);
   var dy2 = Math.pow(y - cy, 2);

   return B + A / Math.pow((1 + dx2 / sqx + dy2 / sqy), beta);
}

function createStarImage(b, a, sx, sy, theta, beta) {
   //
   // implements Moffat function
   //
   var box = boxSize(b, a, beta, sx, sy, theta);

   var c = Math.floor(box / 2);

   var cx = c + 1;
   var cy = c + 1;

   var img = new Image(box, box);

   var max = moffat(cx, cy, b, a, cx, cy, beta, sx, sy);
   var min = moffat(0, 0, b, a, cx, cy, beta, sx, sy);

   var f = 1 / (max - min);

   for (var y = 0; y < img.height; y++) {
      for (var x = 0; x < img.width; x++) {
         var t = new transformXY(- c + x, - c + y, theta);
         var m = moffat(t.x + cx, t.y + cy, b, a, cx, cy, beta, sx, sy);
         m = (m - min) * f;
         img.setSample(m, x, img.height - y - 1);
         // img.setSample(0.4, x, img.height - y - 1);
      }
   }

   // img.fill(0.4);

   return img;
}


StarSpikeDialog.prototype.executeSpikeGeneration = function () {
    let imageId = this.imageSelector.itemText(this.imageSelector.currentItem);
    let view = ImageWindow.windowById(imageId).mainView;
    let targetWindow = ImageWindow.windowById(imageId);

    let spikes = getStars(view);

      let pupilImage = createPupilImage(
          this.pupilSize.value / 2,
          this.obstruction.value,
          this.vaneCount.value,
          this.vaneWidth.value,
          this.rotationAngle.value    // 👈 Add this
      );

    let psfImage = fourierTransformPupil(pupilImage); // Output: DFT_magnitude

    // ✅ Actually generate the scaled spike cache
    let spikeCache = generateSpikeCache(spikes, psfImage, 10, this.spikeBoost.value);

    // ✅ Pass it in
    let showStars = this.showGeneratedStars.checked;
   applySpikesToImage(
       targetWindow,
       spikes,
       spikeCache.scaledSpikes,
       spikeCache.scaleFactors,
       spikeCache.minSize,
       spikeCache.maxSize,
       spikeCache.minScale,
       spikeCache.maxScale,
       this.spikeBoost.value,   // 👈 pass boost value here
       this.starThreshold.value,
       showStars
   );
};


function createPupilImage(apertureRadius, obstruction, vaneCount, vaneWidth, rotationAngle) {
    const size = 1024;  // fixed canvas size
    let pupilWindow = new ImageWindow(size, size, 1, 32, true, false);
    let img = pupilWindow.mainView.image;
    let cx = Math.floor(size / 2);
    let cy = Math.floor(size / 2);

    pupilWindow.mainView.beginProcess(UndoFlag_NoSwapFile);

    for (let y = 0; y < size; ++y) {
        for (let x = 0; x < size; ++x) {
            let dx = x - cx;
            let dy = y - cy;
            let r = Math.sqrt(dx * dx + dy * dy);

            let inAperture = r <= apertureRadius;
            let inObstruction = r <= apertureRadius * obstruction;

            let vaneMask = false;
            for (let i = 0; i < vaneCount; ++i) {
                let theta = (i * Math.PI / vaneCount) + (rotationAngle * Math.PI / 180);

                let xp = dx * Math.cos(theta) + dy * Math.sin(theta);
                if (Math.abs(xp) < vaneWidth) {
                    vaneMask = true;
                    break;
                }
            }

            // Draw white aperture, masked by obstruction and vanes
            let value = inAperture && !inObstruction && !vaneMask ? 1.0 : 0.0;
            img.setSample(value, x, y);
        }
    }

    pupilWindow.mainView.endProcess();

    return pupilWindow;
}





function fourierTransformPupil(pupilWindow) {
    // Execute the Fourier transform on the pupil window.
    let P = new FourierTransform;
    P.radialCoordinates = true;
    P.centered = true;
    P.executeOn(pupilWindow.mainView); // Run directly on the pupil window

    // Grab the generated DFT_magnitude image window.
    let resultWindow = ImageWindow.windowById("DFT_magnitude");
    if (resultWindow && !resultWindow.isNull) {
        // Use the view (not the image) so that PixelMath can execute properly.
        let dftView = resultWindow.mainView;

        // First round of PixelMath: subtract the global minimum.
        let PM1 = new PixelMath;
        PM1.expression = "$T - min($T)";
        PM1.useSingleExpression = true;
        PM1.generateOutput = false;
        PM1.createNewImage = false;
        PM1.executeOn(dftView);

        // Second round of PixelMath: subtract 0.5 times the median.
        let PM2 = new PixelMath;
        PM2.expression = "$T - 0.5*med($T)";
        PM2.useSingleExpression = true;
        PM2.generateOutput = false;
        PM2.createNewImage = false;
        PM2.executeOn(dftView);

        // Optionally close the pupil window.
        if (pupilWindow && pupilWindow.isWindow)
            pupilWindow.forceClose();

        return dftView.image;
    } else {
        throw new Error("DFT_magnitude view not found after FourierTransform.");
    }
}


function cropAndFeatherSpikeImage(spikeWin) {
   // Get the original spike image from the window.
   let original = spikeWin.mainView.image;
   let w = original.width;
   let h = original.height;

   // Define cropping: crop in by 10% on each side.
   let cropLeft = Math.floor(w * 0.1);
   let cropTop  = Math.floor(h * 0.1);
   let cropWidth = Math.floor(w * 0.8);
   let cropHeight = Math.floor(h * 0.8);

   // Create a new image window for the cropped spike image.
   let croppedWin = new ImageWindow(cropWidth, cropHeight, 3, 32, true, false);
   croppedWin.mainView.beginProcess(UndoFlag_NoSwapFile);
   let croppedImg = croppedWin.mainView.image;
   croppedImg.colorSpace = ColorSpace_RGB;

   // Copy the cropped region from the original spike image.
   for (let y = 0; y < cropHeight; y++) {
      for (let x = 0; x < cropWidth; x++) {
         for (let c = 0; c < 3; c++) {
             let val = original.sample(x + cropLeft, y + cropTop, c);
             croppedImg.setSample(val, x, y, c);
         }
      }
   }
   croppedWin.mainView.endProcess();

   // Define feather width as 10% of the smaller dimension of the cropped image.
   let featherWidth = Math.floor(Math.min(cropWidth, cropHeight) * 0.1);

   // Create and apply a feather mask.
   croppedWin.mainView.beginProcess(UndoFlag_NoSwapFile);
   for (let y = 0; y < cropHeight; y++) {
      for (let x = 0; x < cropWidth; x++) {
         // Compute distance from x to left and right edges.
         let dx = Math.min(x, cropWidth - 1 - x);
         // Compute distance from y to top and bottom edges.
         let dy = Math.min(y, cropHeight - 1 - y);
         // Use the smaller of these distances to determine the mask factor.
         let d = Math.min(dx, dy);
         // The mask factor ramps linearly:
         // If d >= featherWidth, factor is 1; if d=0, factor is 0.
         let maskFactor = (d >= featherWidth) ? 1.0 : d / featherWidth;

         for (let c = 0; c < 3; c++) {
             let pix = croppedImg.sample(x, y, c);
             croppedImg.setSample(pix * maskFactor, x, y, c);
         }
      }
   }
   croppedWin.mainView.endProcess();

   // Optionally, show the resulting feathered spike image.

   return croppedWin;
}



function resampleSpikeImage(spikeImage, scaleFactor, show = false) {
    let interp = new Resample;

    // Proper resampling setup
    interp.xSize = scaleFactor;
    interp.ySize = scaleFactor;
    interp.mode = Resample.prototype.RelativeDimensions;
    interp.absoluteMode = Resample.prototype.RelativeDimensions;
    interp.xResolution = 72.0;
    interp.yResolution = 72.0;
    interp.metric = false;
    interp.forceResolution = false;
    interp.interpolation = Resample.prototype.Auto;
    interp.clampingThreshold = 0.3;
    interp.smoothness = 1.5;
    interp.gammaCorrection = false;
    interp.noGUIMessages = false;
    Console.writeln("Resampling with scale factor: " + scaleFactor);

    // Create new window with original spike
    let win = new ImageWindow(spikeImage.width, spikeImage.height, 1, 32, true, false);
    win.mainView.beginProcess(UndoFlag_NoSwapFile);
    win.mainView.image.assign(spikeImage);
    win.mainView.endProcess();

    interp.executeOn(win.mainView);  // now it's scaled

    //if (show)
    //    win.show();

    return win;
}

function resampleSpikeImageRGB(spikeImage, scaleFactor) {
    // Calculate per-channel scale factors.
    let scaleR = scaleFactor * 1.15;
    let scaleG = scaleFactor * 1.0;
    let scaleB = scaleFactor * 0.85;

    // Resample the spike image for each channel.
    let redWin   = resampleSpikeImage(spikeImage, scaleR);
    let greenWin = resampleSpikeImage(spikeImage, scaleG);
    let blueWin  = resampleSpikeImage(spikeImage, scaleB);

    // Obtain the resampled images.
    let redImage   = redWin.mainView.image;
    let greenImage = greenWin.mainView.image;
    let blueImage  = blueWin.mainView.image;

    // Determine composite image size: maximum width and height among the channels.
    let compositeWidth  = Math.max(redImage.width, greenImage.width, blueImage.width);
    let compositeHeight = Math.max(redImage.height, greenImage.height, blueImage.height);

    // Compute offsets for each channel image so that they are centered in the composite.
    let offsetR_x = Math.floor((compositeWidth - redImage.width) / 2);
    let offsetR_y = Math.floor((compositeHeight - redImage.height) / 2);
    let offsetG_x = Math.floor((compositeWidth - greenImage.width) / 2);
    let offsetG_y = Math.floor((compositeHeight - greenImage.height) / 2);
    let offsetB_x = Math.floor((compositeWidth - blueImage.width) / 2);
    let offsetB_y = Math.floor((compositeHeight - blueImage.height) / 2);

    // Create a new window for the composite RGB image.
    let rgbWin = new ImageWindow(compositeWidth, compositeHeight, 3, 32, true, false);
    rgbWin.mainView.beginProcess(UndoFlag_NoSwapFile);
    let rgbImage = rgbWin.mainView.image;

    // Force the composite image to use an RGB color space.
    rgbImage.colorSpace = ColorSpace_RGB;

    // Initialize the composite image to black in all channels.
    for (let y = 0; y < compositeHeight; y++) {
        for (let x = 0; x < compositeWidth; x++) {
            rgbImage.setSample(0, x, y, 0); // Red channel
            rgbImage.setSample(0, x, y, 1); // Green channel
            rgbImage.setSample(0, x, y, 2); // Blue channel
        }
    }

    // Copy each channel's data, offsetting to center them.
    // Red channel:
    for (let y = 0; y < redImage.height; y++) {
        for (let x = 0; x < redImage.width; x++) {
            let rVal = redImage.sample(x, y);
            rgbImage.setSample(rVal, x + offsetR_x, y + offsetR_y, 0);
        }
    }
    // Green channel:
    for (let y = 0; y < greenImage.height; y++) {
        for (let x = 0; x < greenImage.width; x++) {
            let gVal = greenImage.sample(x, y);
            rgbImage.setSample(gVal, x + offsetG_x, y + offsetG_y, 1);
        }
    }
    // Blue channel:
    for (let y = 0; y < blueImage.height; y++) {
        for (let x = 0; x < blueImage.width; x++) {
            let bVal = blueImage.sample(x, y);
            rgbImage.setSample(bVal, x + offsetB_x, y + offsetB_y, 2);
        }
    }

        // If the resulting image has an alpha channel, fill it with ones (fully opaque).
    // Some image windows might be constructed with a hidden alpha channel.
    if (rgbImage.numberOfChannels > 3) {
        for (let y = 0; y < compositeHeight; y++) {
            for (let x = 0; x < compositeWidth; x++) {
                rgbImage.setSample(1.0, x, y, 3);
            }
        }
    }

    rgbWin.mainView.endProcess();

    // Clean up the intermediate resampled windows.
    redWin.forceClose();
    greenWin.forceClose();
    blueWin.forceClose();


    return rgbWin;
}








function getNormalizedScale(size, minSize, maxSize, minScale, maxScale) {
    if (maxSize === minSize)
        return minScale;

    let t = (size - minSize) / (maxSize - minSize);
    t = Math.min(Math.max(t, 0), 1); // clamp
    let scale = minScale + t * (maxScale - minScale);
    return Math.round(scale * 100) / 100;
}



function generateSpikeCache(stars, spikeImage, numBuckets, amount) {
    let sizes = stars.map(s => 0.5 * (s.sx + s.sy));
    let minSize = Math.min.apply(null, sizes);
    let maxSize = Math.max.apply(null, sizes);

    const minScale = 0.02;
    const maxScale = 0.15;

    let scaleFactors = [];
    for (let i = 0; i < numBuckets; ++i) {
        let t = i / (numBuckets - 1);
        let rawSize = minSize + t * (maxSize - minSize);
        let scale = getNormalizedScale(rawSize, minSize, maxSize, minScale, maxScale);
        scaleFactors.push(scale);
    }

    scaleFactors = uniqueArray(scaleFactors);

    let scaledSpikes = {};
    for (let i = 0; i < scaleFactors.length; ++i) {
        let sf = scaleFactors[i];
        // Use the new RGB resampling function.
        let win = resampleSpikeImageRGB(spikeImage, sf);
        // Crop and feather the spike image to remove hard borders.
        let processedWin = cropAndFeatherSpikeImage(win);
        // Apply the curves boost to the processed spike image.
        // Adjust the boost parameter (here, 3) according to your needs.
       applyPixelMath(processedWin, amount);
        scaledSpikes[sf] = {
            window: processedWin,
            image: processedWin.mainView.image
        };
    }

    return {
        scaleFactors: scaleFactors,
        scaledSpikes: scaledSpikes,
        minSize: minSize,
        maxSize: maxSize,
        minScale: minScale,
        maxScale: maxScale
    };
}





function applyPixelMath(spikeWindow, amount) {
    var P = new PixelMath;
    P.expression = "((3^" + amount + ")*$T)/((3^" + amount + " - 1)*$T + 1)";
    P.useSingleExpression = true;
    P.generateOutput = true;
    P.createNewImage = false;
    P.executeOn(spikeWindow.mainView);

    var blur = new Convolution;
    blur.mode = Convolution.prototype.Parametric;
    blur.sigma = 1.00;
    blur.shape = 2.00;
    blur.aspectRatio = 1.00;
    blur.rotationAngle = 0.00;
    blur.filterSource = "";
    blur.rescaleHighPass = false;
    blur.viewId = "";
    blur.executeOn(spikeWindow.mainView); // 👈 this now works correctly

   var P = new PixelMath;
    P.expression = "$T-1*med($T)";
    P.useSingleExpression = true;
    P.generateOutput = true;
    P.createNewImage = false;
    P.executeOn(spikeWindow.mainView);
}

function applyCurvesBoost(spikeWindow, n) {
   // Get the spike image from the window.
   let img = spikeWindow.mainView.image;
   // Use the median() method to get the median brightness value.
   let medVal = img.median();
   console.writeln("Spike image median: " + medVal);

   // Define our anchor points.
   // [0, 0] : Black remains black.
   // [medVal, medVal] : Preserve the median.
   // [ (1 + medVal)/2, ( (1 + medVal)/2 )^(1/n) ] : Boost mid-tones.
   // [1, 1] : White remains white.
   let anchor1 = [0.0, 0.0];
   let anchor2 = [.1,.1];
   let midX = .5;
   let anchor3 = [ midX, Math.pow(midX, 1.0 / n) ];
   let anchor4 = [1.0, 1.0];

   // Create and configure the curves transformation.
   let curves = new CurvesTransformation;
   curves.K = [anchor1, anchor2, anchor3, anchor4];
   curves.Kt = CurvesTransformation.prototype.AkimaSubsplines;

   // Execute the transformation in-place.
   curves.executeOn(spikeWindow.mainView);
}


    // Deduplicate
function uniqueArray(array) {
    var seen = {};
    var out = [];
    for (var i = 0; i < array.length; ++i) {
        var val = array[i];
        if (!seen[val]) {
            seen[val] = true;
            out.push(val);
        }
    }
    return out;
}

function applySpikesToImage(
    targetWindow, stars, scaledSpikes, scaleFactors,
    minSize, maxSize, minScale, maxScale, boostAmount, starThresholdPercent, showStars)
{
    let width = targetWindow.mainView.image.width;
    let height = targetWindow.mainView.image.height;
    let originalImage = targetWindow.mainView.image;
    let isColor = originalImage.numberOfChannels === 3;

    // Filter the stars based on the threshold.
    // We'll use 0.5*(s.sx+s.sy) as a brightness measure.
    // Sort the stars in descending order (brightest first).
    stars.sort(function(a, b) {
        let brightnessA = 0.5 * (a.sx + a.sy);
        let brightnessB = 0.5 * (b.sx + b.sy);
        return brightnessB - brightnessA;
    });
    // Determine how many stars to keep.
    // starThresholdPercent is expected to be in the range 0 to 100.
    // For example, if starThresholdPercent is 10, then we keep the top 10% brightest stars.
    let keepCount = Math.floor(stars.length * (starThresholdPercent / 100.0));
    // If starThresholdPercent is 0, no stars are kept.
    stars = stars.slice(0, keepCount);

    // Ensure the canvas is 3-channel so we can apply colorized spikes.
    let spikeCanvas = new ImageWindow(width, height, 3, 32, true, false);
        spikeCanvas.mainView.beginProcess(UndoFlag_NoSwapFile);
        spikeCanvas.mainView.image.colorSpace = ColorSpace_RGB;
    let canvas = spikeCanvas.mainView.image;



    // Process each detected star.
    for (let i = 0; i < stars.length; ++i) {
        let s = stars[i];
        let cx = Math.round(s.cx);
        let cy = Math.round(s.cy);

        // --- Sample local star color (averaged from a 3x3 region) ---
        let starColor = [0, 0, 0];
        if (isColor) {
            let count = 0;
            for (let dy = -1; dy <= 1; ++dy) {
                for (let dx = -1; dx <= 1; ++dx) {
                    let x = cx + dx;
                    let y = cy + dy;
                    if (x >= 0 && x < width && y >= 0 && y < height) {
                        for (let c = 0; c < 3; ++c)
                            starColor[c] += originalImage.sample(x, y, c);
                        count++;
                    }
                }
            }
            if (count > 0) {
                for (let c = 0; c < 3; ++c)
                    starColor[c] /= count;
            }
        }
        else {
            let grayVal = originalImage.sample(cx, cy);
            starColor = [grayVal, grayVal, grayVal];
        }

        // --- Normalize star color so that the brightest channel equals 1.0 ---
        let maxChannel = Math.max(starColor[0], starColor[1], starColor[2], 1e-6);
        let normColor = starColor.map(v => v / maxChannel);

        // --- Choose best spike scale based on star size ---
        let raw = 0.5 * (s.sx + s.sy);
        let scale = getNormalizedScale(raw, minSize, maxSize, minScale, maxScale);
        let bestScale = scaleFactors.reduce((prev, curr) =>
            Math.abs(curr - scale) < Math.abs(prev - scale) ? curr : prev);

        // Retrieve the cached spike image. It is assumed to be an RGB image
        // where the red channel has the largest size and the green/blue channels have been padded.
        let scaledSpike = scaledSpikes[bestScale].image;
        let sw = scaledSpike.width;
        let sh = scaledSpike.height;
        let scx = Math.floor(sw / 2);
        let scy = Math.floor(sh / 2);

        // --- Blend the spike image into the canvas ---
        // The spikes are applied such that the spike's center aligns with (cx, cy).
        for (let sySpike = 0; sySpike < sh; ++sySpike) {
            for (let sxSpike = 0; sxSpike < sw; ++sxSpike) {
                let targetX = cx + sxSpike - scx;
                let targetY = cy + sySpike - scy;
                if (targetX >= 0 && targetX < width && targetY >= 0 && targetY < height) {
                    for (let c = 0; c < 3; ++c) {
                        let spikeVal = scaledSpike.sample(sxSpike, sySpike, c);
                        let current = canvas.sample(targetX, targetY, c);
                        // Multiply the spike's per-channel value by the normalized star color.
                        let blended = Math.min(1.0, current + spikeVal * normColor[c]);
                        canvas.setSample(blended, targetX, targetY, c);
                    }
                }
            }
        }
    }
spikeCanvas.mainView.id = "Generated_Stars";

    spikeCanvas.mainView.endProcess();
    if (canvas.numberOfChannels > 3) {
        spikeCanvas.mainView.beginProcess(UndoFlag_NoSwapFile);
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                // Set alpha (channel index 3) to 1 (fully opaque).
                canvas.setSample(1.0, x, y, 3);
            }
        }
        spikeCanvas.mainView.endProcess();
    }
    // --- Boost & normalize the spike layer (as before) ---
    //applyPixelMath(spikeCanvas, boostAmount);

    applyCurvesBoost(spikeCanvas, boostAmount);

    // --- Blend spikeCanvas with target image using the spike shape as a mask ---
    let PM = new PixelMath;
    PM.expression = "~(~$T * ~" + spikeCanvas.mainView.id + ")";
    PM.useSingleExpression = true;
    PM.generateOutput = true;
    PM.createNewImage = false;
    PM.executeOn(targetWindow.mainView);

        let PM = new PixelMath;
    PM.expression = "~(~$T * ~" + spikeCanvas.mainView.id + ")";
    PM.useSingleExpression = true;
    PM.generateOutput = true;
    PM.createNewImage = false;
    PM.executeOn(targetWindow.mainView);

    // --- Clean up spike cache windows ---
    for (let i = 0; i < scaleFactors.length; ++i) {
        let win = scaledSpikes[scaleFactors[i]].window;
        if (win && win.isWindow)
            win.forceClose();
    }

   if (showStars)
      spikeCanvas.show();
   else
      spikeCanvas.forceClose();

    // --- Clean up FFT temporary views if they exist ---
    let magWin = ImageWindow.windowById("DFT_magnitude");
    let phaWin = ImageWindow.windowById("DFT_phase");
    if (magWin && magWin.isWindow) magWin.forceClose();
    if (phaWin && phaWin.isWindow) phaWin.forceClose();
}



function main() {
    console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");

    let dlg = new StarSpikeDialog();
    dlg.execute();
}

main();

