#feature-id StatisticalStretch : Utilities > Statistical Stretch
#feature-info This script performs a determines dynamically statistical properties of the image and logirthmically stretches accordingly.

#include <pjsr/Sizer.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/NumericControl.jsh>

#define TITLE "Statistical Astro Stretching"
#define VERSION "1.2"

// Global parameters object
var SHOParameters = {
    targetView: undefined,
    targetMedian: 0.25,
    applyCurveTransformation: false,
    curvesBoost: 0.00,
    numIterations: 1,
    normalizeImageRange: true,  // Default value for normalization

    newInstance: function() {
        console.writeln("New instance created.");
    },

    save: function() {
        Parameters.set("targetView", this.targetView ? this.targetView.id : "");
        Parameters.set("targetMedian", this.targetMedian);
        Parameters.set("applyCurveTransformation", this.applyCurveTransformation);
        Parameters.set("curvesBoost", this.curvesBoost);
        Parameters.set("numIterations", this.numIterations);
        Parameters.set("normalizeImageRange", this.normalizeImageRange);  // Save normalization setting
    },

    load: function() {
        if (Parameters.has("targetView"))
            this.targetView = ImageWindow.windowById(Parameters.getString("targetView")).mainView;
        if (Parameters.has("targetMedian"))
            this.targetMedian = Parameters.getReal("targetMedian");
        if (Parameters.has("applyCurveTransformation"))
            this.applyCurveTransformation = Parameters.getBoolean("applyCurveTransformation");
        if (Parameters.has("curvesBoost"))
            this.curvesBoost = Parameters.getReal("curvesBoost");
        if (Parameters.has("numIterations"))
            this.numIterations = Parameters.getInteger("numIterations");
        if (Parameters.has("normalizeImageRange"))  // Load normalization setting
            this.normalizeImageRange = Parameters.getBoolean("normalizeImageRange");
    },

    main: function() {
        // Load parameters if available
        this.load();

        // Execute directly if there's a predefined target view (from Parameters)
        if (Parameters.isViewTarget && Parameters.targetView) {
            this.executeAlgorithm(this.numIterations);
        } else {
            // Otherwise, open the dialog for user input
            let dialog = new MyDialog();
            if (dialog.execute()) {
                // Check if a valid target view has been selected
                if (this.targetView && this.targetView.id) {
                    this.executeAlgorithm(this.numIterations);
                } else {
                    console.writeln("No target view specified.");
                }
            } else {
                console.writeln("Dialog execution cancelled.");
            }
        }
    },

    executeAlgorithm: function(iteration) {
        if (!this.targetView) {
            console.writeln("No target view specified.");
            return;
        }

        for (let i = 0; i < iteration; i++) {
            if (this.targetView.image.isColor) {
                processColorImage(this.targetView, this.targetMedian, i + 1);
            } else {
                processMonoImage(this.targetView, this.targetMedian, i + 1);
            }
        }

        if (iteration === this.numIterations && this.applyCurveTransformation) {
            applyFinalCurve(this.targetView, this.targetMedian);
        }
    }
};

// Call the load method to initialize parameters if needed
SHOParameters.load();


function MyDialog() {
    this.__base__ = Dialog;
    this.__base__();

    // Initialize the main VerticalSizer for the dialog
    this.algorithmSizer = new VerticalSizer;
    this.algorithmSizer.spacing = 6;

    // Title and instruction setup
    this.titleSizer = new VerticalSizer;
    this.titleSizer.spacing = 4;
    this.titleBox = new Label(this);
    this.titleBox.text = "Statistical Stretch " + VERSION;
    this.titleBox.textAlignment = TextAlign_Center;
    this.titleBox.frameStyle = FrameStyle_Box;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
    this.titleBox.setFixedHeight(30);
    this.titleSizer.add(this.titleBox);

    this.instructionsBox = new Label(this);
   this.instructionsBox.text = "Select your image in the dropdown.\n" +
                            "\n" +
                            "Use the slider to adjust your Target Median Value.\n" +
                            "  0.10 is a good start for distinct objects eg galaxy or PN.\n" +
                            "  0.25 is a good start for distended objects like nebula filling the image.\n" +
                            "Iterate successively to optionally reach statistical equilibrium.";
    this.instructionsBox.textAlignment = TextAlign_Left;
    this.instructionsBox.frameStyle = FrameStyle_Box;
    this.instructionsBox.styleSheet = "font-size: 10pt; padding: 10px; background-color: #e6e6fa;";
    this.instructionsBox.setFixedHeight(125);
    this.titleSizer.add(this.instructionsBox);

    // Add titleSizer to the main layout
    this.algorithmSizer.add(this.titleSizer);

    // Image selection setup
    this.imageSizer = new HorizontalSizer;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image to Stretch:";
    this.imageLabel.textAlignment = TextAlign_Left;
    this.imageList = new ComboBox(this);
    this.imageList.addItem("no view selected");
    for (let i = 0; i < ImageWindow.windows.length; i++) {
        this.imageList.addItem(ImageWindow.windows[i].mainView.id);
    }
    this.imageList.currentItem = 0;
    this.imageList.editEnabled = false;
    this.imageList.dropdownWidth = 350;
    this.imageList.setMinWidth(350);
    this.imageSizer.add(this.imageLabel);
    this.imageSizer.add(this.imageList);
    this.algorithmSizer.add(this.imageSizer);

    // Numeric controls for target median and iterations
    this.targetMedianControl = new NumericControl(this);
    this.targetMedianControl.label.text = "Target Median:";
    this.targetMedianControl.setRange(0, 1);
    this.targetMedianControl.slider.setRange(0, 100);
    this.targetMedianControl.slider.scale = 0.01;
    this.targetMedianControl.setValue(0.25);
    this.targetMedianControl.setPrecision(2);
    this.targetMedianControl.onValueUpdated = (function(value) {
        SHOParameters.targetMedian = value;
    }).bind(this);
    this.algorithmSizer.add(this.targetMedianControl);

    this.iterationsControl = new NumericControl(this);
    this.iterationsControl.label.text = "Number of Iterations:";
    this.iterationsControl.setRange(1, 5);
    this.iterationsControl.setValue(SHOParameters.numIterations);
    this.iterationsControl.setPrecision(0);
    this.iterationsControl.onValueUpdated = (function(value) {
        SHOParameters.numIterations = value;
    }).bind(this);
    this.algorithmSizer.add(this.iterationsControl);

   // Checkbox for Normalizing Image Range
   this.normalizeImageRangeCheckbox = new CheckBox(this);
   this.normalizeImageRangeCheckbox.text = "Normalize Image Range";
   this.normalizeImageRangeCheckbox.checked = SHOParameters.normalizeImageRange; // Set checked state based on loaded settings
   this.normalizeImageRangeCheckbox.onCheck = function(checked) {
       SHOParameters.normalizeImageRange = checked;
   };
    this.algorithmSizer.add(this.normalizeImageRangeCheckbox);

    // Final curves transformation setup
    this.applyCurveCheckbox = new CheckBox(this);
    this.applyCurveCheckbox.text = "Apply Final Sigma Curves Boost";
    this.applyCurveCheckbox.checked = SHOParameters.applyCurveTransformation;
    this.applyCurveCheckbox.onCheck = function(checked) {
        SHOParameters.applyCurveTransformation = checked;
        this.curvesBoostSlider.visible = checked;
        this.adjustToContents();
    }.bind(this);
    this.algorithmSizer.add(this.applyCurveCheckbox);

    this.curvesBoostSlider = new NumericControl(this);
    this.curvesBoostSlider.label.text = "Curves Boost:";
    this.curvesBoostSlider.setRange(0.00, 0.30);
    this.curvesBoostSlider.slider.setRange(0, 300);
    this.curvesBoostSlider.slider.scale = 0.001;
    this.curvesBoostSlider.setValue(0.00);
    this.curvesBoostSlider.setPrecision(2);
    this.curvesBoostSlider.visible = SHOParameters.applyCurveTransformation;
    this.curvesBoostSlider.onValueUpdated = function(value) {
        SHOParameters.curvesBoost = value;
    };
    this.algorithmSizer.add(this.curvesBoostSlider);

    // Footer with authorship and website information
    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "Written by Franklin Marek";
    this.authorshipLabel.textAlignment = TextAlign_Center;
    this.algorithmSizer.add(this.authorshipLabel);

    this.websiteLabel = new Label(this);
    this.websiteLabel.text = "www.setiastro.com";
    this.websiteLabel.textAlignment = TextAlign_Center;
    this.algorithmSizer.add(this.websiteLabel);

    // Button setup
    this.buttonSizer = new HorizontalSizer;
    this.buttonSizer.spacing = 6;
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = () => {
        SHOParameters.save();
        this.newInstance();
    };
    this.buttonSizer.add(this.newInstanceButton);
    this.buttonSizer.addStretch();

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.onClick = () => {
        let iterations = this.iterationsControl.value;
        this.executeAlgorithm(iterations);
    };
    this.buttonSizer.add(this.executeButton);
    this.algorithmSizer.add(this.buttonSizer);

    // Set the main dialog layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.add(this.algorithmSizer);
    this.windowTitle = TITLE + " v" + VERSION;
    this.adjustToContents();
}

MyDialog.prototype = new Dialog;


MyDialog.prototype.executeAlgorithm = function(iteration) {
    if (this.imageList.currentItem < 0) {
        (new MessageBox("No image selected for processing.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let targetView = ImageWindow.windowById(this.imageList.itemText(this.imageList.currentItem)).mainView;
    for (let i = 0; i < iteration; i++) {
        if (targetView.image.isColor) {
            processColorImage(targetView, SHOParameters.targetMedian, i + 1);
        } else {
            processMonoImage(targetView, SHOParameters.targetMedian, i + 1);
        }
    }

    if (iteration === this.iterationsControl.value && this.applyCurveCheckbox.checked) {
        applyFinalCurve(targetView, SHOParameters.targetMedian);
    }
};

function applyFinalCurve(targetView, targetMedian) {
    let P = new CurvesTransformation();
    P.Bt = CurvesTransformation.prototype.AkimaSubsplines;
      // In your CurvesTransformation setup
      P.K = [
          [0.00000, 0.00000],
          [0.5 * SHOParameters.targetMedian, 0.5 * SHOParameters.targetMedian],
          [SHOParameters.targetMedian, SHOParameters.targetMedian],
          [(3 * SHOParameters.targetMedian + 1) / 4, 0.25 * (-3 * SHOParameters.curvesBoost * SHOParameters.targetMedian + 3 * SHOParameters.curvesBoost + 3 * SHOParameters.targetMedian + 1)],
          [1.00000, 1.00000]
      ];

    P.St = CurvesTransformation.prototype.AkimaSubsplines;
    P.executeOn(targetView);
    console.noteln("Final Sigma Curves applied successfully after all iterations.");
}

function processMonoImage(targetView, targetMedian, iteration) {
    var P = new ProcessContainer;

    var P001 = new PixelMath;
    P001.expression = "BlackPoint = iif((med($T) - 3*sdev($T))<min($T),min($T),med($T) - 3*sdev($T));\n" +
                      "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
    P001.useSingleExpression = true;
    P001.symbols = "BlackPoint, Rescaled, CurrentMedian, DesiredMedian, Alpha";
    P001.clearImageCacheAndExit = false;
    P001.cacheGeneratedImages = false;
    P001.generateOutput = true;
    P001.singleThreaded = false;
    P001.optimization = true;
    P001.use64BitWorkingImage = true;
    P001.rescale = false;
    P001.rescaleLower = 0;
    P001.rescaleUpper = 1;
    P001.truncate = true;
    P001.truncateLower = 0;
    P001.truncateUpper = 1;
    P001.createNewImage = false;
    P001.showNewImage = true;
    P.add(P001);

    var P002 = new PixelMath;
    P002.expression = "L=log((Med($T)*" + targetMedian + "-(" + targetMedian + "))/(Med($T)*(" + targetMedian + "-1)))/log(3);\n" +
                      "S=(3^L*$T)/((3^L-1)*$T+1);";
    P002.useSingleExpression = true;
    P002.symbols = "L, S";
    P002.clearImageCacheAndExit = false;
    P002.cacheGeneratedImages = false;
    P002.generateOutput = true;
    P002.singleThreaded = false;
    P002.optimization = true;
    P002.use64BitWorkingImage = true;
    P002.rescale = false;
    P002.rescaleLower = 0;
    P002.rescaleUpper = 1;
    P002.truncate = true;
    P002.truncateLower = 0;
    P002.truncateUpper = 1;
    P002.createNewImage = false;
    P002.showNewImage = true;
    P.add(P002);

    var P003 = new PixelMath;
    // Check the current state of normalization and set the expression accordingly
    if (SHOParameters.normalizeImageRange) {
        P003.expression = "$T/max($T)";
    } else {
        P003.expression = "$T;";
    }
   P003.useSingleExpression = true;
   P003.symbols = "L, Mcolor, S";
   P003.clearImageCacheAndExit = false;
   P003.cacheGeneratedImages = false;
   P003.generateOutput = true;
   P003.singleThreaded = false;
   P003.optimization = true;
   P003.use64BitWorkingImage = true;
   P003.rescale = false;
   P003.rescaleLower = 0;
   P003.rescaleUpper = 1;
   P003.truncate = true;
   P003.truncateLower = 0;
   P003.truncateUpper = 1;
   P003.createNewImage = false;
   P003.showNewImage = true;
   P.add(P003);

    // Execute the process container on the selected target image
 P.executeOn(targetView);
    console.noteln("Mono Image Statistical Stretch completed successfully for iteration " + iteration + ".");
}

function processColorImage(targetView, targetMedian, iteration) {
       var P = new ProcessContainer;

    var P001 = new PixelMath;
    P001.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                      "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                      "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                      "BlackPoint = iif((MedColor - 3*SDevColor)<MinColor,MinColor,MedColor - 3*SDevColor);\n" +
                      "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
    P001.useSingleExpression = true;
    P001.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
    P001.clearImageCacheAndExit = false;
    P001.cacheGeneratedImages = false;
    P001.generateOutput = true;
    P001.singleThreaded = false;
    P001.optimization = true;
    P001.use64BitWorkingImage = true;
    P001.rescale = false;
    P001.rescaleLower = 0;
    P001.rescaleUpper = 1;
    P001.truncate = true;
    P001.truncateLower = 0;
    P001.truncateUpper = 1;
    P001.createNewImage = false;
    P001.showNewImage = true;
    P.add(P001);

    var P002 = new PixelMath;
    P002.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                      "L=log((MedianColor*" + targetMedian + "-(" + targetMedian + "))/(MedianColor*(" + targetMedian + "-1)))/log(3);\n" +
                      "S=(3^L*$T)/((3^L-1)*$T+1);";
    P002.useSingleExpression = true;
    P002.symbols = "L, MedianColor, S";
    P002.clearImageCacheAndExit = false;
    P002.cacheGeneratedImages = false;
    P002.generateOutput = true;
    P002.singleThreaded = false;
    P002.optimization = true;
    P002.use64BitWorkingImage = true;
    P002.rescale = false;
    P002.rescaleLower = 0;
    P002.rescaleUpper = 1;
    P002.truncate = true;
    P002.truncateLower = 0;
    P002.truncateUpper = 1;
    P002.createNewImage = false;
    P002.showNewImage = true;
    P.add(P002);

    var P003 = new PixelMath;
    // Check the current state of normalization and set the expression accordingly
    if (SHOParameters.normalizeImageRange) {
        P003.expression = "Mcolor=max(max($T[0]),max($T[1]),max($T[2]));\n" +
                          "$T/Mcolor;";
    } else {
        P003.expression = "$T;";
    }
   P003.useSingleExpression = true;
   P003.symbols = "L, Mcolor, S";
   P003.clearImageCacheAndExit = false;
   P003.cacheGeneratedImages = false;
   P003.generateOutput = true;
   P003.singleThreaded = false;
   P003.optimization = true;
   P003.use64BitWorkingImage = true;
   P003.rescale = false;
   P003.rescaleLower = 0;
   P003.rescaleUpper = 1;
   P003.truncate = true;
   P003.truncateLower = 0;
   P003.truncateUpper = 1;
   P003.createNewImage = false;
   P003.showNewImage = true;
   P.add(P003);

    // Execute the process container on the selected target image
 P.executeOn(targetView);
    console.noteln("Color Image Statistical Stretch completed successfully for iteration " + iteration + ".");
};

SHOParameters.main();
