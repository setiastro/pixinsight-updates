#feature-id BlindSolver : SetiAstro > Blind Solver 2000
#feature-info This script allows users to query the astrometrynet client to perform a blind astrometric solve then optionally run Image Solver


/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blind Solver 2000
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows users to query the astrometrynet client to perform a
 * blind astrometric solve then optionally run Image Solver
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/



// Define constants for the script
#define VERSION     "v1.0"
#define TITLE       "Blind Solver 2000"
#define DESCRIPTION "A script to upload an image to astrometry.net for blind plate-solving."

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>


#ifdef __PI_PLATFORM__MACOSX
    #define CMD_EXEC "/bin/sh"
    #define SCRIPT_EXT ".sh"
#endif
#ifdef __PI_PLATFORM__MSWINDOWS
    #define CMD_EXEC "cmd.exe"
    #define SCRIPT_EXT ".bat"
#endif
#ifdef __PI_PLATFORM__LINUX
    #define CMD_EXEC "/bin/sh"
    #define SCRIPT_EXT ".sh"
#endif

// Define the dialog for the Blind Image Solver
function BlindImageSolverDialog() {
    console.hide();
    this.__base__ = Dialog;
    this.__base__();

    // Title
    this.title = TITLE;

        let CMD_EXEC, SCRIPT_EXT;
    if (CoreApplication.platform == "MACOSX") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    } else if (CoreApplication.platform == "MSWINDOWS") {
        CMD_EXEC = "cmd.exe";
        SCRIPT_EXT = ".bat";
    } else if (CoreApplication.platform == "LINUX") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    }

        // File path for storing the API key
    let apiKeyFilePath = File.systemTempDirectory + "/astrometry_api_key.txt";

    // Function to load API key from file
    this.loadApiKey = function() {
        if (File.exists(apiKeyFilePath)) {
            return File.readFile(apiKeyFilePath);
        }
        return "";
    };

    // Function to save API key to file
    this.saveApiKey = function(apiKey) {
        File.writeTextFile(apiKeyFilePath, apiKey);
    };

    // Load API key into a variable and ensure it is a string
    let savedApiKey = String(this.loadApiKey());



    // Image Selection Dropdown
    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i; // Default to active image
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

    // API Key Input
    this.apiKeyLabel = new Label(this);
    this.apiKeyLabel.text = "Astrometry.net API Key:";
    this.apiKeyLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.apiKeyInput = new Edit(this);
    this.apiKeyInput.text = savedApiKey; // Placeholder for the API key

    this.apiKeySizer = new HorizontalSizer;
    this.apiKeySizer.spacing = 4;
    this.apiKeySizer.add(this.apiKeyLabel);
    this.apiKeySizer.add(this.apiKeyInput, 100);

        // Checkbox for Full Image Solver
    this.fullSolverCheckbox = new CheckBox(this);
    this.fullSolverCheckbox.text = "Perform Full Image Solver after Astrometry.net solution collected.";
    this.fullSolverCheckbox.checked = true; // Default to checked

    // Start Button
    this.startButton = new PushButton(this);
    this.startButton.text = "Start Plate Solve";
    this.startButton.onClick = () => {
       this.saveApiKey(this.apiKeyInput.text.trim());
        this.startPlateSolve();
    };

    // Status Text
    this.statusText = new Label(this);
    this.statusText.text = "";
    this.statusText.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    // Close Button
    this.closeButton = new PushButton(this);
    this.closeButton.text = "Close";
    this.closeButton.onClick = () => this.cancel();

    this.buttonSizer = new HorizontalSizer;
    this.buttonSizer.spacing = 6;
    this.buttonSizer.add(this.startButton);
    this.buttonSizer.addStretch();
    this.buttonSizer.add(this.closeButton);

    // Main Sizer
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.add(this.imageSelectionSizer);
    this.sizer.addSpacing(4);
    this.sizer.add(this.apiKeySizer);
    this.sizer.addSpacing(4);
    this.sizer.add(this.fullSolverCheckbox); // Add the checkbox to the dialog
    this.sizer.addSpacing(4);
    this.sizer.add(this.statusText);
    this.sizer.addSpacing(4);
    this.sizer.add(this.buttonSizer);

    this.windowTitle = TITLE + " - " + VERSION;
    this.adjustToContents();
    this.setFixedSize();
}

BlindImageSolverDialog.prototype = new Dialog;

BlindImageSolverDialog.prototype.getSessionKey = function(apiKey) {
    let sessionKey = null;
    let loginUrl = "http://nova.astrometry.net/api/login";

    // Properly formatted JSON string for the API key
    let requestData = "request-json={\\\"apikey\\\":\\\"" + apiKey + "\\\"}";

    let responseFilename = File.systemTempDirectory + "/astrometry_login_response.json";
    if (File.exists(responseFilename)) {
        File.remove(responseFilename);  // Ensure old file is deleted before starting the process
    }

    // Platform-specific variables
    let CMD_EXEC, scriptFilePath, curlCommand, scriptContent;

    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        // macOS specific setup
        CMD_EXEC = "/bin/sh";
        scriptFilePath = File.systemTempDirectory + "/login_curl.sh";
        curlCommand = "/usr/bin/curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
        scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
    } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        // Windows specific setup
        CMD_EXEC = "cmd.exe";
        scriptFilePath = File.systemTempDirectory + "/login_curl.bat";
        curlCommand = "curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
        scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
    } else if (CoreApplication.platform == "LINUX") {
        CMD_EXEC = "/bin/sh";
        scriptFilePath = File.systemTempDirectory + "/login_curl.sh";
        curlCommand = "/usr/bin/curl -X POST -d \"" + requestData + "\" " + loginUrl + " -o " + responseFilename;
        scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return null;
    }

    try {
        // Write the script file (either .bat or .sh based on the platform)
        File.writeTextFile(scriptFilePath, scriptContent);
        console.noteln("Login script file created: " + scriptFilePath);
        console.flush();
    } catch (error) {
        console.criticalln("Failed to create login script file: " + error.message);
        console.flush();
        return null;
    }

    let process = new ExternalProcess;

    try {
        console.show();
        console.writeln("Executing script file using: " + CMD_EXEC + " " + scriptFilePath);
        console.flush();

        // Adjust process execution for macOS (remove "/c")
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            if (!process.start(CMD_EXEC, [scriptFilePath])) {
                console.warningln("Login script process started.");
                console.flush();
            } else {
                console.noteln("Login command launched successfully.");
                console.flush();
            }
        } else {
            // For Windows, use "/c"
            if (!process.start(CMD_EXEC, ["/c", scriptFilePath])) {
                console.warningln("Login script process started.");
                console.flush();
            } else {
                console.noteln("Login command launched successfully.");
                console.flush();
            }
        }

        // Wait for the response file to be created
        let maxWaitTime = 15000;  // Maximum wait time of 15 seconds (adjust as needed)
        let waitTime = 0;

        while (!File.exists(responseFilename)) {
            if (waitTime >= maxWaitTime) {
                console.criticalln("Timeout waiting for response file.");
                return null;
            }
            console.noteln("Waiting for the login process to complete...");
            console.flush();
            msleep(1000);  // Sleep for 1 second between checks
            waitTime += 1000;
        }

        // Once the response file exists, read and process the JSON response
        if (File.exists(responseFilename)) {
            let jsonResponse = JSON.parse(File.readFile(responseFilename));
            console.writeln("Raw JSON response: " + JSON.stringify(jsonResponse));
            console.flush();

            if (jsonResponse.status === "success") {
                sessionKey = jsonResponse.session;
                console.noteln("Login successful, session key: " + sessionKey);
            } else {
                console.warningln("Login failed. Response: " + JSON.stringify(jsonResponse, null, 2));
            }
            // Clean up the response file
            File.remove(responseFilename);
        } else {
            console.warningln("Login script file did not execute as expected.");
            console.flush();
        }
    } catch (error) {
        console.warningln("An error occurred while starting the login script file process: " + error.message);
        console.flush();
    }

    // Clean up the script file after use
    if (File.exists(scriptFilePath)) {
        File.remove(scriptFilePath);
        console.noteln("Script file cleaned up: " + scriptFilePath);
    }

    return sessionKey;
};




// Function to start the plate solve process
BlindImageSolverDialog.prototype.startPlateSolve = function() {
    this.statusText.text = "Starting...";
    this.startButton.enabled = false;

    // Step 1: Save the image first
    let imageFile = this.saveImageAsJpg();
    if (!imageFile) {
        this.statusText.text = "Error saving image.";
        this.startButton.enabled = true;
        return;
    }
    console.noteln("Image saved successfully: " + imageFile);
    console.flush();

    // Step 2: Get the API key
    let apiKey = this.apiKeyInput.text.trim();
    if (!apiKey) {
        this.statusText.text = "API key is required.";
        this.startButton.enabled = true;
        return;
    }

    // Step 3: Obtain the session key
    let sessionKey = this.getSessionKey(apiKey);
    if (!sessionKey) {
        this.statusText.text = "Error obtaining session key.";
        this.startButton.enabled = true;
        return;
    }

    // Step 4: Upload the image to astrometry.net
    this.statusText.text = "Uploading image to astrometry.net...";
    let subid = this.uploadImageToAstrometry(imageFile, sessionKey);
    if (!subid) {
        this.statusText.text = "Error uploading image.";
        this.startButton.enabled = true;
        return;
    }

    // Step 5: Poll for submission status and retrieve calibration data
    this.statusText.text = "Submission successful. Waiting for solution...";
    let jobID = this.pollSubmissionStatus(subid);
    if (!jobID) {
        this.statusText.text = "Error retrieving submission status.";
        this.startButton.enabled = true;
        return;
    }

    this.statusText.text = "Solution found. Retrieving calibration data...";
    let calibrationData = this.getJobCalibration(jobID);
    if (!calibrationData) {
        this.statusText.text = "Error retrieving calibration data.";
        this.startButton.enabled = true;
        return;
    }

    this.applyAstrometricSolution(calibrationData);

    this.statusText.text = "Plate solve completed!";
    console.hide();
    this.startButton.enabled = true;
};

// Save the image as .jpg
BlindImageSolverDialog.prototype.saveImageAsJpg = function() {
    let selectedWindow = ImageWindow.activeWindow;
    let homeDir = File.systemTempDirectory;
    let jpgPath = homeDir + "/temp_image.jpg";
    let exportImage = new ImageWindow(
        selectedWindow.mainView.image.width,
        selectedWindow.mainView.image.height,
        3, // RGB
        8, // 8-bit depth
        false, // no alpha
        false, // no grayscale
        selectedWindow.mainView.id + "_temp"
    );
    exportImage.mainView.beginProcess(UndoFlag_NoSwapFile);
    exportImage.mainView.image.assign(selectedWindow.mainView.image);
    exportImage.mainView.endProcess();

    // Manually set JPEG save options
    let fileSaveOptions = {
        compression: 9, // Maximum quality for JPEG
        overwrite: true  // Suppress overwrite confirmation
    };

    exportImage.saveAs(jpgPath, false, false, false, false); // Save without dialogs
    exportImage.close();
    console.noteln("Image saved successfully: " + jpgPath);
    return jpgPath;
};

// Upload image to astrometry.net
BlindImageSolverDialog.prototype.uploadImageToAstrometry = function(imageFile, sessionKey) {
    let subid = null;

    // Create a temporary file to store the response
    let responseFilename = File.systemTempDirectory + "/astrometry_response.json";
    if (File.exists(responseFilename)) {
        File.remove(responseFilename);
    }

    // Platform-specific setup
    let CMD_EXEC, scriptFilePath, curlCommand, scriptContent;
    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        CMD_EXEC = "/bin/sh";
        scriptFilePath = File.systemTempDirectory + "/run_curl.sh";
        curlCommand = "/usr/bin/curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                      " -F \"file=@" + imageFile + "\" " +
                      "http://nova.astrometry.net/api/upload -o " + responseFilename;
        scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
    } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        CMD_EXEC = "cmd.exe";
        scriptFilePath = File.systemTempDirectory + "/run_curl.bat";
        curlCommand = "curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                      " -F \"file=@" + imageFile + "\" " +
                      "http://nova.astrometry.net/api/upload -o " + responseFilename;
        scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
    } else if (CoreApplication.platform == "LINUX") {
        CMD_EXEC = "/bin/sh";
        scriptFilePath = File.systemTempDirectory + "/run_curl.sh";
        curlCommand = "/usr/bin/curl -v -F \"request-json={\\\"publicly_visible\\\": \\\"y\\\", \\\"allow_modifications\\\": \\\"d\\\", \\\"session\\\": \\\"" + sessionKey + "\\\", \\\"allow_commercial_use\\\": \\\"d\\\"}\"" +
                      " -F \"file=@" + imageFile + "\" " +
                      "http://nova.astrometry.net/api/upload -o " + responseFilename;
        scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return null;
    }

    // Write the script file and log the content to the console
    console.writeln("Script content:");
    console.writeln(scriptContent);  // This logs the entire script content for debugging purposes
    console.flush();

    try {
        // Write the script file (either .bat or .sh based on the platform)
        File.writeTextFile(scriptFilePath, scriptContent);
        console.noteln("Curl script file created: " + scriptFilePath);
        console.flush();
    } catch (error) {
        console.criticalln("Failed to create curl script file: " + error.message);
        console.flush();
        return null;
    }

    let process = new ExternalProcess();

    try {
        console.show();
        console.writeln("Executing curl script file using: " + CMD_EXEC + " " + scriptFilePath);
        console.flush();

        // Adjust process execution for macOS (remove "/c")
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            if (!process.start(CMD_EXEC, [scriptFilePath])) {
                console.warningln("Curl script process started.");
                console.flush();
            } else {
                console.noteln("Curl launched successfully.");
                console.flush();
            }
        } else {
            // For Windows, use "/c"
            if (!process.start(CMD_EXEC, ["/c", scriptFilePath])) {
                console.warningln("Curl process started.");
                console.flush();
            } else {
                console.noteln("Curl launched successfully.");
                console.flush();
            }
        }

        // Wait for the response file to be created
        let maxWaitTime = 15000;  // Maximum wait time of 15 seconds
        let waitTime = 0;

        while (!File.exists(responseFilename)) {
            if (waitTime >= maxWaitTime) {
                console.criticalln("Timeout waiting for curl response file.");
                return null;
            }
            console.noteln("Waiting for the curl process to complete...");
            console.flush();
            msleep(1000);  // Sleep for 1 second between checks
            waitTime += 1000;
        }

        // Once the response file exists, read and process the JSON response
        if (File.exists(responseFilename)) {
            let jsonResponse = JSON.parse(File.readFile(responseFilename));
            console.writeln("Raw JSON response: " + JSON.stringify(jsonResponse));
            console.flush();

            if (jsonResponse.status === "success") {
                subid = jsonResponse.subid;
                console.noteln("Submission successful, subid: " + subid);
            } else {
                console.warningln("Submission failed. Response: " + JSON.stringify(jsonResponse, null, 2));
            }
            // Clean up the response file **after** processing is done
            File.remove(responseFilename);
        } else {
            console.warningln("Curl script did not execute as expected.");
            console.flush();
        }
    } catch (error) {
        console.warningln("An error occurred while starting the curl script process: " + error.message);
        console.flush();
    }

    // Clean up the script file after use
    if (File.exists(scriptFilePath)) {
        File.remove(scriptFilePath);
        console.noteln("Curl script file cleaned up: " + scriptFilePath);
    }

    return subid;
};


// Poll submission status
BlindImageSolverDialog.prototype.pollSubmissionStatus = function(subid) {
    let jobID = null;
    let retries = 0;
    const maxRetries = 90; // Wait for up to 15 minutes (90 * 10 seconds)

    // Platform-specific setup
    let CMD_EXEC, SCRIPT_EXT;
    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        CMD_EXEC = "cmd.exe";
        SCRIPT_EXT = ".bat";
    } else if (CoreApplication.platform == "LINUX") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return null;
    }

    // Ensure CMD_EXEC and SCRIPT_EXT are defined
    if (!CMD_EXEC || !SCRIPT_EXT) {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return null;
    }

    while (retries < maxRetries) {
        // Create a temporary file to store the response
        let responseFilename = File.systemTempDirectory + "/astrometry_submission_status.json";
        if (File.exists(responseFilename)) {
            File.remove(responseFilename); // Ensure any old response file is deleted
        }

        // Curl command
        let curlCommand = "curl -X GET http://nova.astrometry.net/api/submissions/" + subid + " -o " + responseFilename;

        // Script file path
        let scriptFilePath = File.systemTempDirectory + "/status_curl" + SCRIPT_EXT;

        // Script content
        let scriptContent;
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
            scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
        }

        try {
            // Write the script file
            File.writeTextFile(scriptFilePath, scriptContent);
            console.noteln("Status check script file created: " + scriptFilePath);
            console.flush();
        } catch (error) {
            console.criticalln("Failed to create status check script file: " + error.message);
            console.flush();
            return null;
        }

        let process = new ExternalProcess;

        try {
            console.writeln("Executing status check script file: " + scriptFilePath);
            console.flush();

        // Adjust process execution for macOS (remove "/c")
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            if (!process.start(CMD_EXEC, [scriptFilePath])) {
                console.warningln("Status check process started.");
                console.flush();
            } else {
                console.noteln("Status check launched successfully.");
                console.flush();
            }
        } else {
            // For Windows, use "/c"
            if (!process.start(CMD_EXEC, ["/c", scriptFilePath])) {
                console.warningln("Status check process started.");
                console.flush();
            } else {
                console.noteln("Status check launched successfully.");
                console.flush();
            }
        }

            // Wait for the process to complete or the response file to be created
            let processTimeout = 0;  // A timeout to avoid indefinite waiting for a file that might not get created

            while (process.isRunning || !File.exists(responseFilename)) {
                console.noteln("Waiting for the status check process to complete...");
                console.flush();
                msleep(10000); // Wait for 10 seconds before retrying

                processTimeout += 10000;
                if (processTimeout >= 30000) {  // Set an arbitrary timeout of 30 seconds
                    console.warningln("Process timeout reached.");
                    break;
                }
            }

            // Check if the response file exists
            if (File.exists(responseFilename)) {
                let jsonResponse = JSON.parse(File.readFile(responseFilename));
                console.writeln("Raw JSON response: " + JSON.stringify(jsonResponse));
                console.flush();

                if (jsonResponse.jobs && jsonResponse.jobs.length > 0 && jsonResponse.jobs[0] !== null) {
                    jobID = jsonResponse.jobs[0];
                    console.noteln("Job ID found: " + jobID);
                    File.remove(responseFilename); // Clean up the response file
                    return jobID;
                } else {
                    console.warningln("Job ID not found or is null. Response: " + JSON.stringify(jsonResponse));
                }
                File.remove(responseFilename); // Clean up
            } else {
                let stdErr = process.readStandardError();
                let stdOut = process.readStandardOutput();
                console.warningln("Status check script file did not execute as expected.");
                console.writeln("Standard Output: " + stdOut);
                console.writeln("Standard Error: " + stdErr);
                console.flush();
            }
        } catch (error) {
            console.warningln("An error occurred while starting the status check script file process: " + error.message);
            console.flush();
        }

        console.noteln("Waiting for submission to be processed... (Retry " + (retries + 1) + ")");
        console.flush();
        msleep(10000); // Wait for 10 seconds before retrying
        retries++;
    }

    console.warningln("Max retries reached. Submission status check failed.");
    console.flush();
    return null;
};


// Get job calibration
BlindImageSolverDialog.prototype.getJobCalibration = function(jobID) {
    let calibrationData = null;
    let retries = 0;
    const maxRetries = 90;  // Retry up to 90 times (15 minutes total)
    const waitTime = 10000; // Wait for 10 seconds between retries
    let success = false;

    // Platform-specific setup
    let CMD_EXEC, SCRIPT_EXT;
    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        CMD_EXEC = "cmd.exe";
        SCRIPT_EXT = ".bat";
    } else if (CoreApplication.platform == "LINUX") {
        CMD_EXEC = "/bin/sh";
        SCRIPT_EXT = ".sh";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return null;
    }

    // Define the response file for the calibration data
    let responseFilename = File.systemTempDirectory + "/astrometry_job_calibration.json";
    if (File.exists(responseFilename)) {
        File.remove(responseFilename);  // Remove any old response file
    }

    // Declare scriptFilePath here to ensure it can be used later in the cleanup
    let scriptFilePath = File.systemTempDirectory + "/calibration_curl" + SCRIPT_EXT;

    while (retries < maxRetries && !success) {
        // Curl command to fetch calibration data
        let curlCommand = "curl -X GET http://nova.astrometry.net/api/jobs/" + jobID + "/calibration/ -o " + responseFilename;

        // Script content
        let scriptContent;
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            scriptContent = "#!/bin/bash\n" + curlCommand + "\n";
        } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
            scriptContent = "@echo on\n" + curlCommand + "\nexit\n";
        }

        // Write the script file
        try {
            File.writeTextFile(scriptFilePath, scriptContent);
            console.noteln("Calibration check script file created: " + scriptFilePath);
            console.flush();
        } catch (error) {
            console.criticalln("Failed to create calibration check script file: " + error.message);
            console.flush();
            return null;
        }

        let process = new ExternalProcess;

        try {
            console.writeln("Executing calibration check script file using: " + CMD_EXEC + " " + scriptFilePath);
            console.flush();

        // Adjust process execution for macOS (remove "/c")
        if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
            if (!process.start(CMD_EXEC, [scriptFilePath])) {
                console.warningln("Calibration script process started.");
                console.flush();
            } else {
                console.noteln("Calibration launched successfully.");
                console.flush();
            }
        } else {
            // For Windows, use "/c"
            if (!process.start(CMD_EXEC, ["/c", scriptFilePath])) {
                console.warningln("Calibration script process started.");
                console.flush();
            } else {
                console.noteln("Calibration launched successfully.");
                console.flush();
            }
        }

            // Wait for the process to complete or the response file to be created
            while (process.isRunning || !File.exists(responseFilename)) {
                console.noteln("Waiting for the calibration check process to complete (Retry " + (retries + 1) + "/" + maxRetries + ")...");
                console.flush();
                msleep(waitTime); // Wait for 10 seconds between checks
                retries++;
            }

            // Check if the response file exists and process it
            if (File.exists(responseFilename)) {
                let jsonResponse = JSON.parse(File.readFile(responseFilename));
                console.writeln("Raw JSON response: " + JSON.stringify(jsonResponse));
                console.flush();

                if (jsonResponse && jsonResponse.ra) {
                    calibrationData = jsonResponse;
                    console.noteln("Calibration data retrieved successfully.");
                    success = true;  // Indicate success
                    File.remove(responseFilename);  // Clean up the response file
                } else {
                    console.warningln("Calibration data not available or incomplete. Response: " + JSON.stringify(jsonResponse));
                }
            } else {
                let stdErr = process.readStandardError();
                let stdOut = process.readStandardOutput();
                console.warningln("Calibration check script file did not execute as expected.");
                console.writeln("Standard Output: " + stdOut);
                console.writeln("Standard Error: " + stdErr);
                console.flush();
            }
        } catch (error) {
            console.warningln("An error occurred while starting the calibration check script process: " + error.message);
            console.flush();
        }

        if (!success && retries >= maxRetries) {
            console.warningln("Max retries reached. Calibration data retrieval failed.");
            console.flush();
            break;
        }
    }

    // Clean up the script file after use (now scriptFilePath is correctly in scope)
    if (File.exists(scriptFilePath)) {
        File.remove(scriptFilePath);
        console.noteln("Calibration check script file cleaned up: " + scriptFilePath);
    }

    return calibrationData;
};





BlindImageSolverDialog.prototype.applyAstrometricSolution = function(calibrationData) {
    let selectedWindow = ImageWindow.activeWindow;
    if (selectedWindow.isNull) {
        console.warningln("No active image window found.");
        return;
    }

    console.writeln("Astrometric Solution:");
    console.writeln("RA: " + calibrationData.ra.toFixed(6));
    console.writeln("Dec: " + calibrationData.dec.toFixed(6));
    console.writeln("Pixel Scale: " + calibrationData.pixscale.toFixed(6) + " arcsec/pixel");
    console.writeln("Orientation: " + calibrationData.orientation.toFixed(6) + " degrees");
    console.writeln("Parity: " + calibrationData.parity);
    console.flush();

    try {
        let view = selectedWindow.mainView;

        // Convert pixel scale to degrees per pixel
        let resolution = calibrationData.pixscale / 3600;  // Convert arcsec/pixel to deg/pixel

        // Set FITS header directly with WCS-related metadata
        let keywords = [
            new FITSKeyword("CTYPE1", "RA---TAN", "Coordinate type for axis 1"),
            new FITSKeyword("CTYPE2", "DEC--TAN", "Coordinate type for axis 2"),
            new FITSKeyword("CRVAL1", calibrationData.ra.toFixed(6), "Reference value for axis 1"),
            new FITSKeyword("CRVAL2", calibrationData.dec.toFixed(6), "Reference value for axis 2"),
            new FITSKeyword("CRPIX1", (view.image.width / 2 + 0.5).toFixed(6), "Reference pixel for axis 1"),
            new FITSKeyword("CRPIX2", (view.image.height / 2 + 0.5).toFixed(6), "Reference pixel for axis 2"),
            new FITSKeyword("CD1_1", (-Math.cos(calibrationData.orientation * Math.PI / 180) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 1_1"),
            new FITSKeyword("CD1_2", (Math.sin(calibrationData.orientation * Math.PI / 180) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 1_2"),
            new FITSKeyword("CD2_1", (-Math.sin(calibrationData.orientation * Math.PI / 180) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 2_1"),
            new FITSKeyword("CD2_2", (-Math.cos(calibrationData.orientation * Math.PI / 180) * calibrationData.pixscale / 3600).toFixed(12), "Transformation matrix element 2_2"),
            new FITSKeyword("RADECSYS", "ICRS", "Coordinate reference system")
        ];

        // Add these keywords to the current image
        selectedWindow.keywords = keywords;

        console.noteln("Astrometric solution applied successfully.");

                // Check if the full ImageSolver should be run
        if (this.fullSolverCheckbox.checked) {
            console.noteln("Running Full ImageSolver...");
            this.statusText.text = "Running Image Solver.";

        #include "AdP/ImageSolver.js"  // Include the ImageSolver script

        // Now run ImageSolver with the necessary parameters
        let P = new Script;
        P.filePath = "$PXI_SRCDIR/scripts/AdP/ImageSolver.js";

        P.parameters = [
            // Metadata parameters
            ["metadata_focal", "946.1306914742877"],  // Adjust with the correct focal length
            ["metadata_useFocal", "false"],           // Assuming useFocal is false
            ["metadata_xpixsz", "3.799999952316284"], // Pixel size in microns (adjust as necessary)
            ["metadata_resolution", resolution.toString()], // Resolution in degrees per pixel
            ["metadata_referenceSystem", "ICRS"],
            ["metadata_ra", calibrationData.ra.toString()],
            ["metadata_dec", calibrationData.dec.toString()],
            ["metadata_observationTime", "2451545"],  // Julian Date (adjust as necessary)
            ["metadata_topocentric", "false"],

        ];

        P.information = "ImageSolver Script Execution";

        }

    } catch (error) {
        console.criticalln("Failed to apply astrometric solution.");
        if (typeof error === 'object' && error !== null) {
            console.criticalln("Error details: " + JSON.stringify(error, null, 2));
        } else {
            console.criticalln("Unknown error occurred during astrometric solution application.");
        }
    }
};
\
// Main Execution
let dialog = new BlindImageSolverDialog();
dialog.execute();
