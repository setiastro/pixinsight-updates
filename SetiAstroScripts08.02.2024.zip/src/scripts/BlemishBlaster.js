#feature-id BlemishBlaster : SetiAstro > Blemish Blaster
#feature-info This script allows blemish removal in astrophotographic images by averaging the surrounding area to replace the selected spot.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Blemish Blaster
 * Version: V1.2
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows blemish removal in astrophotographic images by averaging
 * the surrounding area to replace the selected spot.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define TITLE "Blemish Blaster"
#define VERSION "V1.2"

let parameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    autoSTFApplied: false,
    save: function() {
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        Parameters.set("autoSTFApplied", this.autoSTFApplied ? "true" : "false");
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function() {
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("autoSTFApplied")) {
            this.autoSTFApplied = Parameters.getBoolean("autoSTFApplied");
        }
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
    },
    newInstance: function() {
        console.writeln("New instance created.");
    }
};

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.displayImageWindow = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.debugPoints = [];
      this.currentCircle = null;

    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.zoomFactor = 1;
    this.minZoomFactor = 0.05;
    this.maxZoomFactor = 1;

    this.currentMousePosition = { x: 0, y: 0 };

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.initScrollBars = function(scrollPoint = null) {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
            this.scrollPosition = new Point(0, 0);
        } else {
            let zoomFactor = this.zoomFactor;
            this.setHorizontalScrollRange(0, Math.max(0, 4* image.width * zoomFactor));
            this.setVerticalScrollRange(0, Math.max(0,4* image.height * zoomFactor));
            if (scrollPoint) {
                this.scrollPosition = scrollPoint;
            } else {
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, 4*image.width * zoomFactor),
                    Math.min(this.scrollPosition.y,4* image.height * zoomFactor)
                );
            }
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        let zoomFactor = parent.zoomFactor;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        if (modifiers === 1) {
            // Start drawing the circle
            parent.currentCircle = { x: adjustedX, y: adjustedY, radius: 0 };
        } else if (button === 2) { // Right-click to remove the closest point
            parent.removeBlemishPoint(adjustedX, adjustedY);
        } else {
            this.cursor = new Cursor(StdCursor_ClosedHand);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
            parent.dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        var parent = this.parent;
        if (!parent) return;

        let zoomFactor = parent.zoomFactor;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        parent.currentMousePosition = { x: adjustedX, y: adjustedY };

        if (parent.currentCircle) {
            let dx = adjustedX - parent.currentCircle.x;
            let dy = adjustedY - parent.currentCircle.y;
            parent.currentCircle.radius = Math.sqrt(dx * dx + dy * dy);
        }

        if (parent.dragging) {
            let dx = (parent.dragOrigin.x - x) / parent.zoomFactor;
            let dy = (parent.dragOrigin.y - y) / parent.zoomFactor;
            parent.scrollPosition = new Point(parent.scrollPosition.x + dx, parent.scrollPosition.y + dy);
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
        }
        if (parent.viewport) {
            parent.viewport.update();
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        if (!parent) return;
        this.cursor = new Cursor(StdCursor_Cross);
        parent.dragging = false;

        if (parent.currentCircle && parent.currentCircle.radius > 0) {
            parent.placeBlemishPoint(parent.currentCircle.x, parent.currentCircle.y, parent.currentCircle.radius);
            parent.currentCircle = null;
        }
    };

    this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
        var parent = this.parent;

        if (!parent.displayImage) {
            console.error("No display image set.");
            return;
        }

        let oldZoomFactor = parent.zoomFactor;

        let maxHorizontalScroll = 4*(parent.displayImage.width * oldZoomFactor);
        let maxVerticalScroll = 4*(parent.displayImage.height * oldZoomFactor);
        let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
        let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }
        let newZoomFactor = parent.zoomFactor;

        parent.initScrollBars();

        maxHorizontalScroll = 4*(parent.displayImage.width * newZoomFactor);
        maxVerticalScroll =4*(parent.displayImage.height * newZoomFactor);
        let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
        let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

        newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
        newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

        parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

        parent.viewport.update();
    };

    // Add zoom in and zoom out methods to the ScrollControl prototype
ScrollControl.prototype.zoomIn = function() {
    var parent = this;
    if (!parent.displayImage) {
        console.error("No display image set.");
        return;
    }

    let oldZoomFactor = parent.zoomFactor;

    let maxHorizontalScroll = 4 * (parent.displayImage.width * oldZoomFactor);
    let maxVerticalScroll = 4 * (parent.displayImage.height * oldZoomFactor);
    let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

    parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
    let newZoomFactor = parent.zoomFactor;

    parent.initScrollBars();

    maxHorizontalScroll = 4 * (parent.displayImage.width * newZoomFactor);
    maxVerticalScroll = 4 * (parent.displayImage.height * newZoomFactor);
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    parent.viewport.update();
};

ScrollControl.prototype.zoomOut = function() {
    var parent = this;
    if (!parent.displayImage) {
        console.error("No display image set.");
        return;
    }

    let oldZoomFactor = parent.zoomFactor;

    let maxHorizontalScroll = 4 * (parent.displayImage.width * oldZoomFactor);
    let maxVerticalScroll = 4 * (parent.displayImage.height * oldZoomFactor);
    let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

    parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
    let newZoomFactor = parent.zoomFactor;

    parent.initScrollBars();

    maxHorizontalScroll = 4 * (parent.displayImage.width * newZoomFactor);
    maxVerticalScroll = 4 * (parent.displayImage.height * newZoomFactor);
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    parent.viewport.update();
};

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        let zoomFactor = this.parent.zoomFactor;

        if (result == null || result.isNull || result.isEmpty) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            g.scaleTransformation(zoomFactor);
            g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
            g.drawBitmap(0, 0, result.render());

            // Draw current mouse position circle
            g.pen = new Pen(0xffffff00, 1);
            if (this.parent.currentCircle) {
                g.drawCircle(this.parent.currentCircle.x, this.parent.currentCircle.y, this.parent.currentCircle.radius);
            } else {
                g.drawCircle(this.parent.currentMousePosition.x, this.parent.currentMousePosition.y, 0);
            }

            if (this.parent.blemishPoints.length > 0) {
                g.pen = new Pen(0xff00ff00, 1);
                this.parent.blemishPoints.forEach(point => {
                    g.drawCircle(point.x, point.y, point.radius);
                });
            }
        }

        g.end();
        gc();
    };

    this.blemishPoints = [];
    this.placeBlemishPoint = function(x, y, radius) {
        this.blemishPoints.push({ x: x, y: y, radius: radius });
        if (this.viewport) {
            this.viewport.update();
        }
        //console.writeln("Added blemish point at (" + x + ", " + y + ") with radius " + radius);
    };

    this.removeBlemishPoint = function(x, y) {
        let closestPointIndex = -1;
        let closestDistance = Infinity;
        for (let i = 0; i < this.blemishPoints.length; i++) {
            let point = this.blemishPoints[i];
            let distance = Math.sqrt(Math.pow(point.x - x, 2) + Math.pow(point.y - y, 2));
            if (distance < closestDistance) {
                closestDistance = distance;
                closestPointIndex = i;
            }
        }

        if (closestPointIndex !== -1) {
            this.blemishPoints.splice(closestPointIndex, 1);
            if (this.viewport) {
                this.viewport.update();
            }
            //console.writeln("Removed blemish point at (" + x + ", " + y + ")");
        }
    };

    this.tempImageStack = [];

// MedianCalculator function to calculate the median of an array of numbers
function MedianCalculator() {
    this.calculate = function(arr) {
        arr.sort((a, b) => a - b);
        const mid = Math.floor(arr.length / 2);
        if (arr.length % 2 === 0) {
            return (arr[mid - 1] + arr[mid]) / 2;
        }
        return arr[mid];
    };
}

this.executeCounter = 0;
this.undoStack = []; // Stack to store image states for undo
this.redoStack = []; // Stack to store image states for redo


this.applyBlemishRemoval = function() {
    // Save the current state to the undo stack
    this.undoStack.push(this.displayImageWindow.mainView.id);
    this.redoStack = []; // Clear the redo stack on new operation
    this.executeCounter++;

    let tempImageWindow = new ImageWindow(
        this.displayImage.width,
        this.displayImage.height,
        this.displayImage.numberOfChannels,
        this.displayImage.bitsPerSample,
        this.displayImage.isReal,
        this.displayImage.isColor
    );

    tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    tempImageWindow.mainView.image.assign(this.displayImage);
    tempImageWindow.mainView.endProcess();

    let image = tempImageWindow.mainView.image;
    let numChannels = image.numberOfChannels;

    console.writeln("Starting blemish removal process...");
    console.flush();

    for (let point of this.blemishPoints) {
        let x = point.x;
        let y = point.y;
        console.writeln("Processing blemish point at coordinates: (" + x + ", " + y + ")");
        console.flush();

        let radius = point.radius;
        let centerRadius = radius;
        let surroundingRadius = radius * Math.sqrt(3);
        let angle = Math.PI / 3;
        let dx = [], dy = [];

        for (let i = 0; i < 6; i++) {
            dx.push(Math.cos(angle * i) * surroundingRadius);
            dy.push(Math.sin(angle * i) * surroundingRadius);
        }

        // Calculate the median of all 7 circles (center + 6 surrounding)
        let circleMedians = [];
        let medianCalculator = new MedianCalculator();

        for (let i = 0; i < 7; i++) {
            let sx = i === 0 ? x : Math.round(x + dx[i - 1]);
            let sy = i === 0 ? y : Math.round(y + dy[i - 1]);

            if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                let circlePixels = [];
                for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter += 3) {
                    for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter += 3) {
                        let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                        if (distCenter <= centerRadius) {
                            let cx = sx + dxCenter;
                            let cy = sy + dyCenter;
                            if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                                for (let c = 0; c < numChannels; c++) {
                                    circlePixels.push(image.sample(cx, cy, c));
                                }
                            }
                        }
                    }
                }
                circleMedians.push(medianCalculator.calculate(circlePixels));
            } else {
                circleMedians.push(Number.POSITIVE_INFINITY); // If out of bounds, use a large value
            }
        }

        // Calculate the median of the center circle
        let centerMedian = circleMedians[0];

        // Determine the 3 surrounding circles closest to the median of the center circle
        let closestCircles = [];
        for (let i = 1; i < 7; i++) {
            closestCircles.push({
                index: i,
                distance: Math.abs(circleMedians[i] - centerMedian)
            });
        }

        closestCircles.sort((a, b) => a.distance - b.distance);
        let selectedCircles = closestCircles.slice(0, 3);

        // First pass: Store the values we are going to use
        let sampleValues = [];
        for (let dxCenter = -centerRadius; dxCenter <= centerRadius; dxCenter++) {
            for (let dyCenter = -centerRadius; dyCenter <= centerRadius; dyCenter++) {
                let distCenter = Math.sqrt(dxCenter * dxCenter + dyCenter * dyCenter);
                if (distCenter <= centerRadius) {
                    let featherValue = this.parent.featherSlider.value;
                    let opacityValue = this.parent.opacitySlider.value; // Get opacity value from slider
                    let featherFactor = featherValue === 0 ? 1 : Math.min(1, (1 / featherValue) * (centerRadius - distCenter) / centerRadius);
                    let medianPixel = [];
                    for (let c = 0; c < numChannels; c++) {
                        medianPixel.push([]);
                    }
                    let validSurroundingPixels = 0;

                    for (let i of selectedCircles) {
                        let sx = Math.round(x + dxCenter + dx[i.index - 1]);
                        let sy = Math.round(y + dyCenter + dy[i.index - 1]);
                        if (sx >= 0 && sx < image.width && sy >= 0 && sy < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                medianPixel[c].push(image.sample(sx, sy, c));
                            }
                            validSurroundingPixels++;
                        }
                    }

                    if (validSurroundingPixels > 0) {
                        for (let c = 0; c < numChannels; c++) {
                            medianPixel[c].sort((a, b) => a - b); // Sort the values
                            let median = medianPixel[c].length % 2 === 0
                                ? (medianPixel[c][medianPixel[c].length / 2 - 1] + medianPixel[c][medianPixel[c].length / 2]) / 2
                                : medianPixel[c][Math.floor(medianPixel[c].length / 2)];
                            medianPixel[c] = median;
                        }

                        let cx = Math.round(x + dxCenter);
                        let cy = Math.round(y + dyCenter);
                        if (cx >= 0 && cx < image.width && cy >= 0 && cy < image.height) {
                            for (let c = 0; c < numChannels; c++) {
                                let originalSample = image.sample(cx, cy, c);
                                let newSample = opacityValue * (featherFactor * medianPixel[c] + (1 - featherFactor) * originalSample) + (1 - opacityValue) * originalSample;

                                    sampleValues.push({ cx: cx, cy: cy, c: c, newSample: newSample });

                            }
                        }
                    }
                }
            }
        }

        // Second pass: Set the samples with error handling and batching
        let batchSize = 100;
        for (let i = 0; i < sampleValues.length; i += batchSize) {
            tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
            for (let j = i; j < i + batchSize && j < sampleValues.length; j++) {
                let sample = sampleValues[j];
                try {
                    image.setSample(sample.newSample, sample.cx, sample.cy, sample.c);
                } catch (error) {
                    //console.writeln("Error setting sample at (" + sample.cx + ", " + sample.cy + "): " + error.message);
                    //console.flush();
                }
            }
            tempImageWindow.mainView.endProcess();
        }
    }

    // Push the tempImageWindow ID to the temp image stack
    this.tempImageStack.push(tempImageWindow.mainView.id);
    //console.writeln("Pushed to tempImageStack: " + tempImageWindow.mainView.id);

    console.noteln("Blemish removal process completed.");
    console.flush();

    this.displayImage = tempImageWindow.mainView.image;
    this.displayImageWindow = tempImageWindow; // Store the tempImageWindow
    this.doUpdateImage(this.displayImage);

    // Clear the blemish points after processing
    this.blemishPoints = [];
    this.refreshPreview();

    // Debug: print stack contents
    //console.writeln("undoStack: " + JSON.stringify(this.undoStack));
    //console.writeln("tempImageStack: " + JSON.stringify(this.tempImageStack));
};




this.undoLastBlemishRemoval = function() {
    if (this.undoStack.length > 0) {
        let imageId = this.undoStack.pop();
        //console.writeln("Popped from undoStack: " + imageId);
        this.redoStack.push(this.displayImageWindow.mainView.id); // Save current state to redo stack
        //console.writeln("Pushed to redoStack: " + this.displayImageWindow.mainView.id);
        let window = ImageWindow.windowById(imageId);
        if (window && !window.isNull) {
            this.displayImage = window.mainView.image;
            this.displayImageWindow = window; // Update the display image window
            this.doUpdateImage(this.displayImage);
            this.refreshPreview();
            console.writeln("Last blemish removal undone.");
        } else {
            console.writeln("Image window not found or already closed: " + imageId);
        }
    } else {
        console.writeln("No blemish removals to undo.");
    }

    // Debug: print stack contents
    //console.writeln("undoStack: " + JSON.stringify(this.undoStack));
    //console.writeln("redoStack: " + JSON.stringify(this.redoStack));
};



this.applyChangesToMainImage = function() {
    if (parameters.autoSTFApplied) {
        let originalMedian = parameters.originalMedian;
        let originalMin = parameters.originalMin;

        // Create the PixelMath instance for the first operation
        let pixelMath1 = new PixelMath;
        if (parameters.targetWindow.mainView.image.numberOfChannels === 1) {
            pixelMath1.expression = "((Med($T)-1)*" + originalMedian + "*$T)/(Med($T)*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
        } else {
            pixelMath1.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                                    "((MedianColor-1)*" + originalMedian + "*$T)/(MedianColor*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
            pixelMath1.symbols = "L, MedianColor, S";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.clearImageCacheAndExit = false;
        pixelMath1.cacheGeneratedImages = false;
        pixelMath1.generateOutput = true;
        pixelMath1.singleThreaded = false;
        pixelMath1.optimization = true;
        pixelMath1.use64BitWorkingImage = true;
        pixelMath1.rescale = false;
        pixelMath1.rescaleLower = 0;
        pixelMath1.rescaleUpper = 1;
        pixelMath1.truncate = true;
        pixelMath1.truncateLower = 0;
        pixelMath1.truncateUpper = 1;
        pixelMath1.createNewImage = false;
        pixelMath1.showNewImage = false;
        pixelMath1.newImageId = "";
        pixelMath1.newImageWidth = 0;
        pixelMath1.newImageHeight = 0;
        pixelMath1.newImageAlpha = false;
        pixelMath1.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath1.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        let targetView = this.displayImageWindow.mainView;
        pixelMath1.executeOn(targetView);

        // Create the PixelMath instance for the second operation
        let pixelMath2 = new PixelMath;
        if (parameters.targetWindow.mainView.image.numberOfChannels === 1) {
            pixelMath2.expression = "($T*(1-" + originalMin + ")+" + originalMin + ")";
        } else {
            pixelMath2.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                                    "BlackPoint = MinColor;\n" +
                                    "($T*(1-" + 0.87*originalMin + ")+" + 0.87*originalMin + ")";
            pixelMath2.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.clearImageCacheAndExit = false;
        pixelMath2.cacheGeneratedImages = false;
        pixelMath2.generateOutput = true;
        pixelMath2.singleThreaded = false;
        pixelMath2.optimization = true;
        pixelMath2.use64BitWorkingImage = true;
        pixelMath2.rescale = false;
        pixelMath2.rescaleLower = 0;
        pixelMath2.rescaleUpper = 1;
        pixelMath2.truncate = true;
        pixelMath2.truncateLower = 0;
        pixelMath2.truncateUpper = 1;
        pixelMath2.createNewImage = false;
        pixelMath2.showNewImage = false;
        pixelMath2.newImageId = "";
        pixelMath2.newImageWidth = 0;
        pixelMath2.newImageHeight = 0;
        pixelMath2.newImageAlpha = false;
        pixelMath2.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath2.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        pixelMath2.executeOn(targetView);

        // Third PixelMath operation to replace the main image with the modified preview image
        let pixelMath3 = new PixelMath;
        pixelMath3.expression = this.displayImageWindow.mainView.id; // The preview image ID after modifications
        pixelMath3.useSingleExpression = true;
        pixelMath3.clearImageCacheAndExit = false;
        pixelMath3.cacheGeneratedImages = false;
        pixelMath3.generateOutput = true;
        pixelMath3.singleThreaded = false;
        pixelMath3.optimization = true;
        pixelMath3.use64BitWorkingImage = false;
        pixelMath3.rescale = false;
        pixelMath3.rescaleLower = 0;
        pixelMath3.rescaleUpper = 1;
        pixelMath3.truncate = true;
        pixelMath3.truncateLower = 0;
        pixelMath3.truncateUpper = 1;
        pixelMath3.createNewImage = false;
        pixelMath3.showNewImage = false;
        pixelMath3.newImageId = "";
        pixelMath3.newImageWidth = 0;
        pixelMath3.newImageHeight = 0;
        pixelMath3.newImageAlpha = false;
        pixelMath3.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath3.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        pixelMath3.executeOn(parameters.targetWindow.mainView); // Apply on the main image

        // Apply AutoSTF again to the main image
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.parent.createAndDisplayTemporaryImage(parameters.targetWindow.mainView.image, true);
                this.displayImage = tmpImage;
                this.displayImageWindow = parameters.targetWindow;
                this.initScrollBars();
                this.viewport.update();
                parameters.autoSTFApplied = true;
            }
        }
        //console.noteln("Blemish Removal on Main Image Complete! \nReady to remove more blemishes!");
        //console.flush();
    } else {
        let pixelMath = new PixelMath;
        pixelMath.expression = this.displayImageWindow.mainView.id;
        pixelMath.useSingleExpression = true;
        pixelMath.clearImageCacheAndExit = false;
        pixelMath.cacheGeneratedImages = false;
        pixelMath.generateOutput = true;
        pixelMath.singleThreaded = false;
        pixelMath.optimization = true;
        pixelMath.use64BitWorkingImage = false;
        pixelMath.rescale = false;
        pixelMath.rescaleLower = 0;
        pixelMath.rescaleUpper = 1;
        pixelMath.truncate = true;
        pixelMath.truncateLower = 0;
        pixelMath.truncateUpper = 1;
        pixelMath.createNewImage = false;
        pixelMath.showNewImage = false;
        pixelMath.newImageId = "";
        pixelMath.newImageWidth = 0;
        pixelMath.newImageHeight = 0;
        pixelMath.newImageAlpha = false;
        pixelMath.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        pixelMath.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        let targetView = parameters.targetWindow.mainView;
        pixelMath.executeOn(targetView);
    }

    console.noteln("Blemish Removal on Main Image Complete! \nReady to remove more blemishes!");
    console.flush();

    // Reset the AutoSTF flag
    //parameters.autoSTFApplied = false;
};




    this.refreshPreview = function() {
        this.viewport.update();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function MiniViewport(parent) {
    this.__base__ = Control;
    this.__base__(parent);

    this.feather = 0.5;
    this.opacity = 1.0;

    this.setFixedSize(100, 100);

    this.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        g.fillRect(0, 0, this.width, this.height, new Brush(0xff000000)); // Black background

        let centerX = this.width / 2;
        let centerY = this.height / 2;
        let radius = 25;

        // Draw white circle with variable opacity and feathering
        for (let y = 0; y < this.height; y++) {
            for (let x = 0; x < this.width; x++) {
                let distance = Math.sqrt((x - centerX) * (x - centerX) + (y - centerY) * (y - centerY));
                if (distance <= radius) {
                    let featherFactor = this.feather === 0 ? 1 : Math.min(1, (1 / this.feather) * (radius - distance) / radius);
                    let alpha = Math.floor(this.opacity * 255 * featherFactor); // Calculate alpha value based on opacity and feathering
                    let alphaHex = alpha.toString(16);
                    if (alphaHex.length < 2) {
                        alphaHex = '0' + alphaHex; // Pad with leading zero if needed
                    }
                    let color = parseInt('0x' + alphaHex + 'ffffff', 16); // Combine alpha with white color
                    g.pen = new Pen(color); // Set pen with calculated color
                    g.drawPoint(x, y);
                }
            }
        }

        g.end();
    };

    this.updatePreview = function(feather, opacity) {
        this.feather = feather === 0 ? 1 : feather;
        this.opacity = opacity;
        this.update();
    };
}
MiniViewport.prototype = new Control;



function BlemishEraserDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text ="<b>" + TITLE + " " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

this.instructionBox = new Label(this);
this.instructionBox.frameStyle = FrameStyle_Box;
this.instructionBox.margin = 6;
this.instructionBox.useRichText = true;
this.instructionBox.text = "<b>Instructions:</b><br>1. Select the image.<br>2. Use AutoSTF if needed.<br>3. Shift-click to define the center point and drag to define the radius.<br>4. Right-click to remove a point.<br>.....Multiple Areas Allowed!<br>5. Click Execute to apply blemish removal.<br>6. Click Apply to Main Image to save changes.";
this.instructionBox.textAlignment = TextAlign_Left;


    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

    this.windowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
            if (window && !window.isNull) {
                parameters.targetWindow = window;
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    //console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.displayImageWindow = window;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                } else {
                    console.error("Selected image is undefined.");
                }
            } else {
                console.writeln("No valid window selected for preview!");
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel);
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.autoSTFButton = new PushButton(this);
    this.autoSTFButton.text = "AutoSTF";
    this.autoSTFButton.toolTip = "Apply AutoSTF to the preview image.";
    this.autoSTFButton.icon =":/icons/burn.png"
    this.autoSTFButton.onClick = () => {
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage, true);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.displayImageWindow = parameters.targetWindow;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
                parameters.autoSTFApplied = true;
            }
        }
    };

this.featherSlider = new NumericControl(this);
this.featherSlider.label.text = "Feather:";
this.featherSlider.setRange(0.01, 1);
this.featherSlider.setPrecision(2);
this.featherSlider.slider.setRange(0, 100);
this.featherSlider.setValue(0.5);
this.featherSlider.onValueUpdated = (value) => {
    this.miniViewport.updatePreview(value, this.opacitySlider.value);
};

this.opacitySlider = new NumericControl(this);
this.opacitySlider.label.text = "Opacity:";
this.opacitySlider.setRange(0, 1);
this.opacitySlider.setPrecision(2);
this.opacitySlider.slider.setRange(0, 100);
this.opacitySlider.setValue(1);
this.opacitySlider.onValueUpdated = (value) => {
    this.miniViewport.updatePreview(this.featherSlider.value, value);
};

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.toolTip = "Apply blemish removal to all marked points.";
    this.executeButton.icon =":/icons/ok.png"
    this.executeButton.onClick = () => {
        this.previewControl.applyBlemishRemoval();
    };

    this.undoButton = new PushButton(this);
    this.undoButton.text = "Undo";
    this.undoButton.toolTip = "Undo the last blemish removal.";
    this.undoButton.icon = ":/icons/undo.png";
    this.undoButton.onClick = () => {
        this.previewControl.undoLastBlemishRemoval();
    };

    this.applyButton = new PushButton(this);
    this.applyButton.text = "Apply to Main Image";
    this.applyButton.toolTip = "Apply the changes to the main image.";
    this.applyButton.icon = ":/icons/execute.png";
    this.applyButton.onClick = () => {
        this.previewControl.applyChangesToMainImage();
    };

    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "<p style='text-align:center;'>Written by Franklin Marek 2024.<br><a href='http://www.setiastro.com'>www.setiastro.com</a></p>";
    this.authorshipLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
    this.authorshipLabel.useRichText = true;

    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = () => {
        this.newInstance();
    };

// Button Exit
this.exitButton = new PushButton(this);
this.exitButton.text = "Exit";
this.exitButton.icon = ":/toolbar/file-exit.png";
this.exitButton.toolTip = "Close the dialog and clean up.";
this.exitButton.onClick = () => {
    var msg = new MessageBox("Are you sure you want to exit? All temporary images will be closed.", "Confirm Exit", StdIcon_Question, StdButton_Yes, StdButton_No);
    if (msg.execute() == StdButton_Yes) {
        this.cleanupAndClose();
    }
};

this.cleanupAndClose = function() {

    // Close images in the undo stack
    while (this.previewControl.undoStack.length > 0) {
        let imageId = this.previewControl.undoStack.pop();
        if (imageId !== parameters.targetWindow.mainView.id) { // Skip the main image
            let window = ImageWindow.windowById(imageId);
            if (window && !window.isNull) {
                //console.writeln("Closing image: " + window.mainView.id);
                window.forceClose();
            } else {
                //console.writeln("Image window not found or already closed: " + imageId);
            }
        }
    }

    // Close images in the temp image stack
    while (this.previewControl.tempImageStack.length > 0) {
        let imageId = this.previewControl.tempImageStack.pop();
        let window = ImageWindow.windowById(imageId);
        if (window && !window.isNull) {
            //console.writeln("Closing image: " + window.mainView.id);
            window.forceClose();
        } else {
            //console.writeln("Image window not found or already closed: " + imageId);
        }
    }

    console.writeln("Cleanup complete. Closing dialog.");
    this.cancel();
};


        this.miniViewport = new MiniViewport(this);

              // Create a horizontal sizer for the miniViewport
      let miniViewportSizer = new HorizontalSizer;
      miniViewportSizer.spacing = 6;
      miniViewportSizer.addStretch(); // Add stretch before the miniViewport
      miniViewportSizer.add(this.miniViewport); // Add the miniViewport
      miniViewportSizer.addStretch(); // Add stretch after the miniViewport

    let leftPanel = new VerticalSizer;
    leftPanel.spacing = 6;
    leftPanel.margin = 6;
    leftPanel.add(this.title_Lbl);
    leftPanel.add(this.instructionBox);
    leftPanel.add(this.imageSelectionSizer);
    leftPanel.add(this.autoSTFButton);
        leftPanel.add(this.featherSlider); // Add feather slider here
        leftPanel.add(this.opacitySlider);


    let executeUndoSizer = new HorizontalSizer;
    executeUndoSizer.spacing = 6;
    executeUndoSizer.add(this.executeButton);
    executeUndoSizer.add(this.undoButton);
    leftPanel.add(executeUndoSizer);

    leftPanel.add(this.applyButton);
    leftPanel.add(miniViewportSizer);
    leftPanel.addStretch();
    leftPanel.add(this.authorshipLabel);

        let instanceExitSizer = new HorizontalSizer;
    instanceExitSizer.spacing = 6;
    instanceExitSizer.add(this.newInstanceButton);
    instanceExitSizer.add(this.exitButton);
    leftPanel.add(instanceExitSizer);


    this.zoomInButton = new PushButton(this);
    this.zoomInButton.text = "";
    this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
    this.zoomInButton.toolTip = "Zoom In";
    this.zoomInButton.onClick = () => {
        this.previewControl.zoomIn();
    };

    this.zoomOutButton = new PushButton(this);
    this.zoomOutButton.text = "";
    this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
    this.zoomOutButton.toolTip = "Zoom Out";
    this.zoomOutButton.onClick = () => {
        this.previewControl.zoomOut();
    };

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Buttons to Zoom In/Out or Use Mouse Wheel";

    // Zoom sizer to hold the zoom in and zoom out buttons
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 6;
    this.zoomSizer.add(this.zoomInButton);
    this.zoomSizer.add(this.zoomOutButton);
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.addStretch();

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(900);
    this.previewControl.setMinHeight(700);

        // Right panel to hold zoom buttons and preview control
    let rightPanel = new VerticalSizer;
    rightPanel.spacing = 6;
    rightPanel.margin = 6;
    rightPanel.add(this.zoomSizer);
    rightPanel.add(this.previewControl, 1);

    let mainSizer = new HorizontalSizer;
    mainSizer.spacing = 6;
    mainSizer.margin = 6;
    mainSizer.add(leftPanel);
    mainSizer.add(rightPanel, 1);

    this.sizer = mainSizer;
    this.adjustToContents();

    this.windowTitle = TITLE;

    this.onShow = function() {
        if (this.windowSelector_Cb.currentItem >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
            if (window && !window.isNull) {
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the initial image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.displayImageWindow = window;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                }
            }
        } else {
            console.noteln("No image selected for preview.");
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents();
        }
    };

this.onClose = function() {
    parameters.save();
    this.cleanupAndClose(); // Ensure cleanup is done when closing the dialog
};


    this.createAndDisplayTemporaryImage = function(selectedImage, applyAutoSTF = false) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

    if (applyAutoSTF) {
        let imageMin = window.mainView.image.minimum();
        parameters.originalMin = imageMin;

        // First PixelMath operation: ($T-min($T))/(1-min($T))
        let pixelMath1 = new PixelMath;
        if (selectedImage.numberOfChannels === 1) {
            pixelMath1.expression = "($T-min($T))/(1-min($T))";
        } else {
            pixelMath1.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                                    "BlackPoint = MinColor;\n" +
                                    "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
            pixelMath1.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.executeOn(window.mainView);

        let imageMedian = window.mainView.image.median();
        parameters.originalMedian = imageMedian;
        let targetMedian = 0.25;

        // Second PixelMath operation: ((Med($T)-1)*.25*$T)/(Med($T)*(.25+$T-1)-.25*$T)
        let pixelMath2 = new PixelMath;
        if (selectedImage.numberOfChannels === 1) {
            pixelMath2.expression = "((Med($T)-1)*0.25*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)";
        } else {
            pixelMath2.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                                    "((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
            pixelMath2.symbols = "L, MedianColor, S";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.executeOn(window.mainView);
    }

        let resizedImage = new Image(window.mainView.image);

        if (resizedImage.width > 0 && resizedImage.height > 0) {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.displayImageWindow = window;
            this.previewControl.doUpdateImage(resizedImage);
            this.previewControl.initScrollBars();
        } else {
            console.error("Resized image has invalid dimensions.");
        }
        window.forceClose();

        return resizedImage;
    };
}
BlemishEraserDialog.prototype = new Dialog;

function main() {
    console.show();
     Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new BlemishEraserDialog();
    dialog.execute();
}

main();
