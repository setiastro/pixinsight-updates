#feature-id AstroDepth : SetiAstro > SuperNova Asteroid Hunter
#feature-icon supernova.svg
#feature-info This script allows users to hunt for anomalies in their images

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * SuperNova Asteroid Hunter
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows users to automatically search through registered images
 * for anamolies versus a defined reference image.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StarDetector.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/ColorSpace.jsh>

// Define a global variable containing the script's parameters
var SupernovaHunterParameters = {
   referenceImagePath: "",
   searchImagePaths: [],
   threshold: 0.1,

save: function() {
   Parameters.set("referenceImagePath", SupernovaHunterParameters.referenceImagePath);
   Parameters.set("searchImagePaths", JSON.stringify(SupernovaHunterParameters.searchImagePaths));
   Parameters.set("threshold", SupernovaHunterParameters.threshold);  // Save threshold value
},

load: function() {
   if (Parameters.has("referenceImagePath"))
      SupernovaHunterParameters.referenceImagePath = Parameters.get("referenceImagePath");

   if (Parameters.has("searchImagePaths"))
      SupernovaHunterParameters.searchImagePaths = JSON.parse(Parameters.get("searchImagePaths"));

   if (Parameters.has("threshold"))
      SupernovaHunterParameters.threshold = Parameters.get("threshold");
}

};

// Global object to store preprocessed images
var PreprocessedImages = {
   referenceImage: null,
   searchImages: []
};

// Array to store detected anomalies
let anomalyGroups = [];
let anomalyData = [];

function SupernovaAsteroidHunterDialog() {
   this.__base__ = Dialog;
   this.__base__();

   // Instruction Label
   this.instructionsLabel = new Label(this);
   this.instructionsLabel.text = "Select the reference image and images to search. Then preprocess and run the search.";

   // Horizontal Sizer for Reference TreeBox and Label
   this.refSizer = new HorizontalSizer;
   this.refSizer.spacing = 6;

   // Reference Image Label
   this.referenceLabel = new Label(this);
   this.referenceLabel.text = "Reference Image:";
   this.refSizer.add(this.referenceLabel);

   // Reference Image TreeBox (Single Row)
   this.referenceTreeBox = new TreeBox(this);
   this.referenceTreeBox.numberOfColumns = 1;
   this.referenceTreeBox.headerVisible = false;
   this.referenceTreeBox.setMinSize(250, 20);
   this.referenceTreeBox.setMaxHeight(20);
   this.refSizer.add(this.referenceTreeBox, 100);

   // Reference Image Selection Button with Icon
   this.referenceButton = new PushButton(this);
   this.referenceButton.icon = this.scaledResource(":/icons/select-view.png");
   this.referenceButton.setScaledFixedSize(20, 20);
   this.referenceButton.toolTip = "Select Reference Image";
   this.referenceButton.onClick = function() {
      var dlg = new OpenFileDialog;
      dlg.multipleSelections = false;
      if (dlg.execute()) {
         SupernovaHunterParameters.referenceImagePath = dlg.fileNames[0];
         SupernovaHunterParameters.save();
         this.dialog.referenceTreeBox.clear();
         var refNode = new TreeBoxNode(this.dialog.referenceTreeBox);
         refNode.setText(0, File.extractName(dlg.fileNames[0]));
      }
   }.bind(this);
   this.refSizer.add(this.referenceButton);

   // Horizontal Sizer for Search TreeBox and Button
   this.searchSizer = new HorizontalSizer;
   this.searchSizer.spacing = 6;

   // TreeBox to display selected search images
   this.treeBox = new TreeBox(this);
   this.treeBox.numberOfColumns = 1;
   this.treeBox.headerVisible = true;
   this.treeBox.setHeaderText(0, "Selected Search Images");
   this.treeBox.setMinSize(300, 200);
   this.searchSizer.add(this.treeBox, 100);

   // Search Images Selection Button with Icon (Moved next to TreeBox)
   this.searchButton = new PushButton(this);
   this.searchButton.icon = this.scaledResource(":/icons/select-view.png");
   this.searchButton.setScaledFixedSize(20, 20);
   this.searchButton.toolTip = "Select Search Images";
   this.searchButton.onClick = function() {
      var dlg = new OpenFileDialog;
      dlg.multipleSelections = true;
      if (dlg.execute()) {
         SupernovaHunterParameters.searchImagePaths = dlg.fileNames;
         SupernovaHunterParameters.save();
         this.dialog.treeBox.clear();
         dlg.fileNames.forEach(function(name) {
            var node = new TreeBoxNode(this.dialog.treeBox);
            node.setText(0, File.extractName(name));
         }, this);
      }
   }.bind(this);
   this.searchSizer.add(this.searchButton);

   // Add the threshold slider and label
this.thresholdLabel = new Label(this);
this.thresholdLabel.text = "Anomaly Detection Threshold (Smaller Values = More Sensitive)";
this.thresholdLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

this.thresholdSlider = new NumericControl(this);
this.thresholdSlider.setRange(0.0, 0.5);
this.thresholdSlider.setPrecision(2);
this.thresholdSlider.slider.setRange(1, 500);
this.thresholdSlider.setValue(0.1);
this.thresholdSlider.slider.setMinWidth(200);
this.thresholdSlider.label.text = "Threshold:";
this.thresholdSlider.onValueUpdated = function(value) {
   SupernovaHunterParameters.threshold = value;
}.bind(this);
this.thresholdSlider.toolTip = "Set the anomaly detection threshold between 0 (strict) and 1 (lenient).";


   // Preprocess Button
   this.preprocessButton = new PushButton(this);
   this.preprocessButton.text = "Preprocess Images (ABE + Stretch)";
   this.preprocessButton.onClick = function() {
      this.dialog.preprocessImages();
   };

   // Run Search Button
   this.searchButton = new PushButton(this);
   this.searchButton.text = "Run Supernova/Asteroid Search";
   this.searchButton.onClick = function() {
      this.dialog.runSearch();
   }.bind(this);

   // New Instance Button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = function() {
      SupernovaHunterParameters.save();
      this.newInstance();
   }.bind(this);

   SupernovaHunterParameters.load();
   if (SupernovaHunterParameters.referenceImagePath) {
      var refNode = new TreeBoxNode(this.referenceTreeBox);
      refNode.setText(0, File.extractName(SupernovaHunterParameters.referenceImagePath));
   }

   if (SupernovaHunterParameters.searchImagePaths) {
      SupernovaHunterParameters.searchImagePaths.forEach(function(name) {
         var node = new TreeBoxNode(this.treeBox);
         node.setText(0, File.extractName(name));
      }, this);
   }

   // Preprocessing Progress Label
   this.preprocessingProgressLabel = new Label(this);
   this.preprocessingProgressLabel.text = "Preprocessing progress: 0 / " + SupernovaHunterParameters.searchImagePaths.length;

   // Progress Label
   this.progressLabel = new Label(this);
   this.progressLabel.text = "Processing progress: 0 / " + SupernovaHunterParameters.searchImagePaths.length;

   // Final Setup
   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add(this.instructionsLabel);
   this.sizer.add(this.refSizer);
   this.sizer.add(this.searchSizer);
      this.sizer.spacing = 6;
   this.sizer.add(this.thresholdLabel);
this.sizer.add(this.thresholdSlider);
   this.sizer.add(this.preprocessButton);
   this.sizer.add(this.searchButton);
   this.sizer.add(this.preprocessingProgressLabel);
   this.sizer.add(this.progressLabel);
   this.sizer.add(this.newInstanceButton);

   this.windowTitle = "Supernova/Asteroid Hunter V1.0";
}
SupernovaAsteroidHunterDialog.prototype = new Dialog;

// Preprocess images (reference and search images)
SupernovaAsteroidHunterDialog.prototype.preprocessImages = function() {
   function preprocessImage(window, imagePath) {
      if (!window || window.isNull) {
         console.warningln("Failed to open image.");
         return;
      }

      var processContainer = new ProcessContainer;
      console.writeln("Preprocessing image: " + imagePath);

      window.hide();

      if (window.mainView.image.isColor) {
         var P001 = new BackgroundNeutralization;
         P001.backgroundLow = 0.0000000;
         P001.backgroundHigh = 0.2000000;
         processContainer.add(P001);
      }

      var P002 = new AutomaticBackgroundExtractor;
      P002.polyDegree = 2;
      P002.targetCorrection = AutomaticBackgroundExtractor.prototype.Subtract;
      P002.normalize = true;
P002.discardModel = true;
P002.replaceTarget = true;
      processContainer.add(P002);

      var P003 = new PixelMath;
      P003.expression = "C = -2.8; B = 0.25; c = min(max(0,med($T)+C*1.4826*mdev($T)),1); mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
      P003.useSingleExpression = true;
      P003.symbols = "C,B,c";
      processContainer.add(P003);

      processContainer.executeOn(window.mainView);
   }

   var self = this;

   self.preprocessingProgressLabel.text = "Preprocessing reference image...";
   self.preprocessingProgressLabel.update();

   PreprocessedImages.referenceImage = ImageWindow.open(SupernovaHunterParameters.referenceImagePath)[0];
   preprocessImage(PreprocessedImages.referenceImage, SupernovaHunterParameters.referenceImagePath);

   PreprocessedImages.searchImages = [];

   SupernovaHunterParameters.searchImagePaths.forEach(function(imagePath, index) {
      self.preprocessingProgressLabel.text = "Preprocessing image " + (index + 1) + " of " + SupernovaHunterParameters.searchImagePaths.length;
      self.preprocessingProgressLabel.update();

      var window = ImageWindow.open(imagePath)[0];
      preprocessImage(window, imagePath);
      PreprocessedImages.searchImages.push(window);
   });

   self.preprocessingProgressLabel.text = "Preprocessing complete!";
   self.preprocessingProgressLabel.update();
   console.writeln("Preprocessing completed.");
};

// Run search and anomaly detection
SupernovaAsteroidHunterDialog.prototype.runSearch = function() {
   var refWindow = PreprocessedImages.referenceImage;
   if (!refWindow || refWindow.isNull) {
      console.warningln("Reference window not found.");
      return;
   }

   this.anomalyWindows = [];
   this.windowsToClose = [];
   anomalyData = [];

   PreprocessedImages.searchImages.forEach(function(searchImageWindow, index) {
      this.progressLabel.text = "Processing image " + (index + 1) + " of " + PreprocessedImages.searchImages.length;
      this.progressLabel.update();

      this.subtractImagesOnce(searchImageWindow.mainView.id, refWindow.mainView.id);

      var groupedAnomalies = this.detectAnomaliesInGrid(searchImageWindow, refWindow);

      this.undoSubtraction(searchImageWindow.mainView.id, refWindow.mainView.id);

      anomalyData.push({
         imageName: searchImageWindow.mainView.id,
         anomalyCount: groupedAnomalies.length,
         anomalies: groupedAnomalies.map(function(group) {
            return {
               minX: group.minX,
               minY: group.minY,
               maxX: group.maxX,
               maxY: group.maxY
            };
         })
      });

   }, this);

   this.showAnomalousWindows();
   this.closeNonAnomalousWindows();
   this.showDetailedResultsDialog(anomalyData);

   console.writeln("Search for anomalies completed.");
};

// Perform subtraction only once
SupernovaAsteroidHunterDialog.prototype.subtractImagesOnce = function(searchImageId, refImageId) {
   var P = new PixelMath;
   P.expression = searchImageId + " - " + refImageId + " + 0.1";
   P.useSingleExpression = true;
   P.generateOutput = true;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.executeOn(ImageWindow.windowById(searchImageId).mainView);
   console.writeln("Subtracted reference image from search image: " + searchImageId);
};

// Undo the subtraction (restore original image)
SupernovaAsteroidHunterDialog.prototype.undoSubtraction = function(searchImageId, refImageId) {
   var P = new PixelMath;
   P.expression = searchImageId + " - 0.1 + " + refImageId;
   P.useSingleExpression = true;
   P.generateOutput = true;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.executeOn(ImageWindow.windowById(searchImageId).mainView);
   console.writeln("Restored original image after anomaly detection for: " + searchImageId);
};

SupernovaAsteroidHunterDialog.prototype.detectAnomaliesInGrid = function(searchImageWindow, refImageWindow) {
   // Clear the anomalyGroups array for each new image
   anomalyGroups = [];  // Ensure we start fresh for each image

   var searchImage = searchImageWindow.mainView.image;
   var refImage = refImageWindow.mainView.image;
   var threshold = SupernovaHunterParameters.threshold;  // Difference threshold for anomalies
   var maxGroupSize = 25 * 25; // Define the maximum anomaly group size as 25x25 pixels (625 pixels)

   var gridSize = 3;  // 3x3 grid
   var width = searchImage.width;
   var height = searchImage.height;

   // Calculate 5% border area
   var borderX = Math.round(width * 0.05);
   var borderY = Math.round(height * 0.05);

   var hasAnomalies = false;

   // Loop over the image using the grid size
   for (var y = 0; y < height; y += gridSize) {
      for (var x = 0; x < width; x += gridSize) {

         // Skip grids that are within the 5% border area
         if (x < borderX || x > width - borderX || y < borderY || y > height - borderY) {
            continue;  // Skip this grid
         }

                  // Skip if any pixel in the search grid or reference grid has a value of 0
         if (checkZeroPixelInGrid(searchImage, refImage, x, y, gridSize)) {
            continue;  // Skip this grid
         }

         var searchGridAvg = calculateGridAverage(searchImage, x, y, gridSize);
         var refGridAvg = calculateGridAverage(refImage, x, y, gridSize);

         if (searchGridAvg - refGridAvg > threshold) {
            // Anomaly detected, store it as part of a group
            storeAnomaly(x, y, gridSize);
            hasAnomalies = true;
         }
      }
   }

   // Group anomalies based on proximity
   var groupedAnomalies = groupNearbyAnomalies(anomalyGroups, 40);  // Group anomalies within 40 pixels

   // Filter out groups larger than maxGroupSize (e.g., satellite trails or large artifacts)
   var filteredAnomalies = groupedAnomalies.filter(function(group) {
      var groupWidth = group.maxX - group.minX + 1;
      var groupHeight = group.maxY - group.minY + 1;
      var groupSize = groupWidth * groupHeight;
      return groupSize <= maxGroupSize && groupWidth <= 40 && groupHeight <= 40;  // Exclude large or long groups
   });

   if (filteredAnomalies.length > 0) {
      this.anomalyWindows.push(searchImageWindow);
      this.undoSubtraction(searchImageWindow.mainView.id, refImageWindow.mainView.id);
      this.markImageWithAnomalies(searchImageWindow);
      highlightFilteredAnomalies(searchImageWindow, filteredAnomalies);
   } else {
      this.windowsToClose.push(searchImageWindow);
   }

   return filteredAnomalies;
};

// Mark images with anomalies in TreeBox
SupernovaAsteroidHunterDialog.prototype.markImageWithAnomalies = function(searchImageWindow) {
   var imageName = searchImageWindow.mainView.id;

   for (var i = 0; i < this.treeBox.numberOfChildren; i++) {
      var node = this.treeBox.child(i);
      if (File.extractName(imageName) === node.text(0)) {
         node.setText(0, node.text(0) + " *");
         node.setTextColor(0, 0xFF0000);
         this.treeBox.update();
         break;
      }
   }
};

// Helper function to check if any pixel in the grid has a value of 0 in either the search or reference image
function checkZeroPixelInGrid(searchImage, refImage, startX, startY, gridSize) {
   for (var y = startY; y < Math.min(startY + gridSize, searchImage.height); y++) {
      for (var x = startX; x < Math.min(startX + gridSize, searchImage.width); x++) {
         if (searchImage.sample(x, y) === 0 || refImage.sample(x, y) === 0) {
            return true;  // Return true if any pixel has a value of 0
         }
      }
   }
   return false;  // Return false if no pixels are 0
}

// Helper functions for anomaly detection
function storeAnomaly(x, y, size) {
   anomalyGroups.push({ x: x, y: y, size: size });
}

function calculateGridAverage(image, startX, startY, size) {
   var sum = 0;
   var count = 0;

   for (var y = startY; y < Math.min(startY + size, image.height); y++) {
      for (var x = startX; x < Math.min(startX + size, image.width); x++) {
         sum += image.sample(x, y);
         count++;
      }
   }

   return sum / count;
}

// Function to convert the image to RGB if it's grayscale
function convertImageToRGBIfNeeded(imageWindow) {
    if (!imageWindow.mainView.image.isColor) {
        var P = new ConvertToRGBColor;
        P.executeOn(imageWindow.mainView, false);  // Apply the conversion to the main view
        console.writeln("Converted image to RGB: " + imageWindow.mainView.id);
    }
}

// Function to highlight only the filtered anomaly groups
function highlightFilteredAnomalies(searchImageWindow, filteredAnomalies) {
   let searchImage = searchImageWindow.mainView.image;

   // Convert to RGB if the image is grayscale
   if (!searchImage.isColor) {
      convertImageToRGBIfNeeded(searchImageWindow);  // Convert before drawing
      searchImage = searchImageWindow.mainView.image;  // Update the reference to the converted image
   }

   searchImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);

   filteredAnomalies.forEach(function(group) {
      let minX = group.minX;
      let minY = group.minY;
      let groupWidth = group.maxX - group.minX + 3;
      let groupHeight = group.maxY - group.minY + 3;

      let color = [65535, 0, 0];  // Red color for RGB
      let margin = 50;  // Increase the size of the rectangle by a margin
      draw_rectangle(searchImage, minX, minY, groupWidth, groupHeight, color, margin);

      console.writeln("Filtered anomaly group highlighted at (" + minX + ", " + minY + ") with width " + groupWidth + " and height " + groupHeight);
   });

   searchImageWindow.mainView.endProcess();
}

// Function to draw a rectangle around the grouped anomalies with a size margin
function draw_rectangle(image, x, y, width, height, color, margin) {
   // Increase the width and height of the rectangle by the margin
   width += margin;
   height += margin;
   x -= margin / 2;  // Adjust x position to center the larger rectangle
   y -= margin / 2;  // Adjust y position to center the larger rectangle

   for (let i = 0; i < width; i++) {
      // Top and bottom sides of the rectangle
      set_pixel(image, x + i, y, color); // Top side
      set_pixel(image, x + i, y + height - 1, color); // Bottom side
   }
   for (let i = 0; i < height; i++) {
      // Left and right sides of the rectangle
      set_pixel(image, x, y + i, color); // Left side
      set_pixel(image, x + width - 1, y + i, color); // Right side
   }
}


function set_pixel(image, x, y, color) {
   if (x < image.width && y < image.height) {
      if (image.isColor) {
         for (let c = 0; c < 3; c++) {
            image.setSample(color[c] / 65535, x, y, c);
         }
      } else {
         image.setSample(color[0] / 65535, x, y);
      }
   }
}

function groupNearbyAnomalies(anomalies, proximityThreshold) {
   let groups = [];
   let visited = new Set();

   anomalies.forEach(function(anomaly, index) {
      if (visited.has(index)) return;

      let group = {
         minX: anomaly.x,
         minY: anomaly.y,
         maxX: anomaly.x + anomaly.size,
         maxY: anomaly.y + anomaly.size,
         count: 1
      };

      visited.add(index);

      anomalies.forEach(function(otherAnomaly, otherIndex) {
         if (visited.has(otherIndex)) return;

         if (Math.abs(otherAnomaly.x - group.maxX) <= proximityThreshold &&
            Math.abs(otherAnomaly.y - group.maxY) <= proximityThreshold) {
            group.minX = Math.min(group.minX, otherAnomaly.x);
            group.minY = Math.min(group.minY, otherAnomaly.y);
            group.maxX = Math.max(group.maxX, otherAnomaly.x + otherAnomaly.size);
            group.maxY = Math.max(group.maxY, otherAnomaly.y + otherAnomaly.size);
            group.count++;
            visited.add(otherIndex);
         }
      });

      let groupWidth = group.maxX - group.minX;
      let groupHeight = group.maxY - group.minY;
      if (groupWidth > 1 || groupHeight > 1) {
         groups.push(group);
      }
   });

   return groups;
}

// Show windows with anomalies
SupernovaAsteroidHunterDialog.prototype.showAnomalousWindows = function() {
   if (PreprocessedImages.referenceImage && !PreprocessedImages.referenceImage.isNull) {
      PreprocessedImages.referenceImage.show();
      console.writeln("Reference image has been shown.");
   }

   this.anomalyWindows.forEach(function(window) {
      window.show();
   });
   console.writeln("All windows with anomalies have been shown.");
};

// Close non-anomalous windows
SupernovaAsteroidHunterDialog.prototype.closeNonAnomalousWindows = function() {
   this.windowsToClose.forEach(function(window) {
      if (window && !window.isNull) {
         window.forceClose();
         console.writeln("Closed window without anomalies: " + window.mainView.id);
      }
   });
   console.writeln("All windows with no anomalies have been closed.");
};

// Show detailed results
SupernovaAsteroidHunterDialog.prototype.showDetailedResultsDialog = function(anomalyData) {
   var dialog = new Dialog;
   dialog.windowTitle = "Anomaly Detection Results";

   var textBox = new TextBox(dialog);
   textBox.readOnly = true;
   textBox.text = "Detailed Anomaly Results:\n\n";

   anomalyData.forEach(function(data) {
      textBox.text += "Image: " + data.imageName + "\nAnomalies: " + data.anomalyCount + "\n";
      data.anomalies.forEach(function(anomaly) {
         textBox.text += "  Group Bounding Box: Top-Left (" + anomaly.minX + ", " + anomaly.minY +
                         "), Bottom-Right (" + anomaly.maxX + ", " + anomaly.maxY + ")\n";
      });
      textBox.text += "\n";
   });

   dialog.sizer = new VerticalSizer;
   dialog.sizer.add(textBox);
   dialog.execute();
};

// Main function
function main() {
           console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    Console.writeln("SuperNove Asteroid Hunter Loaded...");

   let dialog = new SupernovaAsteroidHunterDialog();
   dialog.execute();
}

main();
