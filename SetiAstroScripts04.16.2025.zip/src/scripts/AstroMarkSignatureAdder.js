#feature-id AstroMark : SetiAstro > AstroMark Signature and Insert Adder
#feature-icon  astromark.svg
#feature-info This script allows users to overlay their signature image on top of another image.


/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * AstroMark
 * Version: V1.4
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows users to overlay their signature image on top
 * of another image.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/BitmapInterpolation.jsh>

#define TITLE "AstroMark - Signature and Insert Adder"
#define VERSION "V1.4"

let parameters = {
    targetWindow: null,
    signatureWindow: null,
    signaturePosition: new Point(0, 0),
    signatureScale: 1.0,
    signatureRotation: 0.0,
    signatureOpacity: 1.0,
    signaturePositioning: "Lower Right", // Default position
    signatureOffset: 10, // Default offset in pixels
    previewZoomFactor: 1.0,
    blendMode: "Normal", // Default blend mode
    borderEnabled: false, // Border enabled or disabled
    borderWidth: 3,       // Default border width
    borderColor: 0x00000000, // Default white color

    save: function() {
        Parameters.set("signatureScale", this.signatureScale);
        Parameters.set("signatureRotation", this.signatureRotation);
        Parameters.set("signatureOpacity", this.signatureOpacity);
        Parameters.set("signaturePositioning", this.signaturePositioning);
        Parameters.set("signatureOffset", this.signatureOffset);
        Parameters.set("blendMode", this.blendMode);
        Parameters.set("borderEnabled", this.borderEnabled);
        Parameters.set("borderWidth", this.borderWidth);
        Parameters.set("borderColor", this.borderColor);
    },

    load: function() {
        if (Parameters.has("signatureScale")) {
            this.signatureScale = Parameters.getReal("signatureScale");
        }
        if (Parameters.has("signatureRotation")) {
            this.signatureRotation = Parameters.getReal("signatureRotation");
        }
        if (Parameters.has("signatureOpacity")) {
            this.signatureOpacity = Parameters.getReal("signatureOpacity");
        }
        if (Parameters.has("signaturePositioning")) {
            this.signaturePositioning = Parameters.getString("signaturePositioning");
        }
        if (Parameters.has("signatureOffset")) {
            this.signatureOffset = Parameters.getInteger("signatureOffset");
        }
        if (Parameters.has("blendMode")) {
            this.blendMode = Parameters.getString("blendMode");
        }
        if (Parameters.has("borderEnabled")) {
            this.borderEnabled = Parameters.getBoolean("borderEnabled");
        }
        if (Parameters.has("borderWidth")) {
            this.borderWidth = Parameters.getInteger("borderWidth");
        }
        if (Parameters.has("borderColor")) {
            this.borderColor = Parameters.getInteger("borderColor");
        }
    }
};



function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.signaturePosition = new Point(0, 0);
    this.signatureScale = parameters.signatureScale;
    this.signatureRotation = parameters.signatureRotation;
    this.signatureOpacity = parameters.signatureOpacity;
    this.blendMode = parameters.blendMode;

    this.autoScroll = true;
    this.tracking = true;

    this.mainImage = null;
    this.signatureImage = null;
    this.signaturePosition = new Point(0, 0);
    this.signatureScale = 1.0;
    this.dragging = false;
    this.dragOrigin = new Point(0, 0);
    this.isTransforming = false;
    this.transformCenter = null;
    this.initialDistance = null;

    this.zoomFactor = 1.0;
    this.minZoomFactor = 0.1;
    this.maxZoomFactor = 10.0;

    this.cachedSignatureImage = null;  // Cached resampled signature image

    this.getImage = function() {
        return this.mainImage;
    };

    this.doUpdateImage = function(mainImage, signatureImage) {
        this.mainImage = mainImage;
        this.signatureImage = signatureImage;
        this.cacheResampledSignature();  // Cache resampled image
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.initScrollBars = function(scrollPoint = null) {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
            this.scrollPosition = new Point(0, 0);
        } else {
            let zoomFactor = this.zoomFactor;
            this.setHorizontalScrollRange(0, Math.max(0, (4 * image.width * zoomFactor)));
            this.setVerticalScrollRange(0, Math.max(0, (4 * image.height * zoomFactor)));
            if (scrollPoint) {
                this.scrollPosition = scrollPoint;
            } else {
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, (4 * image.width * zoomFactor)),
                    Math.min(this.scrollPosition.y, (4 * image.height * zoomFactor))
                );
            }
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.cacheResampledSignature = function(interpolationMethod = "Bilinear") {
        if (!this.signatureImage) return;

        let scaleFactor = this.signatureScale;

        // Create a temporary ImageWindow to hold the signature
        let tempWindow = new ImageWindow(
            this.signatureImage.width,
            this.signatureImage.height,
            this.signatureImage.numberOfChannels,
            this.signatureImage.bitsPerSample,
            this.signatureImage.isReal,
            this.signatureImage.isColor
        );

        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign(this.signatureImage);
        tempWindow.mainView.endProcess();

        // Define the Resample process
        let P = new Resample;
        P.xSize = scaleFactor;
        P.ySize = scaleFactor;
        P.mode = Resample.prototype.RelativeDimensions;
        P.absoluteMode = Resample.prototype.ForceWidthAndHeight;
        P.xResolution = 72.000;
        P.yResolution = 72.000;
        P.metric = false;
        P.forceResolution = false;

        // Set interpolation method based on the passed argument
        P.interpolation = Resample.prototype.Auto;

        P.clampingThreshold = 0.30;
        P.smoothness = 1.50;
        P.gammaCorrection = false;
        P.noGUIMessages = true;

        // Apply the Resample process to the tempWindow
        P.executeOn(tempWindow.mainView);

        // Get the resampled image
        this.cachedSignatureImage = new Image(tempWindow.mainView.image);

        // Clean up the temporary window
        tempWindow.forceClose();
    };

    this.calculateDistance = function(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        let zoomFactor = parent.zoomFactor;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        if (modifiers === 1) { // Shift key detection for moving signature
            parent.dragging = true;
            parent.dragOrigin.x = adjustedX;
            parent.dragOrigin.y = adjustedY;
        } else if (modifiers === 2) { // Ctrl key detection for resizing signature
            parent.isTransforming = true;
            parent.transformCenter = new Point(
                parent.signaturePosition.x + (parent.signatureImage.width * parent.signatureScale) / 2,
                parent.signaturePosition.y + (parent.signatureImage.height * parent.signatureScale) / 2
            );
            parent.initialDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter.x, parent.transformCenter.y);
        } else if (modifiers === 4) { // Alt key detection for future transformations
            parent.isTransforming = true;
            parent.transformCenter = new Point(
                parent.signaturePosition.x + (parent.signatureImage.width * parent.signatureScale) / 2,
                parent.signaturePosition.y + (parent.signatureImage.height * parent.signatureScale) / 2
            );
            parent.initialAngle = parent.calculateAngle(parent.transformCenter.x, parent.transformCenter.y, adjustedX, adjustedY);
            parent.initialDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter.x, parent.transformCenter.y);
        } else {
            // Default behavior: dragging the entire view (scrolling)
            parent.dragging = true;
            parent.dragOrigin.x = x;
            parent.dragOrigin.y = y;
        }
        this.cursor = new Cursor(StdCursor_ClosedHand);
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        var parent = this.parent;
        let zoomFactor = parent.zoomFactor;
        let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
        let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

        if (parent.dragging) {
            if (modifiers === 1) { // Shift key: move signature
                let dx = adjustedX - parent.dragOrigin.x;
                let dy = adjustedY - parent.dragOrigin.y;
                parent.signaturePosition.x += dx;
                parent.signaturePosition.y += dy;
                parent.dragOrigin.x = adjustedX;
                parent.dragOrigin.y = adjustedY;
            } else { // Default: scrolling
                let dx = (x - parent.dragOrigin.x) / zoomFactor;
                let dy = (y - parent.dragOrigin.y) / zoomFactor;
                parent.scrollPosition = new Point(parent.scrollPosition.x - dx, parent.scrollPosition.y - dy);
                parent.dragOrigin.x = x;
                parent.dragOrigin.y = y;
            }

            if (parent.viewport) {
                parent.viewport.update();
            }
        } else if (parent.isTransforming) { // Ctrl key: resize signature
            let currentDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter.x, parent.transformCenter.y);
            parent.signatureScale *= currentDistance / parent.initialDistance;
            parent.initialDistance = currentDistance;
            parent.cacheResampledSignature("NearestNeighbor"); // Re-cache resampled signature
            if (parent.viewport) {
                parent.viewport.update();
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        var parent = this.parent;
        parent.dragging = false;

        if (parent.isTransforming) {
            parent.isTransforming = false;

            // After resizing is complete, apply high-quality resampling
            parent.cacheResampledSignature("Bilinear"); // High-quality for final rendering

            if (parent.viewport) {
                parent.viewport.update();
            }
        }

        this.cursor = new Cursor(StdCursor_Arrow);
    };

    this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
        var parent = this.parent;

        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }
        parent.initScrollBars();
        if (parent.viewport) {
            parent.viewport.update();
        }
    };

        // Zoom In Function
    this.zoomIn = function() {
        this.zoomFactor = Math.min(this.zoomFactor * 1.25, this.maxZoomFactor);
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    // Zoom Out Function
    this.zoomOut = function() {
        this.zoomFactor = Math.max(this.zoomFactor * 0.8, this.minZoomFactor);
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

this.viewport.onPaint = function(x0, y0, x1, y1) {
    var g = new Graphics(this);
    var mainImage = this.parent.mainImage;
    var signatureImage = this.parent.cachedSignatureImage;
    let zoomFactor = this.parent.zoomFactor;

    if (mainImage == null) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
    } else {
        g.scaleTransformation(zoomFactor);
        g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
        g.drawBitmap(0, 0, mainImage.render());

        if (signatureImage != null) {
            let posX = this.parent.signaturePosition.x;
            let posY = this.parent.signaturePosition.y;
            let width = signatureImage.width;
            let height = signatureImage.height;

            // Apply transformations for rotation
            let centerX = posX + width / 2;
            let centerY = posY + height / 2;

            g.translateTransformation(centerX, centerY);
            g.rotateTransformation(this.parent.signatureRotation * Math.PI / 180);
            g.translateTransformation(-centerX, -centerY);

            // Set opacity for the signature image
            g.opacity = this.parent.signatureOpacity;

            // Draw the signature
            g.drawBitmap(posX, posY, signatureImage.render());

            // Draw the border if enabled
            if (parameters.borderEnabled) {
                let borderColor = parameters.borderColor | 0xFF000000; // Ensure full alpha
                let borderWidth = parameters.borderWidth;

                g.pen = new Pen(borderColor, borderWidth);
                g.brush = new Brush(0x00000000); // Fully transparent ARGB brush


                // Adjust the rectangle dimensions to include border thickness
                g.drawRect(
                    posX - borderWidth / 2,
                    posY - borderWidth / 2,
                    posX + width + borderWidth / 2,
                    posY + height + borderWidth / 2
                );
            }

            g.opacity = 1.0; // Reset opacity
        }
    }
    g.end();
};



    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function SignatureAdderDialog() {
    this.__base__ = Dialog;
    this.__base__();

    // Ensure signaturePosition is initialized
    this.signaturePosition = new Point(0, 0); // Initialize at (0, 0)
    this.signatureScale = parameters.signatureScale; // Load scale factor
    this.signatureRotation = parameters.signatureRotation; // Load rotation
    this.signatureOpacity = parameters.signatureOpacity; // Load opacity
        this.blendMode = parameters.blendMode || "Normal"; // Default to "Normal"

    // Title and Instruction boxes
    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>AstroMark - Signature and Insert Adder " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

    this.instructions_Lbl = new TextBox(this);
    this.instructions_Lbl.readOnly = true;
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.text = "Instructions:\n\n1. Select the target image.\n2. Select the signature image.\n3 Select a blend mode (Preview does not support blend modes but your executed image will)\n4. Adjust the position (shift+click and drag) of the signature using mouse controls.\n5. Click 'Execute' to overlay the signature onto the target image.";
    this.instructions_Lbl.setScaledMinWidth(450); // Set a fixed width for the instructions

    this.targetWindow_Label = new Label(this);
    this.targetWindow_Label.text = "Select Image:";
    this.targetWindow_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.signatureWindow_Label = new Label(this);
    this.signatureWindow_Label.text = "Select Signature:";
    this.signatureWindow_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.targetWindowSelector_Cb = new ComboBox(this);
    this.signatureWindowSelector_Cb = new ComboBox(this);

    // Populate dropdowns with available windows
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        let windowId = ImageWindow.windows[i].mainView.id;
        this.targetWindowSelector_Cb.addItem(windowId);
        this.signatureWindowSelector_Cb.addItem(windowId);
    }

    // Add the "Select Image" option at the beginning of the signature selector
    this.signatureWindowSelector_Cb.insertItem(0, "Select Image");
    this.signatureWindowSelector_Cb.currentItem = 0; // Default to "Select Image"

    // Handle target image selection
    this.targetWindowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let windowId = this.targetWindowSelector_Cb.itemText(index);
            parameters.targetWindow = ImageWindow.windowById(windowId);
            this.updatePreview();
        }
    };

    // Handle signature image selection
    this.signatureWindowSelector_Cb.onItemSelected = (index) => {
        if (index >= 1) { // Make sure "Select Image" isn't used as a valid image
            let windowId = this.signatureWindowSelector_Cb.itemText(index);
            parameters.signatureWindow = ImageWindow.windowById(windowId);

            // Cache the resampled signature image
            this.cacheResampledSignature();
            this.updatePreview();
        } else {
            parameters.signatureWindow = null; // Clear signature window if "Select Image" is chosen
            this.cachedSignatureImage = null; // Clear cached signature image
        }
    };

    // Set default for targetWindowSelector_Cb to the active window
    let activeWindow = ImageWindow.activeWindow;
    if (!activeWindow.isNull) {
        this.targetWindowSelector_Cb.currentItem = this.targetWindowSelector_Cb.findItem(activeWindow.mainView.id);
    } else {
        this.targetWindowSelector_Cb.currentItem = 0; // Default to the first window if no active window
    }

        // Blend Mode Dropdown
    this.blendMode_Label = new Label(this);
    this.blendMode_Label.text = "Blend Mode:";
    this.blendMode_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.blendMode_Cb = new ComboBox(this);
    this.blendMode_Cb.addItem("Normal");
    this.blendMode_Cb.addItem("Replacement");
    this.blendMode_Cb.addItem("Lighten");
    this.blendMode_Cb.addItem("Multiply");
    this.blendMode_Cb.addItem("Screen");
    this.blendMode_Cb.addItem("Overlay");
    this.blendMode_Cb.addItem("Difference");
    this.blendMode_Cb.addItem("Darken");
    this.blendMode_Cb.currentItem = this.blendMode_Cb.findItem(this.blendMode);

    this.blendMode_Cb.onItemSelected = (index) => {
        this.blendMode = this.blendMode_Cb.itemText(index);
        parameters.blendMode = this.blendMode;
        this.previewControl.viewport.update();
    };

    // Help link for blend modes
    this.blendModeHelp_Lbl = new Label(this);
    this.blendModeHelp_Lbl.useRichText = true;
    this.blendModeHelp_Lbl.text = "<a href=\"https://www.setiastro.com/blendmodes\">Help With Different Blend Modes</a>";
    this.blendModeHelp_Lbl.toolTip = "Click for help with different blend modes.";
    this.blendModeHelp_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
this.blendModeHelp_Lbl.onMousePress = () => {
    console.writeln("Blend mode help clicked");
    Dialog.openBrowser("https://www.setiastro.com/blendmodes");
};

    // Blend Mode Horizontal Sizer
this.blendModeSizer = new HorizontalSizer;
this.blendModeSizer.spacing = 4;
this.blendModeSizer.add(this.blendMode_Label);
this.blendModeSizer.add(this.blendMode_Cb);
    this.blendModeSizer.addSpacing(20); // Add some space between the dropdown and link
      this.blendModeSizer.add(this.blendModeHelp_Lbl);
this.blendModeSizer.addStretch();

    this.signatureSize_Slider = new NumericControl(this);
    this.signatureSize_Slider.label.text = "Signature Size:";
    this.signatureSize_Slider.setRange(0.01, 5);
    this.signatureSize_Slider.slider.setRange(1, 500);
    this.signatureSize_Slider.setPrecision(2);
    this.signatureSize_Slider.setValue(parameters.signatureScale); // Load saved value

    let signatureScaleUpdateTimer = new Timer;

    this.signatureSize_Slider.onValueUpdated = (value) => {
        // Stop any existing timer
        signatureScaleUpdateTimer.stop();

        // Set a new timer to update the scale after a 1-second delay
        signatureScaleUpdateTimer.interval = 1.0; // 1 second
        signatureScaleUpdateTimer.singleShot = true; // Ensure it only triggers once
        signatureScaleUpdateTimer.onTimeout = () => {
            this.previewControl.signatureScale = value;
            this.previewControl.cacheResampledSignature("Bilinear");
            this.previewControl.viewport.update();
        };
        signatureScaleUpdateTimer.start();

        parameters.signatureScale = value; // Save the value
    };

    this.signatureRotation_Slider = new NumericControl(this);
    this.signatureRotation_Slider.label.text = "Signature Rotation:";
    this.signatureRotation_Slider.setRange(0.0, 360.0);
    this.signatureRotation_Slider.slider.setRange(0, 3600);
    this.signatureRotation_Slider.setPrecision(1);
    this.signatureRotation_Slider.setValue(parameters.signatureRotation); // Load saved value
    this.signatureRotation_Slider.onValueUpdated = (value) => {
        this.previewControl.signatureRotation = value;
        this.previewControl.viewport.update();

        parameters.signatureRotation = value; // Save the value
    };

    this.signatureOpacity_Slider = new NumericControl(this);
    this.signatureOpacity_Slider.label.text = "Signature Opacity:";
    this.signatureOpacity_Slider.setRange(0.01, 1.00);
    this.signatureOpacity_Slider.slider.setRange(1, 1000);
    this.signatureOpacity_Slider.setPrecision(2);
    this.signatureOpacity_Slider.setValue(parameters.signatureOpacity); // Load saved value
    this.signatureOpacity_Slider.onValueUpdated = (value) => {
        this.previewControl.signatureOpacity = value;
        this.previewControl.viewport.update();

        parameters.signatureOpacity = value; // Save the value
    };

    // Positioning Dropdown Label
this.positioningLabel = new Label(this);
this.positioningLabel.text = "Position:";
this.positioningLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

// Positioning Dropdown
this.positioningComboBox = new ComboBox(this);
this.positioningComboBox.addItem("Upper Left");
this.positioningComboBox.addItem("Upper Center");
this.positioningComboBox.addItem("Upper Right");
this.positioningComboBox.addItem("Left");
this.positioningComboBox.addItem("Center");
this.positioningComboBox.addItem("Right");
this.positioningComboBox.addItem("Lower Left");
this.positioningComboBox.addItem("Lower Center");
this.positioningComboBox.addItem("Lower Right");
this.positioningComboBox.currentItem = this.positioningComboBox.findItem(parameters.signaturePositioning); // Load saved position

this.positioningComboBox.onItemSelected = (index) => {
    parameters.signaturePositioning = this.positioningComboBox.itemText(index);
    this.updateSignaturePosition();
};

// Offset Label
this.offsetLabel = new Label(this);
this.offsetLabel.text = "Offset (px):";
this.offsetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

// Offset Input
this.offsetInput = new Edit(this);
this.offsetInput.text = parameters.signatureOffset.toString(); // Load saved offset

this.offsetInput.onEditCompleted = () => {
    let offsetValue = parseInt(this.offsetInput.text.trim());
    if (!isNaN(offsetValue)) {
        parameters.signatureOffset = offsetValue;
        this.updateSignaturePosition();
    }
};

// Horizontal sizer for the Positioning and Offset controls
this.positioningSizer = new HorizontalSizer;
this.positioningSizer.spacing = 6;
this.positioningSizer.add(this.positioningLabel);
this.positioningSizer.add(this.positioningComboBox);
this.positioningSizer.add(this.offsetLabel);
this.positioningSizer.add(this.offsetInput);
this.positioningSizer.addStretch();

this.updateSignaturePosition = function() {
    let offset = parameters.signatureOffset;
    let mainImage = this.previewControl.mainImage;
    let signatureImage = this.previewControl.cachedSignatureImage;

    if (!mainImage || !signatureImage) {
        return;
    }

    let x, y;

    switch (parameters.signaturePositioning) {
        case "Upper Left":
            x = offset;
            y = offset;
            break;
        case "Upper Center":
            x = (mainImage.width - signatureImage.width) / 2;
            y = offset;
            break;
        case "Upper Right":
            x = mainImage.width - signatureImage.width - offset;
            y = offset;
            break;
        case "Left":
            x = offset;
            y = (mainImage.height - signatureImage.height) / 2;
            break;
        case "Center":
            x = (mainImage.width - signatureImage.width) / 2;
            y = (mainImage.height - signatureImage.height) / 2;
            break;
        case "Right":
            x = mainImage.width - signatureImage.width - offset;
            y = (mainImage.height - signatureImage.height) / 2;
            break;
        case "Lower Left":
            x = offset;
            y = mainImage.height - signatureImage.height - offset;
            break;
        case "Lower Center":
            x = (mainImage.width - signatureImage.width) / 2;
            y = mainImage.height - signatureImage.height - offset;
            break;
        case "Lower Right":
            x = mainImage.width - signatureImage.width - offset;
            y = mainImage.height - signatureImage.height - offset;
            break;
    }

    this.previewControl.signaturePosition = new Point(x, y);
    this.previewControl.viewport.update();
};

// Add border-related UI components in the SignatureAdderDialog
this.borderCheckbox = new CheckBox(this);
this.borderCheckbox.text = "Add Border";
this.borderCheckbox.checked = parameters.borderEnabled;
this.borderCheckbox.toolTip = "Enable or disable border around the signature/image.";

this.borderWidthSlider = new NumericControl(this);
this.borderWidthSlider.label.text = "Border Width:";
this.borderWidthSlider.setRange(1, 20);
this.borderWidthSlider.slider.setRange(1, 200);
this.borderWidthSlider.setPrecision(0);
this.borderWidthSlider.setValue(parameters.borderWidth);
this.borderWidthSlider.enabled = parameters.borderEnabled;

// Preset Colors for the Border Dropdown
const presetColors = {
    "Black": 0x000000,
    "White": 0xFFFFFF,
    "Red": 0xFF0000,
    "Orange": 0xFFA500,
    "Yellow": 0xFFFF00,
    "Green": 0x00FF00,
    "Blue": 0x0000FF,
    "Cyan": 0x00FFFF,
    "Magenta": 0xFF00FF
};

// Border Color Dropdown
this.borderColor_Label = new Label(this);
this.borderColor_Label.text = "Border Color:";
this.borderColor_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

this.borderColorDropdown = new ComboBox(this);
for (let colorName in presetColors) {
    this.borderColorDropdown.addItem(colorName);
}

// Set default selected color based on saved parameter
let currentColor = parameters.borderColor;
let defaultColorIndex = 0; // Default to Black if no match

let i = 0;
for (let colorName in presetColors) {
    if (presetColors[colorName] === currentColor) {
        defaultColorIndex = i;
        break;
    }
    i++;
}
this.borderColorDropdown.currentItem = defaultColorIndex;

// Handle checkbox toggle
this.borderCheckbox.onCheck = (checked) => {
    parameters.borderEnabled = checked;
    this.borderWidthSlider.enabled = checked;
    this.borderColorDropdown.enabled = checked;
    this.previewControl.viewport.update();
};

// Handle border width change
this.borderWidthSlider.onValueUpdated = (value) => {
    parameters.borderWidth = value; // Update global parameters
    this.previewControl.viewport.update();
};

this.borderColorDropdown.onItemSelected = (index) => {
    let colorName = this.borderColorDropdown.itemText(index);
    parameters.borderColor = presetColors[colorName] | 0xFF000000; // Add full alpha (opacity)
    this.previewControl.viewport.update();
};


// Border Controls Sizer
this.borderSizer = new VerticalSizer;
this.borderSizer.spacing = 4;
this.borderSizer.add(this.borderCheckbox);
this.borderSizer.add(this.borderWidthSlider);
this.borderSizer.add(this.borderColor_Label);
this.borderSizer.add(this.borderColorDropdown);

// Ensure dropdown and slider enable/disable states are consistent
this.borderWidthSlider.enabled = parameters.borderEnabled;
this.borderColorDropdown.enabled = parameters.borderEnabled;




        // Zoom In Button
    this.zoomInButton = new PushButton(this);
    this.zoomInButton.text = "";
    this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
    this.zoomInButton.toolTip = "Zoom In";
    this.zoomInButton.onClick = () => {
        this.previewControl.zoomIn();
    };

    // Zoom Out Button
    this.zoomOutButton = new PushButton(this);
    this.zoomOutButton.text = "";
    this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
    this.zoomOutButton.toolTip = "Zoom Out";
    this.zoomOutButton.onClick = () => {
        this.previewControl.zoomOut();
    };

    // Zoom Label
    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Zoom In/Out (Mouse Wheel Supported)";

    // Zoom Sizer
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 6;
    this.zoomSizer.add(this.zoomInButton);
    this.zoomSizer.add(this.zoomOutButton);
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.addStretch();

    // ScrollControl for preview
    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);

    // Execute button
    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Execute";
    this.execute_Btn.toolTip = "Apply the signature overlay to the target image.";
    this.execute_Btn.onClick = () => {
        this.applySignatureOverlay();
        this.ok();
    };

    // New Instance button
    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

    this.buttonSizer = new HorizontalSizer;
    this.buttonSizer.spacing = 6;
    this.buttonSizer.add(this.newInstance_Btn);
    this.buttonSizer.addStretch();
    this.buttonSizer.add(this.execute_Btn);

    // Authorship label
    this.authorship_Lbl = new Label(this);
    this.authorship_Lbl.frameStyle = FrameStyle_Box;
    this.authorship_Lbl.margin = 6;
    this.authorship_Lbl.useRichText = true;
    this.authorship_Lbl.text = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
    this.authorship_Lbl.textAlignment = TextAlign_Center;
    this.authorship_Lbl.onMousePress = () => {
    Dialog.openBrowser("http://www.setiastro.com");
};

    // Function to update preview images based on current selections
    this.updatePreview = function() {
        if (parameters.targetWindow && this.cachedSignatureImage) {
            this.previewControl.doUpdateImage(
                parameters.targetWindow.mainView.image,
                this.cachedSignatureImage
            );
        }
    };

    // Function to cache the resampled signature image
    this.cacheResampledSignature = function() {
        if (parameters.signatureWindow) {
            let signatureImage = new Image(parameters.signatureWindow.mainView.image);
            signatureImage.resample(this.signatureScale);
            this.cachedSignatureImage = signatureImage;
        }
    };

    // Call updatePreview() to populate the preview on dialog open
    parameters.targetWindow = ImageWindow.windowById(this.targetWindowSelector_Cb.itemText(this.targetWindowSelector_Cb.currentItem));
    parameters.signatureWindow = null; // Initially, no signature image is selected
    this.updatePreview();

this.applySignatureOverlay = function() {
    if (!parameters.targetWindow || !this.cachedSignatureImage) {
        (new MessageBox("Please select both main and signature images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let targetImage = parameters.targetWindow.mainView.image;
    let cachedSignatureImage = this.cachedSignatureImage;

    // Check if the main image is grayscale and convert it to RGB if necessary
    if (!targetImage.isColor) {
        let convertToRGBMain = new ConvertToRGBColor;
        convertToRGBMain.executeOn(parameters.targetWindow.mainView); // Convert main image to RGB
        targetImage = parameters.targetWindow.mainView.image; // Reassign the converted image
    }

    // Check if the signature image is grayscale and convert it to RGB if necessary
    if (!cachedSignatureImage.isColor) {
        let tempWindow = new ImageWindow(
            cachedSignatureImage.width,
            cachedSignatureImage.height,
            cachedSignatureImage.numberOfChannels,
            cachedSignatureImage.bitsPerSample,
            cachedSignatureImage.isReal,
            cachedSignatureImage.isColor
        );

        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign(cachedSignatureImage);
        tempWindow.mainView.endProcess();

        let convertToRGB = new ConvertToRGBColor;
        convertToRGB.executeOn(tempWindow.mainView); // Convert signature image to RGB

        // Assign the converted image back to cachedSignatureImage
        cachedSignatureImage.assign(tempWindow.mainView.image);

        // Close the temporary window
        tempWindow.forceClose();
    }

function normalizeAngle(angle) {
    while (angle > Math.PI) {
        angle -= 2 * Math.PI;
    }
    while (angle < -Math.PI) {
        angle += 2 * Math.PI;
    }
    return angle;
}



    // Use the position, scale, and rotation from the ScrollControl
    let signaturePosition = this.previewControl.signaturePosition;
    let signatureScale = this.previewControl.signatureScale;
    let signatureRotation = normalizeAngle(this.previewControl.signatureRotation * Math.PI / 180); // Convert to radians and normalize

    let signatureOpacity = this.previewControl.signatureOpacity;
    let blendMode = parameters.blendMode || "Normal";

    // Create a temporary image to hold the resampled signature
    let resampledSignatureWindow = new ImageWindow(
        cachedSignatureImage.width,
        cachedSignatureImage.height,
        cachedSignatureImage.numberOfChannels,
        cachedSignatureImage.bitsPerSample,
        cachedSignatureImage.isReal,
        cachedSignatureImage.isColor
    );

    resampledSignatureWindow.mainView.beginProcess();
    resampledSignatureWindow.mainView.image.assign(cachedSignatureImage);
    resampledSignatureWindow.mainView.endProcess();

    // Resample the signature using the specified scale factor
    let P = new Resample;
    P.xSize = signatureScale;
    P.ySize = signatureScale;
    P.mode = Resample.prototype.RelativeDimensions;
    P.absoluteMode = Resample.prototype.ForceWidthAndHeight;
    P.xResolution = 72.000;
    P.yResolution = 72.000;
    P.metric = false;
    P.forceResolution = false;
    P.interpolation = Resample.prototype.Auto;
    P.clampingThreshold = 0.30;
    P.smoothness = 2.00;
    P.gammaCorrection = true;
    P.noGUIMessages = true;
    P.executeOn(resampledSignatureWindow.mainView);

    let resampledSignatureImage = resampledSignatureWindow.mainView.image;

if (parameters.borderEnabled) {
    let borderWidth = parameters.borderWidth;
    let borderColor = parameters.borderColor;

    // Extract RGB components with a small epsilon
    let epsilon = 0 / 255.0;
    let red = ((borderColor >> 16) & 0xFF) / 255.0 + epsilon;
    let green = ((borderColor >> 8) & 0xFF) / 255.0 + epsilon;
    let blue = (borderColor & 0xFF) / 255.0 + epsilon;

    // Create a new expanded canvas
    let expandedWidth = resampledSignatureImage.width + 2 * borderWidth;
    let expandedHeight = resampledSignatureImage.height + 2 * borderWidth;

    let expandedSignatureWindow = new ImageWindow(
        expandedWidth,
        expandedHeight,
        resampledSignatureImage.numberOfChannels,
        resampledSignatureImage.bitsPerSample,
        resampledSignatureImage.isReal,
        resampledSignatureImage.isColor
    );

    let expandedImage = expandedSignatureWindow.mainView.image;

    expandedSignatureWindow.mainView.beginProcess();
    expandedImage.fill(1);

    // Copy the resampled signature to the center of the expanded canvas
    let signatureBitmap = resampledSignatureImage.render(); // Convert to Bitmap
    expandedImage.blend(signatureBitmap, new Point(borderWidth, borderWidth));


    // Add the border around the edges
    for (let b = 0; b < borderWidth; b++) {
        // Top Border
        for (let x = b; x < expandedWidth - b; x++) {
            expandedImage.setSample(red, x, b, 0);
            expandedImage.setSample(green, x, b, 1);
            expandedImage.setSample(blue, x, b, 2);
        }

        // Bottom Border
        for (let x = b; x < expandedWidth - b; x++) {
            expandedImage.setSample(red, x, expandedHeight - 1 - b, 0);
            expandedImage.setSample(green, x, expandedHeight - 1 - b, 1);
            expandedImage.setSample(blue, x, expandedHeight - 1 - b, 2);
        }

        // Left Border
        for (let y = b; y < expandedHeight - b; y++) {
            expandedImage.setSample(red, b, y, 0);
            expandedImage.setSample(green, b, y, 1);
            expandedImage.setSample(blue, b, y, 2);
        }

        // Right Border
        for (let y = b; y < expandedHeight - b; y++) {
            expandedImage.setSample(red, expandedWidth - 1 - b, y, 0);
            expandedImage.setSample(green, expandedWidth - 1 - b, y, 1);
            expandedImage.setSample(blue, expandedWidth - 1 - b, y, 2);
        }
    }

    expandedSignatureWindow.mainView.endProcess();

    // Replace resampledSignatureImage with the expanded one
    resampledSignatureImage = expandedImage;
    resampledSignatureWindow.forceClose(); // Clean up the original window
    resampledSignatureWindow = expandedSignatureWindow; // Use the new window
}





    // Apply rotation using the Rotation process
    let rotationProcess = new Rotation;
    rotationProcess.angle = signatureRotation; // Use the calculated rotation in radians
    rotationProcess.optimizeFast = true;
    rotationProcess.interpolation = Rotation.prototype.Auto;
    rotationProcess.clampingThreshold = 0.30;
    rotationProcess.smoothness = 1.50;
    rotationProcess.gammaCorrection = false;
    rotationProcess.red = 0.000000;
    rotationProcess.green = 0.000000;
    rotationProcess.blue = 0.000000;
    rotationProcess.alpha = 1.000000;
    rotationProcess.noGUIMessages = true;

    rotationProcess.executeOn(resampledSignatureWindow.mainView);

    // Get the rotated signature image
    resampledSignatureImage = resampledSignatureWindow.mainView.image;

    // Create a temporary image to hold the result
    let tempImageWindow = new ImageWindow(
        targetImage.width,
        targetImage.height,
        targetImage.numberOfChannels,
        targetImage.bitsPerSample,
        targetImage.isReal,
        targetImage.isColor
    );
    let tempImage = tempImageWindow.mainView.image;

    // Ensure the temporary image is unlocked and editable
    tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    tempImage.assign(targetImage);




    // Apply the scaled and rotated signature to the correct position
    let centerX = signaturePosition.x + resampledSignatureImage.width / 2;
    let centerY = signaturePosition.y + resampledSignatureImage.height / 2;

    for (let y = 0; y < resampledSignatureImage.height; y++) {
        for (let x = 0; x < resampledSignatureImage.width; x++) {
            let alphaChannelIndex = resampledSignatureImage.numberOfChannels - 1; // Assume the last channel is the alpha channel
            let alpha = resampledSignatureImage.sample(x, y, alphaChannelIndex) * signatureOpacity;

            // Check if the pixel is black (all channels 0)
            let isBlackPixel = true;
            for (let c = 0; c < 3; c++) { // Only check the RGB channels
                if (resampledSignatureImage.sample(x, y, c) !== 0) {
                    isBlackPixel = false;
                    break;
                }
            }

            if (!isBlackPixel && alpha > 0) { // Skip black pixels and fully transparent pixels
                let targetX = Math.round(centerX + (x - resampledSignatureImage.width / 2));
                let targetY = Math.round(centerY + (y - resampledSignatureImage.height / 2));

                if (targetX < tempImage.width && targetY < tempImage.height && targetX >= 0 && targetY >= 0) {
                    for (let c = 0; c < tempImage.numberOfChannels; c++) {
                        let signaturePixel = resampledSignatureImage.sample(x, y, c);
                        let currentPixel = tempImage.sample(targetX, targetY, c);
                        let blendedPixel;

                        switch (blendMode) {
                            case "Lighten":
                                blendedPixel = Math.max(signaturePixel * alpha, currentPixel);
                                break;
                            case "Multiply":
                                blendedPixel = signaturePixel * currentPixel;
                                break;
                            case "Screen":
                                blendedPixel = 1 - (1 - signaturePixel * alpha) * (1 - currentPixel);
                                break;
                            case "Overlay":
                                blendedPixel = currentPixel < 0.5
                                    ? 2 * currentPixel * signaturePixel * alpha
                                    : 1 - 2 * (1 - currentPixel) * (1 - signaturePixel * alpha);
                                break;
                            case "Difference":
                                blendedPixel = Math.abs(currentPixel - signaturePixel * alpha);
                                break;
                            case "Darken":
                                blendedPixel = Math.min(signaturePixel * alpha, currentPixel);
                                break;
                            case "Replacement": // New case for "Replacement" mode
                                blendedPixel = (signaturePixel * signatureOpacity) + (currentPixel * (1 - signatureOpacity)) // Directly overwrite the pixel
                                break;
                            default: // Normal
                                blendedPixel = (signaturePixel * alpha) + (currentPixel * (1 - alpha));
                        }

                        tempImage.setSample(blendedPixel, targetX, targetY, c);
                    }
                }
            }
        }
    }

    // Finalize the changes to the temporary image
    tempImageWindow.mainView.endProcess();

    // Use PixelMath to replace the original image with the temporary image
    let pixelMath = new PixelMath;
    pixelMath.expression = tempImageWindow.mainView.id;
    pixelMath.useSingleExpression = true;
    pixelMath.clearImageCacheAndExit = false;
    pixelMath.cacheGeneratedImages = false;
    pixelMath.generateOutput = true;
    pixelMath.singleThreaded = false;
    pixelMath.optimization = true;
    pixelMath.use64BitWorkingImage = false;
    pixelMath.rescale = false;
    pixelMath.rescaleLower = 0;
    pixelMath.rescaleUpper = 1;
    pixelMath.truncate = true;
    pixelMath.truncateLower = 0;
    pixelMath.truncateUpper = 1;
    pixelMath.createNewImage = false;
    pixelMath.showNewImage = false;
    pixelMath.newImageId = "";
    pixelMath.newImageWidth = 0;
    pixelMath.newImageHeight = 0;
    pixelMath.newImageAlpha = false;
    pixelMath.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    pixelMath.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    let targetView = parameters.targetWindow.mainView;
    pixelMath.executeOn(targetView);

    // Clean up the temporary images
    resampledSignatureWindow.forceClose();
    tempImageWindow.forceClose();

    console.noteln("Signature overlay applied successfully!");

    // Close the dialog after execution
    this.ok();
};

// Define the mainSizer as a HorizontalSizer to hold both the left panel and preview
this.mainSizer = new HorizontalSizer;
this.mainSizer.spacing = 4;

// Define a spacer control with a fixed width
this.leftSideSpacer = new Control(this);
this.leftSideSpacer.setFixedWidth(6); // Adjust the width as needed

// Insert the spacer control at the beginning of the mainSizer
this.mainSizer.insert(0, this.leftSideSpacer);
this.mainSizer.addSpacing(0); // Add some spacing after the spacer

// Define the layout for the controls
this.leftSizer = new VerticalSizer;
this.leftSizer.spacing = 6;
this.leftSizer.add(this.title_Lbl);
this.leftSizer.addSpacing(10);
this.leftSizer.add(this.instructions_Lbl);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.targetWindow_Label);
this.leftSizer.add(this.targetWindowSelector_Cb);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.signatureWindow_Label);
this.leftSizer.add(this.signatureWindowSelector_Cb);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.blendModeSizer)
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.signatureSize_Slider);
this.leftSizer.add(this.signatureRotation_Slider);
this.leftSizer.add(this.signatureOpacity_Slider);
this.leftSizer.add(this.positioningSizer);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.borderSizer);
this.leftSizer.addStretch();
this.leftSizer.add(this.authorship_Lbl);
this.leftSizer.add(this.buttonSizer); // Adjusted to have buttons side by side

// Create a control to fix the width of the left panel
this.leftPanel = new Control(this);
this.leftPanel.sizer = this.leftSizer;
this.leftPanel.setFixedWidth(450); // Adjust this value as needed

// Right Side Sizer (includes Zoom Sizer and Preview Control)
this.rightSizer = new VerticalSizer;
this.rightSizer.spacing = 6;
this.rightSizer.add(this.zoomSizer);  // Add Zoom buttons above the preview
this.rightSizer.add(this.previewControl, 1); // Add the preview below the zoom buttons

// Add the leftPanel and rightSizer to the mainSizer
this.mainSizer.add(this.leftPanel);
this.mainSizer.add(this.rightSizer, 1);

this.sizer = this.mainSizer;

this.updateSignaturePosition();
    this.windowTitle = TITLE;
    this.adjustToContents();  // Ensure the window adjusts to its content
}
SignatureAdderDialog.prototype = new Dialog;

function main() {
    console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    Console.writeln("AstroMark Loading...");

    // Load the saved parameters
    parameters.load();

    let dialog = new SignatureAdderDialog();
    dialog.execute();
}

main();

