#feature-id    FrequencySeparation : SetiAstro > FrequencySeparation
#feature-icon  frequencyseparation.svg
#feature-info  Frequency Separation in PJSR
/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * FrequencySeperator.js
 *
 * Demonstrates frequency separation in PJSR with two synchronized previews.
 * - LF and HF are stored in temporary 32-bit float windows.
 * - A "Save & Close" button creates permanent LF/HF windows and closes the script.
 * - A "Combine" tab allows loading existing HF/LF windows and combining them.
 *
 * Written by Franklin Marek, 2024
 * Website: www.setiastro.com
 * License: CC BY-NC 4.0
 ******************************************************************************/
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/BitmapInterpolation.jsh>
#include <pjsr/FontFamily.jsh>

var gSyncing = false; // global or static variable to prevent infinite loops

function SyncScrollControl(parent) {
   this.__base__ = ScrollBox;
   this.__base__(parent);

   this.mainImage = null;
   this.zoomFactor = 1.0;
   this.minZoomFactor = 0.1;
   this.maxZoomFactor = 10.0;
   this.dragging = false;
   this.dragOrigin = new Point(0, 0);

   // We'll store a reference to the "other" scroll control
   this.sibling = null; // We set this externally after creation

   this.setImage = function(image) {
      this.mainImage = image;
      this.initScrollBars();
      if (this.viewport) this.viewport.update();
   };

   this.syncBoth = function() {
      if (!this.sibling) return;
      if (gSyncing) return;
      gSyncing = true;

      // Force sibling to match scrollPosition and zoomFactor
      this.sibling.zoomFactor = this.zoomFactor;
      this.sibling.scrollPosition = new Point(this.scrollPosition.x, this.scrollPosition.y);
      this.sibling.initScrollBars();
      if (this.sibling.viewport) this.sibling.viewport.update();

      gSyncing = false;
   };

   this.initScrollBars = function() {
      if (!this.mainImage || this.mainImage.isEmpty) {
         this.setHorizontalScrollRange(0,0);
         this.setVerticalScrollRange(0,0);
         this.scrollPosition = new Point(0,0);
      } else {
         let w = this.mainImage.width * this.zoomFactor;
         let h = this.mainImage.height * this.zoomFactor;
         this.setHorizontalScrollRange(0, Math.max(0, w));
         this.setVerticalScrollRange(0, Math.max(0, h));
      }
   };

   // Mouse press for drag
   this.viewport.onMousePress = function(x,y) {
      let p = this.parent;
      p.dragging = true;
      p.dragOrigin = new Point(x,y);
      this.cursor = new Cursor(StdCursor_ClosedHand);
   };
   // Mouse move
   this.viewport.onMouseMove = function(x,y) {
      let p = this.parent;
      if (p.dragging) {
         let dx = (x - p.dragOrigin.x)/p.zoomFactor;
         let dy = (y - p.dragOrigin.y)/p.zoomFactor;
         p.scrollPosition = new Point(p.scrollPosition.x - dx,
                                      p.scrollPosition.y - dy);
         p.dragOrigin = new Point(x,y);
         this.update();
         // sync sibling
         p.syncBoth();
      }
   };
   // Mouse release
   this.viewport.onMouseRelease = function() {
      let p = this.parent;
      p.dragging = false;
      this.cursor = new Cursor(StdCursor_Arrow);
   };
   // Mouse wheel => zoom
   this.viewport.onMouseWheel = function(x,y,delta) {
      let p = this.parent;
      if (delta>0) p.zoomFactor = Math.min(p.zoomFactor*1.25, p.maxZoomFactor);
      else if (delta<0) p.zoomFactor = Math.max(p.zoomFactor*0.8, p.minZoomFactor);
      p.initScrollBars();
      this.update();
      p.syncBoth();
   };
   // Paint
   this.viewport.onPaint = function(x0,y0,x1,y1) {
      var g = new Graphics(this);
      if (!this.parent.mainImage || this.parent.mainImage.isEmpty) {
         g.fillRect(x0,y0,x1,y1,new Brush(0xff000000));
      } else {
         g.scaleTransformation(this.parent.zoomFactor);
         g.translateTransformation(-this.parent.scrollPosition.x,
                                   -this.parent.scrollPosition.y);
         g.drawBitmap(0,0,this.parent.mainImage.render());
      }
      g.end();
   };
}
SyncScrollControl.prototype = new ScrollBox;

function ScrollControlFS(parent) {
   this.__base__ = ScrollBox;
   this.__base__(parent);

   this.mainImage = null;
   this.zoomFactor = 1.0;
   this.minZoomFactor = 0.1;
   this.maxZoomFactor = 10.0;
   this.dragging = false;
   this.dragOrigin = new Point(0, 0);

   this.setImage = function(image) {
      this.mainImage = image;
      this.initScrollBars();
      if (this.viewport) {
         this.viewport.update();
      }
   };

   this.initScrollBars = function() {
      if (!this.mainImage || this.mainImage.isEmpty) {
         this.setHorizontalScrollRange(0,0);
         this.setVerticalScrollRange(0,0);
         this.scrollPosition = new Point(0,0);
      } else {
         let w = this.mainImage.width * this.zoomFactor;
         let h = this.mainImage.height * this.zoomFactor;
         this.setHorizontalScrollRange(0, Math.max(0, w));
         this.setVerticalScrollRange(0, Math.max(0, h));
      }
      if (this.viewport) this.viewport.update();
   };

   // Mouse events
   this.viewport.onMousePress = function(x,y) {
      this.parent.dragging = true;
      this.parent.dragOrigin = new Point(x,y);
      this.cursor = new Cursor(StdCursor_ClosedHand);
   };
   this.viewport.onMouseMove = function(x,y) {
      let parent = this.parent;
      if (parent.dragging) {
         let dx = (x - parent.dragOrigin.x) / parent.zoomFactor;
         let dy = (y - parent.dragOrigin.y) / parent.zoomFactor;
         parent.scrollPosition = new Point(
            parent.scrollPosition.x - dx,
            parent.scrollPosition.y - dy
         );
         parent.dragOrigin = new Point(x,y);
         this.update();
      }
   };
   this.viewport.onMouseRelease = function() {
      let p = this.parent;
      p.dragging = false;
      this.cursor = new Cursor(StdCursor_Arrow);
   };
   this.viewport.onMouseWheel = function(x,y,delta) {
      let p = this.parent;
      if (delta > 0) p.zoomFactor = Math.min(p.zoomFactor * 1.25, p.maxZoomFactor);
      else if (delta < 0) p.zoomFactor = Math.max(p.zoomFactor * 0.8, p.minZoomFactor);
      p.initScrollBars();
      this.update();
   };

   // Paint
   this.viewport.onPaint = function(x0,y0,x1,y1) {
      var g = new Graphics(this);
      if (!this.parent.mainImage || this.parent.mainImage.isEmpty) {
         g.fillRect(x0,y0,x1,y1, new Brush(0xff000000));
      } else {
         g.scaleTransformation(this.parent.zoomFactor);
         g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
         g.drawBitmap(0,0,this.parent.mainImage.render());
      }
      g.end();
   };

   this.initScrollBars();
}
ScrollControlFS.prototype = new ScrollBox;

function FrequencySeparationDialog() {
   this.__base__ = Dialog;
   this.__base__();

   this.windowTitle = "Frequency Separation V1.0";

      // Instruction Box
   this.instructionLabel = new Label(this);
   this.instructionLabel.frameStyle = FrameStyle_Box;
   this.instructionLabel.margin = 6;
   this.instructionLabel.useRichText = true; // Allows for HTML formatting
   this.instructionLabel.text =
   "<p><b>Instructions:</b> Select a source image, adjust the frequency radius value, and click 'Separate HF + LF' to perform frequency separation.</p>" +
   "<p>Use the bottom section to load a HF and LF image and recombine them.</p>";
   "<p>Mousewheel can be used to zoom in and out.  Images are scroll synced.</p>";


   // We keep references to the temp LF/HF windows
   this.lfWinTemp = null;
   this.hfWinTemp = null;

   // Source combo
   this.sourceLabel = new Label(this);
   this.sourceLabel.text = "Select Source:";
   this.sourceCombo = new ComboBox(this);

   for (var i = 0; i < ImageWindow.windows.length; i++) {
      let wId = ImageWindow.windows[i].mainView.id;
      this.sourceCombo.addItem(wId);
   }
   if (ImageWindow.activeWindow && !ImageWindow.activeWindow.isNull) {
      for (var j = 0; j < ImageWindow.windows.length; j++) {
         if (ImageWindow.windows[j].mainView.id == ImageWindow.activeWindow.mainView.id) {
            this.sourceCombo.currentItem = j;
            break;
         }
      }
   }

   this.blurSigma = new NumericControl(this);
   this.blurSigma.label.text = "Frequency Radius:";
   this.blurSigma.setRange(0.5, 20.0);
   this.blurSigma.slider.setRange(5, 200);
   this.blurSigma.setPrecision(1);
   this.blurSigma.setValue(2.0);

   // Two sync scroll controls
   this.lfScroll = new SyncScrollControl(this);
   this.hfScroll = new SyncScrollControl(this);
   // Link them
   this.lfScroll.sibling = this.hfScroll;
   this.hfScroll.sibling = this.lfScroll;

   this.lfScroll.setMinSize(300, 300);
   this.hfScroll.setMinSize(300, 300);

   // Buttons: Separate, Save & Close
   this.separateBtn = new PushButton(this);
   this.separateBtn.text = "Separate HF + LF";
   this.separateBtn.onClick = function () {
      this.doSeparate();
   }.bind(this);

   this.saveBtn = new PushButton(this);
   this.saveBtn.text = "Create Images and Close";
   this.saveBtn.onClick = function () {
      this.saveAndClose();
   }.bind(this);

   // A separate "Combine" section: user picks HF, LF from combos, and we create new window
   this.combineHFLabel = new Label(this);
   this.combineHFLabel.text = "Load HF Image:";

   this.combineHFCombo = new ComboBox(this);

   this.combineLFLabel = new Label(this);
   this.combineLFLabel.text = "Load LF Image:";

   this.combineLFCombo = new ComboBox(this);

   this.populateHFAndLFCombos = function () {
      this.combineHFCombo.clear();
      this.combineLFCombo.clear();
      for (var i = 0; i < ImageWindow.windows.length; i++) {
         let wId = ImageWindow.windows[i].mainView.id;
         this.combineHFCombo.addItem(wId);
         this.combineLFCombo.addItem(wId);
      }
   };
   this.populateHFAndLFCombos();

   this.combineButton = new PushButton(this);
   this.combineButton.text = "Combine HF+LF => new image";
   this.combineButton.onClick = function () {
      this.doCombineHFandLF();
   }.bind(this);

   // Sizers
   let topSizer = new HorizontalSizer;
   topSizer.spacing = 6;
   topSizer.add(this.sourceLabel);
   topSizer.add(this.sourceCombo, 100);

   let blurSizer = new HorizontalSizer;
   blurSizer.spacing = 6;
   blurSizer.add(this.blurSigma, 100);

   let buttonSizer = new HorizontalSizer;
   buttonSizer.spacing = 6;
   buttonSizer.add(this.separateBtn);
   buttonSizer.addStretch();
   buttonSizer.add(this.saveBtn);

   let previewSizer = new HorizontalSizer;
   previewSizer.spacing = 6;
   previewSizer.add(this.hfScroll, 1);
   previewSizer.add(this.lfScroll, 1);

   // Combine sizer
   let combineSizer = new VerticalSizer;
   combineSizer.spacing = 6;

   let hfSizer = new HorizontalSizer;
   hfSizer.add(this.combineHFLabel);
   hfSizer.add(this.combineHFCombo, 100);

   let lfSizer = new HorizontalSizer;
   lfSizer.add(this.combineLFLabel);
   lfSizer.add(this.combineLFCombo, 100);

   combineSizer.add(hfSizer);
   combineSizer.add(lfSizer);
   combineSizer.add(this.combineButton);

// Authorship label
this.authorship_Lbl = new Label(this);
this.authorship_Lbl.frameStyle = FrameStyle_Box;
this.authorship_Lbl.margin = 6;
this.authorship_Lbl.useRichText = true;
this.authorship_Lbl.text = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
this.authorship_Lbl.textAlignment = TextAlign_Center;
this.authorship_Lbl.onMousePress = () => {
    Dialog.openBrowser("http://www.setiastro.com");
};

// New instance button
this.newInstanceButton = new ToolButton(this);
this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
this.newInstanceButton.setScaledFixedSize(24, 24);
this.newInstanceButton.toolTip = "Create a new instance with the current parameters.";
this.newInstanceButton.onMousePress = function () {
    this.dialog.newInstance();
}.bind(this);

// Footer sizer: Place the authorship label and new instance button in a horizontal sizer
let footerSizer = new HorizontalSizer;
footerSizer.spacing = 6;
footerSizer.add(this.newInstanceButton); // Stretch the authorship label to occupy available space
footerSizer.addStretch();


   let mainSizer = new VerticalSizer;
   mainSizer.margin = 6;
   mainSizer.spacing = 6;

   // Add the instruction box at the top
   mainSizer.add(this.instructionLabel);
   mainSizer.addSpacing(10);
   mainSizer.margin = 6;
   mainSizer.spacing = 6;
   mainSizer.add(topSizer);
   mainSizer.add(blurSizer);
   mainSizer.add(buttonSizer);
   mainSizer.add(previewSizer, 1);
   mainSizer.addSpacing(10);
   mainSizer.add(combineSizer);
   mainSizer.addSpacing(10);
   mainSizer.add(this.authorship_Lbl);
   mainSizer.add(footerSizer);

   this.sizer = mainSizer;
   this.adjustToContents();

   // Helper references
   this.selectedWindow = function () {
      var idx = this.sourceCombo.currentItem;
      var wId = this.sourceCombo.itemText(idx);
      return ImageWindow.windowById(wId);
   };
}
FrequencySeparationDialog.prototype = new Dialog;



FrequencySeparationDialog.prototype.doSeparate = function() {
   // 1) find source
   let idx = this.sourceCombo.currentItem;
   let wId = this.sourceCombo.itemText(idx);
   let sourceWin = ImageWindow.windowById(wId);
   if (sourceWin.isNull) {
      (new MessageBox("No valid source image.", "Error", StdIcon_Error, StdButton_Ok)).execute();
      return;
   }
   // cleanup old if exist
   this.cleanupTemp();

   // 2) Create LF
   this.lfWinTemp = new ImageWindow(
      sourceWin.mainView.image.width,
      sourceWin.mainView.image.height,
      sourceWin.mainView.image.numberOfChannels,
      /*bitsPerSample=*/32,
      /*isReal=*/true,
      sourceWin.mainView.image.isColor,
      "LF_temp"
   );
   this.lfWinTemp.mainView.beginProcess(UndoFlag_NoSwapFile);
   this.lfWinTemp.mainView.image.assign(sourceWin.mainView.image);
   this.lfWinTemp.mainView.endProcess();

   // Apply a convolution blur with sigma= this.blurSigma.value
   let conv = new Convolution;
   conv.mode = Convolution.prototype.Parametric;
   conv.sigma = this.blurSigma.value;
   conv.executeOn(this.lfWinTemp.mainView,false);

   // 3) Create HF
   this.hfWinTemp = new ImageWindow(
      sourceWin.mainView.image.width,
      sourceWin.mainView.image.height,
      sourceWin.mainView.image.numberOfChannels,
      32,
      true,
      sourceWin.mainView.image.isColor,
      "HF_temp"
   );
   this.hfWinTemp.mainView.beginProcess(UndoFlag_NoSwapFile);
   this.hfWinTemp.mainView.image.assign(sourceWin.mainView.image);
   this.hfWinTemp.mainView.endProcess();

   // 4) PixelMath: HF_temp = max( original - LF_temp, 0 )
   let pm = new PixelMath;
   pm.expression = "max(" + sourceWin.mainView.id + " - " + this.lfWinTemp.mainView.id + " + 0.5, 0)";
   pm.useSingleExpression = true;
   pm.createNewImage = false;
   pm.rescale = false;
   pm.executeOn(this.hfWinTemp.mainView);

   // 5) Show them in the previews
   this.lfScroll.setImage(this.lfWinTemp.mainView.image);
   this.hfScroll.setImage(this.hfWinTemp.mainView.image);

   console.writeln("Separated " + wId + " => LF_temp, HF_temp (32-bit float).");
};

FrequencySeparationDialog.prototype.cleanupTemp = function() {
   if (this.lfWinTemp && !this.lfWinTemp.isNull) {
      this.lfWinTemp.forceClose();
      this.lfWinTemp=null;
   }
   if (this.hfWinTemp && !this.hfWinTemp.isNull) {
      this.hfWinTemp.forceClose();
      this.hfWinTemp=null;
   }
   this.lfScroll.setImage(null);
   this.hfScroll.setImage(null);
};

FrequencySeparationDialog.prototype.saveAndClose = function() {
   if (!this.lfWinTemp || this.lfWinTemp.isNull ||
       !this.hfWinTemp || this.hfWinTemp.isNull) {
      (new MessageBox("No LF/HF images to save. Did you run Separate HF+LF?",
                      "Error", StdIcon_Error, StdButton_Ok)).execute();
      return;
   }
   // rename them
   let lfId = "LF_Final";
   let hfId = "HF_Final";
   // If these exist, you might forceClose or prompt user
   this.lfWinTemp.mainView.id = lfId;
   this.hfWinTemp.mainView.id = hfId;
   this.lfWinTemp.show();
   this.hfWinTemp.show();

   console.writeln("Created final windows: " + lfId + ", " + hfId);

   this.cancel();
};


FrequencySeparationDialog.prototype.doCombineHFandLF = function() {
   let hfIndex = this.combineHFCombo.currentItem;
   let lfIndex = this.combineLFCombo.currentItem;
   let hfName = this.combineHFCombo.itemText(hfIndex);
   let lfName = this.combineLFCombo.itemText(lfIndex);

   let hfWin = ImageWindow.windowById(hfName);
   let lfWin = ImageWindow.windowById(lfName);
   if (hfWin.isNull || lfWin.isNull) {
      (new MessageBox("Invalid HF or LF window selected.","Error",
        StdIcon_Error, StdButton_Ok)).execute();
      return;
   }
   // create new Combined
   let combWin = new ImageWindow(
      hfWin.mainView.image.width,
      hfWin.mainView.image.height,
      hfWin.mainView.image.numberOfChannels,
      32,
      true,
      hfWin.mainView.image.isColor,
      "Combined_temp"
   );
   combWin.mainView.beginProcess(UndoFlag_NoSwapFile);
   combWin.mainView.image.assign(lfWin.mainView.image);
   combWin.mainView.endProcess();

   // PixelMath: combined = clamp(lf + hf, 0, 1 or something)
   let pm = new PixelMath;
   pm.expression = "min(" + lfName + " + " + hfName + "-0.5, 1)";
   pm.useSingleExpression = true;
   pm.createNewImage = false;
   pm.rescale = false;
   pm.executeOn(combWin.mainView);

   combWin.show();

   console.writeln("Combined " + lfName + " + " + hfName + " => " + combWin.mainView.id);
   this.cancel();
};


function main() {
   if (ImageWindow.windows.length<1) {
      (new MessageBox("No images open.","FrequencySeparation",StdIcon_Error,StdButton_Ok)).execute();
      return;
   }
   console.show();
   console.writeln("FrequencySeparation script loaded...");
   let dlg = new FrequencySeparationDialog();
   dlg.execute();
}

main();
