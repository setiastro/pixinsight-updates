#feature-id AstroDepth : SetiAstro > AstroDepth Image Enhancer
#feature-icon  astrodepth.svg
#feature-info This script allows users adjust a depth of field effect on their images


/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * AstroDepth Image Enhancer
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script allows users to overlay their signature image on top
 * of another image.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/


#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/BitmapInterpolation.jsh>

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.mainImage = null;
    this.zoomFactor = 1.0;
    this.minZoomFactor = 0.1;
    this.maxZoomFactor = 10.0;
    this.dragging = false;
    this.dragOrigin = new Point(0, 0);

    this.getImage = function () {
        return this.mainImage;
    };

    this.updateImage = function (image) {
        this.mainImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

    this.initScrollBars = function (scrollPoint = null) {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
            this.scrollPosition = new Point(0, 0);
        } else {
            let zoomFactor = this.zoomFactor;
            this.setHorizontalScrollRange(0, Math.max(0, image.width * zoomFactor));
            this.setVerticalScrollRange(0, Math.max(0, image.height * zoomFactor));
            if (scrollPoint) {
                this.scrollPosition = scrollPoint;
            } else {
                this.scrollPosition = new Point(
                    Math.min(this.scrollPosition.x, image.width * zoomFactor),
                    Math.min(this.scrollPosition.y, image.height * zoomFactor)
                );
            }
        }
        if (this.viewport) {
            this.viewport.update();
        }
    };

// Mouse press event to start dragging or transformation
// Mouse press event to start dragging
this.viewport.onMousePress = function(x, y) {
    var parent = this.parent;
    parent.dragging = true;
    parent.dragOrigin.x = x; // Save the initial drag position in screen coordinates
    parent.dragOrigin.y = y;

    this.cursor = new Cursor(StdCursor_ClosedHand); // Show closed hand cursor when dragging starts
};

// Mouse move event to drag the view (scrolling)
this.viewport.onMouseMove = function(x, y) {
    var parent = this.parent;
    let zoomFactor = parent.zoomFactor;

    if (parent.dragging) {
        let dx = (x - parent.dragOrigin.x) / zoomFactor;
        let dy = (y - parent.dragOrigin.y) / zoomFactor;
        parent.scrollPosition = new Point(parent.scrollPosition.x - dx, parent.scrollPosition.y - dy);
        parent.dragOrigin.x = x; // Update drag origin to continue the drag smoothly
        parent.dragOrigin.y = y;

        if (parent.viewport) {
            parent.viewport.update(); // Refresh the view to reflect scrolling
        }
    }
};

// Mouse release event to stop dragging
this.viewport.onMouseRelease = function() {
    var parent = this.parent;
    parent.dragging = false;
    this.cursor = new Cursor(StdCursor_Arrow); // Reset the cursor when dragging stops
};


    // Mouse wheel event for zooming
    this.viewport.onMouseWheel = function (x, y, delta) {
        var parent = this.parent;
        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }
        parent.initScrollBars();
        this.update();
    };

    // Rendering of the image inside the ScrollControl
this.viewport.onPaint = function(x0, y0, x1, y1) {
    var g = new Graphics(this);
    var image = this.parent.mainImage;  // Fetch the current image
    let zoomFactor = this.parent.zoomFactor;

    if (image == null || image.isEmpty) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));  // Black background if no image
    } else {
        g.scaleTransformation(zoomFactor);  // Apply zoom
        g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);  // Apply scrolling
        g.drawBitmap(0, 0, image.render());  // Render the image
    }
    g.end();
};



    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function DepthEffectDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "AstroDepth Image Enhancer";
    this.userResizable = true; // Allow user to resize the dialog

        // Initialize an array to track all temp image windows
    this.tempImageWindows = [];

    this.titleLabel = new Label(this);
this.titleLabel.frameStyle = FrameStyle_Box;
this.titleLabel.margin = 6;
this.titleLabel.useRichText = true;
this.titleLabel.text = "<b>AstroDepth Image Enhancer</b>";
this.titleLabel.textAlignment = TextAlign_Center;

this.instructionsLabel = new TextBox(this);
this.instructionsLabel.readOnly = true;
this.instructionsLabel.frameStyle = FrameStyle_Box;
this.instructionsLabel.text = "Instructions:\n\nAdjust the Effect Strength using the slider.\nClick 'Refresh Preview' to see the effect.\nOK will apply the effect, Cancel will exit without changes.";
this.instructionsLabel.setScaledMinWidth(200);  // Optional to set width


    // ScrollControl for preview
    this.previewControl = new ScrollControl(this);
        this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);

    // Preview refresh button
    this.previewRefreshButton = new PushButton(this);
    this.previewRefreshButton.text = "Refresh Preview";
// Preview refresh button
this.previewRefreshButton.onClick = function () {
    let selectedWindowIndex = this.imageWindowDropdown.currentItem;
    let windowId = this.imageWindowDropdown.itemText(selectedWindowIndex);
    let selectedWindow = ImageWindow.windowById(windowId);

    console.writeln("Preview refresh selected window: " + windowId); // Log selected window ID

    if (selectedWindow && !selectedWindow.isNull) {
        this.applyPreview(selectedWindow); // Refresh preview for the selected window
    } else {
        console.criticalln("No valid image window selected for preview.");
    }
}.bind(this);


// ComboBox to select the active image window
this.imageWindowDropdown = new ComboBox(this);
this.imageWindowDropdown.editEnabled = false; // Prevent manual entry

// Populate dropdown with available image windows
this.populateImageWindowDropdown = function () {
    this.imageWindowDropdown.clear(); // Clear existing items in the dropdown

    for (var i = 0; i < ImageWindow.windows.length; i++) {
        let windowId = ImageWindow.windows[i].mainView.id;
        this.imageWindowDropdown.addItem(windowId); // Add each window to the dropdown
    }

    // Set the currently active window as the default selection
    var activeWindow = ImageWindow.activeWindow;
    if (!activeWindow.isNull) {
        for (var i = 0; i < ImageWindow.windows.length; i++) {
            if (ImageWindow.windows[i].mainView.id === activeWindow.mainView.id) {
                this.imageWindowDropdown.currentItem = i; // Set active window as selected item
                break;
            }
        }
    }
};



// Handle the selection of a new image window
this.imageWindowDropdown.onItemSelected = function (index) {
    if (index >= 0) {
        let windowId = this.imageWindowDropdown.itemText(index); // Get the selected window's ID
        this.cleanupTemporaryImage();  // Clean up before switching to a new image
        this.selectedWindow = ImageWindow.windowById(windowId); // Store the selected window
        if (this.selectedWindow && !this.selectedWindow.isNull) {
            this.setPreviewImage(this.selectedWindow); // Update the preview with the selected window
        }
    }
}.bind(this);


this.selectedWindow = ImageWindow.activeWindow; // Default to active window

// Function to set the preview image to the selected window
this.setPreviewImage = function (window) {
    if (!window || window.isNull) {
        console.criticalln("No valid image window selected.");
        return;
    }

    // Create a temporary image for preview
    this.tempImageWindow = new ImageWindow(
        window.mainView.image.width,
        window.mainView.image.height,
        window.mainView.image.numberOfChannels,
        window.mainView.image.bitsPerSample,
        window.mainView.image.isReal,
        window.mainView.image.isColor
    );

    this.tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    this.tempImageWindow.mainView.image.assign(window.mainView.image); // Copy the selected image
    this.tempImageWindow.mainView.endProcess();

    // Set the temporary image in the ScrollControl for preview
    this.previewControl.updateImage(this.tempImageWindow.mainView.image);
};

// Initialize the ComboBox
this.populateImageWindowDropdown();

// Set the preview to the selected image window
this.setPreviewImage = function (window) {
    // Ensure previous temporary image is closed
    this.cleanupTemporaryImage();

    if (!window || window.isNull) {
        console.criticalln("No valid image window selected.");
        return;
    }

    // Create a temporary image for preview
    this.tempImageWindow = new ImageWindow(
        window.mainView.image.width,
        window.mainView.image.height,
        window.mainView.image.numberOfChannels,
        window.mainView.image.bitsPerSample,
        window.mainView.image.isReal,
        window.mainView.image.isColor
    );

    this.tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    this.tempImageWindow.mainView.image.assign(window.mainView.image); // Copy the selected image
    this.tempImageWindow.mainView.endProcess();

    // Set the temporary image in the ScrollControl for preview
    this.previewControl.updateImage(this.tempImageWindow.mainView.image);
};

// Create a HorizontalSizer for the Effect Strength label and slider
this.strengthSizer = new HorizontalSizer;
this.strengthSizer.spacing = 6; // Set spacing between the elements

// Slider for effect strength label
this.strengthSliderLabel = new Label(this);
this.strengthSliderLabel.text = "Effect Strength:";
this.strengthSliderLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

// Add label to the sizer
this.strengthSizer.add(this.strengthSliderLabel);

// Slider for effect strength
this.strengthSlider = new NumericControl(this);
this.strengthSlider.setRange(0.1, 2.0); // Minimum 0.1, Maximum 2.0
this.strengthSlider.setPrecision(2);
this.strengthSlider.slider.setRange(1, 200);
this.strengthSlider.slider.setScaledMinWidth(120);
this.strengthSlider.setValue(1.0); // Default to 1.0 (normal effect strength)

// Add the slider to the sizer
this.strengthSizer.add(this.strengthSlider, 1);

    // Force update to ensure slider renders properly
    this.strengthSlider.updateControls();

        // Blend checkbox and slider
    this.blendCheckbox = new CheckBox(this);
    this.blendCheckbox.text = "Enable Blend";
    this.blendCheckbox.toolTip = "Blend the original image with the modified image.";
    this.blendCheckbox.onCheck = function(checked) {
        this.blendSlider.visible = checked; // Show the blend slider if checkbox is checked
    }.bind(this);

    this.blendSlider = new NumericControl(this);
    this.blendSlider.setRange(0, 1); // Range from 0 to 1
    this.blendSlider.setPrecision(2);
    this.blendSlider.slider.setRange(0, 100); // Set slider range
    this.blendSlider.setValue(0.5); // Default blend value
    this.blendSlider.toolTip = "Blend amount between the original and modified image.";
    this.blendSlider.visible = false; // Initially hidden

    // OK and Cancel buttons
    this.okButton = new PushButton(this);
    this.okButton.text = "OK";
      // OK button click event
// OK button click event
this.okButton.onClick = function () {
    let selectedWindowIndex = this.imageWindowDropdown.currentItem;
    let windowId = this.imageWindowDropdown.itemText(selectedWindowIndex);
    let selectedWindow = ImageWindow.windowById(windowId); // Correctly fetch the selected window

    // Apply effect to the selected window directly
    if (selectedWindow && !selectedWindow.isNull) {
        var effectStrength = this.strengthSlider.value;

        // Create an ImageWindow to store the original base image before applying effects
        this.baseImageWindow = new ImageWindow(
            selectedWindow.mainView.image.width,
            selectedWindow.mainView.image.height,
            selectedWindow.mainView.image.numberOfChannels
        );

        // Assign the original image to the baseImageWindow's image
        this.baseImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
        this.baseImageWindow.mainView.image.assign(selectedWindow.mainView.image);
        this.baseImageWindow.mainView.endProcess();

        // Apply the 3D effect to the selected window
        applyDepthEffect(selectedWindow, effectStrength);

        // If blending is enabled, apply the blend operation using PixelMath
        if (this.blendCheckbox.checked) {
            let baseImageId = this.baseImageWindow.mainView.id;  // Now baseImageWindow is created and has a valid ID
            let finalImageId = selectedWindow.mainView.id;  // Get the selected window ID
            this.applyBlendOperation(baseImageId, finalImageId);  // Pass both IDs here
        }

        this.okPressed = true;
    } else {
        console.criticalln("No valid image window selected for 3D effect.");
        this.okPressed = false;
    }
    this.cleanupTemporaryImage(); // Clean up temporary images
    this.cancel();
}.bind(this);





this.cancelButton = new PushButton(this);
this.cancelButton.text = "Cancel";
this.cancelButton.onClick = function () {
    this.okPressed = false;
    this.cleanupTemporaryImage(); // Call the cleanup function here
    this.cancel();
}.bind(this);

this.onClose = function() {
    this.cleanupTemporaryImage();
};

    // Authorship label
    this.authorship_Lbl = new Label(this);
    this.authorship_Lbl.frameStyle = FrameStyle_Box;
    this.authorship_Lbl.margin = 6;
    this.authorship_Lbl.useRichText = true;
    this.authorship_Lbl.text = "Written by Franklin Marek<br>Website: <a href=\"http://www.setiastro.com\">www.setiastro.com</a>";
    this.authorship_Lbl.textAlignment = TextAlign_Center;
    this.authorship_Lbl.onMousePress = () => {
    Dialog.openBrowser("http://www.setiastro.com");
};


    // Add zoom in and zoom out buttons at the top of the right panel
this.zoomInButton = new PushButton(this);
this.zoomInButton.text = "";
this.zoomInButton.icon = this.scaledResource(":/icons/zoom-in.png");
this.zoomInButton.onClick = function() {
    this.dialog.previewControl.zoomFactor = Math.min(this.dialog.previewControl.zoomFactor * 1.25, this.dialog.previewControl.maxZoomFactor);
    this.dialog.previewControl.initScrollBars();
    this.dialog.previewControl.viewport.update();
}.bind(this);

this.zoomOutButton = new PushButton(this);
this.zoomOutButton.text = "";
this.zoomOutButton.icon = this.scaledResource(":/icons/zoom-out.png");
this.zoomOutButton.onClick = function() {
    this.dialog.previewControl.zoomFactor = Math.max(this.dialog.previewControl.zoomFactor * 0.8, this.dialog.previewControl.minZoomFactor);
    this.dialog.previewControl.initScrollBars();
    this.dialog.previewControl.viewport.update();
}.bind(this);

// Add zoom buttons to a horizontal sizer
this.zoomButtonsSizer = new HorizontalSizer;
this.zoomButtonsSizer.spacing = 6;
this.zoomButtonsSizer.add(this.zoomInButton);
this.zoomButtonsSizer.add(this.zoomOutButton);
this.zoomButtonsSizer.addStretch();

this.newInstanceButton = new ToolButton(this);
this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
this.newInstanceButton.setScaledFixedSize(24, 24);
this.newInstanceButton.toolTip = "Create a new instance with the current parameters.";
this.newInstanceButton.onMousePress = function () {
    this.dialog.newInstance();
}.bind(this);

// Add the title label
var titleSizer = new HorizontalSizer;
titleSizer.add(this.titleLabel);

// Add the instructions label
var instructionsSizer = new HorizontalSizer;
instructionsSizer.add(this.instructionsLabel);

// Add the authorship label
var authorshipSizer = new HorizontalSizer;
authorshipSizer.add(this.authorship_Lbl);

// Add the new instance button
var instanceButtonSizer = new HorizontalSizer;
instanceButtonSizer.add(this.newInstanceButton);
instanceButtonSizer.addStretch();


    // Layout
    var leftSideSizer = new VerticalSizer;
    leftSideSizer.margin = 6;
    leftSideSizer.add(titleSizer);
leftSideSizer.addSpacing(10); // Adds a space after title
leftSideSizer.add(instructionsSizer);
leftSideSizer.addSpacing(10); // Adds a space after instructions
    leftSideSizer.addStretch();
    leftSideSizer.add(this.imageWindowDropdown);
    leftSideSizer.addStretch();
    leftSideSizer.add(this.strengthSizer);
    leftSideSizer.addSpacing(10);
        leftSideSizer.add(this.blendCheckbox); // Add blend checkbox
    leftSideSizer.add(this.blendSlider);   // Add blend slider (initially hidden)
        leftSideSizer.addSpacing(10);
    leftSideSizer.add(this.previewRefreshButton);
    leftSideSizer.addSpacing(10);
    leftSideSizer.add(this.okButton);
    leftSideSizer.add(this.cancelButton);
    leftSideSizer.addStretch();
leftSideSizer.add(authorshipSizer); // Add authorship
    leftSideSizer.addStretch();
    leftSideSizer.add(instanceButtonSizer); // Add new instance button

    // Create a control to fix the width of the left panel
    this.leftPanel = new Control(this);
    this.leftPanel.sizer = leftSideSizer;
    this.leftPanel.setFixedWidth(300); // Fix width of the left panel

// Main dialog layout
var mainSizer = new HorizontalSizer;
mainSizer.margin = 6;
mainSizer.spacing = 4;
mainSizer.add(this.leftPanel); // Add the fixed-width left panel

// Right panel includes zoom buttons and the preview
var rightPanelSizer = new VerticalSizer;
rightPanelSizer.margin = 6;
rightPanelSizer.spacing = 4;
rightPanelSizer.add(this.zoomButtonsSizer); // Add zoom buttons at the top
rightPanelSizer.add(this.previewControl, 1); // Add the preview control

mainSizer.add(rightPanelSizer, 1); // Add the right panel to the main layout
this.sizer = mainSizer;

this.adjustToContents();


    // Initialize the preview with a temporary image on dialog open
    this.initializePreview();
}

DepthEffectDialog.prototype = new Dialog;

DepthEffectDialog.prototype.onShow = function() {
    var activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        // Force initial creation of temp image
        this.applyPreview();
    } else {
        console.writeln("No active image window found.");
    }

    this.previewControl.setFocus(); // Ensure key events are handled
    this.previewControl.viewport.update(); // Update the viewport for immediate rendering
};

DepthEffectDialog.prototype.initializePreview = function () {
    var activeWindow = ImageWindow.activeWindow;
    if (activeWindow.isNull) {
        console.criticalln("No active image window found for preview.");
        return;
    }

    // Create a temporary image for preview
    this.tempImageWindow = new ImageWindow(
        activeWindow.mainView.image.width,
        activeWindow.mainView.image.height,
        activeWindow.mainView.image.numberOfChannels,  // Color or grayscale channels
        activeWindow.mainView.image.bitsPerSample,  // Bit depth (floating point if necessary)
        activeWindow.mainView.image.isReal,  // Floating point or integer
        activeWindow.mainView.image.isColor         // Color or grayscale
    );

    this.tempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    this.tempImageWindow.mainView.image.assign(activeWindow.mainView.image); // Copy the original image
    this.tempImageWindow.mainView.endProcess();

    // Set the temporary image in the ScrollControl for preview
    this.previewControl.updateImage(this.tempImageWindow.mainView.image);
};



// Apply preview with blend functionality
DepthEffectDialog.prototype.applyPreview = function(selectedWindow) {
    if (!selectedWindow || selectedWindow.isNull) {
        console.criticalln("No valid image window selected for preview.");
        return;
    }

// Step 1: Create a base image copy (if blending is enabled and baseImage doesn't exist)
if (this.blendCheckbox.checked) {
    console.writeln("Blend checkbox is checked, attempting to create base image...");
    if (!this.baseImageWindow || this.baseImageWindow.isNull) {
        console.writeln("Creating a new base image window...");
        this.baseImageWindow = new ImageWindow(
            selectedWindow.mainView.image.width,
            selectedWindow.mainView.image.height,
            selectedWindow.mainView.image.numberOfChannels,
            selectedWindow.mainView.image.bitsPerSample,
            selectedWindow.mainView.image.isReal,
            selectedWindow.mainView.image.isColor
        );

        if (!this.baseImageWindow || this.baseImageWindow.isNull) {
            console.criticalln("Failed to create base image window.");
            return;
        }

        this.baseImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
        this.baseImageWindow.mainView.image.assign(selectedWindow.mainView.image);  // Copy the original image
        this.baseImageWindow.mainView.endProcess();
        console.writeln("Base image window created successfully.");
    }

       // Ensure baseImage ID is available
    var baseImageId = this.baseImageWindow.mainView.id;
    console.writeln("Base Image ID in preview: " + baseImageId);

} else {
    console.writeln("Blend checkbox is not checked, clearing base image window...");
    // Clear the baseImageWindow if blend is not enabled to avoid referencing it incorrectly
    if (this.baseImageWindow && !this.baseImageWindow.isNull) {
        this.baseImageWindow.forceClose();  // Close the base image window if blending is disabled
        this.baseImageWindow = null;
    }
}

    // Step 2: Create a temporary ImageWindow for preview
    this.applyTempImageWindow = new ImageWindow(
        selectedWindow.mainView.image.width,
        selectedWindow.mainView.image.height,
        selectedWindow.mainView.image.numberOfChannels,
        selectedWindow.mainView.image.bitsPerSample,
        selectedWindow.mainView.image.isReal,
        selectedWindow.mainView.image.isColor
    );

    this.applyTempImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    this.applyTempImageWindow.mainView.image.assign(selectedWindow.mainView.image);  // Copy the current image
    this.applyTempImageWindow.mainView.endProcess();

    // Step 3: Apply the 3D effect to the preview image
    var effectStrength = this.strengthSlider.value;
    applyDepthEffect(this.applyTempImageWindow, effectStrength);  // Apply the effect to the temp image

    // Step 4: If blending is enabled, apply the blend operation using PixelMath
    if (this.blendCheckbox.checked) {
        var blendValue = this.blendSlider.value;

        // Set up PixelMath for blending
        var pixelMath = new PixelMath;
        pixelMath.expression = "~(~(min(1,2*(1 - " + blendValue + ")) *0.8* " + baseImageId + ") * ~(min(1,2*" + blendValue + " )*0.8* " + this.applyTempImageWindow.mainView.id + "))";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage = false;
        pixelMath.executeOn(this.applyTempImageWindow.mainView);
    }

    // Step 5: Update the preview image in ScrollControl
    this.previewControl.updateImage(this.applyTempImageWindow.mainView.image);
};



// Function to apply the blend operation
DepthEffectDialog.prototype.applyBlendOperation = function(baseImageId, finalImageId) {
    var blendValue = this.blendSlider.value;

    // PixelMath operation for blending base and final images
    var pixelMath = new PixelMath;

    // Construct the PixelMath expression for the blend operation with negation and multiplication
    pixelMath.expression = "~(~(min(1,2*(1 - " + blendValue + ")) *0.8* " + baseImageId + ") * ~(min(1,2*" + blendValue + " )*0.8* " + finalImageId + "))";

    pixelMath.useSingleExpression = true;  // Same expression for all channels
    pixelMath.createNewImage = false;      // Modify the current image directly
    pixelMath.rescale = false;             // Ensure PixelMath respects the range of values

    // Execute the PixelMath process on the final image window
    let finalImageWindow = ImageWindow.windowById(finalImageId);  // Fetch the final image window
    if (finalImageWindow && !finalImageWindow.isNull) {
        pixelMath.executeOn(finalImageWindow.mainView);  // Apply PixelMath to the final image
    } else {
        console.criticalln("Error: finalImageWindow is null or undefined.");
    }
};




function applyDepthEffect(window, effectStrength) {
    if (!window || window.isNull) {
        console.criticalln("No valid image window selected.");
        return;
    }
//console.writeln("Effect applying to window: " + window); // Add this in both `Preview Refresh` and `OK` to compare

    // Step 1: Compute median value of the image
    var imageMedianValue = window.mainView.image.median();
    console.writeln("Image median value: ", imageMedianValue);

    // Step 2: RangeSelection mask for dark areas (invert = true for the first pass)
    console.writeln("Creating RangeSelection mask for dark areas...");
    var rangeSelection = new RangeSelection;
    rangeSelection.lowRange = imageMedianValue;
    rangeSelection.highRange = 1.0;
    rangeSelection.fuzziness = 0.33 * effectStrength;
    rangeSelection.smoothness = Math.min(100, 100 * effectStrength);
    rangeSelection.screening = false;
    rangeSelection.toLightness = true;
    rangeSelection.invert = true;  // Mask for dark areas
    rangeSelection.createNewImage = true;
    rangeSelection.showNewImage = false;
    rangeSelection.executeOn(window.mainView);  // Create the mask on the selected image

    // Step 3: Retrieve the mask image
    let maskImage = ImageWindow.activeWindow;  // The mask created becomes the active window

    // Step 4: Apply the mask to the selected image
    console.writeln("Applying the mask for dark areas...");
    window.setMask(maskImage);  // Apply the mask to the selected image
    window.maskVisible = true;  // Show the mask

    // Step 5: Apply convolution to blur the dark background
    console.writeln("Applying Convolution to blur dark background...");
    var convolution = new Convolution;
    convolution.mode = Convolution.prototype.Parametric;
    convolution.sigma = 50 * effectStrength;
    convolution.shape = 2.00;
    convolution.aspectRatio = 1.00;
    convolution.rotationAngle = 0.00;
    convolution.filterSource = "";
    convolution.rescaleHighPass = false;
    convolution.viewId = "";
    convolution.executeOn(window.mainView, true);

    // Step 6: Apply curves to darken the background using the K channel
    console.writeln("Applying CurvesTransformation to darken background...");
    var curves = new CurvesTransformation;

    curves.K = [
        [0.00000, 0.00000],                                 // Starting point
        [0.5 * imageMedianValue, 0.5 * imageMedianValue - 0.2 * imageMedianValue * effectStrength],  // Median point scaled
        [0.75000, 0.75000],                                 // Final point
        [1.00000, 1.00000]                                  // End point
    ];
    curves.Kt = CurvesTransformation.prototype.AkimaSubsplines;

    curves.executeOn(window.mainView, true);

    // Step 7: Remove the mask after applying the effect
    console.writeln("Removing the mask...");
    window.removeMask();  // Remove the mask
    maskImage.forceClose();  // Close the mask window

    // Step 8: Reapply RangeSelection mask for bright areas (invert = false)
    console.writeln("Reapplying RangeSelection mask for bright areas...");
    rangeSelection.invert = false; // Now apply to bright areas
    rangeSelection.createNewImage = true;  // Create a new mask image
    rangeSelection.showNewImage = false;
    rangeSelection.executeOn(window.mainView);

    // Step 9: Retrieve the new mask and apply it to the bright areas
    let brightMaskImage = ImageWindow.activeWindow;  // The new mask becomes the active window
    window.setMask(brightMaskImage);  // Apply the mask to the selected image
    window.maskVisible = true;

    // Step 10: Apply slight sharpening to bright areas
    console.writeln("Applying UnsharpMask to bright areas...");
    var unsharpMask = new UnsharpMask;
    unsharpMask.sigma = 30.00 * effectStrength;
    unsharpMask.amount = Math.max(0.1, 0.2 * effectStrength);
    unsharpMask.useLuminance = true;
    unsharpMask.linear = false;
    unsharpMask.deringing = false;
    unsharpMask.deringingDark = 0.1000;
    unsharpMask.deringingBright = 0.0000;
    unsharpMask.outputDeringingMaps = false;
    unsharpMask.rangeLow = 0.0000000;
    unsharpMask.rangeHigh = 0.0000000;
    unsharpMask.executeOn(window.mainView, true);

    // Step 10b: Apply slight brightening using CurvesTransformation on the K channel
    console.writeln("Applying slight brightening using CurvesTransformation...");
    var brightenCurves = new CurvesTransformation;
    brightenCurves.K = [
        [0.00000, 0.00000],
        [0.25, 0.25],
        [0.5, 0.5 + 0.1 * effectStrength],
        [1.00000, 1.00000]
    ];
    brightenCurves.Kt = CurvesTransformation.prototype.AkimaSubsplines;

    brightenCurves.executeOn(window.mainView, true);

    // Step 11: Remove the bright mask and clean up
    console.writeln("Removing the bright mask...");
    window.removeMask();
    brightMaskImage.forceClose();  // Close the bright mask window

    console.writeln("Effect applied successfully to the selected window!");
}



DepthEffectDialog.prototype.cleanupTemporaryImage = function() {
    // Close the initial temporary image window (used in preview)
    if (this.tempImageWindow && !this.tempImageWindow.isNull) {
        this.tempImageWindow.forceClose(); // Close the initial temporary image window
        this.tempImageWindow = null; // Clear the reference
    }

    // Close the temporary image created by applyPreview
    if (this.applyTempImageWindow && !this.applyTempImageWindow.isNull) {
        this.applyTempImageWindow.forceClose(); // Close the temporary image from applyPreview
        this.applyTempImageWindow = null; // Clear the reference
    }

    // Close the base image window if it was created for blending
    if (this.baseImageWindow && !this.baseImageWindow.isNull) {
        this.baseImageWindow.forceClose(); // Close the base image window
        this.baseImageWindow = null; // Clear the reference
    }

    // Close any additional temporary images created during dropdown changes
    if (this.tempImageWindows && this.tempImageWindows.length > 0) {
        for (let i = 0; i < this.tempImageWindows.length; i++) {
            let tempImageWindow = this.tempImageWindows[i];
            if (tempImageWindow && !tempImageWindow.isNull) {
                tempImageWindow.forceClose(); // Close each temporary image window
            }
        }
        this.tempImageWindows = []; // Clear the array of references
    }
};





function main() {
    var window = ImageWindow.activeWindow;
    if (window.isNull) {
        console.criticalln("No active image window found.");
        return;
    }

        console.show();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    Console.writeln("AstroDepth Loaded...");

    // Create and show the depth effect dialog
    var dialog = new DepthEffectDialog();

    // Do not override the okButton behavior here! Just execute the dialog:
    if (dialog.execute()) {
        if (!dialog.okPressed) {
            console.writeln("Operation canceled.");
        }
    }
}


main();
