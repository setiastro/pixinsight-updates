#feature-id CosmicClarity : SetiAstro > Cosmic Clarity - SASpro
#feature-icon  astrosuite.svg
#feature-info This script works with Seti Astro Suite Pro Cosmic Clarity program

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Cosmic Clarity - SASpro
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script integrates with Seti Astro Suite Pro Cosmic Clarity CLI
 * to sharpen images directly from PixInsight.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * COPYRIGHT © 2026 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.0"

var IS_WIN = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows");
var IS_MAC = (CoreApplication.platform == "MACOSX"   || CoreApplication.platform == "macOS");
var IS_LIN = (CoreApplication.platform == "Linux");

var pathSeparator = IS_WIN ? "\\" : "/";

// Normalize the system temp dir first, then append, then normalize again.
var _sysTemp = normalizePathForExternal(File.systemTempDirectory);
var scriptTempDir = normalizePathForExternal(_sysTemp + pathSeparator + "SetiAstroCosmicClarity_SASpro");

if (!File.directoryExists(scriptTempDir))
   File.createDirectory(scriptTempDir);


/* -------------------------------------------------------------------------
 * Parameters / config
 * ------------------------------------------------------------------------- */
var SetiAstroSharpParameters = {
   targetView: undefined,

   // Sharpen settings
   sharpeningMode: "Both",                // "Both", "Stellar Only", "Non-Stellar Only"
   stellarAmount: 0.90,                   // 0..1
   nonStellarStrength: 3.00,              // 1..8 (maps to --nonstellar-psf)
   nonStellarAmount: 0.50,                // 0..1
   sharpenChannelsSeparately: false,
   useGPU: true,
   // Process mode
   processMode: "sharpen", // sharpen | denoise | both | superres | satellite

   // Sharpen extras
   autoPSF: false,

   // Denoise settings
   denoiseLuma: 0.50,               // 0..1
   denoiseColor: 0.50,              // 0..1
   denoiseMode: "full",             // full | luminance
   separateDenoiseChannels: false,  // --separate-channels

   // Superres settings
   superResScale: 2,                // 2 | 3 | 4

   // Satellite settings
   satelliteMode: "full",           // full | luminance
   satelliteClipTrail: true,        // --clip-trail / --no-clip-trail
   satelliteSensitivity: 0.10,      // float
   // Tiling settings (shared by sharpen/denoise/superres)
   chunkSize: 256,                 // 128..1024 typical
   overlap: 64,                    // 0..256 typical
   // CLI launcher settings
   // Modes:
   // "Auto Detect"
   // "setiastrosuitepro cc (installed command)"
   // "Frozen setiastrosuitepro executable"
   // "python -m setiastro.saspro cc"
   // "python setiastrosuitepro.py cc"
   cliLauncherMode: "Auto Detect",
   cliLauncherPath: "",   // exe path for frozen OR python exe for python modes (optional)
   pythonScriptPath: "",  // path to setiastrosuitepro.py (for direct script mode)

   configFilePath: scriptTempDir + pathSeparator + "saspro_cc_cli_config.txt",

   save: function() {
      // -----------------------------
      // Core processing mode + GPU
      // -----------------------------
      Parameters.set("processMode", this.processMode);
      Parameters.set("useGPU", this.useGPU);

      // -----------------------------
      // Tiling settings
      // -----------------------------
      Parameters.set("chunkSize", this.chunkSize);
      Parameters.set("overlap", this.overlap);

      // -----------------------------
      // Sharpen settings
      // -----------------------------
      Parameters.set("sharpeningMode", this.sharpeningMode);
      Parameters.set("stellarAmount", this.stellarAmount);
      Parameters.set("nonStellarStrength", this.nonStellarStrength);
      Parameters.set("nonStellarAmount", this.nonStellarAmount);
      Parameters.set("sharpenChannelsSeparately", this.sharpenChannelsSeparately);
      Parameters.set("autoPSF", this.autoPSF);

      // -----------------------------
      // Denoise settings
      // -----------------------------
      Parameters.set("denoiseLuma", this.denoiseLuma);
      Parameters.set("denoiseColor", this.denoiseColor);
      Parameters.set("denoiseMode", this.denoiseMode);
      Parameters.set("separateDenoiseChannels", this.separateDenoiseChannels);

      // -----------------------------
      // Superres settings
      // -----------------------------
      Parameters.set("superResScale", this.superResScale);

      // -----------------------------
      // Satellite settings
      // -----------------------------
      Parameters.set("satelliteMode", this.satelliteMode);
      Parameters.set("satelliteClipTrail", this.satelliteClipTrail);
      Parameters.set("satelliteSensitivity", this.satelliteSensitivity);

      // -----------------------------
      // CLI launcher settings
      // -----------------------------
      Parameters.set("cliLauncherMode", this.cliLauncherMode);
      Parameters.set("cliLauncherPath", this.cliLauncherPath);
      Parameters.set("pythonScriptPath", this.pythonScriptPath);

      // Persist to external config too
      this.saveConfigFile();
   },


   load: function() {
      // -----------------------------
      // Core processing mode + GPU
      // -----------------------------
      if (Parameters.has("processMode"))
         this.processMode = Parameters.getString("processMode");
      if (Parameters.has("useGPU"))
         this.useGPU = Parameters.getBoolean("useGPU");

      // -----------------------------
      // Tiling settings
      // -----------------------------
      if (Parameters.has("chunkSize"))
         this.chunkSize = Parameters.getInteger("chunkSize");
      if (Parameters.has("overlap"))
         this.overlap = Parameters.getInteger("overlap");

      // -----------------------------
      // Sharpen settings
      // -----------------------------
      if (Parameters.has("sharpeningMode"))
         this.sharpeningMode = Parameters.getString("sharpeningMode");
      if (Parameters.has("stellarAmount"))
         this.stellarAmount = Parameters.getReal("stellarAmount");
      if (Parameters.has("nonStellarStrength"))
         this.nonStellarStrength = Parameters.getReal("nonStellarStrength");
      if (Parameters.has("nonStellarAmount"))
         this.nonStellarAmount = Parameters.getReal("nonStellarAmount");
      if (Parameters.has("sharpenChannelsSeparately"))
         this.sharpenChannelsSeparately = Parameters.getBoolean("sharpenChannelsSeparately");
      if (Parameters.has("autoPSF"))
         this.autoPSF = Parameters.getBoolean("autoPSF");

      // -----------------------------
      // Denoise settings
      // -----------------------------
      if (Parameters.has("denoiseLuma"))
         this.denoiseLuma = Parameters.getReal("denoiseLuma");
      if (Parameters.has("denoiseColor"))
         this.denoiseColor = Parameters.getReal("denoiseColor");
      if (Parameters.has("denoiseMode"))
         this.denoiseMode = Parameters.getString("denoiseMode");
      if (Parameters.has("separateDenoiseChannels"))
         this.separateDenoiseChannels = Parameters.getBoolean("separateDenoiseChannels");

      // -----------------------------
      // Superres settings
      // -----------------------------
      if (Parameters.has("superResScale"))
         this.superResScale = Parameters.getInteger("superResScale");

      // -----------------------------
      // Satellite settings
      // -----------------------------
      if (Parameters.has("satelliteMode"))
         this.satelliteMode = Parameters.getString("satelliteMode");
      if (Parameters.has("satelliteClipTrail"))
         this.satelliteClipTrail = Parameters.getBoolean("satelliteClipTrail");
      if (Parameters.has("satelliteSensitivity"))
         this.satelliteSensitivity = Parameters.getReal("satelliteSensitivity");

      // -----------------------------
      // CLI launcher settings
      // -----------------------------
      if (Parameters.has("cliLauncherMode"))
         this.cliLauncherMode = Parameters.getString("cliLauncherMode");
      if (Parameters.has("cliLauncherPath"))
         this.cliLauncherPath = Parameters.getString("cliLauncherPath");
      if (Parameters.has("pythonScriptPath"))
         this.pythonScriptPath = Parameters.getString("pythonScriptPath");

      // External config overrides launcher/persistent app settings
      this.loadConfigFile();

      // Safety clamps
      if (this.superResScale != 2 && this.superResScale != 3 && this.superResScale != 4)
         this.superResScale = 2;

      if (this.sharpeningMode != "Both" &&
          this.sharpeningMode != "Stellar Only" &&
          this.sharpeningMode != "Non-Stellar Only")
         this.sharpeningMode = "Both";

      if (this.denoiseMode != "full" && this.denoiseMode != "luminance")
         this.denoiseMode = "full";

      if (this.satelliteMode != "full" && this.satelliteMode != "luminance")
         this.satelliteMode = "full";

      if (this.processMode != "sharpen" &&
          this.processMode != "denoise" &&
          this.processMode != "both" &&
          this.processMode != "superres" &&
          this.processMode != "satellite")
         this.processMode = "sharpen";

      // NEW: clamp tiling
      this.chunkSize = _cc_toInt(this.chunkSize, 256);
      this.overlap   = _cc_toInt(this.overlap, 64);
      if (this.chunkSize < 64) this.chunkSize = 64;
      if (this.chunkSize > 2048) this.chunkSize = 2048;
      if (this.overlap < 0) this.overlap = 0;
      if (this.overlap >= this.chunkSize) this.overlap = Math.max(0, this.chunkSize - 1);
   },

   saveConfigFile: function() {
      try {
         // key=value format so we can extend without breaking old files
         var lines = [];
         lines.push("cliLauncherMode=" + (this.cliLauncherMode || ""));
         lines.push("cliLauncherPath=" + (this.cliLauncherPath || ""));
         lines.push("pythonScriptPath=" + (this.pythonScriptPath || ""));

         // Also persist processing presets across sessions (useful even before UI exposes all modes)
         lines.push("processMode=" + (this.processMode || "sharpen"));
         lines.push("useGPU=" + (this.useGPU ? "1" : "0"));
         lines.push("chunkSize=" + format("%d", this.chunkSize || 256));
         lines.push("overlap=" + format("%d", this.overlap || 64));
         lines.push("sharpeningMode=" + (this.sharpeningMode || "Both"));
         lines.push("stellarAmount=" + format("%.6f", this.stellarAmount));
         lines.push("nonStellarStrength=" + format("%.6f", this.nonStellarStrength));
         lines.push("nonStellarAmount=" + format("%.6f", this.nonStellarAmount));
         lines.push("sharpenChannelsSeparately=" + (this.sharpenChannelsSeparately ? "1" : "0"));
         lines.push("autoPSF=" + (this.autoPSF ? "1" : "0"));

         lines.push("denoiseLuma=" + format("%.6f", this.denoiseLuma));
         lines.push("denoiseColor=" + format("%.6f", this.denoiseColor));
         lines.push("denoiseMode=" + (this.denoiseMode || "full"));
         lines.push("separateDenoiseChannels=" + (this.separateDenoiseChannels ? "1" : "0"));

         lines.push("superResScale=" + format("%d", this.superResScale || 2));

         lines.push("satelliteMode=" + (this.satelliteMode || "full"));
         lines.push("satelliteClipTrail=" + (this.satelliteClipTrail ? "1" : "0"));
         lines.push("satelliteSensitivity=" + format("%.6f", this.satelliteSensitivity));

         File.writeTextFile(this.configFilePath, lines.join("\n"));
      } catch (e) {
         console.warningln("Failed to save CLI config: " + e.message);
      }
   },

   loadConfigFile: function() {
      try {
         if (!File.exists(this.configFilePath))
            return;

         var lines = File.readLines(this.configFilePath);
         if (!lines || lines.length === 0)
            return;

         // Backward compatibility:
         // old format was:
         //   line0=cliLauncherMode
         //   line1=cliLauncherPath
         //   line2=pythonScriptPath
         var looksLikeOldFormat = true;
         for (var i = 0; i < Math.min(lines.length, 3); i++) {
            if (String(lines[i]).indexOf("=") >= 0) {
               looksLikeOldFormat = false;
               break;
            }
         }

         if (looksLikeOldFormat) {
            if (lines.length > 0 && lines[0].trim().length > 0) this.cliLauncherMode = lines[0].trim();
            if (lines.length > 1) this.cliLauncherPath = lines[1].trim();
            if (lines.length > 2) this.pythonScriptPath = lines[2].trim();
            return;
         }

         for (var j = 0; j < lines.length; j++) {
            var line = String(lines[j]);
            var eq = line.indexOf("=");
            if (eq <= 0)
               continue;

            var k = line.substring(0, eq).trim();
            var v = line.substring(eq + 1);

            if (k == "cliLauncherMode") this.cliLauncherMode = v.trim();
            else if (k == "cliLauncherPath") this.cliLauncherPath = v.trim();
            else if (k == "pythonScriptPath") this.pythonScriptPath = v.trim();

            else if (k == "processMode") this.processMode = v.trim();
            else if (k == "useGPU") this.useGPU = _cc_toBool(v, this.useGPU);

            else if (k == "sharpeningMode") this.sharpeningMode = v.trim();
            else if (k == "stellarAmount") this.stellarAmount = _cc_toFloat(v, this.stellarAmount);
            else if (k == "nonStellarStrength") this.nonStellarStrength = _cc_toFloat(v, this.nonStellarStrength);
            else if (k == "nonStellarAmount") this.nonStellarAmount = _cc_toFloat(v, this.nonStellarAmount);
            else if (k == "sharpenChannelsSeparately") this.sharpenChannelsSeparately = _cc_toBool(v, this.sharpenChannelsSeparately);
            else if (k == "autoPSF") this.autoPSF = _cc_toBool(v, this.autoPSF);
            else if (k == "chunkSize") this.chunkSize = _cc_toInt(v, this.chunkSize);
            else if (k == "overlap") this.overlap = _cc_toInt(v, this.overlap);

            else if (k == "denoiseLuma") this.denoiseLuma = _cc_toFloat(v, this.denoiseLuma);
            else if (k == "denoiseColor") this.denoiseColor = _cc_toFloat(v, this.denoiseColor);
            else if (k == "denoiseMode") this.denoiseMode = v.trim();
            else if (k == "separateDenoiseChannels") this.separateDenoiseChannels = _cc_toBool(v, this.separateDenoiseChannels);

            else if (k == "superResScale") this.superResScale = _cc_toInt(v, this.superResScale);

            else if (k == "satelliteMode") this.satelliteMode = v.trim();
            else if (k == "satelliteClipTrail") this.satelliteClipTrail = _cc_toBool(v, this.satelliteClipTrail);
            else if (k == "satelliteSensitivity") this.satelliteSensitivity = _cc_toFloat(v, this.satelliteSensitivity);
         }
      } catch (e) {
         console.warningln("Failed to load CLI config: " + e.message);
      }
   }

};

/* -------------------------------------------------------------------------
 * Utility
 * ------------------------------------------------------------------------- */
// ---- Mutually exclusive checkbox group helper (PI-safe) ----
function _cc_setExclusive(group, checkedBox) {
   for (var i = 0; i < group.length; i++) {
      if (group[i] !== checkedBox)
         group[i].checked = false;
   }
   checkedBox.checked = true;
}


function ensureDir(dirPath) {
   if (!File.directoryExists(dirPath))
      File.createDirectory(dirPath);
}

function uniqueTempBase(viewId) {
   var t = new Date().getTime().toString();
   // sanitize viewId a bit for file names
   var safeId = String(viewId).replace(/[^\w\-\.]/g, "_");
   return normalizePathForExternal(scriptTempDir + pathSeparator + safeId + "_" + t);
}

function fileExistsSafe(p) {
   try {
      return p && p.length > 0 && File.exists(p);
   } catch (e) {
      return false;
   }
}

function waitForFileReady(filePath, timeoutMs, stableMs) {
   var t0 = new Date().getTime();
   var pollMs = 200;
   var seenOnce = false;
   var stableSince = -1;

   while (true) {
      var now = new Date().getTime();
      if ((now - t0) > timeoutMs)
         return false;

      if (File.exists(filePath)) {
         // Try opening for reading as a readiness probe.
         var canRead = false;
         try {
            var f = new File;
            f.openForReading(filePath);
            f.close();
            canRead = true;
         } catch (e) {
            canRead = false;
         }

         if (canRead) {
            if (!seenOnce) {
               seenOnce = true;
               stableSince = now;
            } else if ((now - stableSince) >= stableMs) {
               return true;
            }
         } else {
            // Reset stability timer if probe fails
            seenOnce = false;
            stableSince = -1;
         }
      }

      msleep(pollMs);
   }
}



function msleep(milliseconds) {
   var start = new Date().getTime();
   while (new Date().getTime() - start < milliseconds) {
      processEvents();
   }
}

function waitForFile(filePath, timeoutMs, settleMs) {
   var t0 = new Date().getTime();
   var pollMs = 250;

   while (!File.exists(filePath)) {
      if ((new Date().getTime() - t0) > timeoutMs)
         return false;
      msleep(pollMs);
   }

   if (settleMs > 0)
      msleep(settleMs);

   return true;
}

function deleteFileQuiet(path) {
   try {
      if (File.exists(path))
         File.remove(path);
   } catch (e) {
      // quiet
   }
}

function getDefaultFrozenSasproPath() {
   if (IS_WIN)
      return "C:\\Program Files\\SetiAstroSuitePro\\SetiAstroSuitePro.exe";
   if (IS_MAC)
      return "/Applications/SetiAstroSuitePro.app/Contents/MacOS/SetiAstroSuitePro";
   return ""; // Linux: user-chosen location
}

function looksLikeLinuxSasproFrozenName(p) {
   if (!p) return false;
   var s = String(p).toLowerCase();
   return s.indexOf("setiastrosuitepro_linux_ubuntu24.04") >= 0 ||
          s.indexOf("setiastrosuitepro") >= 0;
}

function promptForFrozenSasproExecutableLinux(ownerDialog) {
   var ofd = new OpenFileDialog;
   ofd.caption = "Select SetiAstroSuitePro Linux Executable";
   ofd.multipleSelections = false;

   if (SetiAstroSharpParameters.cliLauncherPath && SetiAstroSharpParameters.cliLauncherPath.length > 0)
      ofd.initialPath = SetiAstroSharpParameters.cliLauncherPath;

   if (!ofd.execute() || !ofd.fileNames || ofd.fileNames.length < 1)
      return "";

   var p = ofd.fileNames[0];
   SetiAstroSharpParameters.cliLauncherPath = p;
   SetiAstroSharpParameters.save();

   // optional warning if filename is unexpected
   if (!looksLikeLinuxSasproFrozenName(p)) {
      (new MessageBox(
         "Selected file does not look like the usual SASpro Linux executable name.\n\n" +
         "Expected something like:\nSetiAstroSuitePro_linux_ubuntu24.04\n\n" +
         "If this is intentional, you can continue.",
         "SASpro Frozen Executable",
         StdIcon_Warning,
         StdButton_Ok
      )).execute();
   }

   return p;
}

// ---- config parsing helpers (top-level for PI strict mode) ----
function _cc_toBool(s, defv) {
   var v = String(s).toLowerCase().trim();
   if (v == "1" || v == "true" || v == "yes" || v == "on") return true;
   if (v == "0" || v == "false" || v == "no" || v == "off") return false;
   return defv;
}

function _cc_toFloat(s, defv) {
   var x = parseFloat(String(s));
   return isNaN(x) ? defv : x;
}

function _cc_toInt(s, defv) {
   var x = parseInt(String(s), 10);
   return isNaN(x) ? defv : x;
}

/* -------------------------------------------------------------------------
 * Temp file I/O
 * ------------------------------------------------------------------------- */
function saveViewForSasproCLI(view) {
   // Always work from the main view/window
   var imgWindow = view.isMainView ? view.window : view.mainView.window;
   if (!imgWindow)
      throw new Error("Image window is undefined for the specified view.");

   ensureDir(scriptTempDir);

   var base = uniqueTempBase(imgWindow.mainView.id);
   var inputFilePath  = base + "_in.fits";
   var outputFilePath = base + "_out.fits";

   // IMPORTANT:
   // Do NOT call saveAs() on imgWindow (changes the subwindow banner filename).
   // Clone into a temporary ImageWindow and save THAT.
   var srcImg = imgWindow.mainView.image;

   // PJSR ImageWindow ctor wants booleans here:
   // floatSample = true for real (floating point), false for integer
   // color = true for RGB/Color, false for grayscale
   var floatSample = (srcImg.sampleType == SampleType_Real);
   var isColor     = (srcImg.colorSpace != ColorSpace_Gray);

   // Create temp window matching geometry & sample format
   var tmp = new ImageWindow(
      srcImg.width,
      srcImg.height,
      srcImg.numberOfChannels,
      srcImg.bitsPerSample,
      floatSample,
      isColor,
      "SASpro_CC_Temp"
   );

   // Copy pixels into temp window
   tmp.mainView.beginProcess(UndoFlag_NoSwapFile);
   tmp.mainView.image.assign(srcImg);
   tmp.mainView.endProcess();

   // Save temp clone to disk (does NOT touch user's original window)
   if (!tmp.saveAs(inputFilePath, false, false, false, false)) {
      tmp.forceClose();
      throw new Error("Failed to save temporary FITS: " + inputFilePath);
   }

   tmp.forceClose();

   console.writeln("Saved temp input (clone): " + inputFilePath);

   return {
      inputFilePath:  inputFilePath,
      outputFilePath: outputFilePath
   };
}



function processOutputImage(outputFilePath, targetView) {
   if (!File.exists(outputFilePath))
      throw new Error("Cosmic Clarity output file not found: " + outputFilePath);

   var opened = ImageWindow.open(outputFilePath);
   if (!opened || opened.length < 1)
      throw new Error("Failed to open Cosmic Clarity output image: " + outputFilePath);

   var outWindow = opened[0];
   outWindow.show();

   // Preserve original where CLI output is zero (keeps your current behavior)
   var pixelMath = new PixelMath;
   pixelMath.expression = "iif(" + outWindow.mainView.id + " == 0, $T, " + outWindow.mainView.id + ")";
   pixelMath.useSingleExpression = true;
   pixelMath.createNewImage = false;
   pixelMath.executeOn(targetView.mainView);

   outWindow.forceClose();

   try {
      File.remove(outputFilePath);
      console.writeln("Deleted temp output: " + outputFilePath);
   } catch (e) {
      console.warningln("Could not delete temp output: " + e.message);
   }
}


/* -------------------------------------------------------------------------
 * CLI command building
 * ------------------------------------------------------------------------- */
function buildCosmicClarityArgs(inputFilePath, outputFilePath) {
   var args = [];

   inputFilePath  = normalizePathForExternal(inputFilePath);
   outputFilePath = normalizePathForExternal(outputFilePath);

   // Process mode (default sharpen)
   var mode = (SetiAstroSharpParameters.processMode || "sharpen");
   args.push(mode);

   // Common required IO args
   args.push("-i");
   args.push(inputFilePath);

   args.push("-o");
   args.push(outputFilePath);

   // Common GPU flag
   if (SetiAstroSharpParameters.useGPU)
      args.push("--gpu");
   else
      args.push("--no-gpu");

   // ------------------------------
   // NEW: tiling args (shared)
   // ------------------------------
   // Basic clamps to avoid nonsense values
   var cs = _cc_toInt(SetiAstroSharpParameters.chunkSize, 256);
   var ov = _cc_toInt(SetiAstroSharpParameters.overlap, 64);

   if (cs < 64) cs = 64;
   if (cs > 2048) cs = 2048;
   if (ov < 0) ov = 0;
   if (ov >= cs) ov = Math.max(0, cs - 1);

   args.push("--chunk-size");
   args.push(format("%d", cs));

   args.push("--overlap");
   args.push(format("%d", ov));

   // ------------------------------
   // Command-specific options
   // ------------------------------
   if (mode == "sharpen" || mode == "both") {
      args.push("--sharpening-mode");
      args.push(SetiAstroSharpParameters.sharpeningMode || "Both");

      args.push("--stellar-amount");
      args.push(format("%.2f", SetiAstroSharpParameters.stellarAmount));

      args.push("--nonstellar-amount");
      args.push(format("%.2f", SetiAstroSharpParameters.nonStellarAmount));

      // Only send manual PSF if auto-psf is OFF
      if (SetiAstroSharpParameters.autoPSF) {
         args.push("--auto-psf");
      } else {
         args.push("--no-auto-psf");
         args.push("--nonstellar-psf");
         args.push(format("%.2f", SetiAstroSharpParameters.nonStellarStrength));
      }

      if (SetiAstroSharpParameters.sharpenChannelsSeparately)
         args.push("--sharpen-channels-separately");
   }

   if (mode == "denoise" || mode == "both") {
      args.push("--denoise-luma");
      args.push(format("%.2f", SetiAstroSharpParameters.denoiseLuma));

      args.push("--denoise-color");
      args.push(format("%.2f", SetiAstroSharpParameters.denoiseColor));

      args.push("--denoise-mode");
      args.push(SetiAstroSharpParameters.denoiseMode || "full");

      if (SetiAstroSharpParameters.separateDenoiseChannels)
         args.push("--separate-channels");
   }

   if (mode == "superres") {
      args.push("--scale");
      args.push(format("%d", SetiAstroSharpParameters.superResScale || 2));
   }

   if (mode == "satellite") {
      args.push("--mode");
      args.push(SetiAstroSharpParameters.satelliteMode || "full");

      if (SetiAstroSharpParameters.satelliteClipTrail)
         args.push("--clip-trail");
      else
         args.push("--no-clip-trail");

      args.push("--sensitivity");
      args.push(format("%.2f", SetiAstroSharpParameters.satelliteSensitivity));
   }

   return args;
}



function makeLauncher(program, prefixArgs, label) {
   return {
      program: program,
      prefixArgs: prefixArgs || [],
      label: label || String(program)
   };
}

function getDefaultPythonCmd() {
   if (IS_WIN)
      return "python";
   return "python3";
}

function resolveSasproCliLauncher() {
   var mode = SetiAstroSharpParameters.cliLauncherMode;
   var launcherPath = (SetiAstroSharpParameters.cliLauncherPath || "").trim();
   var scriptPath = (SetiAstroSharpParameters.pythonScriptPath || "").trim();

   // manual / explicit modes
   if (mode == "setiastrosuitepro cc (installed command)") {
      return makeLauncher("setiastrosuitepro", ["cc"], "setiastrosuitepro cc (installed command)");
   }

   if (mode == "Frozen setiastrosuitepro executable") {
      if (launcherPath.length == 0) {
         // Try OS default first on Win/mac
         var def = getDefaultFrozenSasproPath();
         if (def.length > 0 && fileExistsSafe(def)) {
            launcherPath = def;
            SetiAstroSharpParameters.cliLauncherPath = launcherPath;
            SetiAstroSharpParameters.save();
         } else if (IS_LIN) {
            // Linux must be user-selected
            throw new Error(
               "Frozen executable mode selected, but no executable path is configured.\n" +
               "On Linux, please browse to your SetiAstroSuitePro executable " +
               "(e.g. SetiAstroSuitePro_linux_ubuntu24.04)."
            );
         } else {
            throw new Error(
               "Frozen executable mode selected, but no executable path is configured.\n" +
               "Expected default path:\n" + def
            );
         }
      }

      return makeLauncher(launcherPath, ["cc"], "Frozen setiastrosuitepro executable");
   }


   if (mode == "python -m setiastro.saspro cc") {
      var py = (launcherPath.length > 0) ? launcherPath : getDefaultPythonCmd();
      return makeLauncher(py, ["-m", "setiastro.saspro", "cc"], "python -m setiastro.saspro cc");
   }

   if (mode == "python setiastrosuitepro.py cc") {
      var py2 = (launcherPath.length > 0) ? launcherPath : getDefaultPythonCmd();
      if (scriptPath.length == 0)
         throw new Error("python setiastrosuitepro.py mode selected, but no script path is configured.");
      return makeLauncher(py2, [scriptPath, "cc"], "python setiastrosuitepro.py cc");
   }

   // Auto-detect mode
   var candidates = [];

   // 1) pip install / PATH (preferred and current)
   candidates.push(makeLauncher("setiastrosuitepro", ["cc"], "Auto: setiastrosuitepro cc"));

   // 2) OS-known frozen defaults (Win/mac)
   var defaultFrozen = getDefaultFrozenSasproPath();
   if (defaultFrozen.length > 0 && fileExistsSafe(defaultFrozen))
      candidates.push(makeLauncher(defaultFrozen, ["cc"], "Auto: frozen default path"));

   // 3) user-provided frozen path if present
   if (launcherPath.length > 0)
      candidates.push(makeLauncher(launcherPath, ["cc"], "Auto: frozen executable path"));

   // 4) python module fallbacks
   if (IS_WIN) {
      candidates.push(makeLauncher("py", ["-3", "-m", "setiastro.saspro", "cc"], "Auto: py -3 -m setiastro.saspro cc"));
      candidates.push(makeLauncher("python", ["-m", "setiastro.saspro", "cc"], "Auto: python -m setiastro.saspro cc"));
   } else {
      candidates.push(makeLauncher("python3", ["-m", "setiastro.saspro", "cc"], "Auto: python3 -m setiastro.saspro cc"));
      candidates.push(makeLauncher("python", ["-m", "setiastro.saspro", "cc"], "Auto: python -m setiastro.saspro cc"));
   }

   // 5) python script fallback (only if user provided script path)
   if (scriptPath.length > 0) {
      var py3 = (launcherPath.length > 0) ? launcherPath : getDefaultPythonCmd();
      candidates.push(makeLauncher(py3, [scriptPath, "cc"], "Auto: python setiastrosuitepro.py cc"));
   }

   return {
      isAuto: true,
      autoCandidates: candidates
   };

}

/* -------------------------------------------------------------------------
 * External process execution + progress parsing
 * ------------------------------------------------------------------------- */
function runExternalProcessBlocking(program, args, options) {
   options = options || {};

   var process = new ExternalProcess;
   var started = false;
   var finished = false;

   // IMPORTANT: PI can emit onError even when the child really launched.
   // Treat this as telemetry, not an automatic fatal condition.
   var sawOnError = false;
   var errorCodes = [];

   var stderrText = "";
   var stdoutText = "";

   process.onStarted = function() {
      started = true;
      Console.noteln("Started: " + program + " " + args.join(" "));
   };

   process.onStandardOutputDataAvailable = function() {
      var out = String(this.stdout);
      if (out && out.length > 0) {
         stdoutText += out;
         if (options.onStdOutText)
            options.onStdOutText(out);
      }
   };

   process.onStandardErrorDataAvailable = function() {
      var err = String(this.stderr);
      if (err && err.length > 0) {
         stderrText += err;
         if (options.onStdErrText)
            options.onStdErrText(err);
      }
   };

   process.onError = function(code) {
      sawOnError = true;
      errorCodes.push(code);
      // Log it, but do not mark the run as failed yet.
      Console.warningln("Process onError event code: " + code + " (ignoring unless process never starts)");
   };

   process.onFinished = function() {
      finished = true;
      Console.noteln("Process finished.");
   };

   var okStart = process.start(program, args);
   if (!okStart) {
      return {
         ok: false,
         started: false,
         finished: false,
         stdout: stdoutText,
         stderr: (stderrText ? stderrText + "\n" : "") + "Failed to start process.",
         sawOnError: sawOnError,
         errorCodes: errorCodes
      };
   }

   while (process.isStarting)
      processEvents();
   while (process.isRunning)
      processEvents();

   // Success here means the process lifecycle completed from PI’s perspective.
   // Actual CLI success/failure should be judged by output file presence and logs.
   return {
      ok: started && finished,
      started: started,
      finished: finished,
      stdout: stdoutText,
      stderr: stderrText,
      sawOnError: sawOnError,
      errorCodes: errorCodes
   };
}


function createProgressTextHandler() {
   var lastPercent = -1;
   var lineBuffer = "";

   return {
      feedStdout: function(text) {
         lineBuffer += text;

         // Process complete lines only
         var lines = lineBuffer.split(/\r?\n/);
         if (lines.length > 0)
            lineBuffer = lines.pop(); // keep trailing partial line

         for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            if (!line || line.length === 0)
               continue;

            var m = line.match(/PROGRESS:\s*(\d+)%/i);
            if (m) {
               var p = parseInt(m[1], 10);
               if (p !== lastPercent) {
                  lastPercent = p;
                  Console.writeln(format("SASpro Cosmic Clarity Progress: %3d%%", p));
               }
            } else {
               Console.writeln(line);
            }
         }
      },

      feedStderr: function(text) {
         // Many CLIs print useful logs to stderr. Show them.
         var lines = String(text).split(/\r?\n/);
         for (var i = 0; i < lines.length; i++) {
            if (lines[i] && lines[i].length > 0)
               Console.warningln(lines[i]);
         }
      }
   };
}

function runSasproCliWithCandidate(candidate, ccArgs) {
   var handler = createProgressTextHandler();

   return runExternalProcessBlocking(
      candidate.program,
      candidate.prefixArgs.concat(ccArgs),
      {
         onStdOutText: function(t) { handler.feedStdout(t); },
         onStdErrText: function(t) { handler.feedStderr(t); }
      }
   );
}


function runSasproCli(launcherOrAuto, ccArgs) {
   if (launcherOrAuto.isAuto) {
      var candidates = launcherOrAuto.autoCandidates;
      var lastError = "";

      for (var i = 0; i < candidates.length; i++) {
         var c = candidates[i];
         Console.noteln("Trying launcher: " + c.label);

         var r = runSasproCliWithCandidate(c, ccArgs);

         // If it started+finished, do NOT try another candidate.
         // Let caller decide success based on output file readiness.
         if (r.started && r.finished)
            return { ok: true, launcher: c, result: r };

         lastError = (r.stderr && r.stderr.length > 0) ? r.stderr : "Launcher failed.";
         Console.warningln("Launcher did not complete: " + c.label);
      }

      return { ok: false, error: lastError };
   }

   var r2 = runSasproCliWithCandidate(launcherOrAuto, ccArgs);

   if (r2.started && r2.finished)
      return { ok: true, launcher: launcherOrAuto, result: r2 };

   return {
      ok: false,
      error: (r2.stderr && r2.stderr.length > 0) ? r2.stderr : "Failed to run configured launcher."
   };
}


function normalizePathForExternal(p) {
   if (!p)
      return p;
   var s = String(p);
   if (IS_WIN) {
      // convert forward slashes to backslashes
      s = s.split("/").join("\\");
   } else {
      // convert backslashes to forward slashes
      s = s.split("\\").join("/");
   }
   return s;
}



/* -------------------------------------------------------------------------
 * Main CC execution
 * ------------------------------------------------------------------------- */
function runCosmicClarityViaSasproCLI(selectedView) {
   var tempFiles = saveViewForSasproCLI(selectedView);
   var inputFilePath = tempFiles.inputFilePath;
   var outputFilePath = tempFiles.outputFilePath;

   var success = false;

   try {
      if (!waitForFileReady(inputFilePath, 30000, 1000))
         throw new Error("Temporary input file was not found/ready in time:\n" + inputFilePath);

      console.noteln("Input file ready: " + inputFilePath);

      var ccArgs = buildCosmicClarityArgs(inputFilePath, outputFilePath);
      var launcher = resolveSasproCliLauncher();

      // Intentionally DO NOT trust/fail on runResult.ok here.
      // PixInsight ExternalProcess can report launch failure spuriously.
      var runResult = runSasproCli(launcher, ccArgs);

      // Helpful telemetry only (no hard failure)
      try {
         if (runResult && runResult.launcher && runResult.launcher.label)
            console.noteln("Launcher used: " + runResult.launcher.label);
      } catch (eTelemetry) {
         // ignore
      }

      // Real success criterion = output file appears and becomes readable
      if (!waitForFileReady(outputFilePath, 300000, 1500)) {
         var extra = "";
         try {
            if (runResult && runResult.result) {
               var rr = runResult.result;

               if (rr.stderr && rr.stderr.length > 0) {
                  var sErr = rr.stderr;
                  if (sErr.length > 2000)
                     sErr = sErr.substring(sErr.length - 2000, sErr.length);
                  extra += "\n\n--- CLI stderr (tail) ---\n" + sErr;
               }

               if (rr.stdout && rr.stdout.length > 0) {
                  var sOut = rr.stdout;
                  if (sOut.length > 2000)
                     sOut = sOut.substring(sOut.length - 2000, sOut.length);
                  extra += "\n\n--- CLI stdout (tail) ---\n" + sOut;
               }
            } else if (runResult && runResult.error) {
               extra += "\n\n--- Launcher error ---\n" + runResult.error;
            }
         } catch (eTail) {
            // ignore telemetry formatting errors
         }

         throw new Error(
            "SASpro CLI did not produce an output file in time:\n" +
            outputFilePath + extra
         );
      }

      processOutputImage(outputFilePath, selectedView);
      success = true;

   } finally {
      if (success) {
         deleteFileQuiet(inputFilePath);
         deleteFileQuiet(outputFilePath);
      } else {
         console.warningln("Keeping temp files for debugging:");
         console.warningln("  input:  " + inputFilePath);
         console.warningln("  output: " + outputFilePath);
      }
   }
}


/* -------------------------------------------------------------------------
 * UI Dialog
 * ------------------------------------------------------------------------- */
function SetiAstroSharpDialog() {
   this.__base__ = Dialog;
   this.__base__();

   SetiAstroSharpParameters.load();

   var self = this;

   // ---------- Title / Description ----------
   this.titleLabel = new Label(this);
   this.titleLabel.text = "Cosmic Clarity - SASpro " + VERSION;
   this.titleLabel.textAlignment = TextAlign_Center;

   this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.setMinWidth(560);
   this.description.setMaxHeight(120);
   this.description.text =
      "This script sends the selected image to Seti Astro Suite Pro Cosmic Clarity (CLI).\n" +
      "It saves a temporary FITS, runs SASpro headless, then replaces the image with the processed result.\n\n" +
      "Supported modes here: Sharpen, Denoise, Sharpen + Denoise, and Super Resolution.\n" +
      "Launcher modes support pip installs, frozen executables, and Python/module development environments.";


   // ---------- Image Selection ----------
   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text = "Select Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   var windows = ImageWindow.windows;
   if (!windows || windows.length === 0) {
      // We'll handle this later, but avoid crashes here.
   } else {
      var activeId = "";
      try {
         if (ImageWindow.activeWindow && ImageWindow.activeWindow.mainView)
            activeId = ImageWindow.activeWindow.mainView.id;
      } catch (e) {
         activeId = "";
      }

      for (var i = 0; i < windows.length; ++i) {
         this.imageSelectionDropdown.addItem(windows[i].mainView.id);
         if (windows[i].mainView.id == activeId)
            this.imageSelectionDropdown.currentItem = i;
      }
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 6;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   // ---------- Process Mode ----------
   this.processModeLabel = new Label(this);
   this.processModeLabel.text = "Process Mode:";
   this.processModeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.processModeRow = new HorizontalSizer;
   this.processModeRow.spacing = 12;

   this.processSharpenCheck = new CheckBox(this);
   this.processSharpenCheck.text = "Sharpen";
   this.processSharpenCheck.checked = (SetiAstroSharpParameters.processMode == "sharpen");
   this.processSharpenCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._procGroup, self.processSharpenCheck);
      else if (!self._anyChecked(self._procGroup)) self.processSharpenCheck.checked = true;
      self.updateVisibility();
   };

   this.processDenoiseCheck = new CheckBox(this);
   this.processDenoiseCheck.text = "Denoise";
   this.processDenoiseCheck.checked = (SetiAstroSharpParameters.processMode == "denoise");
   this.processDenoiseCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._procGroup, self.processDenoiseCheck);
      else if (!self._anyChecked(self._procGroup)) self.processSharpenCheck.checked = true;
      self.updateVisibility();
   };

   this.processBothCheck = new CheckBox(this);
   this.processBothCheck.text = "Sharpen + Denoise";
   this.processBothCheck.checked = (SetiAstroSharpParameters.processMode == "both");
   this.processBothCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._procGroup, self.processBothCheck);
      else if (!self._anyChecked(self._procGroup)) self.processSharpenCheck.checked = true;
      self.updateVisibility();
   };

   this.processSuperResCheck = new CheckBox(this);
   this.processSuperResCheck.text = "Super Resolution";
   this.processSuperResCheck.checked = (SetiAstroSharpParameters.processMode == "superres");
   this.processSuperResCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._procGroup, self.processSuperResCheck);
      else if (!self._anyChecked(self._procGroup)) self.processSharpenCheck.checked = true;
      self.updateVisibility();
   };

   // group list + helper for "none checked" guard
   this._procGroup = [ this.processSharpenCheck, this.processDenoiseCheck, this.processBothCheck, this.processSuperResCheck ];
   this._anyChecked = function(group) {
      for (var i = 0; i < group.length; i++)
         if (group[i].checked) return true;
      return false;
   };

   // safety default
   if (!this._anyChecked(this._procGroup))
      this.processSharpenCheck.checked = true;

   this.processModeRow.add(this.processSharpenCheck);
   this.processModeRow.add(this.processDenoiseCheck);
   this.processModeRow.add(this.processBothCheck);
   this.processModeRow.add(this.processSuperResCheck);
   this.processModeRow.addStretch();


   // ---------- Sharpening section label ----------
   this.sharpenSectionLabel = new Label(this);
   this.sharpenSectionLabel.text = "Sharpen Settings";
   this.sharpenSectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   // ---------- Sharpening Mode (exclusive checkboxes) ----------
   this.sharpeningModeLabel = new Label(this);
   this.sharpeningModeLabel.text = "Sharpening Mode:";
   this.sharpeningModeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.sharpeningModeRow = new HorizontalSizer;
   this.sharpeningModeRow.spacing = 12;

   this.sharpStellarCheck = new CheckBox(this);
   this.sharpStellarCheck.text = "Stellar";
   this.sharpStellarCheck.checked = (SetiAstroSharpParameters.sharpeningMode == "Stellar Only");
   this.sharpStellarCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._sharpModeGroup, self.sharpStellarCheck);
      else if (!self._anyChecked(self._sharpModeGroup)) self.sharpBothCheck.checked = true;
      self.updateVisibility();
   };

   this.sharpNonStellarCheck = new CheckBox(this);
   this.sharpNonStellarCheck.text = "Non-Stellar";
   this.sharpNonStellarCheck.checked = (SetiAstroSharpParameters.sharpeningMode == "Non-Stellar Only");
   this.sharpNonStellarCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._sharpModeGroup, self.sharpNonStellarCheck);
      else if (!self._anyChecked(self._sharpModeGroup)) self.sharpBothCheck.checked = true;
      self.updateVisibility();
   };

   this.sharpBothCheck = new CheckBox(this);
   this.sharpBothCheck.text = "Both";
   this.sharpBothCheck.checked = (SetiAstroSharpParameters.sharpeningMode == "Both");
   this.sharpBothCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._sharpModeGroup, self.sharpBothCheck);
      else if (!self._anyChecked(self._sharpModeGroup)) self.sharpBothCheck.checked = true;
      self.updateVisibility();
   };

   this._sharpModeGroup = [ this.sharpStellarCheck, this.sharpNonStellarCheck, this.sharpBothCheck ];
   if (!this._anyChecked(this._sharpModeGroup))
      this.sharpBothCheck.checked = true;

   this.sharpeningModeRow.add(this.sharpStellarCheck);
   this.sharpeningModeRow.add(this.sharpNonStellarCheck);
   this.sharpeningModeRow.add(this.sharpBothCheck);
   this.sharpeningModeRow.addStretch();


   // ---------- Sharpen channels separately ----------
   this.sharpenChannelsCheckbox = new CheckBox(this);
   this.sharpenChannelsCheckbox.text = "Sharpen RGB Channels Separately";
   this.sharpenChannelsCheckbox.checked = SetiAstroSharpParameters.sharpenChannelsSeparately;
   this.sharpenChannelsCheckbox.onCheck = function(checked) {
      SetiAstroSharpParameters.sharpenChannelsSeparately = checked;
   };

   this.sharpenChannelsSizer = new HorizontalSizer;
   this.sharpenChannelsSizer.addStretch();
   this.sharpenChannelsSizer.add(this.sharpenChannelsCheckbox);
   this.sharpenChannelsSizer.addStretch();

   // ---------- Auto PSF ----------
   this.autoPSFCheckbox = new CheckBox(this);
   this.autoPSFCheckbox.text = "Auto PSF (ignore manual Non-Stellar PSF)";
   this.autoPSFCheckbox.checked = SetiAstroSharpParameters.autoPSF;
   this.autoPSFCheckbox.onCheck = function(checked) {
      SetiAstroSharpParameters.autoPSF = checked;
      self.updateVisibility();
   };

   this.autoPSFSizer = new HorizontalSizer;
   this.autoPSFSizer.addStretch();
   this.autoPSFSizer.add(this.autoPSFCheckbox);
   this.autoPSFSizer.addStretch();

   // ---------- Sharpen numeric controls ----------
   this.stellarAmountSlider = new NumericControl(this);
   this.stellarAmountSlider.label.text = "Stellar Amount:";
   this.stellarAmountSlider.setRange(0, 1);
   this.stellarAmountSlider.setPrecision(2);
   this.stellarAmountSlider.setValue(SetiAstroSharpParameters.stellarAmount);
   this.stellarAmountSlider.toolTip =
      "Amount of stellar sharpening to apply (0 to 1).";
   this.stellarAmountSlider.onValueUpdated = function(value) {
      SetiAstroSharpParameters.stellarAmount = value;
   };

   this.nonStellarStrengthSlider = new NumericControl(this);
   this.nonStellarStrengthSlider.label.text = "Non-Stellar Feature Size (PSF):";
   this.nonStellarStrengthSlider.setRange(1, 8);
   this.nonStellarStrengthSlider.setPrecision(2);
   this.nonStellarStrengthSlider.setValue(SetiAstroSharpParameters.nonStellarStrength);
   this.nonStellarStrengthSlider.toolTip =
      "Manual non-stellar feature size (PSF). Used only when Auto PSF is OFF.";
   this.nonStellarStrengthSlider.onValueUpdated = function(value) {
      SetiAstroSharpParameters.nonStellarStrength = value;
   };

   this.nonStellarAmountSlider = new NumericControl(this);
   this.nonStellarAmountSlider.label.text = "Non-Stellar Amount:";
   this.nonStellarAmountSlider.setRange(0, 1);
   this.nonStellarAmountSlider.setPrecision(2);
   this.nonStellarAmountSlider.setValue(SetiAstroSharpParameters.nonStellarAmount);
   this.nonStellarAmountSlider.toolTip =
      "Amount of non-stellar sharpening to apply (0 to 1).";
   this.nonStellarAmountSlider.onValueUpdated = function(value) {
      SetiAstroSharpParameters.nonStellarAmount = value;
   };

   // ---------- Denoise section ----------
   this.denoiseSectionLabel = new Label(this);
   this.denoiseSectionLabel.text = "Denoise Settings";
   this.denoiseSectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   // ---------- Denoise Mode (exclusive checkboxes) ----------
   this.denoiseModeLabel = new Label(this);
   this.denoiseModeLabel.text = "Denoise Mode:";
   this.denoiseModeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.denoiseModeRow = new HorizontalSizer;
   this.denoiseModeRow.spacing = 12;

   this.denoiseFullCheck = new CheckBox(this);
   this.denoiseFullCheck.text = "Full";
   this.denoiseFullCheck.checked = (SetiAstroSharpParameters.denoiseMode == "full");
   this.denoiseFullCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._denModeGroup, self.denoiseFullCheck);
      else if (!self._anyChecked(self._denModeGroup)) self.denoiseFullCheck.checked = true;
      self.updateVisibility();
   };

   this.denoiseLuminanceCheck = new CheckBox(this);
   this.denoiseLuminanceCheck.text = "Luminance Only";
   this.denoiseLuminanceCheck.checked = (SetiAstroSharpParameters.denoiseMode == "luminance");
   this.denoiseLuminanceCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._denModeGroup, self.denoiseLuminanceCheck);
      else if (!self._anyChecked(self._denModeGroup)) self.denoiseFullCheck.checked = true;
      self.updateVisibility();
   };

   this._denModeGroup = [ this.denoiseFullCheck, this.denoiseLuminanceCheck ];
   if (!this._anyChecked(this._denModeGroup))
      this.denoiseFullCheck.checked = true;

   this.denoiseModeRow.add(this.denoiseFullCheck);
   this.denoiseModeRow.add(this.denoiseLuminanceCheck);
   this.denoiseModeRow.addStretch();


   this.denoiseLumaSlider = new NumericControl(this);
   this.denoiseLumaSlider.label.text = "Denoise Luma:";
   this.denoiseLumaSlider.setRange(0, 1);
   this.denoiseLumaSlider.setPrecision(2);
   this.denoiseLumaSlider.setValue(SetiAstroSharpParameters.denoiseLuma);
   this.denoiseLumaSlider.toolTip = "Luminance denoise strength (0 to 1).";
   this.denoiseLumaSlider.onValueUpdated = function(value) {
      SetiAstroSharpParameters.denoiseLuma = value;
   };

   this.denoiseColorSlider = new NumericControl(this);
   this.denoiseColorSlider.label.text = "Denoise Color:";
   this.denoiseColorSlider.setRange(0, 1);
   this.denoiseColorSlider.setPrecision(2);
   this.denoiseColorSlider.setValue(SetiAstroSharpParameters.denoiseColor);
   this.denoiseColorSlider.toolTip = "Color denoise strength (0 to 1).";
   this.denoiseColorSlider.onValueUpdated = function(value) {
      SetiAstroSharpParameters.denoiseColor = value;
   };

   this.denoiseSeparateChannelsCheckbox = new CheckBox(this);
   this.denoiseSeparateChannelsCheckbox.text = "Denoise RGB Channels Separately";
   this.denoiseSeparateChannelsCheckbox.checked = SetiAstroSharpParameters.separateDenoiseChannels;
   this.denoiseSeparateChannelsCheckbox.onCheck = function(checked) {
      SetiAstroSharpParameters.separateDenoiseChannels = checked;
   };

   this.denoiseSeparateChannelsSizer = new HorizontalSizer;
   this.denoiseSeparateChannelsSizer.addStretch();
   this.denoiseSeparateChannelsSizer.add(this.denoiseSeparateChannelsCheckbox);
   this.denoiseSeparateChannelsSizer.addStretch();

   // ---------- Super Resolution section ----------
   this.superResSectionLabel = new Label(this);
   this.superResSectionLabel.text = "Super Resolution Settings";
   this.superResSectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   // ---------- Super Resolution Scale (exclusive checkboxes) ----------
   this.superResScaleLabel = new Label(this);
   this.superResScaleLabel.text = "Scale:";
   this.superResScaleLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.superResScaleRow = new HorizontalSizer;
   this.superResScaleRow.spacing = 12;

   this.superRes2xCheck = new CheckBox(this);
   this.superRes2xCheck.text = "2x";
   this.superRes2xCheck.checked = (SetiAstroSharpParameters.superResScale == 2);
   this.superRes2xCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._srGroup, self.superRes2xCheck);
      else if (!self._anyChecked(self._srGroup)) self.superRes2xCheck.checked = true;
      self.updateVisibility();
   };

   this.superRes3xCheck = new CheckBox(this);
   this.superRes3xCheck.text = "3x";
   this.superRes3xCheck.checked = (SetiAstroSharpParameters.superResScale == 3);
   this.superRes3xCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._srGroup, self.superRes3xCheck);
      else if (!self._anyChecked(self._srGroup)) self.superRes2xCheck.checked = true;
      self.updateVisibility();
   };

   this.superRes4xCheck = new CheckBox(this);
   this.superRes4xCheck.text = "4x";
   this.superRes4xCheck.checked = (SetiAstroSharpParameters.superResScale == 4);
   this.superRes4xCheck.onCheck = function(checked) {
      if (checked) _cc_setExclusive(self._srGroup, self.superRes4xCheck);
      else if (!self._anyChecked(self._srGroup)) self.superRes2xCheck.checked = true;
      self.updateVisibility();
   };

   this._srGroup = [ this.superRes2xCheck, this.superRes3xCheck, this.superRes4xCheck ];
   if (!this._anyChecked(this._srGroup))
      this.superRes2xCheck.checked = true;

   this.superResScaleRow.add(this.superRes2xCheck);
   this.superResScaleRow.add(this.superRes3xCheck);
   this.superResScaleRow.add(this.superRes4xCheck);
   this.superResScaleRow.addStretch();



   // ---------- GPU ----------
   this.gpuAccelerationCheckbox = new CheckBox(this);
   this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
   this.gpuAccelerationCheckbox.checked = SetiAstroSharpParameters.useGPU;
   this.gpuAccelerationCheckbox.onCheck = function(checked) {
      SetiAstroSharpParameters.useGPU = checked;
   };

   // ---------- Tiling (Chunk Size / Overlap) ----------
   this.tilingSectionLabel = new Label(this);
   this.tilingSectionLabel.text = "Tiling Settings";
   this.tilingSectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.chunkSizeControl = new NumericControl(this);
   this.chunkSizeControl.label.text = "Chunk Size:";
   this.chunkSizeControl.setRange(64, 2048);
   this.chunkSizeControl.setPrecision(0);
   this.chunkSizeControl.setValue(SetiAstroSharpParameters.chunkSize || 256);
   this.chunkSizeControl.toolTip =
      "Tile size used for chunked processing (pixels). Typical: 256 or 512.";
   this.chunkSizeControl.onValueUpdated = function(v) {
      SetiAstroSharpParameters.chunkSize = Math.round(v);
      self.updateVisibility();
   };

   this.overlapControl = new NumericControl(this);
   this.overlapControl.label.text = "Overlap:";
   this.overlapControl.setRange(0, 512);
   this.overlapControl.setPrecision(0);
   this.overlapControl.setValue(SetiAstroSharpParameters.overlap || 64);
   this.overlapControl.toolTip =
      "Overlap between tiles (pixels). Must be < chunk size. Typical: 32–128.";
   this.overlapControl.onValueUpdated = function(v) {
      SetiAstroSharpParameters.overlap = Math.round(v);
      self.updateVisibility();
   };


   // ---------- Launcher Settings ----------
   this.launcherSectionLabel = new Label(this);
   this.launcherSectionLabel.text = "SASpro CLI Launcher Settings";
   this.launcherSectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.launcherModeLabel = new Label(this);
   this.launcherModeLabel.text = "Launcher Mode:";
   this.launcherModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.launcherModeCombo = new ComboBox(this);
   this.launcherModeCombo.editEnabled = false;

   var launcherModes = [
      "Auto Detect",
      "setiastrosuitepro cc (installed command)",
      "Frozen setiastrosuitepro executable",
      "python -m setiastro.saspro cc",
      "python setiastrosuitepro.py cc"
   ];


   var selectedLauncherIndex = 0;
   for (var lm = 0; lm < launcherModes.length; lm++) {
      this.launcherModeCombo.addItem(launcherModes[lm]);
      if (launcherModes[lm] == SetiAstroSharpParameters.cliLauncherMode)
         selectedLauncherIndex = lm;
   }
   this.launcherModeCombo.currentItem = selectedLauncherIndex;
   this.launcherModeCombo.onItemSelected = function(index) {
      SetiAstroSharpParameters.cliLauncherMode = self.launcherModeCombo.itemText(index);
      self.updateLauncherUIVisibility();
      if (SetiAstroSharpParameters.cliLauncherMode == "Frozen setiastrosuitepro executable") {
         if ((!SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.trim().length == 0) && !IS_LIN) {
            var defp = getDefaultFrozenSasproPath();
            if (defp.length > 0) {
               SetiAstroSharpParameters.cliLauncherPath = defp;
               self.launcherPathEdit.text = defp;
            }
         }
      }
   };

   this.launcherModeSizer = new HorizontalSizer;
   this.launcherModeSizer.spacing = 6;
   this.launcherModeSizer.add(this.launcherModeLabel);
   this.launcherModeSizer.add(this.launcherModeCombo, 100);

   // Launcher path row (exe path or python path depending on mode)
   this.launcherPathLabel = new Label(this);
   this.launcherPathLabel.text = "Launcher Path:";
   this.launcherPathLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.launcherPathEdit = new Edit(this);
   this.launcherPathEdit.text = SetiAstroSharpParameters.cliLauncherPath;
   this.launcherPathEdit.toolTip =
      "Path to setiastrosuitepro executable (frozen mode), or Python executable (python modes).";
   this.launcherPathEdit.onTextUpdated = function(text) {
      SetiAstroSharpParameters.cliLauncherPath = text;
   };

   this.launcherPathBrowseButton = new ToolButton(this);
   this.launcherPathBrowseButton.icon = this.scaledResource(":/icons/select-file.png");
   this.launcherPathBrowseButton.setScaledFixedSize(20, 20);
   this.launcherPathBrowseButton.toolTip = "Browse for executable (or Python).";
   this.launcherPathBrowseButton.onClick = function() {
      var mode = self.launcherModeCombo.itemText(self.launcherModeCombo.currentItem);

      // Frozen mode special handling
      if (mode == "Frozen setiastrosuitepro executable") {
         // Win/mac: if empty, seed with default path
         if ((!SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.length == 0) && !IS_LIN) {
            var def = getDefaultFrozenSasproPath();
            if (def.length > 0) {
               SetiAstroSharpParameters.cliLauncherPath = def;
               self.launcherPathEdit.text = def;
            }
         }

         // Linux: prompt specifically for SASpro executable
         if (IS_LIN) {
            var chosen = promptForFrozenSasproExecutableLinux(self);
            if (chosen && chosen.length > 0)
               self.launcherPathEdit.text = chosen;
            return;
         }
      }

      var ofd = new OpenFileDialog;
      ofd.caption = (mode == "Frozen setiastrosuitepro executable")
         ? "Select SetiAstroSuitePro Executable"
         : "Select Launcher Executable";
      ofd.multipleSelections = false;

      if (SetiAstroSharpParameters.cliLauncherPath && SetiAstroSharpParameters.cliLauncherPath.length > 0)
         ofd.initialPath = SetiAstroSharpParameters.cliLauncherPath;

      if (ofd.execute() && ofd.fileNames.length > 0) {
         SetiAstroSharpParameters.cliLauncherPath = ofd.fileNames[0];
         self.launcherPathEdit.text = SetiAstroSharpParameters.cliLauncherPath;
         SetiAstroSharpParameters.save();
      }
   };


   this.launcherPathSizer = new HorizontalSizer;
   this.launcherPathSizer.spacing = 6;
   this.launcherPathSizer.add(this.launcherPathLabel);
   this.launcherPathSizer.add(this.launcherPathEdit, 100);
   this.launcherPathSizer.add(this.launcherPathBrowseButton);

   // Python script path row (direct dev script mode)
   this.pythonScriptPathLabel = new Label(this);
   this.pythonScriptPathLabel.text = "SASpro Script Path:";
   this.pythonScriptPathLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.pythonScriptPathEdit = new Edit(this);
   this.pythonScriptPathEdit.text = SetiAstroSharpParameters.pythonScriptPath;
   this.pythonScriptPathEdit.toolTip =
      "Path to setiastrosuitepro.py (only used for 'python setiastrosuitepro.py cc').";
   this.pythonScriptPathEdit.onTextUpdated = function(text) {
      SetiAstroSharpParameters.pythonScriptPath = text;
   };

   this.pythonScriptBrowseButton = new ToolButton(this);
   this.pythonScriptBrowseButton.icon = this.scaledResource(":/icons/select-file.png");
   this.pythonScriptBrowseButton.setScaledFixedSize(20, 20);
   this.pythonScriptBrowseButton.toolTip = "Browse for setiastrosuitepro.py";
   this.pythonScriptBrowseButton.onClick = function() {
      var ofd = new OpenFileDialog;
      ofd.caption = "Select setiastrosuitepro.py";
      ofd.multipleSelections = false;
      if (SetiAstroSharpParameters.pythonScriptPath && SetiAstroSharpParameters.pythonScriptPath.length > 0)
         ofd.initialPath = SetiAstroSharpParameters.pythonScriptPath;
      // If frozen mode on Linux and no path set, prompt now
      if (IS_LIN && SetiAstroSharpParameters.cliLauncherMode == "Frozen setiastrosuitepro executable") {
         if (!SetiAstroSharpParameters.cliLauncherPath || SetiAstroSharpParameters.cliLauncherPath.trim().length == 0) {
            var chosenLin = promptForFrozenSasproExecutableLinux(self);
            if (!chosenLin || chosenLin.length == 0) {
               (new MessageBox(
                  "Frozen executable mode requires selecting the Linux SASpro executable.\n" +
                  "Please choose your SetiAstroSuitePro_linux_ubuntu24.04 file, or switch launcher mode.",
                  "Cosmic Clarity - SASpro",
                  StdIcon_Error,
                  StdButton_Ok
               )).execute();
               return; // keep dialog open
            }
            self.launcherPathEdit.text = chosenLin;
         }
}
      if (ofd.execute() && ofd.fileNames.length > 0) {
         SetiAstroSharpParameters.pythonScriptPath = ofd.fileNames[0];
         self.pythonScriptPathEdit.text = SetiAstroSharpParameters.pythonScriptPath;
         SetiAstroSharpParameters.save();
      }
   };

   this.pythonScriptPathSizer = new HorizontalSizer;
   this.pythonScriptPathSizer.spacing = 6;
   this.pythonScriptPathSizer.add(this.pythonScriptPathLabel);
   this.pythonScriptPathSizer.add(this.pythonScriptPathEdit, 100);
   this.pythonScriptPathSizer.add(this.pythonScriptBrowseButton);

   // Help / tips text
   this.launcherHelp = new TextBox(this);
   this.launcherHelp.readOnly = true;
   this.launcherHelp.setMinHeight(84);
   this.launcherHelp.text =
      "Tips:\n" +
      "• Auto Detect tries: setiastrosuitepro cc → frozen default path → configured frozen path → python module fallback.\n" +
      "• Windows frozen default path:\n" +
      "  C:\\Program Files\\SetiAstroSuitePro\\SetiAstroSuitePro.exe\n" +
      "• macOS frozen app executable path:\n" +
      "  /Applications/SetiAstroSuitePro.app/Contents/MacOS/SetiAstroSuitePro\n" +
      "• Linux frozen path is user-chosen. Browse to your executable (e.g. SetiAstroSuitePro_linux_ubuntu24.04).\n" +
      "• For source/dev usage, use 'python setiastrosuitepro.py cc' and select the script path.";


   // Test Launcher button
   this.testLauncherButton = new PushButton(this);
   this.testLauncherButton.text = "Test Launcher";
   this.testLauncherButton.toolTip = "Runs '<launcher> ... cc --help' to validate the configuration.";
   this.testLauncherButton.onClick = function() {
      self.testConfiguredLauncher();
   };

   this.launcherButtonsRow = new HorizontalSizer;
   this.launcherButtonsRow.addStretch();
   this.launcherButtonsRow.add(this.testLauncherButton);
   this.launcherButtonsRow.addStretch();

   // ---------- Bottom buttons ----------
   this.okButton = new PushButton(this);
   this.okButton.text = "OK";
   this.okButton.onClick = function() {
      // sync UI fields to params
      SetiAstroSharpParameters.cliLauncherMode = self.launcherModeCombo.itemText(self.launcherModeCombo.currentItem);
      SetiAstroSharpParameters.cliLauncherPath = self.launcherPathEdit.text;
      SetiAstroSharpParameters.pythonScriptPath = self.pythonScriptPathEdit.text;
      SetiAstroSharpParameters.save();
      self.ok();
   };

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { self.cancel(); };

   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function() {
      // ensure latest UI state is saved to process instance
      SetiAstroSharpParameters.cliLauncherMode = self.launcherModeCombo.itemText(self.launcherModeCombo.currentItem);
      SetiAstroSharpParameters.cliLauncherPath = self.launcherPathEdit.text;
      SetiAstroSharpParameters.pythonScriptPath = self.pythonScriptPathEdit.text;
      SetiAstroSharpParameters.save();
      this.dialog.newInstance();
   }.bind(this);

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.okButton);
   this.buttonsSizer.add(this.cancelButton);
   this.buttonsSizer.addStretch();

   // ---------- Layout ----------
   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;

   this.sizer.add(this.titleLabel);
   this.sizer.add(this.description);
   this.sizer.addSpacing(4);

   this.sizer.add(this.imageSelectionSizer);
   this.sizer.addSpacing(4);

   this.sizer.add(this.processModeLabel);
   this.sizer.add(this.processModeRow);
   this.sizer.addSpacing(4);

   // Sharpen controls
   this.sizer.add(this.sharpenSectionLabel);
   this.sizer.add(this.sharpeningModeLabel);
   this.sizer.add(this.sharpeningModeRow);
   this.sizer.add(this.sharpenChannelsSizer);
   this.sizer.add(this.autoPSFSizer);
   this.sizer.add(this.stellarAmountSlider);
   this.sizer.add(this.nonStellarStrengthSlider);
   this.sizer.add(this.nonStellarAmountSlider);

   // Denoise controls
   this.sizer.addSpacing(4);
   this.sizer.add(this.denoiseSectionLabel);
   this.sizer.add(this.denoiseModeLabel);
   this.sizer.add(this.denoiseModeRow);
   this.sizer.add(this.denoiseLumaSlider);
   this.sizer.add(this.denoiseColorSlider);
   this.sizer.add(this.denoiseSeparateChannelsSizer);

   // Superres controls
   this.sizer.addSpacing(4);
   this.sizer.add(this.superResSectionLabel);
   this.sizer.add(this.superResScaleLabel);
   this.sizer.add(this.superResScaleRow);

   this.sizer.addSpacing(4);
   this.sizer.add(this.tilingSectionLabel);
   this.sizer.add(this.chunkSizeControl);
   this.sizer.add(this.overlapControl);

   // Shared
   this.sizer.addSpacing(4);
   this.sizer.add(this.gpuAccelerationCheckbox);


   this.sizer.addSpacing(8);
   this.sizer.add(this.launcherSectionLabel);
   this.sizer.add(this.launcherModeSizer);
   this.sizer.add(this.launcherPathSizer);
   this.sizer.add(this.pythonScriptPathSizer);
   this.sizer.add(this.launcherHelp);
   this.sizer.add(this.launcherButtonsRow);

   this.sizer.addSpacing(8);
   this.sizer.add(this.buttonsSizer);

   this.windowTitle = "Cosmic Clarity - SASpro";
   this.adjustToContents();

   this.updateVisibility();
   this.updateLauncherUIVisibility();
}
SetiAstroSharpDialog.prototype = new Dialog;

SetiAstroSharpDialog.prototype.updateVisibility = function() {
   // ---- resolve process mode from exclusive checkboxes ----
   var isSharpen = this.processSharpenCheck.checked;
   var isDenoise = this.processDenoiseCheck.checked;
   var isBoth    = this.processBothCheck.checked;
   var isSuper   = this.processSuperResCheck.checked;

   if (!isSharpen && !isDenoise && !isBoth && !isSuper) {
      this.processSharpenCheck.checked = true;
      isSharpen = true;
   }

   SetiAstroSharpParameters.processMode =
      isSharpen ? "sharpen" :
      isDenoise ? "denoise" :
      isBoth    ? "both" :
                  "superres";

   // ---- resolve sharpen mode ----
   var stellarMode    = this.sharpStellarCheck.checked;
   var nonStellarMode = this.sharpNonStellarCheck.checked;
   var bothMode       = this.sharpBothCheck.checked;

   if (!stellarMode && !nonStellarMode && !bothMode) {
      this.sharpBothCheck.checked = true;
      bothMode = true;
   }

   SetiAstroSharpParameters.sharpeningMode =
      stellarMode ? "Stellar Only" :
      nonStellarMode ? "Non-Stellar Only" :
                       "Both";

   // ---- resolve denoise mode (keep state sane even when hidden) ----
   if (!this.denoiseFullCheck.checked && !this.denoiseLuminanceCheck.checked)
      this.denoiseFullCheck.checked = true;

   SetiAstroSharpParameters.denoiseMode =
      this.denoiseLuminanceCheck.checked ? "luminance" : "full";

   // ---- resolve superres scale ----
   if (!this.superRes2xCheck.checked && !this.superRes3xCheck.checked && !this.superRes4xCheck.checked)
      this.superRes2xCheck.checked = true;

   SetiAstroSharpParameters.superResScale =
      this.superRes4xCheck.checked ? 4 :
      this.superRes3xCheck.checked ? 3 : 2;

   // ---- clamp tiling ----
   var cs = _cc_toInt(SetiAstroSharpParameters.chunkSize, 256);
   var ov = _cc_toInt(SetiAstroSharpParameters.overlap, 64);
   if (cs < 64) cs = 64;
   if (cs > 2048) cs = 2048;
   if (ov < 0) ov = 0;
   if (ov >= cs) ov = Math.max(0, cs - 1);
   SetiAstroSharpParameters.chunkSize = cs;
   SetiAstroSharpParameters.overlap  = ov;

   if (this.chunkSizeControl) this.chunkSizeControl.setValue(cs);
   if (this.overlapControl)   this.overlapControl.setValue(ov);

   // ---- group visibility ----
   var showSharpenGroup = (SetiAstroSharpParameters.processMode == "sharpen" || SetiAstroSharpParameters.processMode == "both");
   var showDenoiseGroup = (SetiAstroSharpParameters.processMode == "denoise" || SetiAstroSharpParameters.processMode == "both");
   var showSuperGroup   = (SetiAstroSharpParameters.processMode == "superres");

   // Tiling shown for all current modes here
   var showTiling = (SetiAstroSharpParameters.processMode != "satellite");
   if (this.tilingSectionLabel) this.tilingSectionLabel.visible = showTiling;
   if (this.chunkSizeControl)   this.chunkSizeControl.visible   = showTiling;
   if (this.overlapControl)     this.overlapControl.visible     = showTiling;

   // ---- Sharpen section ----
   this.sharpenSectionLabel.visible   = showSharpenGroup;
   this.sharpeningModeLabel.visible   = showSharpenGroup;
   this.sharpeningModeRow.visible     = showSharpenGroup;
   this.sharpStellarCheck.visible     = showSharpenGroup;
   this.sharpNonStellarCheck.visible  = showSharpenGroup;
   this.sharpBothCheck.visible        = showSharpenGroup;
   this.sharpenChannelsSizer.visible  = showSharpenGroup;
   this.sharpenChannelsCheckbox.visible = showSharpenGroup;
   this.autoPSFSizer.visible          = showSharpenGroup;
   this.autoPSFCheckbox.visible       = showSharpenGroup;

   this.stellarAmountSlider.visible    = showSharpenGroup && (stellarMode || bothMode);
   this.nonStellarAmountSlider.visible = showSharpenGroup && (nonStellarMode || bothMode);

   var needsManualPsf = showSharpenGroup && (nonStellarMode || bothMode) && !SetiAstroSharpParameters.autoPSF;
   this.nonStellarStrengthSlider.visible = needsManualPsf;

   // ---- Denoise section ----
   // Label + row + the two mode checkboxes MUST be explicitly hidden when sharpen-only
   this.denoiseSectionLabel.visible   = showDenoiseGroup;
   this.denoiseModeLabel.visible      = showDenoiseGroup;
   this.denoiseModeRow.visible        = showDenoiseGroup;

   this.denoiseFullCheck.visible      = showDenoiseGroup;       // ✅ NEW
   this.denoiseLuminanceCheck.visible = showDenoiseGroup;       // ✅ NEW

   this.denoiseLumaSlider.visible     = showDenoiseGroup;
   this.denoiseColorSlider.visible    = showDenoiseGroup;
   this.denoiseSeparateChannelsSizer.visible    = showDenoiseGroup;
   this.denoiseSeparateChannelsCheckbox.visible = showDenoiseGroup;

   if (showDenoiseGroup && SetiAstroSharpParameters.denoiseMode == "luminance")
      this.denoiseColorSlider.visible = false;

   // ---- Superres section ----
   this.superResSectionLabel.visible = showSuperGroup;
   this.superResScaleLabel.visible   = showSuperGroup;
   this.superResScaleRow.visible     = showSuperGroup;
   this.superRes2xCheck.visible      = showSuperGroup;
   this.superRes3xCheck.visible      = showSuperGroup;
   this.superRes4xCheck.visible      = showSuperGroup;

   // Shared
   this.gpuAccelerationCheckbox.visible = true;

   this.adjustToContents();
};


SetiAstroSharpDialog.prototype.updateLauncherUIVisibility = function() {
   var mode = this.launcherModeCombo.itemText(this.launcherModeCombo.currentItem);

   var showLauncherPath = (
      mode == "Frozen setiastrosuitepro executable" ||
      mode == "python -m setiastro.saspro cc" ||
      mode == "python setiastrosuitepro.py cc"
   );

   var showPythonScriptPath = (mode == "python setiastrosuitepro.py cc");

   this.launcherPathLabel.visible = showLauncherPath;
   this.launcherPathEdit.visible = showLauncherPath;
   this.launcherPathBrowseButton.visible = showLauncherPath;

   this.pythonScriptPathLabel.visible = showPythonScriptPath;
   this.pythonScriptPathEdit.visible = showPythonScriptPath;
   this.pythonScriptBrowseButton.visible = showPythonScriptPath;

   this.adjustToContents();
};

SetiAstroSharpDialog.prototype.testConfiguredLauncher = function() {
   try {
      SetiAstroSharpParameters.cliLauncherMode = this.launcherModeCombo.itemText(this.launcherModeCombo.currentItem);
      SetiAstroSharpParameters.cliLauncherPath = this.launcherPathEdit.text;
      SetiAstroSharpParameters.pythonScriptPath = this.pythonScriptPathEdit.text;
      SetiAstroSharpParameters.save();

      var launcher = resolveSasproCliLauncher();

      // For auto-detect test, test the first candidate that works with `--help`
      if (launcher.isAuto) {
         var candidates = launcher.autoCandidates;
         var anyOk = false;
         for (var i = 0; i < candidates.length; i++) {
            Console.noteln("Testing launcher candidate: " + candidates[i].label);
            var r = runExternalProcessBlocking(candidates[i].program, candidates[i].prefixArgs.concat(["--help"]));
            if (r.ok || (r.stdout && r.stdout.length > 0) || (r.stderr && r.stderr.length > 0)) {
               Console.noteln("Launcher candidate responded: " + candidates[i].label);
               anyOk = true;
               break;
            }
         }
         if (anyOk)
            (new MessageBox("Launcher test completed. Check the PixInsight console output.", "SASpro CLI Test", StdIcon_Information, StdButton_Ok)).execute();
         else
            (new MessageBox("No auto-detect launcher responded. Configure a manual launcher mode/path.", "SASpro CLI Test", StdIcon_Error, StdButton_Ok)).execute();
         return;
      }

      var r2 = runExternalProcessBlocking(launcher.program, launcher.prefixArgs.concat(["--help"]));
      if (r2.ok || (r2.stdout && r2.stdout.length > 0) || (r2.stderr && r2.stderr.length > 0)) {
         (new MessageBox("Launcher test completed. Check the PixInsight console output.", "SASpro CLI Test", StdIcon_Information, StdButton_Ok)).execute();
      } else {
         (new MessageBox("Launcher test failed. Check launcher mode/path and try again.", "SASpro CLI Test", StdIcon_Error, StdButton_Ok)).execute();
      }
   } catch (e) {
      (new MessageBox("Launcher test error:\n" + e.message, "SASpro CLI Test", StdIcon_Error, StdButton_Ok)).execute();
   }
};

/* -------------------------------------------------------------------------
 * Script entry point
 * ------------------------------------------------------------------------- */
console.show();
Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/__/ \\___/ \n                                         ");
Console.noteln    ("Cosmic Clarity - SASpro " + VERSION);
console.flush();

var dialog = new SetiAstroSharpDialog();

if (dialog.execute()) {
   console.writeln("Cosmic Clarity - SASpro process started.");
   console.flush();

   var selectedIndex = dialog.imageSelectionDropdown.currentItem;
   var windows2 = ImageWindow.windows;

   if (!windows2 || windows2.length === 0 || selectedIndex < 0 || selectedIndex >= windows2.length) {
      (new MessageBox("Please open and select an image first.", "Cosmic Clarity - SASpro", StdIcon_Error, StdButton_Ok)).execute();
   } else {
      var selectedView = windows2[selectedIndex];

      if (!selectedView) {
         (new MessageBox("Please select a valid image.", "Cosmic Clarity - SASpro", StdIcon_Error, StdButton_Ok)).execute();
      } else {
         try {
            runCosmicClarityViaSasproCLI(selectedView);
            console.noteln("Cosmic Clarity - SASpro processing complete.");
         } catch (e) {
            console.criticalln("Error: " + e.message);
            (new MessageBox("Cosmic Clarity - SASpro failed:\n\n" + e.message,
                            "Cosmic Clarity - SASpro",
                            StdIcon_Error,
                            StdButton_Ok)).execute();
         }
      }
   }
}
