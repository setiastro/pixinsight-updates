/*!
 * FindBackground
 * File: FindBackgroundUI_1.0.js
 * Description: A script to find regions covering true background in astronomical images. This file handles the UI and interaction with the core functionality.
 *
 * Copyright (c) 2024, Gerrit Erdt
 * Copyright (c) 2024, Franklin Marek
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * In case you are interested in collaborating or have questions regarding the code, its use in other products or anything else, feel free to contact us at:
 *  - Gerrit Erdt: gerrit_erdt@hotmail.com
 *  - Franklin Marek: frank@setiastro.com
 */

#feature-id   FindBackground : SetiAstro > Find Background
#feature-info This script utilizes gradient descent and various filters to quickly determine algorithmically an optimal background region of interest.

#define USE_FIND_BACKGROUND_JS_LIBRARY
#define FORCE_AVERAGE_FILTER

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>

#include "FindBackground_1.0.js"

let parameters =
{
    targetWindow: null,
    filterAvg: true,
    filterSdev: true,
    filterPoisonIndex: false,
    filterMAAD: false,
    filterObjects: false,
    printInformation: true,
    generatePreview: true,
    previewName: "Background",
    slowSearch: false,
    fastSearch: true,
    size: 50,
    spacingRate: 2,
    searchGridSize: 100,
    startingPoints: 40,

    save: function()
    {
        Parameters.set("filterAvg", this.filterAvg);
        Parameters.set("filterSdev", this.filterSdev);
        Parameters.set("filterPoisonIndex", this.filterPoisonIndex);
        Parameters.set("filterMAAD", this.filterMAAD);
        Parameters.set("filterObjects", this.filterObjects);
        Parameters.set("printInformation", this.printInformation);
        Parameters.set("generatePreview", this.generatePreview);
        Parameters.set("previewName", this.previewName);
        Parameters.set("slowSearch", this.slowSearch);
        Parameters.set("fastSearch", this.fastSearch);
        Parameters.set("size", this.size);
        Parameters.set("spacingRate", this.spacingRate);
        Parameters.set("searchGridSize", this.searchGridSize);
        Parameters.set("startingPoints", this.startingPoints);
    },

    load: function()
    {
        if (Parameters.has("filterAvg"))
            this.filterAvg = Parameters.getBoolean("filterAvg");
        if (Parameters.has("filterSdev"))
            this.filterSdev = Parameters.getBoolean("filterSdev");
        if (Parameters.has("filterPoisonIndex"))
            this.filterPoisonIndex = Parameters.getBoolean("filterPoisonIndex");
        if (Parameters.has("filterMAAD"))
            this.filterMAAD = Parameters.getBoolean("filterMAAD");
        if (Parameters.has("filterObjects"))
            this.filterObjects = Parameters.getBoolean("filterObjects");
        if (Parameters.has("printInformation"))
            this.printInformation = Parameters.getBoolean("printInformation");
        if (Parameters.has("generatePreview"))
            this.generatePreview = Parameters.getBoolean("generatePreview");
        if (Parameters.has("previewName"))
            this.previewName = Parameters.getString("previewName");
        if (Parameters.has("slowSearch"))
            this.slowSearch = Parameters.getBoolean("slowSearch");
        if (Parameters.has("fastSearch"))
            this.fastSearch = Parameters.getBoolean("fastSearch");
        if (Parameters.has("size"))
            this.size = Parameters.getInteger("size");
        if (Parameters.has("spacingRate"))
            this.spacingRate = Parameters.getInteger("spacingRate");
        if (Parameters.has("searchGridSize"))
            this.searchGridSize = Parameters.getInteger("searchGridSize");
        if (Parameters.has("startingPoints"))
            this.startingPoints = Parameters.getInteger("startingPoints");
    }
};

let constants =
{
    indent: 20,
    minLabelSize: 170
}



function FindBackgroundDialog()
{
    this.__base__ = Dialog;
    this.__base__();

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>FindBackground 1.2</b> - A script to find a region covering only true background in astronomical images.<br>" +
                      "Copyright (C) 2024, Gerrit Erdt<br>" +
                      "Copyright (C) 2024, Franklin Marek<br>";

    this.conditions_Lbl = new Label(this);
    this.conditions_Lbl.frameStyle = FrameStyle_Box;
    this.conditions_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.conditions_Lbl.useRichText = true;
    this.conditions_Lbl.text = "<b>Preconditions:</b>" +
                               "<ul>" +
                               "<li>The image has been corrected for background gradients.</li>" +
                               "<li>Stacking artifacts at the edges have been removed/cropped.</li>" +
                               "</ul>" +
                               "<b>Results:</b>" +
                               "<ul>" +
                               "<li>A preview named 'Background' that covers the found background region.</li>" +
                               "<li>Optionally: a console output of the background parameters and quality estimators.</li>" +
                               "</ul>" +
                               "For a complete documentation of all functionalities, see the tooltips of the respective elements."

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use for the background search.<br><br>" +
                                     "<b>Usage:</b> <br>The image you selected will be used for the background search.<br><br>" +
                                     "<b>Usage constraints:</b> <br>Selecting a preview is not possible.<br><br>" +
                                     "<b>Default value:</b> <br>The currently active window.<br>This is the window that is currently selected in the PixInsight workspace.";
    for(var i = 0; i < ImageWindow.windows.length; i++)
    {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if(ImageWindow.windows[i].mainView.id == currentWindowName)
        {
            this.windowSelector_Cb.currentItem = i;

            let window = ImageWindow.windowById(currentWindowName);
            if(window && !window.isNull)
            {
                parameters.targetWindow = window;
            }
        }
    }
    this.windowSelector_Cb.onItemSelected = (index) =>
    {
        let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
        if(window && !window.isNull)
        {
            parameters.targetWindow = window;
        }
    }

    this.filterInformation_Lbl = new Label(this);
    this.filterInformation_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.filterInformation_Lbl.useRichText = true;
    this.filterInformation_Lbl.text = "Filters: ";
    this.filterInformation_Lbl.toolTip = "The background in the image is estimated by a combination of different filters.<br><br>" +
                                         "<b>Usage:</b> <br>Select the filters you want to apply for the background estimation. An average brightness filter is always applied.<br><br>" +
                                         "<b>Usage constraints:</b><br>Be careful with the use of the absolute median average deviation filter, as it can be very slow and may not work well.<br><br>" +
                                         "<b>Default value:</b> <br>Standard deviation is selected by default.<br>This finds a background region that is both dark and 'empty'.";
#ifndef FORCE_AVERAGE_FILTER
    this.filterAvg_Chk = new CheckBox(this);
    this.filterAvg_Chk.text = "Average brightness";
    this.filterAvg_Chk.checked = parameters.filterAvg;
    this.filterAvg_Chk.toolTip = "Filter background regions based on their average brightness.<br><br>" +
                                 "<b>Usage:</b> <br>Enabling this filter will find darker regions, while disabling it will find brighter regions.<br><br>" +
                                 "<b>Usage constraints:</b> <br>None.<br><br>" +
                                 "<b>Default value:</b> <br>Enabled.<br>Per definition, the background is darker than all the objects in the image.";
    this.filterAvg_Chk.onCheck = function(checked)
    {
        parameters.filterAvg = checked;
    };
#endif

    this.filterSdev_Chk = new CheckBox(this);
    this.filterSdev_Chk.text = "Standard deviation";
    this.filterSdev_Chk.checked = parameters.filterSdev;
    this.filterSdev_Chk.toolTip = "Filter background regions based on their standard deviation.<br><br>" +
                                  "<b>Usage:</b> <br>Enabling this filter will find regions with low variation in brightness, while disabling it will find regions with high variation.<br><br>" +
                                  "<b>Usage constraints:</b> <br>None.<br><br>" +
                                  "<b>Default value:</b> <br>Enabled.<br>Per definition, the background is empty which means it has low variation in brightness.";
    this.filterSdev_Chk.onCheck = function(checked)
    {
        parameters.filterSdev = checked;
    };

    this.filterPoisonIndex_Chk = new CheckBox(this);
    this.filterPoisonIndex_Chk.text = "Poisson distribution fit";
    this.filterPoisonIndex_Chk.checked = parameters.filterPoisonIndex;
    this.filterPoisonIndex_Chk.toolTip = "Filter background regions based on how good they fit a poisson distribution.<br><br>" +
                                         "<b>Usage:</b> <br>Enabling this filter will find regions that follow a poisson distribution, while disabling it will ignore the intensity distribution.<br><br>" +
                                         "<b>Usage constraints:</b> <br>None.<br><br>" +
                                         "<b>Default value:</b> <br>Disabled.<br>Normally, the default filters will already find a good solution. Enable this filter in case you have doubts that the found region is actually representative.";
    this.filterPoisonIndex_Chk.onCheck = function(checked)
    {
        parameters.filterPoisonIndex = checked;
    }

    this.filterMAAD_Chk = new CheckBox(this);
    this.filterMAAD_Chk.text = "Absolute median average deviation";
    this.filterMAAD_Chk.checked = parameters.filterMAAD;
    this.filterMAAD_Chk.toolTip = "Filter background regions based on their absolute median average deviation (do not confuse this with MAD!).<br><br>" +
                                  "<b>Usage:</b> <br>Enabling this filter will find regions with a low skewness, meaning that the intensity distribution is symmetrical.<br><br>" +
                                  "<b>Usage constraints:</b> <br>Be careful with enabling this filter.<br>True background will not necessarily follow a normal distribution, however any smooth brightness transition will.<br>" +
                                  "Also, this will dramatically increase computation time.<br>Only use this filter if you know what you are doing and you really want a symmetrical distribution!<br><br>" +
                                  "<b>Default value:</b> <br>Disabled.<br>This filter can be very slow and may not work well.";
    this.filterMAAD_Chk.onCheck = function(checked)
    {
        parameters.filterMAAD = checked;
    };

    this.filterObjects_Chk = new CheckBox(this);
    this.filterObjects_Chk.text = "Filters out objects";
    this.filterObjects_Chk.checked = parameters.filterObjects;
    this.filterObjects_Chk.toolTip = "Filter out regions that contain objects.<br><br>" +
                                    "<b>Usage:</b> <br>Enabling this filter will find regions that are not covered by objects, while disabling it can find regions that are covered by objects.<br><br>" +
                                    "<b>Usage constraints:</b> <br>Everything, that is brighter than the darkest detectable star, " +
                                    "is considered an object.<br>Normally, this filter is not needed, but can be helpful for 'crowded' images.<br><br>" +
                                    "<b>Default value:</b> <br>Disabled.<br>Normally, this filter is disabled since the regular combination is good ad excluding bright objects. <br>You should try this filter in case the search converges on a field with objects in it.";
    this.filterObjects_Chk.onCheck = function(checked)
    {
        parameters.filterObjects = checked;
    };

    this.filterSizerVertical = new VerticalSizer;
    this.filterSizerVertical.spacing = 6;
#ifndef FORCE_AVERAGE_FILTER
    this.filterSizerVertical.add(this.filterAvg_Chk);
#endif
    this.filterSizerVertical.add(this.filterSdev_Chk);
    this.filterSizerVertical.add(this.filterPoisonIndex_Chk);
    this.filterSizerVertical.add(this.filterMAAD_Chk);
    this.filterSizerVertical.add(this.filterObjects_Chk);

    this.filterSizerHorizontal = new HorizontalSizer;
    this.filterSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.filterSizerHorizontal.add(this.filterSizerVertical);

    this.searchRoutine_Lbl = new Label(this);
    this.searchRoutine_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.searchRoutine_Lbl.useRichText = true;
    this.searchRoutine_Lbl.text = "Search routine: ";
    this.searchRoutine_Lbl.toolTip = "Select the search routine you want to use.<br><br>" +
                                    "<b>Usage:</b> <br>The slow search is guaranteed to find the best background region in the image, based on the selected filters, but takes a lot of computation time.<br>" +
                                    "The fast search is MUCH faster, but may only find a less than optimal solution. This is ideally suited for comparatively 'empty' images.<br><br>" +
                                    "<b>Usage constraints:</b><br>None<br><br>" +
                                    "<b>Default value:</b> <br>Fast search.<br>Normally, the fast search is sufficient to find a good background region.";

    this.slowSearch_Rdb = new RadioButton(this);
    this.slowSearch_Rdb.text = "Slow search";
    this.slowSearch_Rdb.checked = parameters.slowSearch;
    this.slowSearch_Rdb.toolTip = "The slow search routine is guaranteed to find the best possible background region in the image.<br><br>" +
                                  "<b>Usage:</b> <br>The slow search is guaranteed to find the best background region in the image, based on the selected filters, but takes a lot of computation time.<br><br>" +
                                  "Use the slow search in case you want to find the absolute best background region and don't care about the increased computation time.<br>This is often necessary for 'crowded' images.<br><br>" +
                                  "<b>Usage constraints:</b> <br>None.<br><br>" +
                                  "<b>Default value:</b> <br>Disabled.<br>Normally, the fast search is sufficient to find a good background region."
    this.slowSearch_Rdb.onCheck = (checked) =>
    {
        parameters.slowSearch = checked;
        parameters.fastSearch = !checked;
        this.backgroundParameterSearchGridSize_NC.enabled = false;
        this.backgroundParameterStartingPoints_NC.enabled = false;
    };

    this.fastSearch_Rdb = new RadioButton(this);
    this.fastSearch_Rdb.text = "Fast search";
    this.fastSearch_Rdb.checked = parameters.fastSearch;
    this.fastSearch_Rdb.toolTip = "The fast search routine will find a region that is a good background representation, but maybe not the best possible.<br><br>" +
                                  "<b>Usage:</b> <br>The fast search is much faster than the slow search, but may only find a less than optimal solution.<br>" +
                                  "Use the fast search in case you want to find a good approximation of the background in the image and you want to save computation time.<br><br>" +
                                  "<b>Usage constraints:</b> <br>None<br><br>" +
                                  "<b>Default value:</b> <br>Enabled.<br>Normally, the fast search is sufficient to find a good background region."

    this.fastSearch_Rdb.onCheck = (checked) =>
    {
        parameters.fastSearch = checked;
        parameters.slowSearch = !checked;
        this.backgroundParameterSearchGridSize_NC.enabled = true;
        this.backgroundParameterStartingPoints_NC.enabled = true;
    };

    this.searchOptionsSizerVertical = new VerticalSizer;
    this.searchOptionsSizerVertical.spacing = 6;
    this.searchOptionsSizerVertical.add(this.slowSearch_Rdb);
    this.searchOptionsSizerVertical.add(this.fastSearch_Rdb);

    this.searchOptionsSizerHorizontal = new HorizontalSizer;
    this.searchOptionsSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.searchOptionsSizerHorizontal.add(this.searchOptionsSizerVertical);

    this.backgroundRegionParameters_Lbl = new Label(this);
    this.backgroundRegionParameters_Lbl.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundRegionParameters_Lbl.useRichText = true;
    this.backgroundRegionParameters_Lbl.text = "Search parameters: ";
    this.backgroundRegionParameters_Lbl.toolTip = "Set the available search parameters for the selected search routine.<br><br>" +
                                                  "<b>Usage:</b> <br>Based on the selected search routine, different parameters are available. Tune them based on your needs and image<br><br>" +
                                                  "<b>Usage constraints:</b> <br>'Search grid width' and 'Number of starting points' are only available with the fast search.<br><br>" +
                                                  "<b>Default value:</b> <br>Size: 25, Spacing rate: 2, Search grid width: 100, Number of starting points: 40.<br>These values are a good starting point for most images.";

    this.backgroundParameterSize_NC = new NumericControl(this);
    this.backgroundParameterSize_NC.real = true;
    this.backgroundParameterSize_NC.label.text = "Size: ";
    this.backgroundParameterSize_NC.toolTip = "The size in pixels of the quadratic background region that is searched for. The size is the side length of the quadratic region.<br><br>" +
                                              "<b>Usage:</b> <br>Increase the size to find a larger region, which may be harder to fit between objects.<br>Decrease the size to find a smaller region, which may be easier to fit between objects.<br><br>" +
                                              "<b>Usage constraints:</b> <br>None.<br><br>" +
                                              "<b>Default value:</b> <br>25.<br>This allows for a good statistical analysis of the background region, while still being small enough to fit between objects, even on wider images.";
    this.backgroundParameterSize_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSize_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSize_NC.setRange(2, 500);
    this.backgroundParameterSize_NC.setPrecision(0);
    this.backgroundParameterSize_NC.setValue(parameters.size);
    this.backgroundParameterSize_NC.slider.minWidth = 200;
    this.backgroundParameterSize_NC.edit.minWidth = 50;
    this.backgroundParameterSize_NC.onValueUpdated = function(value)
    {
        parameters.size = Math.round(value);
    };

    this.backgroundParameterSpacingRate_NC = new NumericControl(this);
    this.backgroundParameterSpacingRate_NC.real = true;
    this.backgroundParameterSpacingRate_NC.label.text = "Spacing rate: ";
    this.backgroundParameterSpacingRate_NC.toolTip = "The spacing rate that is used during the search.<br>" +
                                                     "Both search routines work by measuring the filters inside different background regions. During the search, the background region is shifted through the image. " +
                                                     "This parameter defines the fraction of the region size by which it is shifted in each iteration. <br><br>" +
                                                     "<b>Usage:</b> <br>Increase this parameter to find a less perfect background region with less computation time. <br>" +
                                                     "Decrease this parameter to find a better background region at the cost of higher computation time.<br><br>" +
                                                     "<b>Usage constraints:</b> <br>None.<br><br>" +
                                                     "<b>Default value:</b> <br>2.<br>This is normally sufficient to find a good enough background region while still being fast enough for images with 'normal' resolution.<br>" +
                                                     "Only change this value, if the script has trouble finding a good background region.";
    this.backgroundParameterSpacingRate_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSpacingRate_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSpacingRate_NC.setRange(1, 10);
    this.backgroundParameterSpacingRate_NC.setPrecision(0);
    this.backgroundParameterSpacingRate_NC.setValue(parameters.spacingRate);
    this.backgroundParameterSpacingRate_NC.slider.minWidth = 200;
    this.backgroundParameterSpacingRate_NC.edit.minWidth = 50;
    this.backgroundParameterSpacingRate_NC.onValueUpdated = function(value)
    {
        parameters.spacingRate = Math.round(value);
    };

    this.backgroundParameterSearchGridSize_NC = new NumericControl(this);
    this.backgroundParameterSearchGridSize_NC.real = true;
    this.backgroundParameterSearchGridSize_NC.label.text = "Search grid width: ";
    this.backgroundParameterSearchGridSize_NC.toolTip = "The width of the search grid that is used during the fast search.<br>" +
                                                        "The fast search needs multiple starting points in the image.<br>For this purpose, the image is divided in width x width sized regions. " +
                                                        "The n best regions are selected as starting points.<br>This parameter defines the length of the quadratic grid tiles.<br><br>" +
                                                        "<b>Usage:</b> <br>Decrease this parameter to find a better background region at the cost of higher computation time.<br>Increase this parameter to find a less optimal background region with less computation time.<br><br>" +
                                                        "<b>Usage constraints:</b> <br>None.<br><br>" +
                                                        "<b>Default value:</b> <br>100.<br>This is normally sufficient to find starting points that are located in comparatively 'empty' regions of the image while still being fast enough for images with 'normal' resolution.";
    this.backgroundParameterSearchGridSize_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterSearchGridSize_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterSearchGridSize_NC.setRange(10, 500);
    this.backgroundParameterSearchGridSize_NC.setPrecision(0);
    this.backgroundParameterSearchGridSize_NC.setValue(parameters.searchGridSize);
    this.backgroundParameterSearchGridSize_NC.slider.minWidth = 200;
    this.backgroundParameterSearchGridSize_NC.edit.minWidth = 50;
    this.backgroundParameterSearchGridSize_NC.onValueUpdated = function(value)
    {
        parameters.searchGridSize = Math.round(value);
    };

    this.backgroundParameterStartingPoints_NC = new NumericControl(this);
    this.backgroundParameterStartingPoints_NC.real = true;
    this.backgroundParameterStartingPoints_NC.label.text = "Number of starting points: ";
    this.backgroundParameterStartingPoints_NC.toolTip = "The number of starting points that are used during the fast search.<br>" +
                                                        "The fast search needs multiple starting points in the image.<br>For this purpose, the image is divided in width x width sized regions." +
                                                        " The n best regions are selected as starting points.<br>This parameter defines the number of starting points that will be used.<br><br>" +
                                                        "<b>Usage:</b> <br>Increase this parameter to try more starting points to find a better background region, at the cost of higher computation time.<br>" +
                                                        "Decrease this parameter to try less starting points to find a less optimal background region which less computation time.<br><br>" +
                                                        "<b>Usage constraints:</b> <br>None.<br><br>" +
                                                        "<b>Default value:</b> <br>40.<br>This is normally sufficient to find a good enough background region while keeping the computation time low.<br>Increase this value, if the script has trouble finding a good background region.";
    this.backgroundParameterStartingPoints_NC.label.minWidth = constants.minLabelSize;
    this.backgroundParameterStartingPoints_NC.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.backgroundParameterStartingPoints_NC.setRange(1, 1000);
    this.backgroundParameterStartingPoints_NC.setPrecision(0);
    this.backgroundParameterStartingPoints_NC.setValue(parameters.startingPoints);
    this.backgroundParameterStartingPoints_NC.slider.minWidth = 200;
    this.backgroundParameterStartingPoints_NC.edit.minWidth = 50;
    this.backgroundParameterStartingPoints_NC.onValueUpdated = function(value)
    {
        parameters.startingPoints = Math.round(value);
    };

    this.printInformation_Chk = new CheckBox(this);
    this.printInformation_Chk.text = "Print information to the console";
    this.printInformation_Chk.checked = parameters.printInformation;
    this.printInformation_Chk.toolTip = "Print information about the background region to the console.<br><br>" +
                                       "<b>Usage:</b> <br>Enabling this option will print the channel brightnesses, additive color correction constants, coordinates and quality assessment parameters of the found background region to the console.<br>" +
                                       "Disabling will just print the current progress to the console, without information about the found region. <br><br>" +
                                       "<b>Usage constraints:</b> <br>None.<br><br>" +
                                       "<b>Default value:</b> <br>Enabled.<br>It is advisable to manually verify the quality of the found background region, the console output can help with that.";
    this.printInformation_Chk.onCheck = function(checked)
    {
        parameters.printInformation = checked;
    }

    this.generatePreview_Chk = new CheckBox(this);
    this.generatePreview_Chk.text = "Generate background preview";
    this.generatePreview_Chk.checked = parameters.generatePreview;
    this.generatePreview_Chk.toolTip = "Generate a preview of the found background region.<br><br>" +
                                       "<b>Usage:</b> <br>Enabling this option will create a preview of the found background region.<br>" +
                                        "Disabling this option will not create a preview of the found background region.<br><br>" +
                                        "<b>Usage constraints:</b> <br>None.<br><br>" +
                                        "<b>Default value:</b> <br>Enabled.<br>It is advisable to visually verify the quality of the found background region. Additionally, the preview can be used for further processing.";
    this.generatePreview_Chk.onCheck = (checked) =>
    {
        parameters.generatePreview = checked;
        parameters.previewName = checked ? parameters.previewName : "";
        this.previewName.enabled = checked;
    };

    this.previewName = new Edit(this);
    this.previewName.text = parameters.previewName;
    this.previewName.checked = parameters.generatePreview;
    this.previewName.toolTip = "The name of the preview that is generated.<br><br>" +
                               "<b>Usage:</b> <br>Set the name of the preview that is generated for the found background region.<br><br>" +
                               "<b>Usage constraints:</b> <br>This name is only used in case a preview is actually being generated.<br><br>" +
                               "<b>Default value:</b> <br>Background. <br>This is pretty self explanatory ;)";
    this.previewName.onTextUpdated = function(text)
    {
        parameters.previewName = text;
    }

    this.previewSizerHorizontal = new HorizontalSizer;
    this.previewSizerHorizontal.spacing = 6;
    this.previewSizerHorizontal.add(this.generatePreview_Chk);
    this.previewSizerHorizontal.add(this.previewName);

    this.removePreview_Btn = new PushButton(this);
    this.removePreview_Btn.text = "Remove previous preview";
    this.removePreview_Btn.toolTip = "Removes the previously generated preview with the currently selected name.<br><br>" +
                                     "<b>Usage:</b> <br>Click this button to remove the preview with the currently selected name.<br><br>" +
                                     "<b>Usage constraints:</b> <br>None.<br><br>" +
                                     "<b>Default value:</b> <br>Not applicable.";
    this.removePreview_Btn.onClick = function()
    {
        let window = parameters.targetWindow;
        let previews = window.previews;
        for (let i = 0; i < previews.length; i++)
        {
            if (previews[i].id == parameters.previewName)
            {
                window.deletePreview(previews[i]);
                break;
            }
        }
    };

    this.removePreview_Sizer = new HorizontalSizer;
    this.removePreview_Sizer.add(this.removePreview_Btn);
    this.removePreview_Sizer.addStretch();

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Search!";
    this.execute_Btn.toolTip = "Start the search for the background region with the selected parameters.";
    this.execute_Btn.onClick = function()
    {
        this.dialog.ok();
    };

    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 10;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.addStretch();
    this.buttonSizerHorizontal.add(this.execute_Btn);

    this.backgroundParameterSizerVertical = new VerticalSizer;
    this.backgroundParameterSizerVertical.spacing = 6;
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSize_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSpacingRate_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterSearchGridSize_NC);
    this.backgroundParameterSizerVertical.add(this.backgroundParameterStartingPoints_NC);

    this.backgroundParametersSizerHorizontal = new HorizontalSizer;
    this.backgroundParametersSizerHorizontal.addUnscaledSpacing(constants.indent);
    this.backgroundParametersSizerHorizontal.add(this.backgroundParameterSizerVertical);

    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.add(this.title_Lbl);
    this.sizer.addSpacing(10);
    this.sizer.add(this.conditions_Lbl);
    this.sizer.addSpacing(10);
    this.sizer.add(this.windowSelector_Cb);
    this.sizer.addSpacing(10);
    this.sizer.add(this.filterInformation_Lbl);
    this.sizer.add(this.filterSizerHorizontal);
    this.sizer.addSpacing(10);
    this.sizer.add(this.searchRoutine_Lbl);
    this.sizer.add(this.searchOptionsSizerHorizontal);
    this.sizer.addSpacing(10);
    this.sizer.add(this.backgroundRegionParameters_Lbl);
    this.sizer.add(this.backgroundParametersSizerHorizontal);
    this.sizer.addSpacing(10);
    this.sizer.add(this.printInformation_Chk);
    this.sizer.add(this.previewSizerHorizontal);
    this.sizer.add(this.removePreview_Sizer);
    this.sizer.addSpacing(10);
    this.sizer.add(this.buttonSizerHorizontal);

    this.windowTitle = "FindBackground";
}

FindBackgroundDialog.prototype = new Dialog;



function getFinderInstance()
{
    let window = ImageWindow.activeWindow;

    if (window.isNull)
    {
        console.show();
        console.criticalln("No active image window found. Please open an image and try again.");
        return null;
    }

    let finder = new FindBackground(parameters.size, parameters.spacingRate);
    finder.filterAverage = parameters.filterAvg;
    finder.filterStandardDeviation = parameters.filterSdev;
    finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
    finder.filterDisparityIndex = parameters.filterDisparityIndex;
    finder.filterForObjects = parameters.filterObjects;

    finder.setTarget(window);

    return finder;
}

function main()
{
    console.hide();

    if (Parameters.isGlobalTarget)
    {
        console.show();
        console.criticalln("FindBackground can only be executed on a single image and not in global context. Open an image and run the script again.");
        return false;
    }

    if (Parameters.isViewTarget)
    {
        parameters.load();

        let window = ImageWindow.activeWindow;
        if (window.isNull)
        {
            console.show();
            console.criticalln("No active image window found. Please open an image and try again.");
            return false;
        }

        let finder = new FindBackground(parameters.size, parameters.spacingRate);
        finder.filterAverage = parameters.filterAvg;
        finder.filterStandardDeviation = parameters.filterSdev;
        finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
        finder.filterDisparityIndex = parameters.filterDisparityIndex;
        finder.filterForObjects = parameters.filterObjects;

        finder.setTarget(window);

        if (parameters.slowSearch)
        {
            finder.searchBackground(parameters.printInformation, parameters.previewName);
            return false;
        }
        else if (parameters.fastSearch)
        {
            finder.fastSearchBackground(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName);
            return false;
        }
        else
        {
            console.criticalln("No search routine selected. Please select a search routine.");
            return false;
        }
    }
    else
    {
        let dialog = new FindBackgroundDialog();
        if (dialog.execute())
        {
            parameters.save();

            let window = ImageWindow.activeWindow;
            if (window.isNull)
            {
                console.show();
                console.criticalln("No active image window found. Please open an image and try again.");
                return false;
            }

            let finder = new FindBackground(parameters.size, parameters.spacingRate);
            finder.filterAverage = parameters.filterAvg;
            finder.filterStandardDeviation = parameters.filterSdev;
            finder.filterMedianAverageAbsoluteDifference = parameters.filterMAAD;
            finder.filterDisparityIndex = parameters.filterDisparityIndex;
            finder.filterForObjects = parameters.filterObjects;

            finder.setTarget(window);

            if (parameters.slowSearch)
            {
                finder.searchBackground(parameters.printInformation, parameters.previewName);
                return true;
            }
            else if (parameters.fastSearch)
            {
                finder.fastSearchBackground(parameters.searchGridSize, parameters.startingPoints, parameters.printInformation, parameters.previewName);
                return true;
            }
            else
            {
                console.criticalln("No search routine selected. Please select a search routine.");
                return false;
            }
        }
        else
        {
            console.show();
            console.writeln("FindBackground canceled.");
            return false;
        }
    }
}

while(main());
