#feature-id MaskMerge : SetiAstro > MaskMerge
#feature-info This script merges two masks using union, intersection, or subtraction operations.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Mask Merge
 * Version: 1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script merges two masks using union, intersection, or subtraction operations.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>

// include constants
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define TITLE "MaskMerge"
#define VERSION "1.0"
let WIDTH = 500;

var MaskMergeParameters = {
    mask1View: undefined,
    mask2View: undefined,
    mask3View: undefined,
    operation1: "",
    operation2: "",
    invertMask1: false,
    invertMask2: false,
    invertMask3: false,
    operations: [],

    save: function() {
        // Parameters.set("mask1View", this.mask1View ? this.mask1View.id : "");
        // Parameters.set("mask2View", this.mask2View ? this.mask2View.id : "");
        // Parameters.set("operations", this.operations.join(","));
    },

    load: function() {
        // if (Parameters.has("mask1View"))
        //     this.mask1View = ImageWindow.windowById(Parameters.getString("mask1View")).mainView;
        // if (Parameters.has("mask2View"))
        //     this.mask2View = ImageWindow.windowById(Parameters.getString("mask2View")).mainView;
        // if (Parameters.has("operations"))
        //     this.operations = Parameters.getString("operations").split(",");
    }
};

// ScrollControl class definition
function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function MaskMergeDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.userResizable = true;
    this.adjustToContents();
    this.scaledMinWidth = 450;

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 6;

    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;
    this.leftSizer.margin = 8;

    this.title = new TextBox(this);
    this.title.text = "<b>MaskMerge Tool v" + VERSION + "</b><br>Select masks and operations to merge them.";
    this.title.readOnly = true;
    this.title.backgroundColor = 0xf7f7f7;
    this.title.minHeight = 50;
    this.title.maxHeight = 50;
    this.leftSizer.add(this.title);

    this.instructions = new TextBox(this);
    this.instructions.text = "<p>- Choose the operations to perform on the masks and select the masks from the dropdown menus below. 3rd Mask is optional.</p>" +
                             "<p>- When using Subtraction ensure the broader mask (typically Range Mask) is in the upper dropdown of the two.</p>" +
                             "<p>- Example1: Add Mask 1 and Mask 2, then subtract Mask 3.</p>" +
                             "<p>- Example2: Intersect Mask 1 and Mask 2, then add Mask 3.</p>" +
                             "<p>- Example3: Since Union is technically Screening: Add Starless and Stars Only Image!";
    this.instructions.readOnly = true;
    this.instructions.backgroundColor = 0xD3D3D3;
    this.instructions.minHeight = 210;
    this.leftSizer.add(this.instructions);

    this.mask1Group = new HorizontalSizer;
    this.mask1Group.spacing = 4;

    this.mask1Label = new Label(this);
    this.mask1Label.text = "Mask 1 (Base):";
    this.mask1Group.add(this.mask1Label);

    this.mask1ViewList = new ViewList(this);
    this.mask1ViewList.getAll();
    this.mask1ViewList.maxWidth = WIDTH;

    // Set default to active window if there is an active window
    if (ImageWindow.activeWindow.mainView) {
        this.mask1ViewList.currentView = ImageWindow.activeWindow.mainView;
        MaskMergeParameters.mask1View = ImageWindow.activeWindow.mainView;
    }

    this.mask1ViewList.onViewSelected = function(view) {
        MaskMergeParameters.mask1View = view;
    };
    this.mask1ViewList.toolTip = "Select the first mask.";
    this.mask1Group.add(this.mask1ViewList, 100);

    this.mask1InvertCheckbox = new CheckBox(this);
    this.mask1InvertCheckbox.text = "Invert";
    this.mask1InvertCheckbox.toolTip = "Invert the first mask.";
    this.mask1InvertCheckbox.onCheck = function(checked) {
        MaskMergeParameters.invertMask1 = checked;
    };
    this.mask1Group.add(this.mask1InvertCheckbox);

    this.leftSizer.add(this.mask1Group);

    this.operationGroup1 = new HorizontalSizer;
    this.operationGroup1.spacing = 4;

    this.unionCheckbox1 = new CheckBox(this);
    this.unionCheckbox1.text = "Union (Add)";
    this.unionCheckbox1.toolTip = "Combine the two masks by adding (technically screening) them together.";
    this.unionCheckbox1.onCheck = function(checked) {
        if (checked) {
            this.intersectionCheckbox1.checked = false;
            this.subtractCheckbox1.checked = false;
            MaskMergeParameters.operation1 = "union";
        } else {
            MaskMergeParameters.operation1 = "";
        }
    }.bind(this);
    this.operationGroup1.add(this.unionCheckbox1);

    this.intersectionCheckbox1 = new CheckBox(this);
    this.intersectionCheckbox1.text = "Intersect";
    this.intersectionCheckbox1.toolTip = "Combine the two masks by taking their intersection.";
    this.intersectionCheckbox1.onCheck = function(checked) {
        if (checked) {
            this.unionCheckbox1.checked = false;
            this.subtractCheckbox1.checked = false;
            MaskMergeParameters.operation1 = "intersection";
        } else {
            MaskMergeParameters.operation1 = "";
        }
    }.bind(this);
    this.operationGroup1.add(this.intersectionCheckbox1);

    this.subtractCheckbox1 = new CheckBox(this);
    this.subtractCheckbox1.text = "Subtract";
    this.subtractCheckbox1.toolTip = "Subtract the second mask from the first mask.";
    this.subtractCheckbox1.onCheck = function(checked) {
        if (checked) {
            this.unionCheckbox1.checked = false;
            this.intersectionCheckbox1.checked = false;
            MaskMergeParameters.operation1 = "subtract";
        } else {
            MaskMergeParameters.operation1 = "";
        }
    }.bind(this);
    this.operationGroup1.add(this.subtractCheckbox1);

    this.leftSizer.add(this.operationGroup1);

    this.mask2Group = new HorizontalSizer;
    this.mask2Group.spacing = 4;

    this.mask2Label = new Label(this);
    this.mask2Label.text = "Mask 2:";
    this.mask2Group.add(this.mask2Label);

    this.mask2ViewList = new ViewList(this);
    this.mask2ViewList.getAll();
    this.mask2ViewList.maxWidth = WIDTH;
    this.mask2ViewList.onViewSelected = function(view) {
        MaskMergeParameters.mask2View = view;
    };
    this.mask2ViewList.toolTip = "Select the second mask.";
    this.mask2Group.add(this.mask2ViewList, 100);

    this.mask2InvertCheckbox = new CheckBox(this);
    this.mask2InvertCheckbox.text = "Invert";
    this.mask2InvertCheckbox.toolTip = "Invert the second mask.";
    this.mask2InvertCheckbox.onCheck = function(checked) {
        MaskMergeParameters.invertMask2 = checked;
    };
    this.mask2Group.add(this.mask2InvertCheckbox);

    this.leftSizer.add(this.mask2Group);

    this.operationGroup2 = new HorizontalSizer;
    this.operationGroup2.spacing = 4;

    this.unionCheckbox2 = new CheckBox(this);
    this.unionCheckbox2.text = "Union (Add)";
    this.unionCheckbox2.toolTip = "Combine the two masks by adding (technically screening) them together.";
    this.unionCheckbox2.onCheck = function(checked) {
        if (checked) {
            this.intersectionCheckbox2.checked = false;
            this.subtractCheckbox2.checked = false;
            MaskMergeParameters.operation2 = "union";
        } else {
            MaskMergeParameters.operation2 = "";
        }
    }.bind(this);
    this.operationGroup2.add(this.unionCheckbox2);

    this.intersectionCheckbox2 = new CheckBox(this);
    this.intersectionCheckbox2.text = "Intersect";
    this.intersectionCheckbox2.toolTip = "Combine the two masks by taking their intersection.";
    this.intersectionCheckbox2.onCheck = function(checked) {
        if (checked) {
            this.unionCheckbox2.checked = false;
            this.subtractCheckbox2.checked = false;
            MaskMergeParameters.operation2 = "intersection";
        } else {
            MaskMergeParameters.operation2 = "";
        }
    }.bind(this);
    this.operationGroup2.add(this.intersectionCheckbox2);

    this.subtractCheckbox2 = new CheckBox(this);
    this.subtractCheckbox2.text = "Subtract";
    this.subtractCheckbox2.toolTip = "Subtract the second mask from the first mask.";
    this.subtractCheckbox2.onCheck = function(checked) {
        if (checked) {
            this.unionCheckbox2.checked = false;
            this.intersectionCheckbox2.checked = false;
            MaskMergeParameters.operation2 = "subtract";
        } else {
            MaskMergeParameters.operation2 = "";
        }
    }.bind(this);
    this.operationGroup2.add(this.subtractCheckbox2);

    this.leftSizer.add(this.operationGroup2);

    this.mask3Group = new HorizontalSizer;
    this.mask3Group.spacing = 4;

    this.mask3Label = new Label(this);
    this.mask3Label.text = "Mask 3 (Optional):";
    this.mask3Group.add(this.mask3Label);

    this.mask3ViewList = new ViewList(this);
    this.mask3ViewList.getAll();
    this.mask3ViewList.maxWidth = WIDTH;
    this.mask3ViewList.onViewSelected = function(view) {
        MaskMergeParameters.mask3View = view;
    };
    this.mask3ViewList.toolTip = "Select the third mask.";
    this.mask3Group.add(this.mask3ViewList, 100);

    this.mask3InvertCheckbox = new CheckBox(this);
    this.mask3InvertCheckbox.text = "Invert";
    this.mask3InvertCheckbox.toolTip = "Invert the third mask.";
    this.mask3InvertCheckbox.onCheck = function(checked) {
        MaskMergeParameters.invertMask3 = checked;
    };
    this.mask3Group.add(this.mask3InvertCheckbox);

    this.leftSizer.add(this.mask3Group);

   // Add space above the preview button
   this.leftSizer.addSpacing(8);

   // Add Preview Button
   this.previewButton = new PushButton(this);
   this.previewButton.text = "Preview Combined Mask";
   this.previewButton.onClick = function() {
       this.previewControl.visible = true;
       this.performPreview();
   }.bind(this);
   this.previewButton.setFixedWidth(200); // Set the width of the button

   // Center the button using a HorizontalSizer
   this.previewButtonSizer = new HorizontalSizer;
   this.previewButtonSizer.addStretch(); // Add stretchable space to the left
   this.previewButtonSizer.add(this.previewButton); // Add the button
   this.previewButtonSizer.addStretch(); // Add stretchable space to the right

   this.leftSizer.add(this.previewButtonSizer); // Add the sizer to the main sizer


    // Create a preview control
    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(500);  // Set minimum width to avoid taking too much space
    this.previewControl.setMinHeight(500); // Set minimum height
    this.previewControl.visible = false;   // Hide preview control initially

    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "Written by Franklin Marek";
    this.authorshipLabel.textAlignment = TextAlign_Center;
    this.leftSizer.add(this.authorshipLabel);

    this.websiteLabel = new Label(this);
    this.websiteLabel.text = "www.setiastro.com";
    this.websiteLabel.textAlignment = TextAlign_Center;
    this.leftSizer.add(this.websiteLabel);

    this.buttons_Sizer = new HorizontalSizer;
    this.buttons_Sizer.spacing = 6;

    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = new Bitmap(":/process-interface/new-instance.png");
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = function() {
        MaskMergeParameters.save();
        this.dialog.newInstance();
    }.bind(this);
    this.buttons_Sizer.add(this.newInstanceButton);

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute - Generate My Mask!";
    this.executeButton.onClick = function() {
        this.dialog.ok();
    }.bind(this);
    this.buttons_Sizer.add(this.executeButton);

    this.leftSizer.add(this.buttons_Sizer);

    this.mainSizer.add(this.leftSizer);
    this.mainSizer.add(this.previewControl);

    this.sizer = this.mainSizer;

    this.adjustToContents();

    function updateOperations(operation, checked) {
        if (checked) {
            if (MaskMergeParameters.operations.indexOf(operation) === -1) {
                MaskMergeParameters.operations.push(operation);
            }
        } else {
            var index = MaskMergeParameters.operations.indexOf(operation);
            if (index !== -1) {
                MaskMergeParameters.operations.splice(index, 1);
            }
        }
    }
}

MaskMergeDialog.prototype = new Dialog;

MaskMergeDialog.prototype.performPreview = function() {
    // Merge Mask 1 and Mask 2 to create the intermediate image
    var intermediateMaskId = mergeMasks(
        MaskMergeParameters.operation1,
        MaskMergeParameters.mask1View.id,
        MaskMergeParameters.mask2View.id,
        MaskMergeParameters.invertMask1,
        MaskMergeParameters.invertMask2,
        true // Skip showing the image
    );

    // Merge the intermediate image with Mask 3 if Mask 3 is selected
    var finalMaskId = intermediateMaskId;
    if (MaskMergeParameters.mask3View && MaskMergeParameters.operation2) {
        finalMaskId = mergeMasks(
            MaskMergeParameters.operation2,
            intermediateMaskId,
            MaskMergeParameters.mask3View.id,
            false, // Ensure inversion is correctly applied
            MaskMergeParameters.invertMask3,
            true // Skip showing the image
        );
    }

    // Create the final preview image
    var finalImage = ImageWindow.windowById(finalMaskId).mainView.image;
    var previewImage = this.createPreviewImage(finalImage);
    this.previewControl.doUpdateImage(previewImage);
    this.previewControl.viewport.update();
    this.previewControl.visible = true;
    this.adjustToContents();

    // Ensure the final image is hidden from the user
    var finalWindow = ImageWindow.windowById(finalMaskId);
    if (finalWindow) finalWindow.hide();

    // Close all intermediate and final temporary images
    var intermediateWindow = ImageWindow.windowById(intermediateMaskId);
    if (intermediateWindow) intermediateWindow.forceClose();

    if (finalMaskId !== intermediateMaskId) {
        var finalIntermediateWindow = ImageWindow.windowById(finalMaskId);
        if (finalIntermediateWindow) finalIntermediateWindow.forceClose();
    }
};

// Function to merge masks with optional inversion
function mergeMasks(operation, mask1Id, mask2Id, invertMask1, invertMask2, skipShowingImage) {
    var mask1Expr = invertMask1 ? "~" + mask1Id : mask1Id;
    var mask2Expr = invertMask2 ? "~" + mask2Id : mask2Id;

    var P = new PixelMath;
    P.expression = getPixelMathExpression(operation, mask1Expr, mask2Expr);
    P.useSingleExpression = true;
    P.generateOutput = true;
    P.createNewImage = true;
    P.newImageId = mask1Id + "_" + operation + "_" + mask2Id;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.showNewImage = !skipShowingImage; // Show or hide the image
    P.executeOn(ImageWindow.windowById(mask1Id).mainView);
    Console.noteln("Mask " + operation + " operation completed successfully with " + mask1Id + " and " + mask2Id);
    return P.newImageId;
}

// Function to get PixelMath expression with optional inversion
function getPixelMathExpression(operation, mask1Expr, mask2Expr) {
    switch (operation) {
        case "union":
            return mask1Expr + " + " + mask2Expr + " - " + mask1Expr + " * " + mask2Expr;
        case "intersection":
            return mask1Expr + " * " + mask2Expr;
        case "subtract":
            return mask1Expr + " - " + mask2Expr;
        default:
            throw new Error("Invalid operation: " + operation);
    }
}

// Function to create preview image with IntegerResample
MaskMergeDialog.prototype.createPreviewImage = function(image) {
    var window = new ImageWindow(
        image.width, image.height, image.numberOfChannels, image.bitsPerSample, image.isReal, image.isColor
    );
    window.mainView.beginProcess(UndoFlag_NoSwapFile);
    window.mainView.image.assign(image);
    window.mainView.endProcess();

    var P = new IntegerResample;
    const previewWidth = 500;
    const widthScale = Math.floor(image.width / previewWidth);
    P.zoomFactor = -Math.max(widthScale, 1);
    P.executeOn(window.mainView);

    var resizedImage = new Image(window.mainView.image);
    window.forceClose();
    return resizedImage;
};


function main() {
    Console.show();

    if (Parameters.isGlobalTarget || Parameters.isViewTarget) {
        MaskMergeParameters.load();
    }

    var dialog = new MaskMergeDialog();
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");

    if (dialog.execute()) {
        if (!MaskMergeParameters.mask1View || !MaskMergeParameters.mask2View || !MaskMergeParameters.operation1) {
            Console.criticalln("Please ensure both masks are selected and the first operation is chosen.");
            return;
        }

        // Merge Mask 1 and Mask 2 to create the intermediate image
        var intermediateMaskId = mergeMasks(
            MaskMergeParameters.operation1,
            MaskMergeParameters.mask1View.id,
            MaskMergeParameters.mask2View.id,
            MaskMergeParameters.invertMask1,
            MaskMergeParameters.invertMask2,
            false // Show the image
        );

        // Merge the intermediate image with Mask 3 if Mask 3 is selected
        var finalMaskId = intermediateMaskId;
        if (MaskMergeParameters.mask3View && MaskMergeParameters.operation2) {
            finalMaskId = mergeMasks(
                MaskMergeParameters.operation2,
                intermediateMaskId,
                MaskMergeParameters.mask3View.id,
                false, // Ensure inversion is correctly applied
                MaskMergeParameters.invertMask3,
                false // Show the image
            );
        }

        // Hide the intermediate image if there is a final image
        if (finalMaskId !== intermediateMaskId) {
            var intermediateWindow = ImageWindow.windowById(intermediateMaskId);
            if (intermediateWindow) intermediateWindow.forceClose();
        }

    } else {
        Console.noteln("Mask Merge Dialog Closed.");
    }
}

main();
